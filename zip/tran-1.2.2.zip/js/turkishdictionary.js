(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
// turkishdictionary codings
var DICT = {
    350: '%DE', //Ş
    286: '%D0', //Ğ
    287: '%F0', //ğ
    351: '%FE', //ş
    305: '%FD', //ı
    304: '%DD', //İ
    252: '%FC', //ü
    220: '%DC', //Ü
    231: '%E7', //ç
    199: '%C7', //Ç
    246: '%F6', //ö
    244: '%F4', //ô
    214: '%D6', //Ö
    212: '%D4', //Ô
    251: '%FB', //û
    219: '%DB', //Û
    194: '%C2', //Â
    226: '%E2', //â
    39: '',  //'
};

module.exports = DICT;
},{}],2:[function(require,module,exports){
"use strict";

var _prototypeProperties = function (child, staticProps, instanceProps) {
  if (staticProps) Object.defineProperties(child, staticProps);
  if (instanceProps) Object.defineProperties(child.prototype, instanceProps);
};

/*
  Translation engine: http://www.turkishdictionary.net
  For translating turkish-russian and vice versa
*/
var CHAR_CODES = require("./char-codes-turk.js");

var TurkishDictionary = (function () {
  function TurkishDictionary() {
    this.host = "http://www.turkishdictionary.net/?word=%FC";
    this.path = "";
    this.protocol = "http";
    this.query = "&s=";
    this.TABLE_CLASS = "___mtt_translate_table";
    // this flag indicates that if translation was successful then publish it all over extension
    this.need_publish = true;
  }

  _prototypeProperties(TurkishDictionary, null, {
    search: {
      value: function search(data) {
        data.url = this.makeUrl(data.value);
        this.need_publish = false;
        return this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    translate: {
      value: function translate(data) {
        data.url = this.makeUrl(data.selectionText);
        this.need_publish = true;
        this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeUrl: {
      value: function makeUrl(text) {
        var text = this.getEncodedValue(text);
        return ["http://www.turkishdictionary.net/?word=", text].join("");
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    getEncodedValue: {


      // Replace special language characters to html codes
      value: function getEncodedValue(value) {
        // to find spec symbols we first encode them (raw search for that symbol doesn't wor)
        return this.makeStringTransferable(value);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeStringTransferable: {

      /** converting script from the turkishdict */
      value: function makeStringTransferable(inputText) {
        var text = "";
        if (inputText.length > 0) {
          text = inputText;
          for (var i = 0; i < text.length; i++) {
            if (CHAR_CODES[text.charCodeAt(i)]) {
              text = text.substring(0, i) + CHAR_CODES[text.charCodeAt(i)] + text.substring(i + 1, text.length);
            } else if (text.charAt(i) == " ") {
              // replace spaces
              text = text.substring(0, i) + "___" + text.substring(i + 1, text.length);
            }
          }
        }
        return text;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    request: {

      /*
        Request translation and run callback function
        passing translated result or error to callback
      */
      value: function request(opts) {
        console.log("start request");
        this.xhr = new XMLHttpRequest();
        this.xhr.onreadystatechange = this.onReadyStateChange.bind(this, opts);
        this.xhr.open("GET", opts.url, true);
        this.xhr.send();
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    onReadyStateChange: {
      value: function onReadyStateChange(opts, e) {
        var xhr = this.xhr;
        if (xhr.readyState < 4) {
          return;
        } else if (xhr.status != 200) {
          this.errorHandler(xhr);
          return opts.error && opts.error();
        } else if (xhr.readyState == 4) {
          var translation = this.successHandler(e.target.response);
          console.log("success turkish translate", translation);
          console.log("call", opts.success);
          return opts.success && opts.success(translation);
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    successHandler: {
      value: function successHandler(response) {
        var data = this.parse(response);
        if (this.need_publish) {
          chrome.tabs.getSelected(null, this.publishTranslation.bind(this, data));
        }
        return data;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    publishTranslation: {

      /* publish successfuly translated text all over extension */
      value: function publishTranslation(translation, tab) {
        console.log("publish translation");
        chrome.tabs.sendMessage(tab.id, {
          action: this.tooltipAction(translation),
          data: translation.outerHTML,
          success: !translation.classList.contains("failTranslate")
        });
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    tooltipAction: {
      value: function tooltipAction(translation) {
        if (translation.textContent.trim().indexOf("was not found in our dictionary") != -1) {
          console.log("similar words");
          return "similar_words";
        } else {
          console.log("open tooltip");
          return "open_tooltip";
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    errorHandler: {
      value: function errorHandler(response) {
        console.log("error ajax", response);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parse: {

      /* Parse response from translation engine */
      value: function parse(response, silent, translate) {
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);
        if (fragment) {
          translate = fragment.querySelector("#meaning_div > table");
          if (translate) {
            translate.className = this.TABLE_CLASS;
            translate.setAttribute("cellpadding", "5");
            // @fixImages(translate)
            // @fixLinks(translate)
          } else if (!silent) {
            translate = document.createElement("div");
            translate.className = "failTranslate";
            translate.innerText = "Unfortunately, could not translate";
          }
        }
        return translate;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parseText: {

      /** parsing of terrible html markup */
      value: function parseText(response, silent, translate) {
        var _this = this;
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);

        if (fragment) {
          var i;
          var _ret = (function () {
            var stopIndex = null;
            var tr = fragment.querySelectorAll("#meaning_div>table>tbody>tr");
            tr = Array.prototype.slice.call(tr);

            var trans = tr.filter(function (tr, index) {
              if (!isNaN(parseInt(stopIndex, 10)) && index >= stopIndex) {
                return;
              } else {
                tr = $(tr);
                // take every row before next section (which is English->English)
                if (tr.attr("bgcolor") == "e0e6ff") {
                  stopIndex = index;return;
                } else {
                  return $.trim(tr.find("td").text()).length;
                }
              }
            });
            trans = trans.slice(1, trans.length - 1);
            trans = trans.filter(function (el, indx) {
              return indx % 2;
            });
            var frag = _this.fragmentFromList(trans);
            var fonts = frag.querySelectorAll("font");
            var text = "";
            for (i = 0; i < fonts.length; i++) {
              text += " " + fonts[i].textContent.trim();
            }
            return {
              v: text
            };
          })();

          if (typeof _ret === "object") return _ret.v;
        } else {
          throw "HTML fragment could not be parsed";
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    stripScripts: {

      //TODO extract to base engine class
      /* removes <script> tags from html code */
      value: function stripScripts(html) {
        var div = document.createElement("div");
        div.innerHTML = html;
        var scripts = div.getElementsByTagName("script");
        var i = scripts.length;
        while (i--) scripts[i].parentNode.removeChild(scripts[i]);
        return div.innerHTML;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeFragment: {

      //TODO extract to base engine class
      /* creates temp object to parse translation from page 
        (since it's not a friendly api) 
      */
      value: function makeFragment(html) {
        var fragment = document.createDocumentFragment(),
            div = document.createElement("div");
        div.innerHTML = html;
        while (div.firstChild) {
          fragment.appendChild(div.firstChild);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    fragmentFromList: {

      /** create fragment from list of DOM elements */
      value: function fragmentFromList(list) {
        var fragment = document.createDocumentFragment(),
            len = list.length;
        while (len--) {
          fragment.appendChild(list[len]);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    }
  });

  return TurkishDictionary;
})();

// Singletone
module.exports = new TurkishDictionary();
},{"./char-codes-turk.js":1}]},{},[2])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvY2hhci1jb2Rlcy10dXJrLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy90dXJraXNoZGljdGlvbmFyeS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN2QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKX12YXIgZj1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwoZi5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxmLGYuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiLy8gdHVya2lzaGRpY3Rpb25hcnkgY29kaW5nc1xudmFyIERJQ1QgPSB7XG4gICAgMzUwOiAnJURFJywgLy/FnlxuICAgIDI4NjogJyVEMCcsIC8vxJ5cbiAgICAyODc6ICclRjAnLCAvL8SfXG4gICAgMzUxOiAnJUZFJywgLy/Fn1xuICAgIDMwNTogJyVGRCcsIC8vxLFcbiAgICAzMDQ6ICclREQnLCAvL8SwXG4gICAgMjUyOiAnJUZDJywgLy/DvFxuICAgIDIyMDogJyVEQycsIC8vw5xcbiAgICAyMzE6ICclRTcnLCAvL8OnXG4gICAgMTk5OiAnJUM3JywgLy/Dh1xuICAgIDI0NjogJyVGNicsIC8vw7ZcbiAgICAyNDQ6ICclRjQnLCAvL8O0XG4gICAgMjE0OiAnJUQ2JywgLy/DllxuICAgIDIxMjogJyVENCcsIC8vw5RcbiAgICAyNTE6ICclRkInLCAvL8O7XG4gICAgMjE5OiAnJURCJywgLy/Dm1xuICAgIDE5NDogJyVDMicsIC8vw4JcbiAgICAyMjY6ICclRTInLCAvL8OiXG4gICAgMzk6ICcnLCAgLy8nXG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IERJQ1Q7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbnZhciBfcHJvdG90eXBlUHJvcGVydGllcyA9IGZ1bmN0aW9uIChjaGlsZCwgc3RhdGljUHJvcHMsIGluc3RhbmNlUHJvcHMpIHtcbiAgaWYgKHN0YXRpY1Byb3BzKSBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhjaGlsZCwgc3RhdGljUHJvcHMpO1xuICBpZiAoaW5zdGFuY2VQcm9wcykgT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoY2hpbGQucHJvdG90eXBlLCBpbnN0YW5jZVByb3BzKTtcbn07XG5cbi8qXG4gIFRyYW5zbGF0aW9uIGVuZ2luZTogaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXRcbiAgRm9yIHRyYW5zbGF0aW5nIHR1cmtpc2gtcnVzc2lhbiBhbmQgdmljZSB2ZXJzYVxuKi9cbnZhciBDSEFSX0NPREVTID0gcmVxdWlyZShcIi4vY2hhci1jb2Rlcy10dXJrLmpzXCIpO1xuXG52YXIgVHVya2lzaERpY3Rpb25hcnkgPSAoZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBUdXJraXNoRGljdGlvbmFyeSgpIHtcbiAgICB0aGlzLmhvc3QgPSBcImh0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0Lz93b3JkPSVGQ1wiO1xuICAgIHRoaXMucGF0aCA9IFwiXCI7XG4gICAgdGhpcy5wcm90b2NvbCA9IFwiaHR0cFwiO1xuICAgIHRoaXMucXVlcnkgPSBcIiZzPVwiO1xuICAgIHRoaXMuVEFCTEVfQ0xBU1MgPSBcIl9fX210dF90cmFuc2xhdGVfdGFibGVcIjtcbiAgICAvLyB0aGlzIGZsYWcgaW5kaWNhdGVzIHRoYXQgaWYgdHJhbnNsYXRpb24gd2FzIHN1Y2Nlc3NmdWwgdGhlbiBwdWJsaXNoIGl0IGFsbCBvdmVyIGV4dGVuc2lvblxuICAgIHRoaXMubmVlZF9wdWJsaXNoID0gdHJ1ZTtcbiAgfVxuXG4gIF9wcm90b3R5cGVQcm9wZXJ0aWVzKFR1cmtpc2hEaWN0aW9uYXJ5LCBudWxsLCB7XG4gICAgc2VhcmNoOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gc2VhcmNoKGRhdGEpIHtcbiAgICAgICAgZGF0YS51cmwgPSB0aGlzLm1ha2VVcmwoZGF0YS52YWx1ZSk7XG4gICAgICAgIHRoaXMubmVlZF9wdWJsaXNoID0gZmFsc2U7XG4gICAgICAgIHJldHVybiB0aGlzLnJlcXVlc3QoZGF0YSk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICB0cmFuc2xhdGU6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiB0cmFuc2xhdGUoZGF0YSkge1xuICAgICAgICBkYXRhLnVybCA9IHRoaXMubWFrZVVybChkYXRhLnNlbGVjdGlvblRleHQpO1xuICAgICAgICB0aGlzLm5lZWRfcHVibGlzaCA9IHRydWU7XG4gICAgICAgIHRoaXMucmVxdWVzdChkYXRhKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIG1ha2VVcmw6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlVXJsKHRleHQpIHtcbiAgICAgICAgdmFyIHRleHQgPSB0aGlzLmdldEVuY29kZWRWYWx1ZSh0ZXh0KTtcbiAgICAgICAgcmV0dXJuIFtcImh0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0Lz93b3JkPVwiLCB0ZXh0XS5qb2luKFwiXCIpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgZ2V0RW5jb2RlZFZhbHVlOiB7XG5cblxuICAgICAgLy8gUmVwbGFjZSBzcGVjaWFsIGxhbmd1YWdlIGNoYXJhY3RlcnMgdG8gaHRtbCBjb2Rlc1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIGdldEVuY29kZWRWYWx1ZSh2YWx1ZSkge1xuICAgICAgICAvLyB0byBmaW5kIHNwZWMgc3ltYm9scyB3ZSBmaXJzdCBlbmNvZGUgdGhlbSAocmF3IHNlYXJjaCBmb3IgdGhhdCBzeW1ib2wgZG9lc24ndCB3b3IpXG4gICAgICAgIHJldHVybiB0aGlzLm1ha2VTdHJpbmdUcmFuc2ZlcmFibGUodmFsdWUpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgbWFrZVN0cmluZ1RyYW5zZmVyYWJsZToge1xuXG4gICAgICAvKiogY29udmVydGluZyBzY3JpcHQgZnJvbSB0aGUgdHVya2lzaGRpY3QgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlU3RyaW5nVHJhbnNmZXJhYmxlKGlucHV0VGV4dCkge1xuICAgICAgICB2YXIgdGV4dCA9IFwiXCI7XG4gICAgICAgIGlmIChpbnB1dFRleHQubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHRleHQgPSBpbnB1dFRleHQ7XG4gICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0ZXh0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoQ0hBUl9DT0RFU1t0ZXh0LmNoYXJDb2RlQXQoaSldKSB7XG4gICAgICAgICAgICAgIHRleHQgPSB0ZXh0LnN1YnN0cmluZygwLCBpKSArIENIQVJfQ09ERVNbdGV4dC5jaGFyQ29kZUF0KGkpXSArIHRleHQuc3Vic3RyaW5nKGkgKyAxLCB0ZXh0Lmxlbmd0aCk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHRleHQuY2hhckF0KGkpID09IFwiIFwiKSB7XG4gICAgICAgICAgICAgIC8vIHJlcGxhY2Ugc3BhY2VzXG4gICAgICAgICAgICAgIHRleHQgPSB0ZXh0LnN1YnN0cmluZygwLCBpKSArIFwiX19fXCIgKyB0ZXh0LnN1YnN0cmluZyhpICsgMSwgdGV4dC5sZW5ndGgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGV4dDtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHJlcXVlc3Q6IHtcblxuICAgICAgLypcbiAgICAgICAgUmVxdWVzdCB0cmFuc2xhdGlvbiBhbmQgcnVuIGNhbGxiYWNrIGZ1bmN0aW9uXG4gICAgICAgIHBhc3NpbmcgdHJhbnNsYXRlZCByZXN1bHQgb3IgZXJyb3IgdG8gY2FsbGJhY2tcbiAgICAgICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gcmVxdWVzdChvcHRzKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwic3RhcnQgcmVxdWVzdFwiKTtcbiAgICAgICAgdGhpcy54aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgICAgdGhpcy54aHIub25yZWFkeXN0YXRlY2hhbmdlID0gdGhpcy5vblJlYWR5U3RhdGVDaGFuZ2UuYmluZCh0aGlzLCBvcHRzKTtcbiAgICAgICAgdGhpcy54aHIub3BlbihcIkdFVFwiLCBvcHRzLnVybCwgdHJ1ZSk7XG4gICAgICAgIHRoaXMueGhyLnNlbmQoKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIG9uUmVhZHlTdGF0ZUNoYW5nZToge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIG9uUmVhZHlTdGF0ZUNoYW5nZShvcHRzLCBlKSB7XG4gICAgICAgIHZhciB4aHIgPSB0aGlzLnhocjtcbiAgICAgICAgaWYgKHhoci5yZWFkeVN0YXRlIDwgNCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSBlbHNlIGlmICh4aHIuc3RhdHVzICE9IDIwMCkge1xuICAgICAgICAgIHRoaXMuZXJyb3JIYW5kbGVyKHhocik7XG4gICAgICAgICAgcmV0dXJuIG9wdHMuZXJyb3IgJiYgb3B0cy5lcnJvcigpO1xuICAgICAgICB9IGVsc2UgaWYgKHhoci5yZWFkeVN0YXRlID09IDQpIHtcbiAgICAgICAgICB2YXIgdHJhbnNsYXRpb24gPSB0aGlzLnN1Y2Nlc3NIYW5kbGVyKGUudGFyZ2V0LnJlc3BvbnNlKTtcbiAgICAgICAgICBjb25zb2xlLmxvZyhcInN1Y2Nlc3MgdHVya2lzaCB0cmFuc2xhdGVcIiwgdHJhbnNsYXRpb24pO1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwiY2FsbFwiLCBvcHRzLnN1Y2Nlc3MpO1xuICAgICAgICAgIHJldHVybiBvcHRzLnN1Y2Nlc3MgJiYgb3B0cy5zdWNjZXNzKHRyYW5zbGF0aW9uKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgc3VjY2Vzc0hhbmRsZXI6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBzdWNjZXNzSGFuZGxlcihyZXNwb25zZSkge1xuICAgICAgICB2YXIgZGF0YSA9IHRoaXMucGFyc2UocmVzcG9uc2UpO1xuICAgICAgICBpZiAodGhpcy5uZWVkX3B1Ymxpc2gpIHtcbiAgICAgICAgICBjaHJvbWUudGFicy5nZXRTZWxlY3RlZChudWxsLCB0aGlzLnB1Ymxpc2hUcmFuc2xhdGlvbi5iaW5kKHRoaXMsIGRhdGEpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZGF0YTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHB1Ymxpc2hUcmFuc2xhdGlvbjoge1xuXG4gICAgICAvKiBwdWJsaXNoIHN1Y2Nlc3NmdWx5IHRyYW5zbGF0ZWQgdGV4dCBhbGwgb3ZlciBleHRlbnNpb24gKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBwdWJsaXNoVHJhbnNsYXRpb24odHJhbnNsYXRpb24sIHRhYikge1xuICAgICAgICBjb25zb2xlLmxvZyhcInB1Ymxpc2ggdHJhbnNsYXRpb25cIik7XG4gICAgICAgIGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhYi5pZCwge1xuICAgICAgICAgIGFjdGlvbjogdGhpcy50b29sdGlwQWN0aW9uKHRyYW5zbGF0aW9uKSxcbiAgICAgICAgICBkYXRhOiB0cmFuc2xhdGlvbi5vdXRlckhUTUwsXG4gICAgICAgICAgc3VjY2VzczogIXRyYW5zbGF0aW9uLmNsYXNzTGlzdC5jb250YWlucyhcImZhaWxUcmFuc2xhdGVcIilcbiAgICAgICAgfSk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICB0b29sdGlwQWN0aW9uOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gdG9vbHRpcEFjdGlvbih0cmFuc2xhdGlvbikge1xuICAgICAgICBpZiAodHJhbnNsYXRpb24udGV4dENvbnRlbnQudHJpbSgpLmluZGV4T2YoXCJ3YXMgbm90IGZvdW5kIGluIG91ciBkaWN0aW9uYXJ5XCIpICE9IC0xKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJzaW1pbGFyIHdvcmRzXCIpO1xuICAgICAgICAgIHJldHVybiBcInNpbWlsYXJfd29yZHNcIjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIm9wZW4gdG9vbHRpcFwiKTtcbiAgICAgICAgICByZXR1cm4gXCJvcGVuX3Rvb2x0aXBcIjtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgZXJyb3JIYW5kbGVyOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gZXJyb3JIYW5kbGVyKHJlc3BvbnNlKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiZXJyb3IgYWpheFwiLCByZXNwb25zZSk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBwYXJzZToge1xuXG4gICAgICAvKiBQYXJzZSByZXNwb25zZSBmcm9tIHRyYW5zbGF0aW9uIGVuZ2luZSAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHBhcnNlKHJlc3BvbnNlLCBzaWxlbnQsIHRyYW5zbGF0ZSkge1xuICAgICAgICB2YXIgZG9jID0gdGhpcy5zdHJpcFNjcmlwdHMocmVzcG9uc2UpLFxuICAgICAgICAgICAgZnJhZ21lbnQgPSB0aGlzLm1ha2VGcmFnbWVudChkb2MpO1xuICAgICAgICBpZiAoZnJhZ21lbnQpIHtcbiAgICAgICAgICB0cmFuc2xhdGUgPSBmcmFnbWVudC5xdWVyeVNlbGVjdG9yKFwiI21lYW5pbmdfZGl2ID4gdGFibGVcIik7XG4gICAgICAgICAgaWYgKHRyYW5zbGF0ZSkge1xuICAgICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9IHRoaXMuVEFCTEVfQ0xBU1M7XG4gICAgICAgICAgICB0cmFuc2xhdGUuc2V0QXR0cmlidXRlKFwiY2VsbHBhZGRpbmdcIiwgXCI1XCIpO1xuICAgICAgICAgICAgLy8gQGZpeEltYWdlcyh0cmFuc2xhdGUpXG4gICAgICAgICAgICAvLyBAZml4TGlua3ModHJhbnNsYXRlKVxuICAgICAgICAgIH0gZWxzZSBpZiAoIXNpbGVudCkge1xuICAgICAgICAgICAgdHJhbnNsYXRlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSBcImZhaWxUcmFuc2xhdGVcIjtcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5pbm5lclRleHQgPSBcIlVuZm9ydHVuYXRlbHksIGNvdWxkIG5vdCB0cmFuc2xhdGVcIjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRyYW5zbGF0ZTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHBhcnNlVGV4dDoge1xuXG4gICAgICAvKiogcGFyc2luZyBvZiB0ZXJyaWJsZSBodG1sIG1hcmt1cCAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHBhcnNlVGV4dChyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgdmFyIGRvYyA9IHRoaXMuc3RyaXBTY3JpcHRzKHJlc3BvbnNlKSxcbiAgICAgICAgICAgIGZyYWdtZW50ID0gdGhpcy5tYWtlRnJhZ21lbnQoZG9jKTtcblxuICAgICAgICBpZiAoZnJhZ21lbnQpIHtcbiAgICAgICAgICB2YXIgaTtcbiAgICAgICAgICB2YXIgX3JldCA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgc3RvcEluZGV4ID0gbnVsbDtcbiAgICAgICAgICAgIHZhciB0ciA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIjbWVhbmluZ19kaXY+dGFibGU+dGJvZHk+dHJcIik7XG4gICAgICAgICAgICB0ciA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKHRyKTtcblxuICAgICAgICAgICAgdmFyIHRyYW5zID0gdHIuZmlsdGVyKGZ1bmN0aW9uICh0ciwgaW5kZXgpIHtcbiAgICAgICAgICAgICAgaWYgKCFpc05hTihwYXJzZUludChzdG9wSW5kZXgsIDEwKSkgJiYgaW5kZXggPj0gc3RvcEluZGV4KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRyID0gJCh0cik7XG4gICAgICAgICAgICAgICAgLy8gdGFrZSBldmVyeSByb3cgYmVmb3JlIG5leHQgc2VjdGlvbiAod2hpY2ggaXMgRW5nbGlzaC0+RW5nbGlzaClcbiAgICAgICAgICAgICAgICBpZiAodHIuYXR0cihcImJnY29sb3JcIikgPT0gXCJlMGU2ZmZcIikge1xuICAgICAgICAgICAgICAgICAgc3RvcEluZGV4ID0gaW5kZXg7cmV0dXJuO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gJC50cmltKHRyLmZpbmQoXCJ0ZFwiKS50ZXh0KCkpLmxlbmd0aDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdHJhbnMgPSB0cmFucy5zbGljZSgxLCB0cmFucy5sZW5ndGggLSAxKTtcbiAgICAgICAgICAgIHRyYW5zID0gdHJhbnMuZmlsdGVyKGZ1bmN0aW9uIChlbCwgaW5keCkge1xuICAgICAgICAgICAgICByZXR1cm4gaW5keCAlIDI7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHZhciBmcmFnID0gX3RoaXMuZnJhZ21lbnRGcm9tTGlzdCh0cmFucyk7XG4gICAgICAgICAgICB2YXIgZm9udHMgPSBmcmFnLnF1ZXJ5U2VsZWN0b3JBbGwoXCJmb250XCIpO1xuICAgICAgICAgICAgdmFyIHRleHQgPSBcIlwiO1xuICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IGZvbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgIHRleHQgKz0gXCIgXCIgKyBmb250c1tpXS50ZXh0Q29udGVudC50cmltKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICB2OiB0ZXh0XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH0pKCk7XG5cbiAgICAgICAgICBpZiAodHlwZW9mIF9yZXQgPT09IFwib2JqZWN0XCIpIHJldHVybiBfcmV0LnY7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhyb3cgXCJIVE1MIGZyYWdtZW50IGNvdWxkIG5vdCBiZSBwYXJzZWRcIjtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgc3RyaXBTY3JpcHRzOiB7XG5cbiAgICAgIC8vVE9ETyBleHRyYWN0IHRvIGJhc2UgZW5naW5lIGNsYXNzXG4gICAgICAvKiByZW1vdmVzIDxzY3JpcHQ+IHRhZ3MgZnJvbSBodG1sIGNvZGUgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBzdHJpcFNjcmlwdHMoaHRtbCkge1xuICAgICAgICB2YXIgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgZGl2LmlubmVySFRNTCA9IGh0bWw7XG4gICAgICAgIHZhciBzY3JpcHRzID0gZGl2LmdldEVsZW1lbnRzQnlUYWdOYW1lKFwic2NyaXB0XCIpO1xuICAgICAgICB2YXIgaSA9IHNjcmlwdHMubGVuZ3RoO1xuICAgICAgICB3aGlsZSAoaS0tKSBzY3JpcHRzW2ldLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc2NyaXB0c1tpXSk7XG4gICAgICAgIHJldHVybiBkaXYuaW5uZXJIVE1MO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgbWFrZUZyYWdtZW50OiB7XG5cbiAgICAgIC8vVE9ETyBleHRyYWN0IHRvIGJhc2UgZW5naW5lIGNsYXNzXG4gICAgICAvKiBjcmVhdGVzIHRlbXAgb2JqZWN0IHRvIHBhcnNlIHRyYW5zbGF0aW9uIGZyb20gcGFnZSBcbiAgICAgICAgKHNpbmNlIGl0J3Mgbm90IGEgZnJpZW5kbHkgYXBpKSBcbiAgICAgICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZUZyYWdtZW50KGh0bWwpIHtcbiAgICAgICAgdmFyIGZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpLFxuICAgICAgICAgICAgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgZGl2LmlubmVySFRNTCA9IGh0bWw7XG4gICAgICAgIHdoaWxlIChkaXYuZmlyc3RDaGlsZCkge1xuICAgICAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKGRpdi5maXJzdENoaWxkKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBmcmFnbWVudEZyb21MaXN0OiB7XG5cbiAgICAgIC8qKiBjcmVhdGUgZnJhZ21lbnQgZnJvbSBsaXN0IG9mIERPTSBlbGVtZW50cyAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIGZyYWdtZW50RnJvbUxpc3QobGlzdCkge1xuICAgICAgICB2YXIgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCksXG4gICAgICAgICAgICBsZW4gPSBsaXN0Lmxlbmd0aDtcbiAgICAgICAgd2hpbGUgKGxlbi0tKSB7XG4gICAgICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQobGlzdFtsZW5dKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfVxuICB9KTtcblxuICByZXR1cm4gVHVya2lzaERpY3Rpb25hcnk7XG59KSgpO1xuXG4vLyBTaW5nbGV0b25lXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBUdXJraXNoRGljdGlvbmFyeSgpOyJdfQ==
