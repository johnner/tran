(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
/* global chrome */
/*
 Script embedded on each user page
 Listens messages from translation module and renders popup
 with translated text
*/
"use strict";

require("../polyfills/Array.from.js");

var View = require('./view.js');
var content = new View();
//# sourceMappingURL=content.js.map

},{"../polyfills/Array.from.js":4,"./view.js":3}],2:[function(require,module,exports){
// TODO вынести настройки подключения в settings.js
//var HOST = 'http://tran-service.com'
'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var HOST = 'http://localhost:5000';

var TOOLTIP_CLASS_PREFIX = '__mtt_translate_dialog__';
var ctrlDown = false;
var ctrlKey = 17;
var cmdKey = 91;
var cKey = 67;
var add_title = 'Добавить в персональный словарь';

var _ = require('../utils.js');

var Tooltip = (function () {
  function Tooltip(coordinates) {
    _classCallCheck(this, Tooltip);

    this.setListeners();
    this.clickTarget = null;
  }

  _createClass(Tooltip, [{
    key: 'createEl',
    value: function createEl(storage) {
      this.el = document.createElement('div');
      this.memorizeButton = this.createMemoBtn();
      this.elContainer = this.createContainer();
      this.el.appendChild(this.memorizeButton);
      this.el.appendChild(this.elContainer);
      this.el.classList.add(TOOLTIP_CLASS_PREFIX);
      this.addListeners();
    }
  }, {
    key: 'addListeners',
    value: function addListeners() {
      this.el.addEventListener('mousedown', function (e) {
        return e.stopPropagation();
      });
      this.el.addEventListener('keydown', this.onKeyDown);
      this.memorizeButton.addEventListener('click', this.memoClick);
    }
  }, {
    key: 'createMemoBtn',
    value: function createMemoBtn() {
      var t = document.createElement('template');
      var tmpl = '<a title="' + add_title + '"\n                   class="btn-floating waves-effect waves-light blue word-add">\n                  <i class="material-icons">+</i>\n                </a>';
      t.innerHTML = tmpl;
      return t.content;
    }
  }, {
    key: 'memoClick',
    value: function memoClick(e) {
      e.stopPropagation();
      e.preventDefault();
      _.post(HOST + '/api/plugin/add_word/', { data: 'blabla' });
    }
  }, {
    key: 'createContainer',
    value: function createContainer() {
      var docFragment = document.createDocumentFragment();
      var container = document.createElement('div');
      container.classList.add(TOOLTIP_CLASS_PREFIX + 'container');
      return container;
    }
  }, {
    key: 'onKeyDown',
    value: function onKeyDown(e) {
      if (ctrlDown && (e.keyCode == vKey || e.keyCode == cKey)) {
        e.stopPropagation();
        return true;
      }
    }
  }, {
    key: 'setListeners',
    value: function setListeners() {
      var _this = this;

      window.addEventListener('mousedown', function (e) {
        return _this.destroy(e);
      });
      document.addEventListener('mousedown', function (e) {
        return _this.destroy(e);
      });
      window.addEventListener('blur', function (e) {
        return _this.destroy(e);
      });
      document.addEventListener('keydown', function (e) {
        return _this.keydown(e);
      });
      document.addEventListener('keyup', function (e) {
        return _this.keyup(e);
      });
    }
  }, {
    key: 'render',
    value: function render(data) {
      var transform = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];

      if (!this.el) {
        this.createEl();
      }
      this.checkMemorize();
      this.elContainer.innerHTML = data;
      if (transform) {
        transform(this.el);
      }
      this.el.style.left = this.coordinates.mouseX + 'px';
      this.el.style.top = this.coordinates.mouseY + 'px';
      document.body.appendChild(this.el);
    }
  }, {
    key: 'checkMemorize',
    value: function checkMemorize() {
      var self = this;
      chrome.storage.sync.get({ memorize: false, auth_token: null }, function (storage) {
        if (storage.memorize && storage.auth_token) {
          self.el.classList.add('memorize');
        } else {
          self.el.classList.remove('memorize');
        }
      });
    }
  }, {
    key: 'keydown',
    value: function keydown(e) {
      if (e.keyCode == ctrlKey || e.keyCode == cmdKey) {
        ctrlDown = true;
      }
      if (ctrlDown && (e.keyCode == ctrlKey || e.keyCode == cKey || e.keyCode == cmdKey)) {
        return true;
      } else {
        this.destroy(e);
      }
    }
  }, {
    key: 'keyup',
    value: function keyup(e) {
      if (e.keyCode == ctrlKey) {
        ctrlDown = false;
      }
    }
  }, {
    key: 'destroy',
    value: function destroy(e) {
      if (this.el && this.el.parentNode == document.body) {
        document.body.removeChild(this.el);
        this.el = null;
        this.clickTarget = null; // reset click target
      }
    }
  }, {
    key: 'setCoordinates',
    value: function setCoordinates(coordinates) {
      this.coordinates = coordinates;
    }
  }]);

  return Tooltip;
})();

module.exports = Tooltip;
//# sourceMappingURL=tooltip.js.map

},{"../utils.js":5}],3:[function(require,module,exports){
'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var Tooltip = require('./tooltip.js');
var TEXTBOX_TAGS = ['input', 'textarea'];

var Main = (function () {
  function Main() {
    _classCallCheck(this, Main);

    this.addEventListeners();
    this.coordinates = { mouseX: 0, mouseY: 0 };
    this.tooltip = new Tooltip(this.coordinates);
    chrome.runtime.onMessage.addListener(this.renderResult.bind(this));
  }

  _createClass(Main, [{
    key: 'addEventListeners',
    value: function addEventListeners() {
      var _this = this;

      window.addEventListener('mousedown', function (e) {
        return _this.mouseDownEvent(e);
      });
      document.addEventListener('mousedown', function (e) {
        return _this.mouseDownEvent(e);
      });
      window.addEventListener('mouseup', function (e) {
        return _this.mouseUpEvent(e);
      });
      document.addEventListener('contextmenu', function (e) {
        return _this.saveMousePosition(e);
      });
    }
  }, {
    key: 'renderResult',
    value: function renderResult(msg) {
      if (msg.action == 'open_tooltip' || msg.action == 'similar_words') {
        //don't show annoying tooltip when typing
        if (!msg.success && this.tooltip.clickTarget == 'textbox') {
          return;
        } else if (msg.action == 'similar_words') {
          this.tooltip.render(msg.data, this.attachSimilarWordsHandlers.bind(this));
        } else {
          this.tooltip.render(msg.data);
        }
      }
    }
  }, {
    key: 'requestSearch',
    value: function requestSearch(selection) {
      chrome.runtime.sendMessage({
        method: "request_search",
        data: {
          selectionText: selection
        }
      });
    }
  }, {
    key: 'saveMousePosition',
    value: function saveMousePosition(e) {
      this.coordinates.mouseX = e.pageX + 5;
      this.coordinates.mouseY = e.pageY + 10;
      this.tooltip.setCoordinates(this.coordinates);
    }
  }, {
    key: 'mouseDownEvent',
    value: function mouseDownEvent(e) {
      var tag = e.target.tagName.toLowerCase();
      if (TEXTBOX_TAGS.indexOf(tag) != -1) {
        this.tooltip.clickTarget = 'textbox';
      }
    }
  }, {
    key: 'mouseUpEvent',
    value: function mouseUpEvent(e) {
      // fix for accidental tooltip appearance when clicked on text
      setTimeout(this.clickHandler.bind(this, e), 10);
      return true;
    }
  }, {
    key: 'clickHandler',
    value: function clickHandler(e) {
      this.saveMousePosition(e);
      var selection = this.getSelection();
      var self = this;
      if (selection.length > 0) {
        chrome.storage.sync.get({ fast: true }, function (items) {
          if (items.fast) {
            self.requestSearch(selection);
          }
        });
      }
    }
  }, {
    key: 'getSelection',
    value: function getSelection(e) {
      var txt = window.getSelection().toString();
      var span = document.createElement('SPAN');
      span.innerHTML = txt;
      var selection = span.textContent.trim();
      return selection;
    }
  }, {
    key: 'attachSimilarWordsHandlers',
    value: function attachSimilarWordsHandlers(fragment) {
      var _this2 = this;

      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        var _loop = function () {
          var link = _step.value;

          // sanitize
          link.removeAttribute('onclick');
          link.onclick = null;
          var clone = link.cloneNode(true);
          link.parentNode.replaceChild(clone, link);
          var word = clone.textContent;
          // Prevent link from being followed.
          clone.addEventListener('click', function (e) {
            e.stopPropagation();e.preventDefault();
          });
          // Don't let @mouseUpEvent fire again with the wrong word.
          self = _this2;

          clone.addEventListener('mouseup', function (e) {
            e.stopPropagation();
            self.requestSearch(word);
          });
        };

        for (var _iterator = Array.from(fragment.querySelectorAll('a'))[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var self;

          _loop();
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator['return']) {
            _iterator['return']();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return true;
    }
  }]);

  return Main;
})();

module.exports = Main;
//# sourceMappingURL=view.js.map

},{"./tooltip.js":2}],4:[function(require,module,exports){
"use strict";

Array.from || !(function () {
  "use strict";var r = (function () {
    try {
      var r = {},
          e = Object.defineProperty,
          t = e(r, r, r) && e;
    } catch (n) {}return t || function (r, e, t) {
      r[e] = t.value;
    };
  })(),
      e = Object.prototype.toString,
      t = function t(r) {
    return "function" == typeof r || "[object Function]" == e.call(r);
  },
      n = function n(r) {
    var e = Number(r);return isNaN(e) ? 0 : 0 != e && isFinite(e) ? (e > 0 ? 1 : -1) * Math.floor(Math.abs(e)) : e;
  },
      a = Math.pow(2, 53) - 1,
      o = function o(r) {
    var e = n(r);return Math.min(Math.max(e, 0), a);
  },
      u = function u(e) {
    var n = this;if (null == e) throw new TypeError("`Array.from` requires an array-like object, not `null` or `undefined`");{
      var a,
          u,
          i = Object(e);arguments.length > 1;
    }if (arguments.length > 1) {
      if ((a = arguments[1], !t(a))) throw new TypeError("When provided, the second argument to `Array.from` must be a function");arguments.length > 2 && (u = arguments[2]);
    }for (var f, c, l = o(i.length), h = t(n) ? Object(new n(l)) : new Array(l), m = 0; l > m;) f = i[m], c = a ? "undefined" == typeof u ? a(f, m) : a.call(u, f, m) : f, r(h, m, { value: c, configurable: !0, enumerable: !0, writable: !0 }), ++m;return h.length = l, h;
  };r(Array, "from", { value: u, configurable: !0, writable: !0 });
})();
//# sourceMappingURL=Array.from.js.map

},{}],5:[function(require,module,exports){
"use strict";

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Utils = (function () {
  function Utils() {
    _classCallCheck(this, Utils);
  }

  _createClass(Utils, [{
    key: "request",
    value: function request(type, url, opts) {
      // Return a new promise.
      return new Promise(function (resolve, reject) {
        // Do the usual XHR stuff
        var req = new XMLHttpRequest();
        req.withCredentials = true;
        req.open(type, url);
        if (type == 'POST') {
          req.setRequestHeader("Content-Type", "application/json");
        }
        req.onload = function () {
          // This is called even on 404 etc
          // so check the status
          if (req.status == 200) {
            // Resolve the promise with the response text
            resolve(req.response);
          } else {
            // Otherwise reject with the status text
            // which will hopefully be a meaningful error
            reject(Error(req.statusText));
          }
        };

        // Handle network errors
        req.onerror = function () {
          reject(Error("Network Error"));
        };

        // Set headers
        if (opts.headers) {
          var _iteratorNormalCompletion = true;
          var _didIteratorError = false;
          var _iteratorError = undefined;

          try {
            for (var _iterator = Object.keys(opts.headers)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              var key = _step.value;

              req.setRequestHeader(key, opts.headers[key]);
            }
          } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion && _iterator["return"]) {
                _iterator["return"]();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
          }
        }
        // Make the request
        req.send(JSON.stringify(opts.data));
      });
    }
  }, {
    key: "get",
    value: function get(url) {
      var opts = arguments.length <= 1 || arguments[1] === undefined ? { data: '' } : arguments[1];

      return this.request('GET', url, opts);
    }
  }, {
    key: "post",
    value: function post(url) {
      var opts = arguments.length <= 1 || arguments[1] === undefined ? { data: '' } : arguments[1];

      return this.request('POST', url, opts);
    }
  }]);

  return Utils;
})();

module.exports = new Utils();
//# sourceMappingURL=utils.js.map

},{}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0Rldi90cmFuL25vZGVfbW9kdWxlcy9ncnVudC1icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCIvVXNlcnMvYW50aG9ueS9EZXYvdHJhbi9qcy9lczUvY29udGVudF9zY3JpcHQvY29udGVudC5qcyIsIi9Vc2Vycy9hbnRob255L0Rldi90cmFuL2pzL2VzNS9jb250ZW50X3NjcmlwdC90b29sdGlwLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2L3RyYW4vanMvZXM1L2NvbnRlbnRfc2NyaXB0L3ZpZXcuanMiLCIvVXNlcnMvYW50aG9ueS9EZXYvdHJhbi9qcy9lczUvcG9seWZpbGxzL0FycmF5LmZyb20uanMiLCIvVXNlcnMvYW50aG9ueS9EZXYvdHJhbi9qcy9lczUvdXRpbHMuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3hLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdktBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3Rocm93IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIil9dmFyIGY9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGYuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sZixmLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIi8qIGdsb2JhbCBjaHJvbWUgKi9cbi8qXG4gU2NyaXB0IGVtYmVkZGVkIG9uIGVhY2ggdXNlciBwYWdlXG4gTGlzdGVucyBtZXNzYWdlcyBmcm9tIHRyYW5zbGF0aW9uIG1vZHVsZSBhbmQgcmVuZGVycyBwb3B1cFxuIHdpdGggdHJhbnNsYXRlZCB0ZXh0XG4qL1xuXCJ1c2Ugc3RyaWN0XCI7XG5cbnJlcXVpcmUoXCIuLi9wb2x5ZmlsbHMvQXJyYXkuZnJvbS5qc1wiKTtcblxudmFyIFZpZXcgPSByZXF1aXJlKCcuL3ZpZXcuanMnKTtcbnZhciBjb250ZW50ID0gbmV3IFZpZXcoKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNvbnRlbnQuanMubWFwXG4iLCIvLyBUT0RPINCy0YvQvdC10YHRgtC4INC90LDRgdGC0YDQvtC50LrQuCDQv9C+0LTQutC70Y7Rh9C10L3QuNGPINCyIHNldHRpbmdzLmpzXG4vL3ZhciBIT1NUID0gJ2h0dHA6Ly90cmFuLXNlcnZpY2UuY29tJ1xuJ3VzZSBzdHJpY3QnO1xuXG52YXIgX2NyZWF0ZUNsYXNzID0gKGZ1bmN0aW9uICgpIHsgZnVuY3Rpb24gZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIHByb3BzKSB7IGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpKyspIHsgdmFyIGRlc2NyaXB0b3IgPSBwcm9wc1tpXTsgZGVzY3JpcHRvci5lbnVtZXJhYmxlID0gZGVzY3JpcHRvci5lbnVtZXJhYmxlIHx8IGZhbHNlOyBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSA9IHRydWU7IGlmICgndmFsdWUnIGluIGRlc2NyaXB0b3IpIGRlc2NyaXB0b3Iud3JpdGFibGUgPSB0cnVlOyBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBkZXNjcmlwdG9yLmtleSwgZGVzY3JpcHRvcik7IH0gfSByZXR1cm4gZnVuY3Rpb24gKENvbnN0cnVjdG9yLCBwcm90b1Byb3BzLCBzdGF0aWNQcm9wcykgeyBpZiAocHJvdG9Qcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvci5wcm90b3R5cGUsIHByb3RvUHJvcHMpOyBpZiAoc3RhdGljUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IsIHN0YXRpY1Byb3BzKTsgcmV0dXJuIENvbnN0cnVjdG9yOyB9OyB9KSgpO1xuXG5mdW5jdGlvbiBfY2xhc3NDYWxsQ2hlY2soaW5zdGFuY2UsIENvbnN0cnVjdG9yKSB7IGlmICghKGluc3RhbmNlIGluc3RhbmNlb2YgQ29uc3RydWN0b3IpKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoJ0Nhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvbicpOyB9IH1cblxudmFyIEhPU1QgPSAnaHR0cDovL2xvY2FsaG9zdDo1MDAwJztcblxudmFyIFRPT0xUSVBfQ0xBU1NfUFJFRklYID0gJ19fbXR0X3RyYW5zbGF0ZV9kaWFsb2dfXyc7XG52YXIgY3RybERvd24gPSBmYWxzZTtcbnZhciBjdHJsS2V5ID0gMTc7XG52YXIgY21kS2V5ID0gOTE7XG52YXIgY0tleSA9IDY3O1xudmFyIGFkZF90aXRsZSA9ICfQlNC+0LHQsNCy0LjRgtGMINCyINC/0LXRgNGB0L7QvdCw0LvRjNC90YvQuSDRgdC70L7QstCw0YDRjCc7XG5cbnZhciBfID0gcmVxdWlyZSgnLi4vdXRpbHMuanMnKTtcblxudmFyIFRvb2x0aXAgPSAoZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBUb29sdGlwKGNvb3JkaW5hdGVzKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIFRvb2x0aXApO1xuXG4gICAgdGhpcy5zZXRMaXN0ZW5lcnMoKTtcbiAgICB0aGlzLmNsaWNrVGFyZ2V0ID0gbnVsbDtcbiAgfVxuXG4gIF9jcmVhdGVDbGFzcyhUb29sdGlwLCBbe1xuICAgIGtleTogJ2NyZWF0ZUVsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gY3JlYXRlRWwoc3RvcmFnZSkge1xuICAgICAgdGhpcy5lbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgdGhpcy5tZW1vcml6ZUJ1dHRvbiA9IHRoaXMuY3JlYXRlTWVtb0J0bigpO1xuICAgICAgdGhpcy5lbENvbnRhaW5lciA9IHRoaXMuY3JlYXRlQ29udGFpbmVyKCk7XG4gICAgICB0aGlzLmVsLmFwcGVuZENoaWxkKHRoaXMubWVtb3JpemVCdXR0b24pO1xuICAgICAgdGhpcy5lbC5hcHBlbmRDaGlsZCh0aGlzLmVsQ29udGFpbmVyKTtcbiAgICAgIHRoaXMuZWwuY2xhc3NMaXN0LmFkZChUT09MVElQX0NMQVNTX1BSRUZJWCk7XG4gICAgICB0aGlzLmFkZExpc3RlbmVycygpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2FkZExpc3RlbmVycycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGFkZExpc3RlbmVycygpIHtcbiAgICAgIHRoaXMuZWwuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgcmV0dXJuIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICB9KTtcbiAgICAgIHRoaXMuZWwuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIHRoaXMub25LZXlEb3duKTtcbiAgICAgIHRoaXMubWVtb3JpemVCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLm1lbW9DbGljayk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnY3JlYXRlTWVtb0J0bicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNyZWF0ZU1lbW9CdG4oKSB7XG4gICAgICB2YXIgdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3RlbXBsYXRlJyk7XG4gICAgICB2YXIgdG1wbCA9ICc8YSB0aXRsZT1cIicgKyBhZGRfdGl0bGUgKyAnXCJcXG4gICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidG4tZmxvYXRpbmcgd2F2ZXMtZWZmZWN0IHdhdmVzLWxpZ2h0IGJsdWUgd29yZC1hZGRcIj5cXG4gICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cIm1hdGVyaWFsLWljb25zXCI+KzwvaT5cXG4gICAgICAgICAgICAgICAgPC9hPic7XG4gICAgICB0LmlubmVySFRNTCA9IHRtcGw7XG4gICAgICByZXR1cm4gdC5jb250ZW50O1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ21lbW9DbGljaycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG1lbW9DbGljayhlKSB7XG4gICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgXy5wb3N0KEhPU1QgKyAnL2FwaS9wbHVnaW4vYWRkX3dvcmQvJywgeyBkYXRhOiAnYmxhYmxhJyB9KTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdjcmVhdGVDb250YWluZXInLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjcmVhdGVDb250YWluZXIoKSB7XG4gICAgICB2YXIgZG9jRnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG4gICAgICB2YXIgY29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICBjb250YWluZXIuY2xhc3NMaXN0LmFkZChUT09MVElQX0NMQVNTX1BSRUZJWCArICdjb250YWluZXInKTtcbiAgICAgIHJldHVybiBjb250YWluZXI7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnb25LZXlEb3duJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gb25LZXlEb3duKGUpIHtcbiAgICAgIGlmIChjdHJsRG93biAmJiAoZS5rZXlDb2RlID09IHZLZXkgfHwgZS5rZXlDb2RlID09IGNLZXkpKSB7XG4gICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3NldExpc3RlbmVycycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHNldExpc3RlbmVycygpIHtcbiAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gX3RoaXMuZGVzdHJveShlKTtcbiAgICAgIH0pO1xuICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzLmRlc3Ryb3koZSk7XG4gICAgICB9KTtcbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdibHVyJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzLmRlc3Ryb3koZSk7XG4gICAgICB9KTtcbiAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gX3RoaXMua2V5ZG93bihlKTtcbiAgICAgIH0pO1xuICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigna2V5dXAnLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gX3RoaXMua2V5dXAoZSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdyZW5kZXInLFxuICAgIHZhbHVlOiBmdW5jdGlvbiByZW5kZXIoZGF0YSkge1xuICAgICAgdmFyIHRyYW5zZm9ybSA9IGFyZ3VtZW50cy5sZW5ndGggPD0gMSB8fCBhcmd1bWVudHNbMV0gPT09IHVuZGVmaW5lZCA/IG51bGwgOiBhcmd1bWVudHNbMV07XG5cbiAgICAgIGlmICghdGhpcy5lbCkge1xuICAgICAgICB0aGlzLmNyZWF0ZUVsKCk7XG4gICAgICB9XG4gICAgICB0aGlzLmNoZWNrTWVtb3JpemUoKTtcbiAgICAgIHRoaXMuZWxDb250YWluZXIuaW5uZXJIVE1MID0gZGF0YTtcbiAgICAgIGlmICh0cmFuc2Zvcm0pIHtcbiAgICAgICAgdHJhbnNmb3JtKHRoaXMuZWwpO1xuICAgICAgfVxuICAgICAgdGhpcy5lbC5zdHlsZS5sZWZ0ID0gdGhpcy5jb29yZGluYXRlcy5tb3VzZVggKyAncHgnO1xuICAgICAgdGhpcy5lbC5zdHlsZS50b3AgPSB0aGlzLmNvb3JkaW5hdGVzLm1vdXNlWSArICdweCc7XG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHRoaXMuZWwpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2NoZWNrTWVtb3JpemUnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjaGVja01lbW9yaXplKCkge1xuICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoeyBtZW1vcml6ZTogZmFsc2UsIGF1dGhfdG9rZW46IG51bGwgfSwgZnVuY3Rpb24gKHN0b3JhZ2UpIHtcbiAgICAgICAgaWYgKHN0b3JhZ2UubWVtb3JpemUgJiYgc3RvcmFnZS5hdXRoX3Rva2VuKSB7XG4gICAgICAgICAgc2VsZi5lbC5jbGFzc0xpc3QuYWRkKCdtZW1vcml6ZScpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNlbGYuZWwuY2xhc3NMaXN0LnJlbW92ZSgnbWVtb3JpemUnKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAna2V5ZG93bicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGtleWRvd24oZSkge1xuICAgICAgaWYgKGUua2V5Q29kZSA9PSBjdHJsS2V5IHx8IGUua2V5Q29kZSA9PSBjbWRLZXkpIHtcbiAgICAgICAgY3RybERvd24gPSB0cnVlO1xuICAgICAgfVxuICAgICAgaWYgKGN0cmxEb3duICYmIChlLmtleUNvZGUgPT0gY3RybEtleSB8fCBlLmtleUNvZGUgPT0gY0tleSB8fCBlLmtleUNvZGUgPT0gY21kS2V5KSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuZGVzdHJveShlKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdrZXl1cCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGtleXVwKGUpIHtcbiAgICAgIGlmIChlLmtleUNvZGUgPT0gY3RybEtleSkge1xuICAgICAgICBjdHJsRG93biA9IGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2Rlc3Ryb3knLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBkZXN0cm95KGUpIHtcbiAgICAgIGlmICh0aGlzLmVsICYmIHRoaXMuZWwucGFyZW50Tm9kZSA9PSBkb2N1bWVudC5ib2R5KSB7XG4gICAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQodGhpcy5lbCk7XG4gICAgICAgIHRoaXMuZWwgPSBudWxsO1xuICAgICAgICB0aGlzLmNsaWNrVGFyZ2V0ID0gbnVsbDsgLy8gcmVzZXQgY2xpY2sgdGFyZ2V0XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnc2V0Q29vcmRpbmF0ZXMnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzZXRDb29yZGluYXRlcyhjb29yZGluYXRlcykge1xuICAgICAgdGhpcy5jb29yZGluYXRlcyA9IGNvb3JkaW5hdGVzO1xuICAgIH1cbiAgfV0pO1xuXG4gIHJldHVybiBUb29sdGlwO1xufSkoKTtcblxubW9kdWxlLmV4cG9ydHMgPSBUb29sdGlwO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dG9vbHRpcC5qcy5tYXBcbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIF9jcmVhdGVDbGFzcyA9IChmdW5jdGlvbiAoKSB7IGZ1bmN0aW9uIGRlZmluZVByb3BlcnRpZXModGFyZ2V0LCBwcm9wcykgeyBmb3IgKHZhciBpID0gMDsgaSA8IHByb3BzLmxlbmd0aDsgaSsrKSB7IHZhciBkZXNjcmlwdG9yID0gcHJvcHNbaV07IGRlc2NyaXB0b3IuZW51bWVyYWJsZSA9IGRlc2NyaXB0b3IuZW51bWVyYWJsZSB8fCBmYWxzZTsgZGVzY3JpcHRvci5jb25maWd1cmFibGUgPSB0cnVlOyBpZiAoJ3ZhbHVlJyBpbiBkZXNjcmlwdG9yKSBkZXNjcmlwdG9yLndyaXRhYmxlID0gdHJ1ZTsgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgZGVzY3JpcHRvci5rZXksIGRlc2NyaXB0b3IpOyB9IH0gcmV0dXJuIGZ1bmN0aW9uIChDb25zdHJ1Y3RvciwgcHJvdG9Qcm9wcywgc3RhdGljUHJvcHMpIHsgaWYgKHByb3RvUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IucHJvdG90eXBlLCBwcm90b1Byb3BzKTsgaWYgKHN0YXRpY1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLCBzdGF0aWNQcm9wcyk7IHJldHVybiBDb25zdHJ1Y3RvcjsgfTsgfSkoKTtcblxuZnVuY3Rpb24gX2NsYXNzQ2FsbENoZWNrKGluc3RhbmNlLCBDb25zdHJ1Y3RvcikgeyBpZiAoIShpbnN0YW5jZSBpbnN0YW5jZW9mIENvbnN0cnVjdG9yKSkgeyB0aHJvdyBuZXcgVHlwZUVycm9yKCdDYW5ub3QgY2FsbCBhIGNsYXNzIGFzIGEgZnVuY3Rpb24nKTsgfSB9XG5cbnZhciBUb29sdGlwID0gcmVxdWlyZSgnLi90b29sdGlwLmpzJyk7XG52YXIgVEVYVEJPWF9UQUdTID0gWydpbnB1dCcsICd0ZXh0YXJlYSddO1xuXG52YXIgTWFpbiA9IChmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIE1haW4oKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIE1haW4pO1xuXG4gICAgdGhpcy5hZGRFdmVudExpc3RlbmVycygpO1xuICAgIHRoaXMuY29vcmRpbmF0ZXMgPSB7IG1vdXNlWDogMCwgbW91c2VZOiAwIH07XG4gICAgdGhpcy50b29sdGlwID0gbmV3IFRvb2x0aXAodGhpcy5jb29yZGluYXRlcyk7XG4gICAgY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKHRoaXMucmVuZGVyUmVzdWx0LmJpbmQodGhpcykpO1xuICB9XG5cbiAgX2NyZWF0ZUNsYXNzKE1haW4sIFt7XG4gICAga2V5OiAnYWRkRXZlbnRMaXN0ZW5lcnMnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBhZGRFdmVudExpc3RlbmVycygpIHtcbiAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gX3RoaXMubW91c2VEb3duRXZlbnQoZSk7XG4gICAgICB9KTtcbiAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlZG93bicsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHJldHVybiBfdGhpcy5tb3VzZURvd25FdmVudChlKTtcbiAgICAgIH0pO1xuICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNldXAnLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gX3RoaXMubW91c2VVcEV2ZW50KGUpO1xuICAgICAgfSk7XG4gICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjb250ZXh0bWVudScsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHJldHVybiBfdGhpcy5zYXZlTW91c2VQb3NpdGlvbihlKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3JlbmRlclJlc3VsdCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJlbmRlclJlc3VsdChtc2cpIHtcbiAgICAgIGlmIChtc2cuYWN0aW9uID09ICdvcGVuX3Rvb2x0aXAnIHx8IG1zZy5hY3Rpb24gPT0gJ3NpbWlsYXJfd29yZHMnKSB7XG4gICAgICAgIC8vZG9uJ3Qgc2hvdyBhbm5veWluZyB0b29sdGlwIHdoZW4gdHlwaW5nXG4gICAgICAgIGlmICghbXNnLnN1Y2Nlc3MgJiYgdGhpcy50b29sdGlwLmNsaWNrVGFyZ2V0ID09ICd0ZXh0Ym94Jykge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSBlbHNlIGlmIChtc2cuYWN0aW9uID09ICdzaW1pbGFyX3dvcmRzJykge1xuICAgICAgICAgIHRoaXMudG9vbHRpcC5yZW5kZXIobXNnLmRhdGEsIHRoaXMuYXR0YWNoU2ltaWxhcldvcmRzSGFuZGxlcnMuYmluZCh0aGlzKSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy50b29sdGlwLnJlbmRlcihtc2cuZGF0YSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdyZXF1ZXN0U2VhcmNoJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gcmVxdWVzdFNlYXJjaChzZWxlY3Rpb24pIHtcbiAgICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHtcbiAgICAgICAgbWV0aG9kOiBcInJlcXVlc3Rfc2VhcmNoXCIsXG4gICAgICAgIGRhdGE6IHtcbiAgICAgICAgICBzZWxlY3Rpb25UZXh0OiBzZWxlY3Rpb25cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnc2F2ZU1vdXNlUG9zaXRpb24nLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzYXZlTW91c2VQb3NpdGlvbihlKSB7XG4gICAgICB0aGlzLmNvb3JkaW5hdGVzLm1vdXNlWCA9IGUucGFnZVggKyA1O1xuICAgICAgdGhpcy5jb29yZGluYXRlcy5tb3VzZVkgPSBlLnBhZ2VZICsgMTA7XG4gICAgICB0aGlzLnRvb2x0aXAuc2V0Q29vcmRpbmF0ZXModGhpcy5jb29yZGluYXRlcyk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnbW91c2VEb3duRXZlbnQnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtb3VzZURvd25FdmVudChlKSB7XG4gICAgICB2YXIgdGFnID0gZS50YXJnZXQudGFnTmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgICAgaWYgKFRFWFRCT1hfVEFHUy5pbmRleE9mKHRhZykgIT0gLTEpIHtcbiAgICAgICAgdGhpcy50b29sdGlwLmNsaWNrVGFyZ2V0ID0gJ3RleHRib3gnO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ21vdXNlVXBFdmVudCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG1vdXNlVXBFdmVudChlKSB7XG4gICAgICAvLyBmaXggZm9yIGFjY2lkZW50YWwgdG9vbHRpcCBhcHBlYXJhbmNlIHdoZW4gY2xpY2tlZCBvbiB0ZXh0XG4gICAgICBzZXRUaW1lb3V0KHRoaXMuY2xpY2tIYW5kbGVyLmJpbmQodGhpcywgZSksIDEwKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2NsaWNrSGFuZGxlcicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNsaWNrSGFuZGxlcihlKSB7XG4gICAgICB0aGlzLnNhdmVNb3VzZVBvc2l0aW9uKGUpO1xuICAgICAgdmFyIHNlbGVjdGlvbiA9IHRoaXMuZ2V0U2VsZWN0aW9uKCk7XG4gICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICBpZiAoc2VsZWN0aW9uLmxlbmd0aCA+IDApIHtcbiAgICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoeyBmYXN0OiB0cnVlIH0sIGZ1bmN0aW9uIChpdGVtcykge1xuICAgICAgICAgIGlmIChpdGVtcy5mYXN0KSB7XG4gICAgICAgICAgICBzZWxmLnJlcXVlc3RTZWFyY2goc2VsZWN0aW9uKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2dldFNlbGVjdGlvbicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGdldFNlbGVjdGlvbihlKSB7XG4gICAgICB2YXIgdHh0ID0gd2luZG93LmdldFNlbGVjdGlvbigpLnRvU3RyaW5nKCk7XG4gICAgICB2YXIgc3BhbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ1NQQU4nKTtcbiAgICAgIHNwYW4uaW5uZXJIVE1MID0gdHh0O1xuICAgICAgdmFyIHNlbGVjdGlvbiA9IHNwYW4udGV4dENvbnRlbnQudHJpbSgpO1xuICAgICAgcmV0dXJuIHNlbGVjdGlvbjtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdhdHRhY2hTaW1pbGFyV29yZHNIYW5kbGVycycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGF0dGFjaFNpbWlsYXJXb3Jkc0hhbmRsZXJzKGZyYWdtZW50KSB7XG4gICAgICB2YXIgX3RoaXMyID0gdGhpcztcblxuICAgICAgdmFyIF9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gPSB0cnVlO1xuICAgICAgdmFyIF9kaWRJdGVyYXRvckVycm9yID0gZmFsc2U7XG4gICAgICB2YXIgX2l0ZXJhdG9yRXJyb3IgPSB1bmRlZmluZWQ7XG5cbiAgICAgIHRyeSB7XG4gICAgICAgIHZhciBfbG9vcCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgbGluayA9IF9zdGVwLnZhbHVlO1xuXG4gICAgICAgICAgLy8gc2FuaXRpemVcbiAgICAgICAgICBsaW5rLnJlbW92ZUF0dHJpYnV0ZSgnb25jbGljaycpO1xuICAgICAgICAgIGxpbmsub25jbGljayA9IG51bGw7XG4gICAgICAgICAgdmFyIGNsb25lID0gbGluay5jbG9uZU5vZGUodHJ1ZSk7XG4gICAgICAgICAgbGluay5wYXJlbnROb2RlLnJlcGxhY2VDaGlsZChjbG9uZSwgbGluayk7XG4gICAgICAgICAgdmFyIHdvcmQgPSBjbG9uZS50ZXh0Q29udGVudDtcbiAgICAgICAgICAvLyBQcmV2ZW50IGxpbmsgZnJvbSBiZWluZyBmb2xsb3dlZC5cbiAgICAgICAgICBjbG9uZS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO2UucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICAvLyBEb24ndCBsZXQgQG1vdXNlVXBFdmVudCBmaXJlIGFnYWluIHdpdGggdGhlIHdyb25nIHdvcmQuXG4gICAgICAgICAgc2VsZiA9IF90aGlzMjtcblxuICAgICAgICAgIGNsb25lLmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNldXAnLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgIHNlbGYucmVxdWVzdFNlYXJjaCh3b3JkKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfTtcblxuICAgICAgICBmb3IgKHZhciBfaXRlcmF0b3IgPSBBcnJheS5mcm9tKGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ2EnKSlbU3ltYm9sLml0ZXJhdG9yXSgpLCBfc3RlcDsgIShfaXRlcmF0b3JOb3JtYWxDb21wbGV0aW9uID0gKF9zdGVwID0gX2l0ZXJhdG9yLm5leHQoKSkuZG9uZSk7IF9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gPSB0cnVlKSB7XG4gICAgICAgICAgdmFyIHNlbGY7XG5cbiAgICAgICAgICBfbG9vcCgpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgX2RpZEl0ZXJhdG9yRXJyb3IgPSB0cnVlO1xuICAgICAgICBfaXRlcmF0b3JFcnJvciA9IGVycjtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgaWYgKCFfaXRlcmF0b3JOb3JtYWxDb21wbGV0aW9uICYmIF9pdGVyYXRvclsncmV0dXJuJ10pIHtcbiAgICAgICAgICAgIF9pdGVyYXRvclsncmV0dXJuJ10oKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgaWYgKF9kaWRJdGVyYXRvckVycm9yKSB7XG4gICAgICAgICAgICB0aHJvdyBfaXRlcmF0b3JFcnJvcjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9XSk7XG5cbiAgcmV0dXJuIE1haW47XG59KSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IE1haW47XG4vLyMgc291cmNlTWFwcGluZ1VSTD12aWV3LmpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbkFycmF5LmZyb20gfHwgIShmdW5jdGlvbiAoKSB7XG4gIFwidXNlIHN0cmljdFwiO3ZhciByID0gKGZ1bmN0aW9uICgpIHtcbiAgICB0cnkge1xuICAgICAgdmFyIHIgPSB7fSxcbiAgICAgICAgICBlID0gT2JqZWN0LmRlZmluZVByb3BlcnR5LFxuICAgICAgICAgIHQgPSBlKHIsIHIsIHIpICYmIGU7XG4gICAgfSBjYXRjaCAobikge31yZXR1cm4gdCB8fCBmdW5jdGlvbiAociwgZSwgdCkge1xuICAgICAgcltlXSA9IHQudmFsdWU7XG4gICAgfTtcbiAgfSkoKSxcbiAgICAgIGUgPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLFxuICAgICAgdCA9IGZ1bmN0aW9uIHQocikge1xuICAgIHJldHVybiBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIHIgfHwgXCJbb2JqZWN0IEZ1bmN0aW9uXVwiID09IGUuY2FsbChyKTtcbiAgfSxcbiAgICAgIG4gPSBmdW5jdGlvbiBuKHIpIHtcbiAgICB2YXIgZSA9IE51bWJlcihyKTtyZXR1cm4gaXNOYU4oZSkgPyAwIDogMCAhPSBlICYmIGlzRmluaXRlKGUpID8gKGUgPiAwID8gMSA6IC0xKSAqIE1hdGguZmxvb3IoTWF0aC5hYnMoZSkpIDogZTtcbiAgfSxcbiAgICAgIGEgPSBNYXRoLnBvdygyLCA1MykgLSAxLFxuICAgICAgbyA9IGZ1bmN0aW9uIG8ocikge1xuICAgIHZhciBlID0gbihyKTtyZXR1cm4gTWF0aC5taW4oTWF0aC5tYXgoZSwgMCksIGEpO1xuICB9LFxuICAgICAgdSA9IGZ1bmN0aW9uIHUoZSkge1xuICAgIHZhciBuID0gdGhpcztpZiAobnVsbCA9PSBlKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiYEFycmF5LmZyb21gIHJlcXVpcmVzIGFuIGFycmF5LWxpa2Ugb2JqZWN0LCBub3QgYG51bGxgIG9yIGB1bmRlZmluZWRgXCIpO3tcbiAgICAgIHZhciBhLFxuICAgICAgICAgIHUsXG4gICAgICAgICAgaSA9IE9iamVjdChlKTthcmd1bWVudHMubGVuZ3RoID4gMTtcbiAgICB9aWYgKGFyZ3VtZW50cy5sZW5ndGggPiAxKSB7XG4gICAgICBpZiAoKGEgPSBhcmd1bWVudHNbMV0sICF0KGEpKSkgdGhyb3cgbmV3IFR5cGVFcnJvcihcIldoZW4gcHJvdmlkZWQsIHRoZSBzZWNvbmQgYXJndW1lbnQgdG8gYEFycmF5LmZyb21gIG11c3QgYmUgYSBmdW5jdGlvblwiKTthcmd1bWVudHMubGVuZ3RoID4gMiAmJiAodSA9IGFyZ3VtZW50c1syXSk7XG4gICAgfWZvciAodmFyIGYsIGMsIGwgPSBvKGkubGVuZ3RoKSwgaCA9IHQobikgPyBPYmplY3QobmV3IG4obCkpIDogbmV3IEFycmF5KGwpLCBtID0gMDsgbCA+IG07KSBmID0gaVttXSwgYyA9IGEgPyBcInVuZGVmaW5lZFwiID09IHR5cGVvZiB1ID8gYShmLCBtKSA6IGEuY2FsbCh1LCBmLCBtKSA6IGYsIHIoaCwgbSwgeyB2YWx1ZTogYywgY29uZmlndXJhYmxlOiAhMCwgZW51bWVyYWJsZTogITAsIHdyaXRhYmxlOiAhMCB9KSwgKyttO3JldHVybiBoLmxlbmd0aCA9IGwsIGg7XG4gIH07cihBcnJheSwgXCJmcm9tXCIsIHsgdmFsdWU6IHUsIGNvbmZpZ3VyYWJsZTogITAsIHdyaXRhYmxlOiAhMCB9KTtcbn0pKCk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1BcnJheS5mcm9tLmpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbnZhciBfY3JlYXRlQ2xhc3MgPSAoZnVuY3Rpb24gKCkgeyBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0aWVzKHRhcmdldCwgcHJvcHMpIHsgZm9yICh2YXIgaSA9IDA7IGkgPCBwcm9wcy5sZW5ndGg7IGkrKykgeyB2YXIgZGVzY3JpcHRvciA9IHByb3BzW2ldOyBkZXNjcmlwdG9yLmVudW1lcmFibGUgPSBkZXNjcmlwdG9yLmVudW1lcmFibGUgfHwgZmFsc2U7IGRlc2NyaXB0b3IuY29uZmlndXJhYmxlID0gdHJ1ZTsgaWYgKFwidmFsdWVcIiBpbiBkZXNjcmlwdG9yKSBkZXNjcmlwdG9yLndyaXRhYmxlID0gdHJ1ZTsgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgZGVzY3JpcHRvci5rZXksIGRlc2NyaXB0b3IpOyB9IH0gcmV0dXJuIGZ1bmN0aW9uIChDb25zdHJ1Y3RvciwgcHJvdG9Qcm9wcywgc3RhdGljUHJvcHMpIHsgaWYgKHByb3RvUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IucHJvdG90eXBlLCBwcm90b1Byb3BzKTsgaWYgKHN0YXRpY1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLCBzdGF0aWNQcm9wcyk7IHJldHVybiBDb25zdHJ1Y3RvcjsgfTsgfSkoKTtcblxuZnVuY3Rpb24gX2NsYXNzQ2FsbENoZWNrKGluc3RhbmNlLCBDb25zdHJ1Y3RvcikgeyBpZiAoIShpbnN0YW5jZSBpbnN0YW5jZW9mIENvbnN0cnVjdG9yKSkgeyB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IGNhbGwgYSBjbGFzcyBhcyBhIGZ1bmN0aW9uXCIpOyB9IH1cblxudmFyIFV0aWxzID0gKGZ1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gVXRpbHMoKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIFV0aWxzKTtcbiAgfVxuXG4gIF9jcmVhdGVDbGFzcyhVdGlscywgW3tcbiAgICBrZXk6IFwicmVxdWVzdFwiLFxuICAgIHZhbHVlOiBmdW5jdGlvbiByZXF1ZXN0KHR5cGUsIHVybCwgb3B0cykge1xuICAgICAgLy8gUmV0dXJuIGEgbmV3IHByb21pc2UuXG4gICAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAvLyBEbyB0aGUgdXN1YWwgWEhSIHN0dWZmXG4gICAgICAgIHZhciByZXEgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgICAgcmVxLndpdGhDcmVkZW50aWFscyA9IHRydWU7XG4gICAgICAgIHJlcS5vcGVuKHR5cGUsIHVybCk7XG4gICAgICAgIGlmICh0eXBlID09ICdQT1NUJykge1xuICAgICAgICAgIHJlcS5zZXRSZXF1ZXN0SGVhZGVyKFwiQ29udGVudC1UeXBlXCIsIFwiYXBwbGljYXRpb24vanNvblwiKTtcbiAgICAgICAgfVxuICAgICAgICByZXEub25sb2FkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIC8vIFRoaXMgaXMgY2FsbGVkIGV2ZW4gb24gNDA0IGV0Y1xuICAgICAgICAgIC8vIHNvIGNoZWNrIHRoZSBzdGF0dXNcbiAgICAgICAgICBpZiAocmVxLnN0YXR1cyA9PSAyMDApIHtcbiAgICAgICAgICAgIC8vIFJlc29sdmUgdGhlIHByb21pc2Ugd2l0aCB0aGUgcmVzcG9uc2UgdGV4dFxuICAgICAgICAgICAgcmVzb2x2ZShyZXEucmVzcG9uc2UpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBPdGhlcndpc2UgcmVqZWN0IHdpdGggdGhlIHN0YXR1cyB0ZXh0XG4gICAgICAgICAgICAvLyB3aGljaCB3aWxsIGhvcGVmdWxseSBiZSBhIG1lYW5pbmdmdWwgZXJyb3JcbiAgICAgICAgICAgIHJlamVjdChFcnJvcihyZXEuc3RhdHVzVGV4dCkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICAvLyBIYW5kbGUgbmV0d29yayBlcnJvcnNcbiAgICAgICAgcmVxLm9uZXJyb3IgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmVqZWN0KEVycm9yKFwiTmV0d29yayBFcnJvclwiKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gU2V0IGhlYWRlcnNcbiAgICAgICAgaWYgKG9wdHMuaGVhZGVycykge1xuICAgICAgICAgIHZhciBfaXRlcmF0b3JOb3JtYWxDb21wbGV0aW9uID0gdHJ1ZTtcbiAgICAgICAgICB2YXIgX2RpZEl0ZXJhdG9yRXJyb3IgPSBmYWxzZTtcbiAgICAgICAgICB2YXIgX2l0ZXJhdG9yRXJyb3IgPSB1bmRlZmluZWQ7XG5cbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgZm9yICh2YXIgX2l0ZXJhdG9yID0gT2JqZWN0LmtleXMob3B0cy5oZWFkZXJzKVtTeW1ib2wuaXRlcmF0b3JdKCksIF9zdGVwOyAhKF9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gPSAoX3N0ZXAgPSBfaXRlcmF0b3IubmV4dCgpKS5kb25lKTsgX2l0ZXJhdG9yTm9ybWFsQ29tcGxldGlvbiA9IHRydWUpIHtcbiAgICAgICAgICAgICAgdmFyIGtleSA9IF9zdGVwLnZhbHVlO1xuXG4gICAgICAgICAgICAgIHJlcS5zZXRSZXF1ZXN0SGVhZGVyKGtleSwgb3B0cy5oZWFkZXJzW2tleV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgX2RpZEl0ZXJhdG9yRXJyb3IgPSB0cnVlO1xuICAgICAgICAgICAgX2l0ZXJhdG9yRXJyb3IgPSBlcnI7XG4gICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIGlmICghX2l0ZXJhdG9yTm9ybWFsQ29tcGxldGlvbiAmJiBfaXRlcmF0b3JbXCJyZXR1cm5cIl0pIHtcbiAgICAgICAgICAgICAgICBfaXRlcmF0b3JbXCJyZXR1cm5cIl0oKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgaWYgKF9kaWRJdGVyYXRvckVycm9yKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgX2l0ZXJhdG9yRXJyb3I7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gTWFrZSB0aGUgcmVxdWVzdFxuICAgICAgICByZXEuc2VuZChKU09OLnN0cmluZ2lmeShvcHRzLmRhdGEpKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogXCJnZXRcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gZ2V0KHVybCkge1xuICAgICAgdmFyIG9wdHMgPSBhcmd1bWVudHMubGVuZ3RoIDw9IDEgfHwgYXJndW1lbnRzWzFdID09PSB1bmRlZmluZWQgPyB7IGRhdGE6ICcnIH0gOiBhcmd1bWVudHNbMV07XG5cbiAgICAgIHJldHVybiB0aGlzLnJlcXVlc3QoJ0dFVCcsIHVybCwgb3B0cyk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiBcInBvc3RcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gcG9zdCh1cmwpIHtcbiAgICAgIHZhciBvcHRzID0gYXJndW1lbnRzLmxlbmd0aCA8PSAxIHx8IGFyZ3VtZW50c1sxXSA9PT0gdW5kZWZpbmVkID8geyBkYXRhOiAnJyB9IDogYXJndW1lbnRzWzFdO1xuXG4gICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KCdQT1NUJywgdXJsLCBvcHRzKTtcbiAgICB9XG4gIH1dKTtcblxuICByZXR1cm4gVXRpbHM7XG59KSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBVdGlscygpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXRpbHMuanMubWFwXG4iXX0=
