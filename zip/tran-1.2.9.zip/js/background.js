(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){

/*global tran, chrome */
var CHAR_CODES, tran, turkishDictionary;

CHAR_CODES = require('./char-codes.js');

tran = require('./tran.coffee');

turkishDictionary = require('./turkishdictionary.js');

chrome.contextMenus.create({
  title: 'Multitran: "%s"',
  contexts: ["editable", "selection"],
  onclick: function(data) {
    data.silent = false;
    return tran.click(data);
  }
});


/*
 Can't get chrome.storage directly from content_script
 so content_script sends request message and then background script
 responds with storage value
 */

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.method === "get_fast_option") {
    chrome.storage.sync.get({
      fast: true
    }, function(items) {
      return sendResponse({
        fast: items.fast
      });
    });
  } else if (request.method === 'request_search') {
    chrome.storage.sync.get({
      language: '1',
      fast: true
    }, function(items) {
      request.data.silent = true;
      if (parseInt(items.language, 10) === 1000) {
        turkishDictionary.translate(request.data);
      } else {
        tran.click(request.data);
      }
      return true;
    });
  }
  return true;
});


},{"./char-codes.js":3,"./tran.coffee":4,"./turkishdictionary.js":5}],2:[function(require,module,exports){
// turkishdictionary codings
'use strict';

var DICT = {
    350: '%DE', //Ş
    286: '%D0', //Ğ
    287: '%F0', //ğ
    351: '%FE', //ş
    305: '%FD', //ı
    304: '%DD', //İ
    252: '%FC', //ü
    220: '%DC', //Ü
    231: '%E7', //ç
    199: '%C7', //Ç
    246: '%F6', //ö
    244: '%F4', //ô
    214: '%D6', //Ö
    212: '%D4', //Ô
    251: '%FB', //û
    219: '%DB', //Û
    194: '%C2', //Â
    226: '%E2', //â
    39: '' };

//'
module.exports = DICT;
//# sourceMappingURL=char-codes-turk.js.map

},{}],3:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/
'use strict';

var CHAR_CODES = {
  //russian
  '%D1%8A': { val: '%FA', lang: 'ru' }, // ъ
  '%D0%AA': { val: '%DA', lang: 'ru' }, // Ъ

  '%C3%80': '&#192;', // À
  '%C3%81': '&#193;', // Á
  '%C3%82': '&#194;', // Â
  '%C3%83': '&#195;', // Ã
  '%C3%84': '&#196;', // Ä
  '%C3%85': '&#197;', // Å
  '%C3%86': '&#198;', // Æ

  '%C3%87': '&#199;', // Ç
  '%C3%88': '&#200;', // È
  '%C3%89': '&#201;', // É
  '%C3%8A': '&#202;', // Ê
  '%C3%8B': '&#203;', // Ë

  '%C3%8C': '&#204;', // Ì
  '%C3%8D': '&#205;', // Í
  '%C3%8E': '&#206;', // Î
  '%C3%8F': '&#207;', // Ï

  '%C3%91': '&#209;', // Ñ
  '%C3%92': '&#210;', // Ò
  '%C3%93': '&#211;', // Ó
  '%C3%94': '&#212;', // Ô
  '%C3%95': '&#213;', // Õ
  '%C3%96': '&#214;', // Ö

  '%C3%99': '&#217;', // Ù
  '%C3%9A': '&#218;', // Ú
  '%C3%9B': '&#219;', // Û
  '%C3%9C': '&#220;', // Ü

  '%C3%A0': '&#224;', // à
  '%C3%A1': '&#225;', // á
  '%C3%A2': '&#226;', // â
  '%C3%A3': '&#227;', // ã
  '%C3%A4': '&#228;', // ä
  '%C3%A5': '&#229;', // å
  '%C3%A6': '&#230;', // æ
  '%C3%A7': '&#231;', // ç

  '%C3%A8': '&#232;', // è
  '%C3%A9': '&#233;', // é
  '%C3%AA': '&#234;', // ê
  '%C3%AB': '&#235;', // ë

  '%C3%AC': '&#236;', // ì
  '%C3%AD': '&#237;', // í
  '%C3%AE': '&#238;', // î
  '%C3%AF': '&#239;', // ï

  '%C3%B0': '&#240;', // ð
  '%C3%B1': '&#241;', // ñ

  '%C3%B2': '&#242;', // ò
  '%C3%B3': '&#243;', // ó
  '%C3%B4': '&#244;', // ô
  '%C3%B5': '&#245;', // õ
  '%C3%B6': '&#246;', // ö

  '%C3%B9': '&#249;', // ù
  '%C3%BA': '&#250;', // ú
  '%C3%BB': '&#251;', // û
  '%C3%BC': '&#252;', // ü
  '%C3%BF': '&#255;', // ÿ
  '%C5%B8': '&#376;', // Ÿ

  '%C3%9F': '&#223;', // ß

  '%C2%BF': '&#191;', // ¿
  '%C2%A1': '&#161;' };

// ¡
module.exports = CHAR_CODES;
//# sourceMappingURL=char-codes.js.map

},{}],4:[function(require,module,exports){

/*global chrome */

/*
  Multitran.ru translate engine
  Provides program interface for making translate queries to multitran and get clean response

  All engines must follow common interface and provide methods:
    - search (languange, successHandler)  clean translation must be passed into successHandler
    - click

  Translation-module that makes requests to language-engine,
  parses results and sends plugin-global message with translation data
 */
var CHAR_CODES, Tran;

CHAR_CODES = require('./char-codes.js');

Tran = (function() {
  function Tran() {
    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1';
    this.xhr = {};
  }


  /*
    Context menu click handler
   */

  Tran.prototype.click = function(data) {
    var selectionText;
    if (typeof data.silent === void 0 || data.silent === null) {
      data.silent = true;
    }
    selectionText = this.removeHyphenation(data.selectionText);
    return this.search({
      value: selectionText,
      success: this.successtHandler.bind(this),
      silent: data.silent
    });
  };


  /*
    Discard soft hyphen character (U+00AD, &shy;) from the input
   */

  Tran.prototype.removeHyphenation = function(text) {
    return text.replace(/\xad/g, '');
  };


  /*
    Initiate translation search
   */

  Tran.prototype.search = function(params) {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(items) {
        var language, origSuccess, url;
        if (language === '') {
          language = '1';
        }
        _this.setLanguage(items.language);
        url = _this.makeUrl(params.value);
        origSuccess = params.success;
        params.success = function(response) {
          var translated;
          translated = _this.parse(response, params.silent);
          return origSuccess(translated);
        };
        return _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      };
    })(this));
  };

  Tran.prototype.setLanguage = function(language) {
    this.currentLanguage = language;
    return this.lang = '?l1=2&l2=' + language;
  };


  /*
    Request translation and run callback function
    passing translated result or error to callback
   */

  Tran.prototype.request = function(opts) {
    var xhr;
    xhr = this.xhr = new XMLHttpRequest();
    xhr.onreadystatechange = (function(_this) {
      return function(e) {
        xhr = _this.xhr;
        if (xhr.readyState < 4) {

        } else if (xhr.status !== 200) {
          _this.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error();
          }
        } else if (xhr.readyState === 4) {
          return opts.success(e.target.response);
        }
      };
    })(this);
    xhr.open("GET", opts.url, true);
    return xhr.send();
  };

  Tran.prototype.makeUrl = function(value) {
    var url;
    url = [this.protocol, '://', this.host, this.path, this.lang, this.query, this.getEncodedValue(value)].join('');
    return url;
  };

  Tran.prototype.getEncodedValue = function(value) {
    var cc, char, code, val;
    val = encodeURIComponent(value);
    for (char in CHAR_CODES) {
      code = CHAR_CODES[char];
      if (typeof code === 'object') {
        cc = code.val;
      } else {
        cc = encodeURIComponent(code);
      }
      val = val.replace(char, cc);
    }
    return val;
  };

  Tran.prototype.errorHandler = function(xhr) {
    return console.log('error', xhr);
  };


  /*
   Receiving data from translation-engine and send ready message with data
   */

  Tran.prototype.successtHandler = function(translated) {
    if (translated) {
      return chrome.tabs.getSelected(null, (function(_this) {
        return function(tab) {
          return chrome.tabs.sendMessage(tab.id, {
            action: _this.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        };
      })(this));
    }
  };

  Tran.prototype.messageType = function(translated) {
    var _ref;
    if ((translated != null ? (_ref = translated.rows) != null ? _ref.length : void 0 : void 0) === 1) {
      return 'similar_words';
    } else {
      return 'open_tooltip';
    }
  };


  /*
    Parse response from translation engine
   */

  Tran.prototype.parse = function(response, silent, translate) {
    var doc, fragment;
    if (translate == null) {
      translate = null;
    }
    doc = this.stripScripts(response);
    fragment = this.makeFragment(doc);
    if (fragment) {
      translate = fragment.querySelector('#translation ~ table');
      if (translate) {
        translate.className = this.TABLE_CLASS;
        translate.setAttribute("cellpadding", "5");
        this.fixImages(translate);
        this.fixLinks(translate);
      } else if (!silent) {
        translate = document.createElement('div');
        translate.className = 'failTranslate';
        translate.innerText = "Unfortunately, could not translate";
      }
    }
    return translate;
  };


  /*
    Strip script tags from response html
   */

  Tran.prototype.stripScripts = function(s) {
    var div, i, scripts;
    div = document.createElement('div');
    div.innerHTML = s;
    scripts = div.getElementsByTagName('script');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
    return div.innerHTML;
  };

  Tran.prototype.makeFragment = function(doc, fragment) {
    var div;
    if (fragment == null) {
      fragment = null;
    }
    div = document.createElement("div");
    div.innerHTML = doc;
    fragment = document.createDocumentFragment();
    while (div.firstChild) {
      fragment.appendChild(div.firstChild);
    }
    return fragment;
  };

  Tran.prototype.fixImages = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'img', 'src');
    return fragment;
  };

  Tran.prototype.fixLinks = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'a', 'href');
    return fragment;
  };

  Tran.prototype.fixUrl = function(fragment, tag, attr) {
    var parser, tags, _i, _len, _results;
    if (fragment == null) {
      fragment = null;
    }
    if (fragment) {
      tags = fragment.querySelectorAll(tag);
      parser = document.createElement('a');
      _results = [];
      for (_i = 0, _len = tags.length; _i < _len; _i++) {
        tag = tags[_i];
        parser.href = tag[attr];
        parser.host = this.host;
        parser.protocol = this.protocol;
        if (tag.tagName === 'A') {
          tag.classList.add('mtt_link');
          if (parser.pathname.indexOf('m.exe') !== -1) {
            parser.pathname = '/c' + parser.pathname;
            tag.setAttribute('target', '_blank');
          }
        } else if (tag.tagName === 'IMG') {
          tag.classList.add('mtt_img');
        }
        _results.push(tag.setAttribute(attr, parser.href));
      }
      return _results;
    }
  };

  return Tran;

})();

module.exports = new Tran;


},{"./char-codes.js":3}],5:[function(require,module,exports){
/*
  Translation engine: http://www.turkishdictionary.net
  For translating turkish-russian and vice versa
*/
'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var CHAR_CODES = require('./char-codes-turk.js');

var TurkishDictionary = (function () {
  function TurkishDictionary() {
    _classCallCheck(this, TurkishDictionary);

    this.host = 'http://www.turkishdictionary.net/?word=%FC';
    this.path = '';
    this.protocol = 'http';
    this.query = '&s=';
    this.TABLE_CLASS = '___mtt_translate_table';
    // this flag indicates that if translation was successful then publish it all over extension
    this.need_publish = true;
  }

  // Singletone

  _createClass(TurkishDictionary, [{
    key: 'search',
    value: function search(data) {
      data.url = this.makeUrl(data.value);
      this.need_publish = false;
      return this.request(data);
    }
  }, {
    key: 'translate',
    value: function translate(data) {
      data.url = this.makeUrl(data.selectionText);
      this.need_publish = true;
      this.request(data);
    }
  }, {
    key: 'makeUrl',
    value: function makeUrl(text) {
      var text = this.getEncodedValue(text);
      return ['http://www.turkishdictionary.net/?word=', text].join('');
    }

    // Replace special language characters to html codes
  }, {
    key: 'getEncodedValue',
    value: function getEncodedValue(value) {
      // to find spec symbols we first encode them (raw search for that symbol doesn't wor)
      return encodeURIComponent(value);
      //return this.makeStringTransferable(value);
    }

    /** converting script from the turkishdict */
  }, {
    key: 'makeStringTransferable',
    value: function makeStringTransferable(inputText) {
      var text = "";
      if (inputText.length > 0) {
        text = inputText;
        for (var i = 0; i < text.length; i++) {
          if (CHAR_CODES[text.charCodeAt(i)]) {
            text = text.substring(0, i) + CHAR_CODES[text.charCodeAt(i)] + text.substring(i + 1, text.length);
          } else if (text.charAt(i) == ' ') {
            // replace spaces
            text = text.substring(0, i) + '___' + text.substring(i + 1, text.length);
          }
        }
      }
      return text;
    }

    /*
      Request translation and run callback function
      passing translated result or error to callback
    */
  }, {
    key: 'request',
    value: function request(opts) {
      console.log('start request');
      this.xhr = new XMLHttpRequest();
      this.xhr.onreadystatechange = this.onReadyStateChange.bind(this, opts);
      this.xhr.open("GET", opts.url, true);
      this.xhr.send();
    }
  }, {
    key: 'onReadyStateChange',
    value: function onReadyStateChange(opts, e) {
      var xhr = this.xhr;
      if (xhr.readyState < 4) {
        return;
      } else if (xhr.status != 200) {
        this.errorHandler(xhr);
        return opts.error && opts.error();
      } else if (xhr.readyState == 4) {
        var translation = this.successHandler(e.target.response);
        console.log('success turkish translate', translation);
        console.log('call', opts.success);
        return opts.success && opts.success(translation);
      }
    }
  }, {
    key: 'successHandler',
    value: function successHandler(response) {
      var data = this.parse(response);
      if (this.need_publish) {
        chrome.tabs.getSelected(null, this.publishTranslation.bind(this, data));
      }
      return data;
    }

    /* publish successfuly translated text all over extension */
  }, {
    key: 'publishTranslation',
    value: function publishTranslation(translation, tab) {
      console.log('publish translation');
      chrome.tabs.sendMessage(tab.id, {
        action: this.tooltipAction(translation),
        data: translation.outerHTML,
        success: !translation.classList.contains('failTranslate')
      });
    }
  }, {
    key: 'tooltipAction',
    value: function tooltipAction(translation) {
      if (translation.textContent.trim().indexOf('was not found in our dictionary') != -1) {
        console.log('similar words');
        return 'similar_words';
      } else {
        console.log('open tooltip');
        return 'open_tooltip';
      }
    }
  }, {
    key: 'errorHandler',
    value: function errorHandler(response) {
      console.log('error ajax', response);
    }

    /* Parse response from translation engine */
  }, {
    key: 'parse',
    value: function parse(response, silent, translate) {
      var doc = this.stripScripts(response),
          fragment = this.makeFragment(doc);
      if (fragment) {
        translate = fragment.querySelector('#meaning_div > table');
        if (translate) {
          translate.className = this.TABLE_CLASS;
          translate.setAttribute("cellpadding", "5");
          // @fixImages(translate)
          // @fixLinks(translate)
        } else if (!silent) {
            translate = document.createElement('div');
            translate.className = 'failTranslate';
            translate.innerText = "Unfortunately, could not translate";
          }
      }
      return translate;
    }

    /** parsing of terrible html markup */
  }, {
    key: 'parseText',
    value: function parseText(response, silent, translate) {
      var _this = this;

      var doc = this.stripScripts(response),
          fragment = this.makeFragment(doc);

      if (fragment) {
        var i;

        var _ret = (function () {
          var stopIndex = null;
          var tr = fragment.querySelectorAll('#meaning_div>table>tbody>tr');
          tr = Array.prototype.slice.call(tr);

          var trans = tr.filter(function (tr, index) {
            if (!isNaN(parseInt(stopIndex, 10)) && index >= stopIndex) {
              return;
            } else {
              tr = $(tr);
              // take every row before next section (which is English->English)
              if (tr.attr('bgcolor') == "e0e6ff") {
                stopIndex = index;return;
              } else {
                return $.trim(tr.find('td').text()).length;
              }
            }
          });
          trans = trans.slice(1, trans.length - 1);
          trans = trans.filter(function (el, indx) {
            return indx % 2;
          });
          var frag = _this.fragmentFromList(trans);
          var fonts = frag.querySelectorAll('font');
          var text = '';
          for (i = 0; i < fonts.length; i++) {
            text += ' ' + fonts[i].textContent.trim();
          }
          return {
            v: text
          };
        })();

        if (typeof _ret === 'object') return _ret.v;
      } else {
        throw "HTML fragment could not be parsed";
      }
    }

    //TODO extract to base engine class
    /* removes <script> tags from html code */
  }, {
    key: 'stripScripts',
    value: function stripScripts(html) {
      var div = document.createElement('div');
      div.innerHTML = html;
      var scripts = div.getElementsByTagName('script');
      var i = scripts.length;
      while (i--) scripts[i].parentNode.removeChild(scripts[i]);
      return div.innerHTML;
    }

    //TODO extract to base engine class
    /* creates temp object to parse translation from page 
      (since it's not a friendly api) 
    */
  }, {
    key: 'makeFragment',
    value: function makeFragment(html) {
      var fragment = document.createDocumentFragment(),
          div = document.createElement("div");
      div.innerHTML = html;
      while (div.firstChild) {
        fragment.appendChild(div.firstChild);
      }
      return fragment;
    }

    /** create fragment from list of DOM elements */
  }, {
    key: 'fragmentFromList',
    value: function fragmentFromList(list) {
      var fragment = document.createDocumentFragment(),
          len = list.length;
      while (len--) {
        fragment.appendChild(list[len]);
      }
      return fragment;
    }
  }]);

  return TurkishDictionary;
})();

module.exports = new TurkishDictionary();
//# sourceMappingURL=turkishdictionary.js.map

},{"./char-codes-turk.js":2}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0Rldi90cmFuL25vZGVfbW9kdWxlcy9ncnVudC1icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCIvVXNlcnMvYW50aG9ueS9EZXYvdHJhbi9qcy9lczUvYmFja2dyb3VuZC5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXYvdHJhbi9qcy9lczUvY2hhci1jb2Rlcy10dXJrLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2L3RyYW4vanMvZXM1L2NoYXItY29kZXMuanMiLCIvVXNlcnMvYW50aG9ueS9EZXYvdHJhbi9qcy9lczUvdHJhbi5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXYvdHJhbi9qcy9lczUvdHVya2lzaGRpY3Rpb25hcnkuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUFBLHdCQUFBO0FBQUEsSUFBQSxtQ0FBQTs7QUFBQSxVQUdBLEdBQWEsT0FBQSxDQUFRLGlCQUFSLENBSGIsQ0FBQTs7QUFBQSxJQUtBLEdBQU8sT0FBQSxDQUFRLGVBQVIsQ0FMUCxDQUFBOztBQUFBLGlCQU1BLEdBQW9CLE9BQUEsQ0FBUSx3QkFBUixDQU5wQixDQUFBOztBQUFBLE1BU00sQ0FBQyxZQUFZLENBQUMsTUFBcEIsQ0FDRTtBQUFBLEVBQUEsS0FBQSxFQUFRLGlCQUFSO0FBQUEsRUFDQSxRQUFBLEVBQVUsQ0FBQyxVQUFELEVBQWEsV0FBYixDQURWO0FBQUEsRUFFQSxPQUFBLEVBQVUsU0FBQyxJQUFELEdBQUE7QUFDUixJQUFBLElBQUksQ0FBQyxNQUFMLEdBQWMsS0FBZCxDQUFBO1dBQ0EsSUFBSSxDQUFDLEtBQUwsQ0FBVyxJQUFYLEVBRlE7RUFBQSxDQUZWO0NBREYsQ0FUQSxDQUFBOztBQWlCQTtBQUFBOzs7O0dBakJBOztBQUFBLE1Bc0JNLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxXQUF6QixDQUFxQyxTQUFDLE9BQUQsRUFBVSxNQUFWLEVBQWtCLFlBQWxCLEdBQUE7QUFDbkMsRUFBQSxJQUFHLE9BQU8sQ0FBQyxNQUFSLEtBQWtCLGlCQUFyQjtBQUNFLElBQUEsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBcEIsQ0FBd0I7QUFBQSxNQUFBLElBQUEsRUFBTSxJQUFOO0tBQXhCLEVBQW9DLFNBQUMsS0FBRCxHQUFBO2FBQ2hDLFlBQUEsQ0FBYTtBQUFBLFFBQUEsSUFBQSxFQUFNLEtBQUssQ0FBQyxJQUFaO09BQWIsRUFEZ0M7SUFBQSxDQUFwQyxDQUFBLENBREY7R0FBQSxNQU9LLElBQUcsT0FBTyxDQUFDLE1BQVIsS0FBa0IsZ0JBQXJCO0FBQ0gsSUFBQSxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUUsUUFBQSxFQUFVLEdBQVo7QUFBQSxNQUFpQixJQUFBLEVBQU0sSUFBdkI7S0FBeEIsRUFBc0QsU0FBQyxLQUFELEdBQUE7QUFDcEQsTUFBQSxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQWIsR0FBc0IsSUFBdEIsQ0FBQTtBQUNBLE1BQUEsSUFBRyxRQUFBLENBQVMsS0FBSyxDQUFDLFFBQWYsRUFBd0IsRUFBeEIsQ0FBQSxLQUErQixJQUFsQztBQUNFLFFBQUEsaUJBQWlCLENBQUMsU0FBbEIsQ0FBNEIsT0FBTyxDQUFDLElBQXBDLENBQUEsQ0FERjtPQUFBLE1BQUE7QUFHRSxRQUFBLElBQUksQ0FBQyxLQUFMLENBQVcsT0FBTyxDQUFDLElBQW5CLENBQUEsQ0FIRjtPQURBO0FBS0EsYUFBTyxJQUFQLENBTm9EO0lBQUEsQ0FBdEQsQ0FBQSxDQURHO0dBUEw7U0FnQkEsS0FqQm1DO0FBQUEsQ0FBckMsQ0F0QkEsQ0FBQTs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzNCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2xGQTtBQUFBLGtCQUFBO0FBQ0E7QUFBQTs7Ozs7Ozs7OztHQURBO0FBQUEsSUFBQSxnQkFBQTs7QUFBQSxVQWFBLEdBQWEsT0FBQSxDQUFRLGlCQUFSLENBYmIsQ0FBQTs7QUFBQTtBQWdCZSxFQUFBLGNBQUEsR0FBQTtBQUNYLElBQUEsSUFBQyxDQUFBLFdBQUQsR0FBZSx3QkFBZixDQUFBO0FBQUEsSUFDQSxJQUFDLENBQUEsUUFBRCxHQUFZLE1BRFosQ0FBQTtBQUFBLElBRUEsSUFBQyxDQUFBLElBQUQsR0FBUSxrQkFGUixDQUFBO0FBQUEsSUFHQSxJQUFDLENBQUEsSUFBRCxHQUFRLFVBSFIsQ0FBQTtBQUFBLElBSUEsSUFBQyxDQUFBLEtBQUQsR0FBUyxLQUpULENBQUE7QUFBQSxJQUtBLElBQUMsQ0FBQSxJQUFELEdBQVEsWUFMUixDQUFBO0FBQUEsSUFNQSxJQUFDLENBQUEsR0FBRCxHQUFPLEVBTlAsQ0FEVztFQUFBLENBQWI7O0FBU0E7QUFBQTs7S0FUQTs7QUFBQSxpQkFZQSxLQUFBLEdBQU8sU0FBQyxJQUFELEdBQUE7QUFDTCxRQUFBLGFBQUE7QUFBQSxJQUFBLElBQUcsTUFBQSxDQUFBLElBQVcsQ0FBQyxNQUFaLEtBQXNCLE1BQXRCLElBQW1DLElBQUksQ0FBQyxNQUFMLEtBQWUsSUFBckQ7QUFDRSxNQUFBLElBQUksQ0FBQyxNQUFMLEdBQWMsSUFBZCxDQURGO0tBQUE7QUFBQSxJQUVBLGFBQUEsR0FBZ0IsSUFBQyxDQUFBLGlCQUFELENBQW1CLElBQUksQ0FBQyxhQUF4QixDQUZoQixDQUFBO1dBR0EsSUFBQyxDQUFBLE1BQUQsQ0FDSTtBQUFBLE1BQUEsS0FBQSxFQUFPLGFBQVA7QUFBQSxNQUNBLE9BQUEsRUFBUyxJQUFDLENBQUEsZUFBZSxDQUFDLElBQWpCLENBQXNCLElBQXRCLENBRFQ7QUFBQSxNQUVBLE1BQUEsRUFBUSxJQUFJLENBQUMsTUFGYjtLQURKLEVBSks7RUFBQSxDQVpQLENBQUE7O0FBcUJBO0FBQUE7O0tBckJBOztBQUFBLGlCQXdCQSxpQkFBQSxHQUFtQixTQUFDLElBQUQsR0FBQTtXQUNqQixJQUFJLENBQUMsT0FBTCxDQUFhLE9BQWIsRUFBc0IsRUFBdEIsRUFEaUI7RUFBQSxDQXhCbkIsQ0FBQTs7QUEyQkE7QUFBQTs7S0EzQkE7O0FBQUEsaUJBOEJBLE1BQUEsR0FBUSxTQUFDLE1BQUQsR0FBQTtXQUVOLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsTUFBQyxRQUFBLEVBQVUsR0FBWDtLQUF4QixFQUF5QyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxLQUFELEdBQUE7QUFDdkMsWUFBQSwwQkFBQTtBQUFBLFFBQUEsSUFBRyxRQUFBLEtBQVksRUFBZjtBQUNFLFVBQUEsUUFBQSxHQUFXLEdBQVgsQ0FERjtTQUFBO0FBQUEsUUFFQSxLQUFDLENBQUEsV0FBRCxDQUFhLEtBQUssQ0FBQyxRQUFuQixDQUZBLENBQUE7QUFBQSxRQUdBLEdBQUEsR0FBTSxLQUFDLENBQUEsT0FBRCxDQUFTLE1BQU0sQ0FBQyxLQUFoQixDQUhOLENBQUE7QUFBQSxRQUtBLFdBQUEsR0FBYyxNQUFNLENBQUMsT0FMckIsQ0FBQTtBQUFBLFFBTUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsU0FBQyxRQUFELEdBQUE7QUFDZixjQUFBLFVBQUE7QUFBQSxVQUFBLFVBQUEsR0FBYSxLQUFDLENBQUEsS0FBRCxDQUFPLFFBQVAsRUFBaUIsTUFBTSxDQUFDLE1BQXhCLENBQWIsQ0FBQTtpQkFDQSxXQUFBLENBQVksVUFBWixFQUZlO1FBQUEsQ0FOakIsQ0FBQTtlQVdBLEtBQUMsQ0FBQSxPQUFELENBQ0U7QUFBQSxVQUFBLEdBQUEsRUFBSyxHQUFMO0FBQUEsVUFDQSxPQUFBLEVBQVMsTUFBTSxDQUFDLE9BRGhCO0FBQUEsVUFFQSxLQUFBLEVBQU8sTUFBTSxDQUFDLEtBRmQ7U0FERixFQVp1QztNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpDLEVBRk07RUFBQSxDQTlCUixDQUFBOztBQUFBLGlCQW1EQSxXQUFBLEdBQWEsU0FBQyxRQUFELEdBQUE7QUFDWCxJQUFBLElBQUMsQ0FBQSxlQUFELEdBQW1CLFFBQW5CLENBQUE7V0FDQSxJQUFDLENBQUEsSUFBRCxHQUFRLFdBQUEsR0FBYyxTQUZYO0VBQUEsQ0FuRGIsQ0FBQTs7QUF1REE7QUFBQTs7O0tBdkRBOztBQUFBLGlCQTJEQSxPQUFBLEdBQVMsU0FBQyxJQUFELEdBQUE7QUFDUCxRQUFBLEdBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxJQUFDLENBQUEsR0FBRCxHQUFXLElBQUEsY0FBQSxDQUFBLENBQWpCLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxrQkFBSixHQUF5QixDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7QUFDdkIsUUFBQSxHQUFBLEdBQU0sS0FBQyxDQUFBLEdBQVAsQ0FBQTtBQUNBLFFBQUEsSUFBRyxHQUFHLENBQUMsVUFBSixHQUFpQixDQUFwQjtBQUFBO1NBQUEsTUFFSyxJQUFHLEdBQUcsQ0FBQyxNQUFKLEtBQWMsR0FBakI7QUFDSCxVQUFBLEtBQUMsQ0FBQSxZQUFELENBQWMsR0FBZCxDQUFBLENBQUE7QUFDQSxVQUFBLElBQUksTUFBQSxDQUFBLElBQVcsQ0FBQyxLQUFaLEtBQXFCLFVBQXpCO0FBQ0UsWUFBQSxJQUFJLENBQUMsS0FBTCxDQUFBLENBQUEsQ0FERjtXQUZHO1NBQUEsTUFLQSxJQUFHLEdBQUcsQ0FBQyxVQUFKLEtBQWtCLENBQXJCO0FBQ0QsaUJBQU8sSUFBSSxDQUFDLE9BQUwsQ0FBYSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQXRCLENBQVAsQ0FEQztTQVRrQjtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRHpCLENBQUE7QUFBQSxJQWFBLEdBQUcsQ0FBQyxJQUFKLENBQVMsS0FBVCxFQUFnQixJQUFJLENBQUMsR0FBckIsRUFBMEIsSUFBMUIsQ0FiQSxDQUFBO1dBY0EsR0FBRyxDQUFDLElBQUosQ0FBQSxFQWZPO0VBQUEsQ0EzRFQsQ0FBQTs7QUFBQSxpQkE2RUEsT0FBQSxHQUFTLFNBQUMsS0FBRCxHQUFBO0FBQ1AsUUFBQSxHQUFBO0FBQUEsSUFBQSxHQUFBLEdBQU0sQ0FBQyxJQUFDLENBQUEsUUFBRixFQUFZLEtBQVosRUFDSSxJQUFDLENBQUEsSUFETCxFQUVJLElBQUMsQ0FBQSxJQUZMLEVBR0ksSUFBQyxDQUFBLElBSEwsRUFJSSxJQUFDLENBQUEsS0FKTCxFQUtJLElBQUMsQ0FBQSxlQUFELENBQWlCLEtBQWpCLENBTEosQ0FNQyxDQUFDLElBTkYsQ0FNTyxFQU5QLENBQU4sQ0FBQTtBQVFBLFdBQU8sR0FBUCxDQVRPO0VBQUEsQ0E3RVQsQ0FBQTs7QUFBQSxpQkF5RkEsZUFBQSxHQUFpQixTQUFDLEtBQUQsR0FBQTtBQUVmLFFBQUEsbUJBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxrQkFBQSxDQUFtQixLQUFuQixDQUFOLENBQUE7QUFDQSxTQUFBLGtCQUFBOzhCQUFBO0FBQ0UsTUFBQSxJQUFHLE1BQUEsQ0FBQSxJQUFBLEtBQWUsUUFBbEI7QUFFRSxRQUFBLEVBQUEsR0FBSyxJQUFJLENBQUMsR0FBVixDQUZGO09BQUEsTUFBQTtBQU1FLFFBQUEsRUFBQSxHQUFLLGtCQUFBLENBQW1CLElBQW5CLENBQUwsQ0FORjtPQUFBO0FBQUEsTUFPQSxHQUFBLEdBQU0sR0FBRyxDQUFDLE9BQUosQ0FBWSxJQUFaLEVBQWtCLEVBQWxCLENBUE4sQ0FERjtBQUFBLEtBREE7QUFVQSxXQUFPLEdBQVAsQ0FaZTtFQUFBLENBekZqQixDQUFBOztBQUFBLGlCQXVHQSxZQUFBLEdBQWMsU0FBQyxHQUFELEdBQUE7V0FDWixPQUFPLENBQUMsR0FBUixDQUFZLE9BQVosRUFBcUIsR0FBckIsRUFEWTtFQUFBLENBdkdkLENBQUE7O0FBMEdBO0FBQUE7O0tBMUdBOztBQUFBLGlCQTZHQSxlQUFBLEdBQWlCLFNBQUMsVUFBRCxHQUFBO0FBQ2YsSUFBQSxJQUFHLFVBQUg7YUFDRSxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVosQ0FBd0IsSUFBeEIsRUFBOEIsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsR0FBRCxHQUFBO2lCQUM1QixNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVosQ0FBd0IsR0FBRyxDQUFDLEVBQTVCLEVBQWdDO0FBQUEsWUFDOUIsTUFBQSxFQUFRLEtBQUMsQ0FBQSxXQUFELENBQWEsVUFBYixDQURzQjtBQUFBLFlBRTlCLElBQUEsRUFBTSxVQUFVLENBQUMsU0FGYTtBQUFBLFlBRzlCLE9BQUEsRUFBUyxDQUFBLFVBQVcsQ0FBQyxTQUFTLENBQUMsUUFBckIsQ0FBOEIsZUFBOUIsQ0FIb0I7V0FBaEMsRUFENEI7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUE5QixFQURGO0tBRGU7RUFBQSxDQTdHakIsQ0FBQTs7QUFBQSxpQkF1SEEsV0FBQSxHQUFhLFNBQUMsVUFBRCxHQUFBO0FBQ1gsUUFBQSxJQUFBO0FBQUEsSUFBQSxpRUFBbUIsQ0FBRSx5QkFBbEIsS0FBNEIsQ0FBL0I7YUFDRSxnQkFERjtLQUFBLE1BQUE7YUFHRSxlQUhGO0tBRFc7RUFBQSxDQXZIYixDQUFBOztBQTZIQTtBQUFBOztLQTdIQTs7QUFBQSxpQkFnSUEsS0FBQSxHQUFPLFNBQUMsUUFBRCxFQUFXLE1BQVgsRUFBbUIsU0FBbkIsR0FBQTtBQUNILFFBQUEsYUFBQTs7TUFEc0IsWUFBWTtLQUNsQztBQUFBLElBQUEsR0FBQSxHQUFNLElBQUMsQ0FBQSxZQUFELENBQWMsUUFBZCxDQUFOLENBQUE7QUFBQSxJQUNBLFFBQUEsR0FBVyxJQUFDLENBQUEsWUFBRCxDQUFjLEdBQWQsQ0FEWCxDQUFBO0FBRUEsSUFBQSxJQUFHLFFBQUg7QUFDRSxNQUFBLFNBQUEsR0FBWSxRQUFRLENBQUMsYUFBVCxDQUF1QixzQkFBdkIsQ0FBWixDQUFBO0FBQ0EsTUFBQSxJQUFHLFNBQUg7QUFDRSxRQUFBLFNBQVMsQ0FBQyxTQUFWLEdBQXNCLElBQUMsQ0FBQSxXQUF2QixDQUFBO0FBQUEsUUFDQSxTQUFTLENBQUMsWUFBVixDQUF1QixhQUF2QixFQUFzQyxHQUF0QyxDQURBLENBQUE7QUFBQSxRQUVBLElBQUMsQ0FBQSxTQUFELENBQVcsU0FBWCxDQUZBLENBQUE7QUFBQSxRQUdBLElBQUMsQ0FBQSxRQUFELENBQVUsU0FBVixDQUhBLENBREY7T0FBQSxNQUtLLElBQUcsQ0FBQSxNQUFIO0FBQ0gsUUFBQSxTQUFBLEdBQVksUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBWixDQUFBO0FBQUEsUUFDQSxTQUFTLENBQUMsU0FBVixHQUFzQixlQUR0QixDQUFBO0FBQUEsUUFFQSxTQUFTLENBQUMsU0FBVixHQUFzQixvQ0FGdEIsQ0FERztPQVBQO0tBRkE7QUFjQSxXQUFPLFNBQVAsQ0FmRztFQUFBLENBaElQLENBQUE7O0FBaUpBO0FBQUE7O0tBakpBOztBQUFBLGlCQW9KQSxZQUFBLEdBQWMsU0FBQyxDQUFELEdBQUE7QUFDWixRQUFBLGVBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFOLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxTQUFKLEdBQWdCLENBRGhCLENBQUE7QUFBQSxJQUVBLE9BQUEsR0FBVSxHQUFHLENBQUMsb0JBQUosQ0FBeUIsUUFBekIsQ0FGVixDQUFBO0FBQUEsSUFHQSxDQUFBLEdBQUksT0FBTyxDQUFDLE1BSFosQ0FBQTtBQUlBLFdBQU0sQ0FBQSxFQUFOLEdBQUE7QUFDRSxNQUFBLE9BQVEsQ0FBQSxDQUFBLENBQUUsQ0FBQyxVQUFVLENBQUMsV0FBdEIsQ0FBa0MsT0FBUSxDQUFBLENBQUEsQ0FBMUMsQ0FBQSxDQURGO0lBQUEsQ0FKQTtBQU1BLFdBQU8sR0FBRyxDQUFDLFNBQVgsQ0FQWTtFQUFBLENBcEpkLENBQUE7O0FBQUEsaUJBNkpBLFlBQUEsR0FBYyxTQUFDLEdBQUQsRUFBTSxRQUFOLEdBQUE7QUFDWixRQUFBLEdBQUE7O01BRGtCLFdBQVc7S0FDN0I7QUFBQSxJQUFBLEdBQUEsR0FBTSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFOLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxTQUFKLEdBQWdCLEdBRGhCLENBQUE7QUFBQSxJQUVBLFFBQUEsR0FBVyxRQUFRLENBQUMsc0JBQVQsQ0FBQSxDQUZYLENBQUE7QUFHQSxXQUFRLEdBQUcsQ0FBQyxVQUFaLEdBQUE7QUFDRSxNQUFBLFFBQVEsQ0FBQyxXQUFULENBQXNCLEdBQUcsQ0FBQyxVQUExQixDQUFBLENBREY7SUFBQSxDQUhBO0FBS0EsV0FBTyxRQUFQLENBTlk7RUFBQSxDQTdKZCxDQUFBOztBQUFBLGlCQXFLQSxTQUFBLEdBQVcsU0FBQyxRQUFELEdBQUE7O01BQUMsV0FBUztLQUNuQjtBQUFBLElBQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxRQUFaLEVBQXNCLEtBQXRCLEVBQTZCLEtBQTdCLENBQUEsQ0FBQTtBQUNBLFdBQU8sUUFBUCxDQUZTO0VBQUEsQ0FyS1gsQ0FBQTs7QUFBQSxpQkF5S0EsUUFBQSxHQUFVLFNBQUMsUUFBRCxHQUFBOztNQUFDLFdBQVM7S0FDbEI7QUFBQSxJQUFBLElBQUksQ0FBQyxNQUFMLENBQVksUUFBWixFQUFzQixHQUF0QixFQUEyQixNQUEzQixDQUFBLENBQUE7QUFDQSxXQUFPLFFBQVAsQ0FGUTtFQUFBLENBektWLENBQUE7O0FBQUEsaUJBNktBLE1BQUEsR0FBUSxTQUFDLFFBQUQsRUFBZ0IsR0FBaEIsRUFBcUIsSUFBckIsR0FBQTtBQUNOLFFBQUEsZ0NBQUE7O01BRE8sV0FBUztLQUNoQjtBQUFBLElBQUEsSUFBRyxRQUFIO0FBQ0UsTUFBQSxJQUFBLEdBQVEsUUFBUSxDQUFDLGdCQUFULENBQTBCLEdBQTFCLENBQVIsQ0FBQTtBQUFBLE1BQ0EsTUFBQSxHQUFTLFFBQVEsQ0FBQyxhQUFULENBQXVCLEdBQXZCLENBRFQsQ0FBQTtBQUVBO1dBQUEsMkNBQUE7dUJBQUE7QUFDRSxRQUFBLE1BQU0sQ0FBQyxJQUFQLEdBQWMsR0FBSSxDQUFBLElBQUEsQ0FBbEIsQ0FBQTtBQUFBLFFBQ0EsTUFBTSxDQUFDLElBQVAsR0FBYyxJQUFDLENBQUEsSUFEZixDQUFBO0FBQUEsUUFFQSxNQUFNLENBQUMsUUFBUCxHQUFrQixJQUFDLENBQUEsUUFGbkIsQ0FBQTtBQUlBLFFBQUEsSUFBRyxHQUFHLENBQUMsT0FBSixLQUFlLEdBQWxCO0FBQ0UsVUFBQSxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQWQsQ0FBa0IsVUFBbEIsQ0FBQSxDQUFBO0FBQ0EsVUFBQSxJQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBaEIsQ0FBd0IsT0FBeEIsQ0FBQSxLQUFzQyxDQUFBLENBQXpDO0FBQ0UsWUFBQSxNQUFNLENBQUMsUUFBUCxHQUFrQixJQUFBLEdBQU8sTUFBTSxDQUFDLFFBQWhDLENBQUE7QUFBQSxZQUNBLEdBQUcsQ0FBQyxZQUFKLENBQWlCLFFBQWpCLEVBQTJCLFFBQTNCLENBREEsQ0FERjtXQUZGO1NBQUEsTUFLSyxJQUFHLEdBQUcsQ0FBQyxPQUFKLEtBQWUsS0FBbEI7QUFDSCxVQUFBLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBZCxDQUFrQixTQUFsQixDQUFBLENBREc7U0FUTDtBQUFBLHNCQVlBLEdBQUcsQ0FBQyxZQUFKLENBQWlCLElBQWpCLEVBQXVCLE1BQU0sQ0FBQyxJQUE5QixFQVpBLENBREY7QUFBQTtzQkFIRjtLQURNO0VBQUEsQ0E3S1IsQ0FBQTs7Y0FBQTs7SUFoQkYsQ0FBQTs7QUFBQSxNQWtOTSxDQUFDLE9BQVAsR0FBaUIsR0FBQSxDQUFBLElBbE5qQixDQUFBOzs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3Rocm93IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIil9dmFyIGY9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGYuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sZixmLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIiMjI2dsb2JhbCB0cmFuLCBjaHJvbWUjIyNcblxuI2xvYWQgZW5naW5lc1xuQ0hBUl9DT0RFUyA9IHJlcXVpcmUoJy4vY2hhci1jb2Rlcy5qcycpO1xuXG50cmFuID0gcmVxdWlyZSgnLi90cmFuLmNvZmZlZScpICAgICAgICAgICAgICAgICAgICAgICAgICAgICAjIG11bHRpdHJhbi5ydVxudHVya2lzaERpY3Rpb25hcnkgPSByZXF1aXJlKCcuL3R1cmtpc2hkaWN0aW9uYXJ5LmpzJykgICAjIHR1cmtpc2hkaWN0aW9uYXJ5Lm5ldFxuXG4jZ2VuZXJhdGVzIGEgY29udGV4dCBtZW51XG5jaHJvbWUuY29udGV4dE1lbnVzLmNyZWF0ZShcbiAgdGl0bGU6ICAnTXVsdGl0cmFuOiBcIiVzXCInXG4gIGNvbnRleHRzOiBbXCJlZGl0YWJsZVwiLCBcInNlbGVjdGlvblwiXVxuICBvbmNsaWNrOiAgKGRhdGEpIC0+XG4gICAgZGF0YS5zaWxlbnQgPSBmYWxzZVxuICAgIHRyYW4uY2xpY2soZGF0YSlcbilcblxuIyMjXG4gQ2FuJ3QgZ2V0IGNocm9tZS5zdG9yYWdlIGRpcmVjdGx5IGZyb20gY29udGVudF9zY3JpcHRcbiBzbyBjb250ZW50X3NjcmlwdCBzZW5kcyByZXF1ZXN0IG1lc3NhZ2UgYW5kIHRoZW4gYmFja2dyb3VuZCBzY3JpcHRcbiByZXNwb25kcyB3aXRoIHN0b3JhZ2UgdmFsdWVcbiMjI1xuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyIChyZXF1ZXN0LCBzZW5kZXIsIHNlbmRSZXNwb25zZSkgLT5cbiAgaWYgcmVxdWVzdC5tZXRob2QgPT0gXCJnZXRfZmFzdF9vcHRpb25cIlxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KGZhc3Q6IHRydWUsIChpdGVtcykgLT5cbiAgICAgICAgc2VuZFJlc3BvbnNlKGZhc3Q6IGl0ZW1zLmZhc3QpXG4gICAgICAgICNyZXR1cm4gdHJ1ZVxuICAgIClcbiAgI0Zhc3QgdHJhbnNsYXRpb24gaW5pdGlhdGUgc2VhcmNoIHdpdGggJ3JlcXVlc3Rfc2VhcmNoJyBtZXNzYWdlIGZyb21cbiAgI2NvbnRlbnRfc2NyaXB0XG4gIGVsc2UgaWYgcmVxdWVzdC5tZXRob2QgPT0gJ3JlcXVlc3Rfc2VhcmNoJ1xuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHsgbGFuZ3VhZ2U6ICcxJywgZmFzdDogdHJ1ZX0sIChpdGVtcykgLT5cbiAgICAgIHJlcXVlc3QuZGF0YS5zaWxlbnQgPSB0cnVlXG4gICAgICBpZiBwYXJzZUludChpdGVtcy5sYW5ndWFnZSwxMCkgPT0gMTAwMFxuICAgICAgICB0dXJraXNoRGljdGlvbmFyeS50cmFuc2xhdGUocmVxdWVzdC5kYXRhKVxuICAgICAgZWxzZVxuICAgICAgICB0cmFuLmNsaWNrKHJlcXVlc3QuZGF0YSlcbiAgICAgIHJldHVybiB0cnVlXG4gICAgKVxuICB0cnVlXG5cbiIsIi8vIHR1cmtpc2hkaWN0aW9uYXJ5IGNvZGluZ3Ncbid1c2Ugc3RyaWN0JztcblxudmFyIERJQ1QgPSB7XG4gICAgMzUwOiAnJURFJywgLy/FnlxuICAgIDI4NjogJyVEMCcsIC8vxJ5cbiAgICAyODc6ICclRjAnLCAvL8SfXG4gICAgMzUxOiAnJUZFJywgLy/Fn1xuICAgIDMwNTogJyVGRCcsIC8vxLFcbiAgICAzMDQ6ICclREQnLCAvL8SwXG4gICAgMjUyOiAnJUZDJywgLy/DvFxuICAgIDIyMDogJyVEQycsIC8vw5xcbiAgICAyMzE6ICclRTcnLCAvL8OnXG4gICAgMTk5OiAnJUM3JywgLy/Dh1xuICAgIDI0NjogJyVGNicsIC8vw7ZcbiAgICAyNDQ6ICclRjQnLCAvL8O0XG4gICAgMjE0OiAnJUQ2JywgLy/DllxuICAgIDIxMjogJyVENCcsIC8vw5RcbiAgICAyNTE6ICclRkInLCAvL8O7XG4gICAgMjE5OiAnJURCJywgLy/Dm1xuICAgIDE5NDogJyVDMicsIC8vw4JcbiAgICAyMjY6ICclRTInLCAvL8OiXG4gICAgMzk6ICcnIH07XG5cbi8vJ1xubW9kdWxlLmV4cG9ydHMgPSBESUNUO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y2hhci1jb2Rlcy10dXJrLmpzLm1hcFxuIiwiLypcciAgTXVsdGl0cmFuIGRlcGVuZHMgb24gaHRtbC1lc2NhcGluZyAobm90IFVURi04KSBydWxlcyBmb3Igc3BlY2lhbCBzeW1ib2xzXHIgIMOgLCDDqCwgw6wsIMOyLCDDuSAtIMOALCDDiCwgw4wsIMOSLCDDmVxyICDDoSwgw6ksIMOtLCDDsywgw7osIMO9IC0gw4EsIMOJLCDDjSwgw5MsIMOaLCDDnVxyICDDoiwgw6osIMOuLCDDtCwgw7sgw4IsIMOKLCDDjiwgw5QsIMObXHIgIMOjLCDDsSwgw7Ugw4MsIMORLCDDlVxyICDDpCwgw6ssIMOvLCDDtiwgw7wsIMO/IMOELCDDiywgw48sIMOWLCDDnCxcciAgw6UsIMOFXHIgIMOmLCDDhlxyICDDpywgw4dcciAgw7AsIMOQXHIgIMO4LCDDmFxyICDCvyDCoSDDn1xyKi9cbid1c2Ugc3RyaWN0JztcblxudmFyIENIQVJfQ09ERVMgPSB7XG4gIC8vcnVzc2lhblxuICAnJUQxJThBJzogeyB2YWw6ICclRkEnLCBsYW5nOiAncnUnIH0sIC8vINGKXG4gICclRDAlQUEnOiB7IHZhbDogJyVEQScsIGxhbmc6ICdydScgfSwgLy8g0KpcblxuICAnJUMzJTgwJzogJyYjMTkyOycsIC8vIMOAXG4gICclQzMlODEnOiAnJiMxOTM7JywgLy8gw4FcbiAgJyVDMyU4Mic6ICcmIzE5NDsnLCAvLyDDglxuICAnJUMzJTgzJzogJyYjMTk1OycsIC8vIMODXG4gICclQzMlODQnOiAnJiMxOTY7JywgLy8gw4RcbiAgJyVDMyU4NSc6ICcmIzE5NzsnLCAvLyDDhVxuICAnJUMzJTg2JzogJyYjMTk4OycsIC8vIMOGXG5cbiAgJyVDMyU4Nyc6ICcmIzE5OTsnLCAvLyDDh1xuICAnJUMzJTg4JzogJyYjMjAwOycsIC8vIMOIXG4gICclQzMlODknOiAnJiMyMDE7JywgLy8gw4lcbiAgJyVDMyU4QSc6ICcmIzIwMjsnLCAvLyDDilxuICAnJUMzJThCJzogJyYjMjAzOycsIC8vIMOLXG5cbiAgJyVDMyU4Qyc6ICcmIzIwNDsnLCAvLyDDjFxuICAnJUMzJThEJzogJyYjMjA1OycsIC8vIMONXG4gICclQzMlOEUnOiAnJiMyMDY7JywgLy8gw45cbiAgJyVDMyU4Ric6ICcmIzIwNzsnLCAvLyDDj1xuXG4gICclQzMlOTEnOiAnJiMyMDk7JywgLy8gw5FcbiAgJyVDMyU5Mic6ICcmIzIxMDsnLCAvLyDDklxuICAnJUMzJTkzJzogJyYjMjExOycsIC8vIMOTXG4gICclQzMlOTQnOiAnJiMyMTI7JywgLy8gw5RcbiAgJyVDMyU5NSc6ICcmIzIxMzsnLCAvLyDDlVxuICAnJUMzJTk2JzogJyYjMjE0OycsIC8vIMOWXG5cbiAgJyVDMyU5OSc6ICcmIzIxNzsnLCAvLyDDmVxuICAnJUMzJTlBJzogJyYjMjE4OycsIC8vIMOaXG4gICclQzMlOUInOiAnJiMyMTk7JywgLy8gw5tcbiAgJyVDMyU5Qyc6ICcmIzIyMDsnLCAvLyDDnFxuXG4gICclQzMlQTAnOiAnJiMyMjQ7JywgLy8gw6BcbiAgJyVDMyVBMSc6ICcmIzIyNTsnLCAvLyDDoVxuICAnJUMzJUEyJzogJyYjMjI2OycsIC8vIMOiXG4gICclQzMlQTMnOiAnJiMyMjc7JywgLy8gw6NcbiAgJyVDMyVBNCc6ICcmIzIyODsnLCAvLyDDpFxuICAnJUMzJUE1JzogJyYjMjI5OycsIC8vIMOlXG4gICclQzMlQTYnOiAnJiMyMzA7JywgLy8gw6ZcbiAgJyVDMyVBNyc6ICcmIzIzMTsnLCAvLyDDp1xuXG4gICclQzMlQTgnOiAnJiMyMzI7JywgLy8gw6hcbiAgJyVDMyVBOSc6ICcmIzIzMzsnLCAvLyDDqVxuICAnJUMzJUFBJzogJyYjMjM0OycsIC8vIMOqXG4gICclQzMlQUInOiAnJiMyMzU7JywgLy8gw6tcblxuICAnJUMzJUFDJzogJyYjMjM2OycsIC8vIMOsXG4gICclQzMlQUQnOiAnJiMyMzc7JywgLy8gw61cbiAgJyVDMyVBRSc6ICcmIzIzODsnLCAvLyDDrlxuICAnJUMzJUFGJzogJyYjMjM5OycsIC8vIMOvXG5cbiAgJyVDMyVCMCc6ICcmIzI0MDsnLCAvLyDDsFxuICAnJUMzJUIxJzogJyYjMjQxOycsIC8vIMOxXG5cbiAgJyVDMyVCMic6ICcmIzI0MjsnLCAvLyDDslxuICAnJUMzJUIzJzogJyYjMjQzOycsIC8vIMOzXG4gICclQzMlQjQnOiAnJiMyNDQ7JywgLy8gw7RcbiAgJyVDMyVCNSc6ICcmIzI0NTsnLCAvLyDDtVxuICAnJUMzJUI2JzogJyYjMjQ2OycsIC8vIMO2XG5cbiAgJyVDMyVCOSc6ICcmIzI0OTsnLCAvLyDDuVxuICAnJUMzJUJBJzogJyYjMjUwOycsIC8vIMO6XG4gICclQzMlQkInOiAnJiMyNTE7JywgLy8gw7tcbiAgJyVDMyVCQyc6ICcmIzI1MjsnLCAvLyDDvFxuICAnJUMzJUJGJzogJyYjMjU1OycsIC8vIMO/XG4gICclQzUlQjgnOiAnJiMzNzY7JywgLy8gxbhcblxuICAnJUMzJTlGJzogJyYjMjIzOycsIC8vIMOfXG5cbiAgJyVDMiVCRic6ICcmIzE5MTsnLCAvLyDCv1xuICAnJUMyJUExJzogJyYjMTYxOycgfTtcblxuLy8gwqFcbm1vZHVsZS5leHBvcnRzID0gQ0hBUl9DT0RFUztcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNoYXItY29kZXMuanMubWFwXG4iLCIjIyNnbG9iYWwgY2hyb21lIyMjXG4jIyNcbiAgTXVsdGl0cmFuLnJ1IHRyYW5zbGF0ZSBlbmdpbmVcbiAgUHJvdmlkZXMgcHJvZ3JhbSBpbnRlcmZhY2UgZm9yIG1ha2luZyB0cmFuc2xhdGUgcXVlcmllcyB0byBtdWx0aXRyYW4gYW5kIGdldCBjbGVhbiByZXNwb25zZVxuXG4gIEFsbCBlbmdpbmVzIG11c3QgZm9sbG93IGNvbW1vbiBpbnRlcmZhY2UgYW5kIHByb3ZpZGUgbWV0aG9kczpcbiAgICAtIHNlYXJjaCAobGFuZ3VhbmdlLCBzdWNjZXNzSGFuZGxlcikgIGNsZWFuIHRyYW5zbGF0aW9uIG11c3QgYmUgcGFzc2VkIGludG8gc3VjY2Vzc0hhbmRsZXJcbiAgICAtIGNsaWNrXG5cbiAgVHJhbnNsYXRpb24tbW9kdWxlIHRoYXQgbWFrZXMgcmVxdWVzdHMgdG8gbGFuZ3VhZ2UtZW5naW5lLFxuICBwYXJzZXMgcmVzdWx0cyBhbmQgc2VuZHMgcGx1Z2luLWdsb2JhbCBtZXNzYWdlIHdpdGggdHJhbnNsYXRpb24gZGF0YVxuIyMjXG5cbkNIQVJfQ09ERVMgPSByZXF1aXJlKCcuL2NoYXItY29kZXMuanMnKTtcblxuY2xhc3MgVHJhblxuICBjb25zdHJ1Y3RvcjogLT5cbiAgICBAVEFCTEVfQ0xBU1MgPSBcIl9fX210dF90cmFuc2xhdGVfdGFibGVcIlxuICAgIEBwcm90b2NvbCA9ICdodHRwJ1xuICAgIEBob3N0ID0gJ3d3dy5tdWx0aXRyYW4ucnUnXG4gICAgQHBhdGggPSAnL2MvbS5leGUnXG4gICAgQHF1ZXJ5ID0gJyZzPSdcbiAgICBAbGFuZyA9ICc/bDE9MiZsMj0xJyAjZnJvbSBydXNzaWFuIHRvIGVuZ2xpc2ggYnkgZGVmYXVsdFxuICAgIEB4aHIgPSB7fVxuXG4gICMjI1xuICAgIENvbnRleHQgbWVudSBjbGljayBoYW5kbGVyXG4gICMjI1xuICBjbGljazogKGRhdGEpIC0+XG4gICAgaWYgdHlwZW9mIGRhdGEuc2lsZW50ID09IHVuZGVmaW5lZCB8fCBkYXRhLnNpbGVudCA9PSBudWxsXG4gICAgICBkYXRhLnNpbGVudCA9IHRydWUgIyB0cnVlIGJ5IGRlZmF1bHRcbiAgICBzZWxlY3Rpb25UZXh0ID0gQHJlbW92ZUh5cGhlbmF0aW9uIGRhdGEuc2VsZWN0aW9uVGV4dFxuICAgIEBzZWFyY2hcbiAgICAgICAgdmFsdWU6IHNlbGVjdGlvblRleHRcbiAgICAgICAgc3VjY2VzczogQHN1Y2Nlc3N0SGFuZGxlci5iaW5kKHRoaXMpXG4gICAgICAgIHNpbGVudDogZGF0YS5zaWxlbnQgICMgaWYgdHJhbnNsYXRpb24gZmFpbGVkIGRvIG5vdCBzaG93IGRpYWxvZ1xuXG4gICMjI1xuICAgIERpc2NhcmQgc29mdCBoeXBoZW4gY2hhcmFjdGVyIChVKzAwQUQsICZzaHk7KSBmcm9tIHRoZSBpbnB1dFxuICAjIyNcbiAgcmVtb3ZlSHlwaGVuYXRpb246ICh0ZXh0KSAtPlxuICAgIHRleHQucmVwbGFjZSAvXFx4YWQvZywgJydcblxuICAjIyNcbiAgICBJbml0aWF0ZSB0cmFuc2xhdGlvbiBzZWFyY2hcbiAgIyMjXG4gIHNlYXJjaDogKHBhcmFtcykgLT5cbiAgICAjdmFsdWUsIGNhbGxiYWNrLCBlcnJcbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7bGFuZ3VhZ2U6ICcxJ30sIChpdGVtcykgPT5cbiAgICAgIGlmIGxhbmd1YWdlIGlzICcnXG4gICAgICAgIGxhbmd1YWdlID0gJzEnXG4gICAgICBAc2V0TGFuZ3VhZ2UoaXRlbXMubGFuZ3VhZ2UpXG4gICAgICB1cmwgPSBAbWFrZVVybChwYXJhbXMudmFsdWUpO1xuICAgICAgIyBkZWNvcmF0ZSBzdWNjZXNzIHRvIG1ha2UgcHJlbGltaW5hcnkgcGFyc2luZ1xuICAgICAgb3JpZ1N1Y2Nlc3MgPSBwYXJhbXMuc3VjY2Vzc1xuICAgICAgcGFyYW1zLnN1Y2Nlc3MgPSAocmVzcG9uc2UpID0+XG4gICAgICAgIHRyYW5zbGF0ZWQgPSBAcGFyc2UocmVzcG9uc2UsIHBhcmFtcy5zaWxlbnQpXG4gICAgICAgIG9yaWdTdWNjZXNzKHRyYW5zbGF0ZWQpXG5cbiAgICAgICMgbWFrZSByZXF1ZXN0IChHRVQgcmVxdWVzdCB3aXRoIHF1ZXJ5IHBhcmFtZXRlcnMgaW4gdXJsKVxuICAgICAgQHJlcXVlc3QoXG4gICAgICAgIHVybDogdXJsLFxuICAgICAgICBzdWNjZXNzOiBwYXJhbXMuc3VjY2VzcyxcbiAgICAgICAgZXJyb3I6IHBhcmFtcy5lcnJvclxuICAgICAgKVxuICAgIClcblxuICBzZXRMYW5ndWFnZTogKGxhbmd1YWdlKSAtPlxuICAgIEBjdXJyZW50TGFuZ3VhZ2UgPSBsYW5ndWFnZVxuICAgIEBsYW5nID0gJz9sMT0yJmwyPScgKyBsYW5ndWFnZVxuXG4gICMjI1xuICAgIFJlcXVlc3QgdHJhbnNsYXRpb24gYW5kIHJ1biBjYWxsYmFjayBmdW5jdGlvblxuICAgIHBhc3NpbmcgdHJhbnNsYXRlZCByZXN1bHQgb3IgZXJyb3IgdG8gY2FsbGJhY2tcbiAgIyMjXG4gIHJlcXVlc3Q6IChvcHRzKSAtPlxuICAgIHhociA9IEB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKVxuICAgIHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSAoZSkgPT5cbiAgICAgIHhociA9IEB4aHJcbiAgICAgIGlmIHhoci5yZWFkeVN0YXRlIDwgNFxuICAgICAgICByZXR1cm5cbiAgICAgIGVsc2UgaWYgeGhyLnN0YXR1cyAhPSAyMDBcbiAgICAgICAgQGVycm9ySGFuZGxlcih4aHIpXG4gICAgICAgIGlmICh0eXBlb2Ygb3B0cy5lcnJvciA9PSAnZnVuY3Rpb24nKVxuICAgICAgICAgIG9wdHMuZXJyb3IoKVxuICAgICAgICByZXR1cm5cbiAgICAgIGVsc2UgaWYgeGhyLnJlYWR5U3RhdGUgPT0gNFxuICAgICAgICAgIHJldHVybiBvcHRzLnN1Y2Nlc3MoZS50YXJnZXQucmVzcG9uc2UpXG5cbiAgICB4aHIub3BlbihcIkdFVFwiLCBvcHRzLnVybCwgdHJ1ZSk7XG4gICAgeGhyLnNlbmQoKTtcblxuXG4gIG1ha2VVcmw6ICh2YWx1ZSkgLT5cbiAgICB1cmwgPSBbQHByb3RvY29sLCAnOi8vJyxcbiAgICAgICAgICAgICAgQGhvc3QsXG4gICAgICAgICAgICAgIEBwYXRoLFxuICAgICAgICAgICAgICBAbGFuZyxcbiAgICAgICAgICAgICAgQHF1ZXJ5LFxuICAgICAgICAgICAgICBAZ2V0RW5jb2RlZFZhbHVlKHZhbHVlKVxuICAgICAgICAgIF0uam9pbignJylcblxuICAgIHJldHVybiB1cmw7XG5cbiAgIyBSZXBsYWNlIHNwZWNpYWwgbGFuZ3VhZ2UgY2hhcmFjdGVycyB0byBodG1sIGNvZGVzXG4gIGdldEVuY29kZWRWYWx1ZTogKHZhbHVlKSAtPlxuICAgICMgdG8gZmluZCBzcGVjIHN5bWJvbHMgd2UgZmlyc3QgZW5jb2RlIHRoZW0gKHJhdyBzZWFyY2ggZm9yIHRoYXQgc3ltYm9sIGRvZXNuJ3Qgd29yKVxuICAgIHZhbCA9IGVuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSlcbiAgICBmb3IgY2hhciwgY29kZSBvZiBDSEFSX0NPREVTXG4gICAgICBpZiB0eXBlb2YgY29kZSA9PSAnb2JqZWN0J1xuICAgICAgICAjIHJ1c3NpYW4gaGFzIHNwZWNpYWwgY29kZXNcbiAgICAgICAgY2MgPSBjb2RlLnZhbFxuICAgICAgZWxzZVxuICAgICAgICAjIGZvciBhbGwgbGFuZ3MgZXhjZXB0IHJ1c3NpYW4gZW5jb2RlIGh0bWwtY29kZXMgbmVlZGVkXG4gICAgICAgICMg0LTQu9GPINCy0YHQtdGFINC+0YHRgtCw0LvRjNC90YvRhSDRj9C30YvQutC+0LJcbiAgICAgICAgY2MgPSBlbmNvZGVVUklDb21wb25lbnQoY29kZSlcbiAgICAgIHZhbCA9IHZhbC5yZXBsYWNlKGNoYXIsIGNjKVxuICAgIHJldHVybiB2YWxcblxuICBlcnJvckhhbmRsZXI6ICh4aHIpIC0+XG4gICAgY29uc29sZS5sb2coJ2Vycm9yJywgeGhyKVxuXG4gICMjI1xuICAgUmVjZWl2aW5nIGRhdGEgZnJvbSB0cmFuc2xhdGlvbi1lbmdpbmUgYW5kIHNlbmQgcmVhZHkgbWVzc2FnZSB3aXRoIGRhdGFcbiAgIyMjXG4gIHN1Y2Nlc3N0SGFuZGxlcjogKHRyYW5zbGF0ZWQpIC0+XG4gICAgaWYgdHJhbnNsYXRlZFxuICAgICAgY2hyb21lLnRhYnMuZ2V0U2VsZWN0ZWQobnVsbCwgKHRhYikgPT5cbiAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgYWN0aW9uOiBAbWVzc2FnZVR5cGUgdHJhbnNsYXRlZFxuICAgICAgICAgIGRhdGE6IHRyYW5zbGF0ZWQub3V0ZXJIVE1MLFxuICAgICAgICAgIHN1Y2Nlc3M6ICF0cmFuc2xhdGVkLmNsYXNzTGlzdC5jb250YWlucygnZmFpbFRyYW5zbGF0ZScpXG4gICAgICAgIH0pXG4gICAgICApXG5cbiAgbWVzc2FnZVR5cGU6ICh0cmFuc2xhdGVkKSAtPlxuICAgIGlmIHRyYW5zbGF0ZWQ/LnJvd3M/Lmxlbmd0aCA9PSAxXG4gICAgICAnc2ltaWxhcl93b3JkcydcbiAgICBlbHNlXG4gICAgICAnb3Blbl90b29sdGlwJ1xuXG4gICMjI1xuICAgIFBhcnNlIHJlc3BvbnNlIGZyb20gdHJhbnNsYXRpb24gZW5naW5lXG4gICMjI1xuICBwYXJzZTogKHJlc3BvbnNlLCBzaWxlbnQsIHRyYW5zbGF0ZSA9IG51bGwpIC0+XG4gICAgICBkb2MgPSBAc3RyaXBTY3JpcHRzKHJlc3BvbnNlKVxuICAgICAgZnJhZ21lbnQgPSBAbWFrZUZyYWdtZW50KGRvYylcbiAgICAgIGlmIGZyYWdtZW50XG4gICAgICAgIHRyYW5zbGF0ZSA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3IoJyN0cmFuc2xhdGlvbiB+IHRhYmxlJylcbiAgICAgICAgaWYgdHJhbnNsYXRlXG4gICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9IEBUQUJMRV9DTEFTUztcbiAgICAgICAgICB0cmFuc2xhdGUuc2V0QXR0cmlidXRlKFwiY2VsbHBhZGRpbmdcIiwgXCI1XCIpXG4gICAgICAgICAgQGZpeEltYWdlcyh0cmFuc2xhdGUpXG4gICAgICAgICAgQGZpeExpbmtzKHRyYW5zbGF0ZSlcbiAgICAgICAgZWxzZSBpZiBub3Qgc2lsZW50XG4gICAgICAgICAgdHJhbnNsYXRlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gJ2ZhaWxUcmFuc2xhdGUnXG4gICAgICAgICAgdHJhbnNsYXRlLmlubmVyVGV4dCA9IFwiVW5mb3J0dW5hdGVseSwgY291bGQgbm90IHRyYW5zbGF0ZVwiXG5cbiAgICAgIHJldHVybiB0cmFuc2xhdGU7XG5cbiAgIyMjXG4gICAgU3RyaXAgc2NyaXB0IHRhZ3MgZnJvbSByZXNwb25zZSBodG1sXG4gICMjI1xuICBzdHJpcFNjcmlwdHM6IChzKSAtPlxuICAgIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgZGl2LmlubmVySFRNTCA9IHNcbiAgICBzY3JpcHRzID0gZGl2LmdldEVsZW1lbnRzQnlUYWdOYW1lKCdzY3JpcHQnKVxuICAgIGkgPSBzY3JpcHRzLmxlbmd0aFxuICAgIHdoaWxlIGktLVxuICAgICAgc2NyaXB0c1tpXS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHNjcmlwdHNbaV0pXG4gICAgcmV0dXJuIGRpdi5pbm5lckhUTUw7XG5cbiAgbWFrZUZyYWdtZW50OiAoZG9jLCBmcmFnbWVudCA9IG51bGwpIC0+XG4gICAgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKVxuICAgIGRpdi5pbm5lckhUTUwgPSBkb2NcbiAgICBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKVxuICAgIHdoaWxlICggZGl2LmZpcnN0Q2hpbGQgKVxuICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoIGRpdi5maXJzdENoaWxkIClcbiAgICByZXR1cm4gZnJhZ21lbnRcblxuICBmaXhJbWFnZXM6IChmcmFnbWVudD1udWxsKSAtPlxuICAgIHRoaXMuZml4VXJsKGZyYWdtZW50LCAnaW1nJywgJ3NyYycpO1xuICAgIHJldHVybiBmcmFnbWVudDtcblxuICBmaXhMaW5rczogKGZyYWdtZW50PW51bGwpIC0+XG4gICAgdGhpcy5maXhVcmwoZnJhZ21lbnQsICdhJywgJ2hyZWYnKVxuICAgIHJldHVybiBmcmFnbWVudFxuXG4gIGZpeFVybDogKGZyYWdtZW50PW51bGwsIHRhZywgYXR0cikgLT5cbiAgICBpZiBmcmFnbWVudFxuICAgICAgdGFncyA9ICBmcmFnbWVudC5xdWVyeVNlbGVjdG9yQWxsKHRhZylcbiAgICAgIHBhcnNlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKVxuICAgICAgZm9yIHRhZyBpbiB0YWdzXG4gICAgICAgIHBhcnNlci5ocmVmID0gdGFnW2F0dHJdXG4gICAgICAgIHBhcnNlci5ob3N0ID0gQGhvc3RcbiAgICAgICAgcGFyc2VyLnByb3RvY29sID0gQHByb3RvY29sXG4gICAgICAgICNmaXggcmVsYXRpdmUgbGlua3NcbiAgICAgICAgaWYgdGFnLnRhZ05hbWUgPT0gJ0EnXG4gICAgICAgICAgdGFnLmNsYXNzTGlzdC5hZGQgJ210dF9saW5rJ1xuICAgICAgICAgIGlmIHBhcnNlci5wYXRobmFtZS5pbmRleE9mKCdtLmV4ZScpIGlzbnQgLTFcbiAgICAgICAgICAgIHBhcnNlci5wYXRobmFtZSA9ICcvYycgKyBwYXJzZXIucGF0aG5hbWVcbiAgICAgICAgICAgIHRhZy5zZXRBdHRyaWJ1dGUoJ3RhcmdldCcsICdfYmxhbmsnKVxuICAgICAgICBlbHNlIGlmIHRhZy50YWdOYW1lID09ICdJTUcnXG4gICAgICAgICAgdGFnLmNsYXNzTGlzdC5hZGQgJ210dF9pbWcnXG5cbiAgICAgICAgdGFnLnNldEF0dHJpYnV0ZShhdHRyLCBwYXJzZXIuaHJlZilcblxuXG5cbm1vZHVsZS5leHBvcnRzID0gbmV3IFRyYW4iLCIvKlxuICBUcmFuc2xhdGlvbiBlbmdpbmU6IGh0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0XG4gIEZvciB0cmFuc2xhdGluZyB0dXJraXNoLXJ1c3NpYW4gYW5kIHZpY2UgdmVyc2FcbiovXG4ndXNlIHN0cmljdCc7XG5cbnZhciBfY3JlYXRlQ2xhc3MgPSAoZnVuY3Rpb24gKCkgeyBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0aWVzKHRhcmdldCwgcHJvcHMpIHsgZm9yICh2YXIgaSA9IDA7IGkgPCBwcm9wcy5sZW5ndGg7IGkrKykgeyB2YXIgZGVzY3JpcHRvciA9IHByb3BzW2ldOyBkZXNjcmlwdG9yLmVudW1lcmFibGUgPSBkZXNjcmlwdG9yLmVudW1lcmFibGUgfHwgZmFsc2U7IGRlc2NyaXB0b3IuY29uZmlndXJhYmxlID0gdHJ1ZTsgaWYgKCd2YWx1ZScgaW4gZGVzY3JpcHRvcikgZGVzY3JpcHRvci53cml0YWJsZSA9IHRydWU7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGRlc2NyaXB0b3Iua2V5LCBkZXNjcmlwdG9yKTsgfSB9IHJldHVybiBmdW5jdGlvbiAoQ29uc3RydWN0b3IsIHByb3RvUHJvcHMsIHN0YXRpY1Byb3BzKSB7IGlmIChwcm90b1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLnByb3RvdHlwZSwgcHJvdG9Qcm9wcyk7IGlmIChzdGF0aWNQcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvciwgc3RhdGljUHJvcHMpOyByZXR1cm4gQ29uc3RydWN0b3I7IH07IH0pKCk7XG5cbmZ1bmN0aW9uIF9jbGFzc0NhbGxDaGVjayhpbnN0YW5jZSwgQ29uc3RydWN0b3IpIHsgaWYgKCEoaW5zdGFuY2UgaW5zdGFuY2VvZiBDb25zdHJ1Y3RvcikpIHsgdGhyb3cgbmV3IFR5cGVFcnJvcignQ2Fubm90IGNhbGwgYSBjbGFzcyBhcyBhIGZ1bmN0aW9uJyk7IH0gfVxuXG52YXIgQ0hBUl9DT0RFUyA9IHJlcXVpcmUoJy4vY2hhci1jb2Rlcy10dXJrLmpzJyk7XG5cbnZhciBUdXJraXNoRGljdGlvbmFyeSA9IChmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIFR1cmtpc2hEaWN0aW9uYXJ5KCkge1xuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBUdXJraXNoRGljdGlvbmFyeSk7XG5cbiAgICB0aGlzLmhvc3QgPSAnaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXQvP3dvcmQ9JUZDJztcbiAgICB0aGlzLnBhdGggPSAnJztcbiAgICB0aGlzLnByb3RvY29sID0gJ2h0dHAnO1xuICAgIHRoaXMucXVlcnkgPSAnJnM9JztcbiAgICB0aGlzLlRBQkxFX0NMQVNTID0gJ19fX210dF90cmFuc2xhdGVfdGFibGUnO1xuICAgIC8vIHRoaXMgZmxhZyBpbmRpY2F0ZXMgdGhhdCBpZiB0cmFuc2xhdGlvbiB3YXMgc3VjY2Vzc2Z1bCB0aGVuIHB1Ymxpc2ggaXQgYWxsIG92ZXIgZXh0ZW5zaW9uXG4gICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSB0cnVlO1xuICB9XG5cbiAgLy8gU2luZ2xldG9uZVxuXG4gIF9jcmVhdGVDbGFzcyhUdXJraXNoRGljdGlvbmFyeSwgW3tcbiAgICBrZXk6ICdzZWFyY2gnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzZWFyY2goZGF0YSkge1xuICAgICAgZGF0YS51cmwgPSB0aGlzLm1ha2VVcmwoZGF0YS52YWx1ZSk7XG4gICAgICB0aGlzLm5lZWRfcHVibGlzaCA9IGZhbHNlO1xuICAgICAgcmV0dXJuIHRoaXMucmVxdWVzdChkYXRhKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICd0cmFuc2xhdGUnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiB0cmFuc2xhdGUoZGF0YSkge1xuICAgICAgZGF0YS51cmwgPSB0aGlzLm1ha2VVcmwoZGF0YS5zZWxlY3Rpb25UZXh0KTtcbiAgICAgIHRoaXMubmVlZF9wdWJsaXNoID0gdHJ1ZTtcbiAgICAgIHRoaXMucmVxdWVzdChkYXRhKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdtYWtlVXJsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZVVybCh0ZXh0KSB7XG4gICAgICB2YXIgdGV4dCA9IHRoaXMuZ2V0RW5jb2RlZFZhbHVlKHRleHQpO1xuICAgICAgcmV0dXJuIFsnaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXQvP3dvcmQ9JywgdGV4dF0uam9pbignJyk7XG4gICAgfVxuXG4gICAgLy8gUmVwbGFjZSBzcGVjaWFsIGxhbmd1YWdlIGNoYXJhY3RlcnMgdG8gaHRtbCBjb2Rlc1xuICB9LCB7XG4gICAga2V5OiAnZ2V0RW5jb2RlZFZhbHVlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZ2V0RW5jb2RlZFZhbHVlKHZhbHVlKSB7XG4gICAgICAvLyB0byBmaW5kIHNwZWMgc3ltYm9scyB3ZSBmaXJzdCBlbmNvZGUgdGhlbSAocmF3IHNlYXJjaCBmb3IgdGhhdCBzeW1ib2wgZG9lc24ndCB3b3IpXG4gICAgICByZXR1cm4gZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcbiAgICAgIC8vcmV0dXJuIHRoaXMubWFrZVN0cmluZ1RyYW5zZmVyYWJsZSh2YWx1ZSk7XG4gICAgfVxuXG4gICAgLyoqIGNvbnZlcnRpbmcgc2NyaXB0IGZyb20gdGhlIHR1cmtpc2hkaWN0ICovXG4gIH0sIHtcbiAgICBrZXk6ICdtYWtlU3RyaW5nVHJhbnNmZXJhYmxlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZVN0cmluZ1RyYW5zZmVyYWJsZShpbnB1dFRleHQpIHtcbiAgICAgIHZhciB0ZXh0ID0gXCJcIjtcbiAgICAgIGlmIChpbnB1dFRleHQubGVuZ3RoID4gMCkge1xuICAgICAgICB0ZXh0ID0gaW5wdXRUZXh0O1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRleHQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBpZiAoQ0hBUl9DT0RFU1t0ZXh0LmNoYXJDb2RlQXQoaSldKSB7XG4gICAgICAgICAgICB0ZXh0ID0gdGV4dC5zdWJzdHJpbmcoMCwgaSkgKyBDSEFSX0NPREVTW3RleHQuY2hhckNvZGVBdChpKV0gKyB0ZXh0LnN1YnN0cmluZyhpICsgMSwgdGV4dC5sZW5ndGgpO1xuICAgICAgICAgIH0gZWxzZSBpZiAodGV4dC5jaGFyQXQoaSkgPT0gJyAnKSB7XG4gICAgICAgICAgICAvLyByZXBsYWNlIHNwYWNlc1xuICAgICAgICAgICAgdGV4dCA9IHRleHQuc3Vic3RyaW5nKDAsIGkpICsgJ19fXycgKyB0ZXh0LnN1YnN0cmluZyhpICsgMSwgdGV4dC5sZW5ndGgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRleHQ7XG4gICAgfVxuXG4gICAgLypcbiAgICAgIFJlcXVlc3QgdHJhbnNsYXRpb24gYW5kIHJ1biBjYWxsYmFjayBmdW5jdGlvblxuICAgICAgcGFzc2luZyB0cmFuc2xhdGVkIHJlc3VsdCBvciBlcnJvciB0byBjYWxsYmFja1xuICAgICovXG4gIH0sIHtcbiAgICBrZXk6ICdyZXF1ZXN0JyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gcmVxdWVzdChvcHRzKSB7XG4gICAgICBjb25zb2xlLmxvZygnc3RhcnQgcmVxdWVzdCcpO1xuICAgICAgdGhpcy54aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgIHRoaXMueGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IHRoaXMub25SZWFkeVN0YXRlQ2hhbmdlLmJpbmQodGhpcywgb3B0cyk7XG4gICAgICB0aGlzLnhoci5vcGVuKFwiR0VUXCIsIG9wdHMudXJsLCB0cnVlKTtcbiAgICAgIHRoaXMueGhyLnNlbmQoKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdvblJlYWR5U3RhdGVDaGFuZ2UnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBvblJlYWR5U3RhdGVDaGFuZ2Uob3B0cywgZSkge1xuICAgICAgdmFyIHhociA9IHRoaXMueGhyO1xuICAgICAgaWYgKHhoci5yZWFkeVN0YXRlIDwgNCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9IGVsc2UgaWYgKHhoci5zdGF0dXMgIT0gMjAwKSB7XG4gICAgICAgIHRoaXMuZXJyb3JIYW5kbGVyKHhocik7XG4gICAgICAgIHJldHVybiBvcHRzLmVycm9yICYmIG9wdHMuZXJyb3IoKTtcbiAgICAgIH0gZWxzZSBpZiAoeGhyLnJlYWR5U3RhdGUgPT0gNCkge1xuICAgICAgICB2YXIgdHJhbnNsYXRpb24gPSB0aGlzLnN1Y2Nlc3NIYW5kbGVyKGUudGFyZ2V0LnJlc3BvbnNlKTtcbiAgICAgICAgY29uc29sZS5sb2coJ3N1Y2Nlc3MgdHVya2lzaCB0cmFuc2xhdGUnLCB0cmFuc2xhdGlvbik7XG4gICAgICAgIGNvbnNvbGUubG9nKCdjYWxsJywgb3B0cy5zdWNjZXNzKTtcbiAgICAgICAgcmV0dXJuIG9wdHMuc3VjY2VzcyAmJiBvcHRzLnN1Y2Nlc3ModHJhbnNsYXRpb24pO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3N1Y2Nlc3NIYW5kbGVyJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc3VjY2Vzc0hhbmRsZXIocmVzcG9uc2UpIHtcbiAgICAgIHZhciBkYXRhID0gdGhpcy5wYXJzZShyZXNwb25zZSk7XG4gICAgICBpZiAodGhpcy5uZWVkX3B1Ymxpc2gpIHtcbiAgICAgICAgY2hyb21lLnRhYnMuZ2V0U2VsZWN0ZWQobnVsbCwgdGhpcy5wdWJsaXNoVHJhbnNsYXRpb24uYmluZCh0aGlzLCBkYXRhKSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZGF0YTtcbiAgICB9XG5cbiAgICAvKiBwdWJsaXNoIHN1Y2Nlc3NmdWx5IHRyYW5zbGF0ZWQgdGV4dCBhbGwgb3ZlciBleHRlbnNpb24gKi9cbiAgfSwge1xuICAgIGtleTogJ3B1Ymxpc2hUcmFuc2xhdGlvbicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHB1Ymxpc2hUcmFuc2xhdGlvbih0cmFuc2xhdGlvbiwgdGFiKSB7XG4gICAgICBjb25zb2xlLmxvZygncHVibGlzaCB0cmFuc2xhdGlvbicpO1xuICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgIGFjdGlvbjogdGhpcy50b29sdGlwQWN0aW9uKHRyYW5zbGF0aW9uKSxcbiAgICAgICAgZGF0YTogdHJhbnNsYXRpb24ub3V0ZXJIVE1MLFxuICAgICAgICBzdWNjZXNzOiAhdHJhbnNsYXRpb24uY2xhc3NMaXN0LmNvbnRhaW5zKCdmYWlsVHJhbnNsYXRlJylcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3Rvb2x0aXBBY3Rpb24nLFxuICAgIHZhbHVlOiBmdW5jdGlvbiB0b29sdGlwQWN0aW9uKHRyYW5zbGF0aW9uKSB7XG4gICAgICBpZiAodHJhbnNsYXRpb24udGV4dENvbnRlbnQudHJpbSgpLmluZGV4T2YoJ3dhcyBub3QgZm91bmQgaW4gb3VyIGRpY3Rpb25hcnknKSAhPSAtMSkge1xuICAgICAgICBjb25zb2xlLmxvZygnc2ltaWxhciB3b3JkcycpO1xuICAgICAgICByZXR1cm4gJ3NpbWlsYXJfd29yZHMnO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coJ29wZW4gdG9vbHRpcCcpO1xuICAgICAgICByZXR1cm4gJ29wZW5fdG9vbHRpcCc7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnZXJyb3JIYW5kbGVyJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZXJyb3JIYW5kbGVyKHJlc3BvbnNlKSB7XG4gICAgICBjb25zb2xlLmxvZygnZXJyb3IgYWpheCcsIHJlc3BvbnNlKTtcbiAgICB9XG5cbiAgICAvKiBQYXJzZSByZXNwb25zZSBmcm9tIHRyYW5zbGF0aW9uIGVuZ2luZSAqL1xuICB9LCB7XG4gICAga2V5OiAncGFyc2UnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBwYXJzZShyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUpIHtcbiAgICAgIHZhciBkb2MgPSB0aGlzLnN0cmlwU2NyaXB0cyhyZXNwb25zZSksXG4gICAgICAgICAgZnJhZ21lbnQgPSB0aGlzLm1ha2VGcmFnbWVudChkb2MpO1xuICAgICAgaWYgKGZyYWdtZW50KSB7XG4gICAgICAgIHRyYW5zbGF0ZSA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3IoJyNtZWFuaW5nX2RpdiA+IHRhYmxlJyk7XG4gICAgICAgIGlmICh0cmFuc2xhdGUpIHtcbiAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gdGhpcy5UQUJMRV9DTEFTUztcbiAgICAgICAgICB0cmFuc2xhdGUuc2V0QXR0cmlidXRlKFwiY2VsbHBhZGRpbmdcIiwgXCI1XCIpO1xuICAgICAgICAgIC8vIEBmaXhJbWFnZXModHJhbnNsYXRlKVxuICAgICAgICAgIC8vIEBmaXhMaW5rcyh0cmFuc2xhdGUpXG4gICAgICAgIH0gZWxzZSBpZiAoIXNpbGVudCkge1xuICAgICAgICAgICAgdHJhbnNsYXRlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gJ2ZhaWxUcmFuc2xhdGUnO1xuICAgICAgICAgICAgdHJhbnNsYXRlLmlubmVyVGV4dCA9IFwiVW5mb3J0dW5hdGVseSwgY291bGQgbm90IHRyYW5zbGF0ZVwiO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiB0cmFuc2xhdGU7XG4gICAgfVxuXG4gICAgLyoqIHBhcnNpbmcgb2YgdGVycmlibGUgaHRtbCBtYXJrdXAgKi9cbiAgfSwge1xuICAgIGtleTogJ3BhcnNlVGV4dCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHBhcnNlVGV4dChyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUpIHtcbiAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAgIHZhciBkb2MgPSB0aGlzLnN0cmlwU2NyaXB0cyhyZXNwb25zZSksXG4gICAgICAgICAgZnJhZ21lbnQgPSB0aGlzLm1ha2VGcmFnbWVudChkb2MpO1xuXG4gICAgICBpZiAoZnJhZ21lbnQpIHtcbiAgICAgICAgdmFyIGk7XG5cbiAgICAgICAgdmFyIF9yZXQgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHZhciBzdG9wSW5kZXggPSBudWxsO1xuICAgICAgICAgIHZhciB0ciA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJyNtZWFuaW5nX2Rpdj50YWJsZT50Ym9keT50cicpO1xuICAgICAgICAgIHRyID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwodHIpO1xuXG4gICAgICAgICAgdmFyIHRyYW5zID0gdHIuZmlsdGVyKGZ1bmN0aW9uICh0ciwgaW5kZXgpIHtcbiAgICAgICAgICAgIGlmICghaXNOYU4ocGFyc2VJbnQoc3RvcEluZGV4LCAxMCkpICYmIGluZGV4ID49IHN0b3BJbmRleCkge1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB0ciA9ICQodHIpO1xuICAgICAgICAgICAgICAvLyB0YWtlIGV2ZXJ5IHJvdyBiZWZvcmUgbmV4dCBzZWN0aW9uICh3aGljaCBpcyBFbmdsaXNoLT5FbmdsaXNoKVxuICAgICAgICAgICAgICBpZiAodHIuYXR0cignYmdjb2xvcicpID09IFwiZTBlNmZmXCIpIHtcbiAgICAgICAgICAgICAgICBzdG9wSW5kZXggPSBpbmRleDtyZXR1cm47XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuICQudHJpbSh0ci5maW5kKCd0ZCcpLnRleHQoKSkubGVuZ3RoO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgdHJhbnMgPSB0cmFucy5zbGljZSgxLCB0cmFucy5sZW5ndGggLSAxKTtcbiAgICAgICAgICB0cmFucyA9IHRyYW5zLmZpbHRlcihmdW5jdGlvbiAoZWwsIGluZHgpIHtcbiAgICAgICAgICAgIHJldHVybiBpbmR4ICUgMjtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICB2YXIgZnJhZyA9IF90aGlzLmZyYWdtZW50RnJvbUxpc3QodHJhbnMpO1xuICAgICAgICAgIHZhciBmb250cyA9IGZyYWcucXVlcnlTZWxlY3RvckFsbCgnZm9udCcpO1xuICAgICAgICAgIHZhciB0ZXh0ID0gJyc7XG4gICAgICAgICAgZm9yIChpID0gMDsgaSA8IGZvbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICB0ZXh0ICs9ICcgJyArIGZvbnRzW2ldLnRleHRDb250ZW50LnRyaW0oKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHY6IHRleHRcbiAgICAgICAgICB9O1xuICAgICAgICB9KSgpO1xuXG4gICAgICAgIGlmICh0eXBlb2YgX3JldCA9PT0gJ29iamVjdCcpIHJldHVybiBfcmV0LnY7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBcIkhUTUwgZnJhZ21lbnQgY291bGQgbm90IGJlIHBhcnNlZFwiO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vVE9ETyBleHRyYWN0IHRvIGJhc2UgZW5naW5lIGNsYXNzXG4gICAgLyogcmVtb3ZlcyA8c2NyaXB0PiB0YWdzIGZyb20gaHRtbCBjb2RlICovXG4gIH0sIHtcbiAgICBrZXk6ICdzdHJpcFNjcmlwdHMnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzdHJpcFNjcmlwdHMoaHRtbCkge1xuICAgICAgdmFyIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgZGl2LmlubmVySFRNTCA9IGh0bWw7XG4gICAgICB2YXIgc2NyaXB0cyA9IGRpdi5nZXRFbGVtZW50c0J5VGFnTmFtZSgnc2NyaXB0Jyk7XG4gICAgICB2YXIgaSA9IHNjcmlwdHMubGVuZ3RoO1xuICAgICAgd2hpbGUgKGktLSkgc2NyaXB0c1tpXS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHNjcmlwdHNbaV0pO1xuICAgICAgcmV0dXJuIGRpdi5pbm5lckhUTUw7XG4gICAgfVxuXG4gICAgLy9UT0RPIGV4dHJhY3QgdG8gYmFzZSBlbmdpbmUgY2xhc3NcbiAgICAvKiBjcmVhdGVzIHRlbXAgb2JqZWN0IHRvIHBhcnNlIHRyYW5zbGF0aW9uIGZyb20gcGFnZSBcbiAgICAgIChzaW5jZSBpdCdzIG5vdCBhIGZyaWVuZGx5IGFwaSkgXG4gICAgKi9cbiAgfSwge1xuICAgIGtleTogJ21ha2VGcmFnbWVudCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG1ha2VGcmFnbWVudChodG1sKSB7XG4gICAgICB2YXIgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCksXG4gICAgICAgICAgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgIGRpdi5pbm5lckhUTUwgPSBodG1sO1xuICAgICAgd2hpbGUgKGRpdi5maXJzdENoaWxkKSB7XG4gICAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKGRpdi5maXJzdENoaWxkKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmcmFnbWVudDtcbiAgICB9XG5cbiAgICAvKiogY3JlYXRlIGZyYWdtZW50IGZyb20gbGlzdCBvZiBET00gZWxlbWVudHMgKi9cbiAgfSwge1xuICAgIGtleTogJ2ZyYWdtZW50RnJvbUxpc3QnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBmcmFnbWVudEZyb21MaXN0KGxpc3QpIHtcbiAgICAgIHZhciBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKSxcbiAgICAgICAgICBsZW4gPSBsaXN0Lmxlbmd0aDtcbiAgICAgIHdoaWxlIChsZW4tLSkge1xuICAgICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZChsaXN0W2xlbl0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZyYWdtZW50O1xuICAgIH1cbiAgfV0pO1xuXG4gIHJldHVybiBUdXJraXNoRGljdGlvbmFyeTtcbn0pKCk7XG5cbm1vZHVsZS5leHBvcnRzID0gbmV3IFR1cmtpc2hEaWN0aW9uYXJ5KCk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD10dXJraXNoZGljdGlvbmFyeS5qcy5tYXBcbiJdfQ==
