(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
var CHAR_CODES = {
  // turkishdictionary codings
  '%C4%B1': '%FD', //ı (Lowercase i-dotless)  actually it is &#305; but turkishdictionary need it this way 
  '%C5%9F': '%FE', //ş
  '%C4%9F': '%F0', //ğ  (silent character)
  '%C3%A7': '%E7', //ç
  '%C3%B6': '%F6', //ö
  '%C3%BC': '%FC', //ü
  '%C3%A2': '%E2', // â

   // '' : '', //Ç
   // '' : '', //Ğ
   // '' : '', //Ö
   // '' : '', //Ş
   // '' : '', //Ü
   // '' : '', //İ
   // '' : '', //Â
}

module.exports = CHAR_CODES;
},{}],2:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/var CHAR_CODES = {  //russian  '%D1%8A': {val:'%FA', lang:'ru'}, // ъ  '%D0%AA': {val:'%DA', lang:'ru'},// Ъ  '%C3%80': '&#192;', // À  '%C3%81': '&#193;', // Á  '%C3%82': '&#194;', // Â  '%C3%83': '&#195;', // Ã  '%C3%84': '&#196;', // Ä  '%C3%85': '&#197;', // Å  '%C3%86': '&#198;', // Æ  '%C3%87': '&#199;', // Ç  '%C3%88': '&#200;', // È  '%C3%89': '&#201;', // É  '%C3%8A': '&#202;', // Ê  '%C3%8B': '&#203;', // Ë  '%C3%8C': '&#204;', // Ì  '%C3%8D': '&#205;', // Í  '%C3%8E': '&#206;', // Î  '%C3%8F': '&#207;', // Ï  '%C3%91': '&#209;', // Ñ  '%C3%92': '&#210;', // Ò  '%C3%93': '&#211;', // Ó  '%C3%94': '&#212;', // Ô  '%C3%95': '&#213;', // Õ  '%C3%96': '&#214;', // Ö  '%C3%99': '&#217;', // Ù  '%C3%9A': '&#218;', // Ú  '%C3%9B': '&#219;', // Û  '%C3%9C': '&#220;', // Ü  '%C3%A0': '&#224;', // à  '%C3%A1': '&#225;', // á  '%C3%A2': '&#226;', // â  '%C3%A3': '&#227;', // ã  '%C3%A4': '&#228;', // ä  '%C3%A5': '&#229;', // å  '%C3%A6': '&#230;', // æ  '%C3%A7': '&#231;', // ç  '%C3%A8': '&#232;', // è  '%C3%A9': '&#233;', // é  '%C3%AA': '&#234;', // ê  '%C3%AB': '&#235;', // ë  '%C3%AC': '&#236;', // ì  '%C3%AD': '&#237;', // í  '%C3%AE': '&#238;', // î  '%C3%AF': '&#239;', // ï  '%C3%B0': '&#240;', // ð  '%C3%B1': '&#241;', // ñ  '%C3%B2': '&#242;', // ò  '%C3%B3': '&#243;', // ó  '%C3%B4': '&#244;', // ô  '%C3%B5': '&#245;', // õ  '%C3%B6': '&#246;', // ö  '%C3%B9': '&#249;', // ù  '%C3%BA': '&#250;', // ú  '%C3%BB': '&#251;', // û  '%C3%BC': '&#252;', // ü  '%C3%BF': '&#255;', // ÿ  '%C5%B8': '&#376;', // Ÿ  '%C3%9F': '&#223;', // ß  '%C2%BF': '&#191;', // ¿  '%C2%A1': '&#161;', // ¡};module.exports = CHAR_CODES;
},{}],3:[function(require,module,exports){

/*
  Dropdown language menu
  @param opts takes element and onSelect handler
  example:
  new Dropdown({
   el: document.getElementById('#menu');
   onSelect: function () {}
  })
 */
var DICT_CODE, Dropdown, LANG_CODE;

LANG_CODE = {
  '1': 'Eng',
  '2': 'Rus',
  '3': 'Ger',
  '4': 'Fre',
  '5': 'Spa',
  '23': 'Ita',
  '24': 'Dut',
  '26': 'Est',
  '27': 'Lav',
  '31': 'Afr',
  '34': 'Epo',
  '35': 'Xal',
  '1000': 'Tur'
};

DICT_CODE = {
  '1': 'multitran',
  '1000': 'turkish'
};

Dropdown = (function() {
  function Dropdown(opts) {
    this.el = opts.el || document.createElement('div');
    this.onSelect = opts.onSelect;
    this.menu = this.el.querySelector('.dropdown-menu');
    if (this.menu) {
      this.menu.style.display = 'none';
      this.items = this.menu.getElementsByClassName('language-type');
      this.button = this.el.querySelector('.dropdown-toggle');
      this.addListeners();
      this.initLanguage();
    }
  }

  Dropdown.prototype.addListeners = function() {
    this.button.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.toggle(e);
      };
    })(this));
    document.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.hide(e);
      };
    })(this));
    return this.menu.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.choose(e);
      };
    })(this));
  };

  Dropdown.prototype.initLanguage = function() {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(store) {
        return _this.setTitle(store.language);
      };
    })(this));
  };

  Dropdown.prototype.toggle = function(e) {
    e.stopPropagation();
    this.setActiveItem();
    if (this.menu && this.menu.style.display === 'none') {
      return this.show();
    } else {
      return this.hide();
    }
  };

  Dropdown.prototype.setActiveItem = function() {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(store) {
        var item, _i, _len, _ref, _results;
        _ref = _this.items;
        _results = [];
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          item = _ref[_i];
          if (item.getAttribute('data-val') === store.language) {
            _results.push(item.classList.add('active'));
          } else {
            _results.push(item.classList.remove('active'));
          }
        }
        return _results;
      };
    })(this));
  };

  Dropdown.prototype.hide = function() {
    return this.menu.style.display = 'none';
  };

  Dropdown.prototype.show = function() {
    return this.menu.style.display = 'block';
  };

  Dropdown.prototype.choose = function(e) {
    var dictionary, language;
    e.stopPropagation();
    e.preventDefault();
    language = e.target.getAttribute('data-val');
    dictionary = this.getDictionary(language);
    chrome.storage.sync.set({
      language: language,
      dictionary: dictionary
    }, this.onSelect);
    this.setTitle(language);
    return this.hide();
  };

  Dropdown.prototype.getDictionary = function(lang) {
    var dict;
    console.log('choose dict: for', lang);
    dict = DICT_CODE[lang] || 'multitran';
    console.log('dict', dict);
    return dict;
  };

  Dropdown.prototype.setTitle = function(language) {
    var html;
    html = LANG_CODE[language] + ' <span class="caret"></span>';
    return this.button.innerHTML = html;
  };

  return Dropdown;

})();

module.exports = Dropdown;


},{}],4:[function(require,module,exports){

/*
  Extension popup window
  Shows search form and dropdown menu with languages
 */
var SearchForm;

SearchForm = require('./search_form.coffee');

document.addEventListener("DOMContentLoaded", function() {
  var form, link;
  form = new SearchForm(document.getElementById('tran-form'));
  link = document.getElementById('header-link');
  if (link) {
    return link.addEventListener('click', function(e) {
      var href;
      e.preventDefault();
      href = e.target.getAttribute('href') + form.getValue();
      return chrome.tabs.create({
        url: href
      });
    });
  }
});


},{"./search_form.coffee":5}],5:[function(require,module,exports){

/*
  Serves search input and form

  @param form DOM elemnt
  @constructor
 */
var Dropdown, SearchForm, TRANSLATE_ENGINES, tran, turkishdictionary,
  __indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

Dropdown = require('./dropdown.coffee');

tran = require('../tran.coffee');

turkishdictionary = require('../turkishdictionary.js');

TRANSLATE_ENGINES = {
  'multitran': tran,
  'turkish': turkishdictionary
};

SearchForm = (function() {
  function SearchForm(form) {
    this.form = form;
    this.input = document.getElementById('translate-txt');
    this.input.focus();
    this.result = document.getElementById('result');
    this.addListeners();
    this.dropdown = new Dropdown({
      el: document.querySelector('.dropdown-el'),
      onSelect: (function(_this) {
        return function() {
          return _this.search();
        };
      })(this)
    });
  }

  SearchForm.prototype.addListeners = function() {
    if (this.form && this.result) {
      this.form.addEventListener('submit', (function(_this) {
        return function(e) {
          return _this.search(e);
        };
      })(this));
      return this.result.addEventListener('click', (function(_this) {
        return function(e) {
          return _this.resultClickHandler(e);
        };
      })(this));
    }
  };

  SearchForm.prototype.search = function(e) {
    e && e.preventDefault && e.preventDefault();
    if (this.input.value.length > 0) {
      return chrome.storage.sync.get({
        language: '1',
        dictionary: 'multitran'
      }, (function(_this) {
        return function(items) {
          console.log('ITEMS:', items);
          return TRANSLATE_ENGINES[items.dictionary].search({
            value: _this.input.value,
            success: _this.successHandler.bind(_this)
          });
        };
      })(this));
    }
  };

  SearchForm.prototype.successHandler = function(response) {
    this.clean(this.result);
    return this.result.appendChild(response);
  };

  SearchForm.prototype.clean = function(el) {
    var _results;
    _results = [];
    while (el.lastChild) {
      _results.push(el.removeChild(el.lastChild));
    }
    return _results;
  };

  SearchForm.prototype.resultClickHandler = function(e) {
    var linkTags, _ref;
    e.preventDefault();
    linkTags = ['A', 'a'];
    if (_ref = e.target.tagName, __indexOf.call(linkTags, _ref) >= 0) {
      this.input.value = e.target.innerText;
      return this.search(e);
    }
  };

  SearchForm.prototype.getValue = function() {
    return this.input.value;
  };

  return SearchForm;

})();

module.exports = SearchForm;


},{"../tran.coffee":6,"../turkishdictionary.js":7,"./dropdown.coffee":3}],6:[function(require,module,exports){

/*global chrome */

/*
  Multitran.ru translate engine
  Provides program interface for making translate queries to multitran and get clean response

  All engines must follow common interface and provide methods:
    - search (languange, successHandler)  clean translation must be passed into successHandler
    - click

  Translation-module that makes requests to language-engine,
  parses results and sends plugin-global message with translation data
 */
var CHAR_CODES, Tran;

CHAR_CODES = require('./char-codes.js');

Tran = (function() {
  function Tran() {
    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1';
    this.xhr = {};
  }


  /*
    Context menu click handler
   */

  Tran.prototype.click = function(data) {
    var selectionText;
    if (typeof data.silent === void 0 || data.silent === null) {
      data.silent = true;
    }
    selectionText = this.removeHyphenation(data.selectionText);
    return this.search({
      value: selectionText,
      success: this.successtHandler.bind(this),
      silent: data.silent
    });
  };


  /*
    Discard soft hyphen character (U+00AD, &shy;) from the input
   */

  Tran.prototype.removeHyphenation = function(text) {
    return text.replace(/\xad/g, '');
  };


  /*
    Initiate translation search
   */

  Tran.prototype.search = function(params) {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(items) {
        var language, origSuccess, url;
        if (language === '') {
          language = '1';
        }
        _this.setLanguage(items.language);
        url = _this.makeUrl(params.value);
        origSuccess = params.success;
        params.success = function(response) {
          var translated;
          translated = _this.parse(response, params.silent);
          return origSuccess(translated);
        };
        return _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      };
    })(this));
  };

  Tran.prototype.setLanguage = function(language) {
    this.currentLanguage = language;
    return this.lang = '?l1=2&l2=' + language;
  };


  /*
    Request translation and run callback function
    passing translated result or error to callback
   */

  Tran.prototype.request = function(opts) {
    var xhr;
    xhr = this.xhr = new XMLHttpRequest();
    xhr.onreadystatechange = (function(_this) {
      return function(e) {
        xhr = _this.xhr;
        if (xhr.readyState < 4) {

        } else if (xhr.status !== 200) {
          _this.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error();
          }
        } else if (xhr.readyState === 4) {
          return opts.success(e.target.response);
        }
      };
    })(this);
    xhr.open("GET", opts.url, true);
    return xhr.send();
  };

  Tran.prototype.makeUrl = function(value) {
    var url;
    url = [this.protocol, '://', this.host, this.path, this.lang, this.query, this.getEncodedValue(value)].join('');
    return url;
  };

  Tran.prototype.getEncodedValue = function(value) {
    var cc, char, code, val;
    val = encodeURIComponent(value);
    for (char in CHAR_CODES) {
      code = CHAR_CODES[char];
      if (typeof code === 'object') {
        cc = code.val;
        console.log('rus', cc);
      } else {
        console.log('latin', cc);
        cc = encodeURIComponent(code);
      }
      val = val.replace(char, cc);
    }
    return val;
  };

  Tran.prototype.errorHandler = function(xhr) {
    return console.log('error', xhr);
  };


  /*
   Receiving data from translation-engine and send ready message with data
   */

  Tran.prototype.successtHandler = function(translated) {
    if (translated) {
      return chrome.tabs.getSelected(null, (function(_this) {
        return function(tab) {
          return chrome.tabs.sendMessage(tab.id, {
            action: _this.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        };
      })(this));
    }
  };

  Tran.prototype.messageType = function(translated) {
    var _ref;
    if ((translated != null ? (_ref = translated.rows) != null ? _ref.length : void 0 : void 0) === 1) {
      return 'similar_words';
    } else {
      return 'open_tooltip';
    }
  };


  /*
    Parse response from translation engine
   */

  Tran.prototype.parse = function(response, silent, translate) {
    var doc, fragment;
    if (translate == null) {
      translate = null;
    }
    doc = this.stripScripts(response);
    fragment = this.makeFragment(doc);
    if (fragment) {
      translate = fragment.querySelector('#translation ~ table');
      if (translate) {
        translate.className = this.TABLE_CLASS;
        translate.setAttribute("cellpadding", "5");
        this.fixImages(translate);
        this.fixLinks(translate);
      } else if (!silent) {
        translate = document.createElement('div');
        translate.className = 'failTranslate';
        translate.innerText = "Unfortunately, could not translate";
      }
    }
    return translate;
  };


  /*
    Strip script tags from response html
   */

  Tran.prototype.stripScripts = function(s) {
    var div, i, scripts;
    div = document.createElement('div');
    div.innerHTML = s;
    scripts = div.getElementsByTagName('script');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
    return div.innerHTML;
  };

  Tran.prototype.makeFragment = function(doc, fragment) {
    var div;
    if (fragment == null) {
      fragment = null;
    }
    div = document.createElement("div");
    div.innerHTML = doc;
    fragment = document.createDocumentFragment();
    while (div.firstChild) {
      fragment.appendChild(div.firstChild);
    }
    return fragment;
  };

  Tran.prototype.fixImages = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'img', 'src');
    return fragment;
  };

  Tran.prototype.fixLinks = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'a', 'href');
    return fragment;
  };

  Tran.prototype.fixUrl = function(fragment, tag, attr) {
    var parser, tags, _i, _len, _results;
    if (fragment == null) {
      fragment = null;
    }
    if (fragment) {
      tags = fragment.querySelectorAll(tag);
      parser = document.createElement('a');
      _results = [];
      for (_i = 0, _len = tags.length; _i < _len; _i++) {
        tag = tags[_i];
        parser.href = tag[attr];
        parser.host = this.host;
        parser.protocol = this.protocol;
        if (tag.tagName === 'A') {
          tag.classList.add('mtt_link');
          if (parser.pathname.indexOf('m.exe') !== -1) {
            parser.pathname = '/c' + parser.pathname;
            tag.setAttribute('target', '_blank');
          }
        } else if (tag.tagName === 'IMG') {
          tag.classList.add('mtt_img');
        }
        _results.push(tag.setAttribute(attr, parser.href));
      }
      return _results;
    }
  };

  return Tran;

})();

module.exports = new Tran;


},{"./char-codes.js":2}],7:[function(require,module,exports){
"use strict";

var _prototypeProperties = function (child, staticProps, instanceProps) {
  if (staticProps) Object.defineProperties(child, staticProps);
  if (instanceProps) Object.defineProperties(child.prototype, instanceProps);
};

/*
  Translation engine: http://www.turkishdictionary.net
  For translating turkish-russian and vice versa
*/
var CHAR_CODES = require("./char-codes-turk.js");

var TurkishDictionary = (function () {
  function TurkishDictionary() {
    this.host = "http://www.turkishdictionary.net/?word=%FC";
    this.path = "";
    this.protocol = "http";
    this.query = "&s=";
    this.TABLE_CLASS = "___mtt_translate_table";
    this.need_publish = true;
  }

  _prototypeProperties(TurkishDictionary, null, {
    search: {
      value: function search(data) {
        data.url = this.makeUrl(data.value);
        this.need_publish = false;
        return this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    translate: {
      value: function translate(data) {
        console.log("request data:", data);
        data.url = this.makeUrl(data.selectionText);
        this.need_publish = true;
        this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeUrl: {
      value: function makeUrl(text) {
        var text = this.getEncodedValue(text);
        return ["http://www.turkishdictionary.net/?word=", text].join("");
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    getEncodedValue: {
      // Replace special language characters to html codes
      value: function getEncodedValue(value) {
        // to find spec symbols we first encode them (raw search for that symbol doesn't wor)
        var val = encodeURIComponent(value);
        for (var char in CHAR_CODES) {
          val = val.replace(char, CHAR_CODES[char]);
        }
        return val;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    request: {

      /*
        Request translation and run callback function
        passing translated result or error to callback
      */
      value: function request(opts) {
        console.log("start request");
        this.xhr = new XMLHttpRequest();
        this.xhr.onreadystatechange = this.onReadyStateChange.bind(this, opts);
        this.xhr.open("GET", opts.url, true);
        this.xhr.send();
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    onReadyStateChange: {
      value: function onReadyStateChange(opts, e) {
        var xhr = this.xhr;
        if (xhr.readyState < 4) {
          return;
        } else if (xhr.status != 200) {
          this.errorHandler(xhr);
          return opts.error && opts.error();
        } else if (xhr.readyState == 4) {
          var translation = this.successHandler(e.target.response);
          console.log("success turkish translate", translation);
          console.log("call", opts.success);
          return opts.success && opts.success(translation);
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    successHandler: {
      value: function successHandler(response) {
        var data = this.parse(response);
        if (this.need_publish) {
          chrome.tabs.getSelected(null, this.publishTranslation.bind(this, data));
        }
        return data;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    publishTranslation: {

      /* publish successfuly translated text all over extension */
      value: function publishTranslation(translation, tab) {
        console.log("publish translation");
        chrome.tabs.sendMessage(tab.id, {
          action: "open_tooltip",
          data: translation.outerHTML,
          success: !translation.classList.contains("failTranslate")
        });
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    errorHandler: {
      value: function errorHandler(response) {
        console.log("error ajax", response);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parse: {

      /* Parse response from translation engine */
      value: function parse(response, silent, translate) {
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);
        if (fragment) {
          translate = fragment.querySelector("#meaning_div > table");
          if (translate) {
            translate.className = this.TABLE_CLASS;
            translate.setAttribute("cellpadding", "5");
            // @fixImages(translate)
            // @fixLinks(translate)
          } else if (!silent) {
            translate = document.createElement("div");
            translate.className = "failTranslate";
            translate.innerText = "Unfortunately, could not translate";
          }
        }
        return translate;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    stripScripts: {

      //TODO extract to base engine class
      /* removes <script> tags from html code */
      value: function stripScripts(html) {
        var div = document.createElement("div");
        div.innerHTML = html;
        var scripts = div.getElementsByTagName("script");
        var i = scripts.length;
        while (i--) scripts[i].parentNode.removeChild(scripts[i]);
        return div.innerHTML;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeFragment: {

      //TODO extract to base engine class
      /* creates temp object to parse translation from page 
        (since it's not a friendly api) 
      */
      value: function makeFragment(html) {
        var fragment,
            div = document.createElement("div");
        div.innerHTML = html;
        fragment = document.createDocumentFragment();
        while (div.firstChild) {
          fragment.appendChild(div.firstChild);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    }
  });

  return TurkishDictionary;
})();

// Singletone
module.exports = new TurkishDictionary();
},{"./char-codes-turk.js":1}]},{},[4])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvY2hhci1jb2Rlcy10dXJrLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy9jaGFyLWNvZGVzLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy9wb3B1cC9kcm9wZG93bi5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXZlbG9wbWVudC90cmFuL2pzL3BvcHVwL3BvcHVwLmNvZmZlZSIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvcG9wdXAvc2VhcmNoX2Zvcm0uY29mZmVlIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy90cmFuLmNvZmZlZSIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvdHVya2lzaGRpY3Rpb25hcnkuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ25CQTs7QUNBQTtBQUFBOzs7Ozs7OztHQUFBO0FBQUEsSUFBQSw4QkFBQTs7QUFBQSxTQVNBLEdBQ0U7QUFBQSxFQUFBLEdBQUEsRUFBSyxLQUFMO0FBQUEsRUFDQSxHQUFBLEVBQUssS0FETDtBQUFBLEVBRUEsR0FBQSxFQUFLLEtBRkw7QUFBQSxFQUdBLEdBQUEsRUFBSyxLQUhMO0FBQUEsRUFJQSxHQUFBLEVBQUssS0FKTDtBQUFBLEVBS0EsSUFBQSxFQUFNLEtBTE47QUFBQSxFQU1BLElBQUEsRUFBTSxLQU5OO0FBQUEsRUFPQSxJQUFBLEVBQU0sS0FQTjtBQUFBLEVBUUEsSUFBQSxFQUFNLEtBUk47QUFBQSxFQVNBLElBQUEsRUFBTSxLQVROO0FBQUEsRUFVQSxJQUFBLEVBQU0sS0FWTjtBQUFBLEVBV0EsSUFBQSxFQUFNLEtBWE47QUFBQSxFQVlBLE1BQUEsRUFBUSxLQVpSO0NBVkYsQ0FBQTs7QUFBQSxTQXdCQSxHQUNFO0FBQUEsRUFBQSxHQUFBLEVBQUssV0FBTDtBQUFBLEVBQ0EsTUFBQSxFQUFRLFNBRFI7Q0F6QkYsQ0FBQTs7QUFBQTtBQTZCZSxFQUFBLGtCQUFDLElBQUQsR0FBQTtBQUNYLElBQUEsSUFBQyxDQUFBLEVBQUQsR0FBTSxJQUFJLENBQUMsRUFBTCxJQUFXLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCLENBQWpCLENBQUE7QUFBQSxJQUVBLElBQUMsQ0FBQSxRQUFELEdBQVksSUFBSSxDQUFDLFFBRmpCLENBQUE7QUFBQSxJQUlBLElBQUMsQ0FBQSxJQUFELEdBQVEsSUFBQyxDQUFBLEVBQUUsQ0FBQyxhQUFKLENBQWtCLGdCQUFsQixDQUpSLENBQUE7QUFLQSxJQUFBLElBQUcsSUFBQyxDQUFBLElBQUo7QUFDRSxNQUFBLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQVosR0FBc0IsTUFBdEIsQ0FBQTtBQUFBLE1BQ0EsSUFBQyxDQUFBLEtBQUQsR0FBUyxJQUFDLENBQUEsSUFBSSxDQUFDLHNCQUFOLENBQTZCLGVBQTdCLENBRFQsQ0FBQTtBQUFBLE1BRUEsSUFBQyxDQUFBLE1BQUQsR0FBVSxJQUFDLENBQUEsRUFBRSxDQUFDLGFBQUosQ0FBa0Isa0JBQWxCLENBRlYsQ0FBQTtBQUFBLE1BR0EsSUFBQyxDQUFBLFlBQUQsQ0FBQSxDQUhBLENBQUE7QUFBQSxNQUlBLElBQUMsQ0FBQSxZQUFELENBQUEsQ0FKQSxDQURGO0tBTlc7RUFBQSxDQUFiOztBQUFBLHFCQWFBLFlBQUEsR0FBYyxTQUFBLEdBQUE7QUFDWixJQUFBLElBQUMsQ0FBQSxNQUFNLENBQUMsZ0JBQVIsQ0FBeUIsT0FBekIsRUFBa0MsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsQ0FBRCxHQUFBO2VBQU8sS0FBQyxDQUFBLE1BQUQsQ0FBUSxDQUFSLEVBQVA7TUFBQSxFQUFBO0lBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFsQyxDQUFBLENBQUE7QUFBQSxJQUNBLFFBQVEsQ0FBQyxnQkFBVCxDQUEwQixPQUExQixFQUFtQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7ZUFBTyxLQUFDLENBQUEsSUFBRCxDQUFNLENBQU4sRUFBUDtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQW5DLENBREEsQ0FBQTtXQUVBLElBQUMsQ0FBQSxJQUFJLENBQUMsZ0JBQU4sQ0FBdUIsT0FBdkIsRUFBZ0MsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsQ0FBRCxHQUFBO2VBQU8sS0FBQyxDQUFBLE1BQUQsQ0FBUSxDQUFSLEVBQVA7TUFBQSxFQUFBO0lBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFoQyxFQUhZO0VBQUEsQ0FiZCxDQUFBOztBQUFBLHFCQW1CQSxZQUFBLEdBQWMsU0FBQSxHQUFBO1dBQ1osTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBcEIsQ0FBd0I7QUFBQSxNQUFFLFFBQUEsRUFBVSxHQUFaO0tBQXhCLEVBQTBDLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLEtBQUQsR0FBQTtlQUN4QyxLQUFDLENBQUEsUUFBRCxDQUFVLEtBQUssQ0FBQyxRQUFoQixFQUR3QztNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQTFDLEVBRFk7RUFBQSxDQW5CZCxDQUFBOztBQUFBLHFCQXdCQSxNQUFBLEdBQVEsU0FBQyxDQUFELEdBQUE7QUFDTixJQUFBLENBQUMsQ0FBQyxlQUFGLENBQUEsQ0FBQSxDQUFBO0FBQUEsSUFDQSxJQUFDLENBQUEsYUFBRCxDQUFBLENBREEsQ0FBQTtBQUVBLElBQUEsSUFBRyxJQUFDLENBQUEsSUFBRCxJQUFVLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQVosS0FBdUIsTUFBcEM7YUFDRSxJQUFDLENBQUEsSUFBRCxDQUFBLEVBREY7S0FBQSxNQUFBO2FBR0UsSUFBQyxDQUFBLElBQUQsQ0FBQSxFQUhGO0tBSE07RUFBQSxDQXhCUixDQUFBOztBQUFBLHFCQWlDQSxhQUFBLEdBQWUsU0FBQSxHQUFBO1dBQ2IsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBcEIsQ0FBd0I7QUFBQSxNQUFDLFFBQUEsRUFBVSxHQUFYO0tBQXhCLEVBQXlDLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLEtBQUQsR0FBQTtBQUN2QyxZQUFBLDhCQUFBO0FBQUE7QUFBQTthQUFBLDJDQUFBOzBCQUFBO0FBQ0UsVUFBQSxJQUFHLElBQUksQ0FBQyxZQUFMLENBQWtCLFVBQWxCLENBQUEsS0FBaUMsS0FBSyxDQUFDLFFBQTFDOzBCQUNFLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBZixDQUFtQixRQUFuQixHQURGO1dBQUEsTUFBQTswQkFHRSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQWYsQ0FBc0IsUUFBdEIsR0FIRjtXQURGO0FBQUE7d0JBRHVDO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBekMsRUFEYTtFQUFBLENBakNmLENBQUE7O0FBQUEscUJBeUNBLElBQUEsR0FBTSxTQUFBLEdBQUE7V0FDSixJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFaLEdBQXNCLE9BRGxCO0VBQUEsQ0F6Q04sQ0FBQTs7QUFBQSxxQkE0Q0EsSUFBQSxHQUFNLFNBQUEsR0FBQTtXQUNKLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQVosR0FBc0IsUUFEbEI7RUFBQSxDQTVDTixDQUFBOztBQUFBLHFCQWlEQSxNQUFBLEdBQVEsU0FBQyxDQUFELEdBQUE7QUFDTixRQUFBLG9CQUFBO0FBQUEsSUFBQSxDQUFDLENBQUMsZUFBRixDQUFBLENBQUEsQ0FBQTtBQUFBLElBQ0EsQ0FBQyxDQUFDLGNBQUYsQ0FBQSxDQURBLENBQUE7QUFBQSxJQUVBLFFBQUEsR0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVQsQ0FBc0IsVUFBdEIsQ0FGWCxDQUFBO0FBQUEsSUFHQSxVQUFBLEdBQWEsSUFBQyxDQUFBLGFBQUQsQ0FBZSxRQUFmLENBSGIsQ0FBQTtBQUFBLElBSUEsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBcEIsQ0FBd0I7QUFBQSxNQUFDLFFBQUEsRUFBVSxRQUFYO0FBQUEsTUFBcUIsVUFBQSxFQUFZLFVBQWpDO0tBQXhCLEVBQXNFLElBQUMsQ0FBQSxRQUF2RSxDQUpBLENBQUE7QUFBQSxJQUtBLElBQUMsQ0FBQSxRQUFELENBQVUsUUFBVixDQUxBLENBQUE7V0FNQSxJQUFDLENBQUEsSUFBRCxDQUFBLEVBUE07RUFBQSxDQWpEUixDQUFBOztBQUFBLHFCQTREQSxhQUFBLEdBQWUsU0FBQyxJQUFELEdBQUE7QUFDYixRQUFBLElBQUE7QUFBQSxJQUFBLE9BQU8sQ0FBQyxHQUFSLENBQVksa0JBQVosRUFBK0IsSUFBL0IsQ0FBQSxDQUFBO0FBQUEsSUFDQSxJQUFBLEdBQU8sU0FBVSxDQUFBLElBQUEsQ0FBVixJQUFtQixXQUQxQixDQUFBO0FBQUEsSUFFQSxPQUFPLENBQUMsR0FBUixDQUFZLE1BQVosRUFBbUIsSUFBbkIsQ0FGQSxDQUFBO0FBR0EsV0FBTyxJQUFQLENBSmE7RUFBQSxDQTVEZixDQUFBOztBQUFBLHFCQW1FQSxRQUFBLEdBQVUsU0FBQyxRQUFELEdBQUE7QUFDUixRQUFBLElBQUE7QUFBQSxJQUFBLElBQUEsR0FBTyxTQUFVLENBQUEsUUFBQSxDQUFWLEdBQXNCLDhCQUE3QixDQUFBO1dBQ0EsSUFBQyxDQUFBLE1BQU0sQ0FBQyxTQUFSLEdBQW9CLEtBRlo7RUFBQSxDQW5FVixDQUFBOztrQkFBQTs7SUE3QkYsQ0FBQTs7QUFBQSxNQXFHTSxDQUFDLE9BQVAsR0FBaUIsUUFyR2pCLENBQUE7Ozs7QUNBQTtBQUFBOzs7R0FBQTtBQUFBLElBQUEsVUFBQTs7QUFBQSxVQUlBLEdBQWEsT0FBQSxDQUFRLHNCQUFSLENBSmIsQ0FBQTs7QUFBQSxRQU1RLENBQUMsZ0JBQVQsQ0FBMEIsa0JBQTFCLEVBQThDLFNBQUEsR0FBQTtBQUM1QyxNQUFBLFVBQUE7QUFBQSxFQUFBLElBQUEsR0FBVyxJQUFBLFVBQUEsQ0FBVyxRQUFRLENBQUMsY0FBVCxDQUF3QixXQUF4QixDQUFYLENBQVgsQ0FBQTtBQUFBLEVBQ0EsSUFBQSxHQUFPLFFBQVEsQ0FBQyxjQUFULENBQXdCLGFBQXhCLENBRFAsQ0FBQTtBQUVBLEVBQUEsSUFBRyxJQUFIO1dBQ0UsSUFBSSxDQUFDLGdCQUFMLENBQXNCLE9BQXRCLEVBQStCLFNBQUMsQ0FBRCxHQUFBO0FBQzdCLFVBQUEsSUFBQTtBQUFBLE1BQUEsQ0FBQyxDQUFDLGNBQUYsQ0FBQSxDQUFBLENBQUE7QUFBQSxNQUNBLElBQUEsR0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVQsQ0FBc0IsTUFBdEIsQ0FBQSxHQUFnQyxJQUFJLENBQUMsUUFBTCxDQUFBLENBRHZDLENBQUE7YUFFQSxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQVosQ0FBbUI7QUFBQSxRQUFFLEdBQUEsRUFBSyxJQUFQO09BQW5CLEVBSDZCO0lBQUEsQ0FBL0IsRUFERjtHQUg0QztBQUFBLENBQTlDLENBTkEsQ0FBQTs7OztBQ0FBO0FBQUE7Ozs7O0dBQUE7QUFBQSxJQUFBLGdFQUFBO0VBQUEscUpBQUE7O0FBQUEsUUFNQSxHQUFXLE9BQUEsQ0FBUSxtQkFBUixDQU5YLENBQUE7O0FBQUEsSUFTQSxHQUFPLE9BQUEsQ0FBUSxnQkFBUixDQVRQLENBQUE7O0FBQUEsaUJBVUEsR0FBb0IsT0FBQSxDQUFRLHlCQUFSLENBVnBCLENBQUE7O0FBQUEsaUJBY0EsR0FDRTtBQUFBLEVBQUEsV0FBQSxFQUFhLElBQWI7QUFBQSxFQUNBLFNBQUEsRUFBVyxpQkFEWDtDQWZGLENBQUE7O0FBQUE7QUFtQmUsRUFBQSxvQkFBRSxJQUFGLEdBQUE7QUFDWCxJQURZLElBQUMsQ0FBQSxPQUFBLElBQ2IsQ0FBQTtBQUFBLElBQUEsSUFBQyxDQUFBLEtBQUQsR0FBUyxRQUFRLENBQUMsY0FBVCxDQUF3QixlQUF4QixDQUFULENBQUE7QUFBQSxJQUNBLElBQUMsQ0FBQSxLQUFLLENBQUMsS0FBUCxDQUFBLENBREEsQ0FBQTtBQUFBLElBR0EsSUFBQyxDQUFBLE1BQUQsR0FBVSxRQUFRLENBQUMsY0FBVCxDQUF3QixRQUF4QixDQUhWLENBQUE7QUFBQSxJQUlBLElBQUMsQ0FBQSxZQUFELENBQUEsQ0FKQSxDQUFBO0FBQUEsSUFLQSxJQUFDLENBQUEsUUFBRCxHQUFnQixJQUFBLFFBQUEsQ0FBUztBQUFBLE1BQ3ZCLEVBQUEsRUFBSSxRQUFRLENBQUMsYUFBVCxDQUF1QixjQUF2QixDQURtQjtBQUFBLE1BRXZCLFFBQUEsRUFBVSxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQSxHQUFBO2lCQUFHLEtBQUMsQ0FBQSxNQUFELENBQUEsRUFBSDtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRmE7S0FBVCxDQUxoQixDQURXO0VBQUEsQ0FBYjs7QUFBQSx1QkFXQSxZQUFBLEdBQWMsU0FBQSxHQUFBO0FBQ1osSUFBQSxJQUFHLElBQUMsQ0FBQSxJQUFELElBQVUsSUFBQyxDQUFBLE1BQWQ7QUFDRSxNQUFBLElBQUMsQ0FBQSxJQUFJLENBQUMsZ0JBQU4sQ0FBdUIsUUFBdkIsRUFBaUMsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsQ0FBRCxHQUFBO2lCQUFPLEtBQUMsQ0FBQSxNQUFELENBQVEsQ0FBUixFQUFQO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBakMsQ0FBQSxDQUFBO2FBQ0EsSUFBQyxDQUFBLE1BQU0sQ0FBQyxnQkFBUixDQUF5QixPQUF6QixFQUFrQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxDQUFELEdBQUE7aUJBQU8sS0FBQyxDQUFBLGtCQUFELENBQW9CLENBQXBCLEVBQVA7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFsQyxFQUZGO0tBRFk7RUFBQSxDQVhkLENBQUE7O0FBQUEsdUJBZ0JBLE1BQUEsR0FBUSxTQUFDLENBQUQsR0FBQTtBQUNOLElBQUEsQ0FBQSxJQUFLLENBQUMsQ0FBQyxjQUFQLElBQXlCLENBQUMsQ0FBQyxjQUFGLENBQUEsQ0FBekIsQ0FBQTtBQUNBLElBQUEsSUFBRyxJQUFDLENBQUEsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFiLEdBQXNCLENBQXpCO2FBRUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBcEIsQ0FBd0I7QUFBQSxRQUFDLFFBQUEsRUFBVSxHQUFYO0FBQUEsUUFBZ0IsVUFBQSxFQUFZLFdBQTVCO09BQXhCLEVBQWtFLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLEtBQUQsR0FBQTtBQUNoRSxVQUFBLE9BQU8sQ0FBQyxHQUFSLENBQVksUUFBWixFQUFzQixLQUF0QixDQUFBLENBQUE7aUJBQ0EsaUJBQWtCLENBQUEsS0FBSyxDQUFDLFVBQU4sQ0FBaUIsQ0FBQyxNQUFwQyxDQUNFO0FBQUEsWUFBQSxLQUFBLEVBQU8sS0FBQyxDQUFBLEtBQUssQ0FBQyxLQUFkO0FBQUEsWUFDQSxPQUFBLEVBQVMsS0FBQyxDQUFBLGNBQWMsQ0FBQyxJQUFoQixDQUFxQixLQUFyQixDQURUO1dBREYsRUFGZ0U7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFsRSxFQUZGO0tBRk07RUFBQSxDQWhCUixDQUFBOztBQUFBLHVCQTJCQSxjQUFBLEdBQWdCLFNBQUMsUUFBRCxHQUFBO0FBQ1osSUFBQSxJQUFDLENBQUEsS0FBRCxDQUFPLElBQUMsQ0FBQSxNQUFSLENBQUEsQ0FBQTtXQUNBLElBQUMsQ0FBQSxNQUFNLENBQUMsV0FBUixDQUFvQixRQUFwQixFQUZZO0VBQUEsQ0EzQmhCLENBQUE7O0FBQUEsdUJBK0JBLEtBQUEsR0FBTyxTQUFDLEVBQUQsR0FBQTtBQUNMLFFBQUEsUUFBQTtBQUFBO1dBQU8sRUFBRSxDQUFDLFNBQVYsR0FBQTtBQUNFLG9CQUFBLEVBQUUsQ0FBQyxXQUFILENBQWUsRUFBRSxDQUFDLFNBQWxCLEVBQUEsQ0FERjtJQUFBLENBQUE7b0JBREs7RUFBQSxDQS9CUCxDQUFBOztBQUFBLHVCQW1DQSxrQkFBQSxHQUFvQixTQUFDLENBQUQsR0FBQTtBQUNsQixRQUFBLGNBQUE7QUFBQSxJQUFBLENBQUMsQ0FBQyxjQUFGLENBQUEsQ0FBQSxDQUFBO0FBQUEsSUFDQSxRQUFBLEdBQVcsQ0FBQyxHQUFELEVBQU0sR0FBTixDQURYLENBQUE7QUFFQSxJQUFBLFdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFULEVBQUEsZUFBb0IsUUFBcEIsRUFBQSxJQUFBLE1BQUg7QUFDRSxNQUFBLElBQUMsQ0FBQSxLQUFLLENBQUMsS0FBUCxHQUFlLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBeEIsQ0FBQTthQUNBLElBQUMsQ0FBQSxNQUFELENBQVEsQ0FBUixFQUZGO0tBSGtCO0VBQUEsQ0FuQ3BCLENBQUE7O0FBQUEsdUJBMENBLFFBQUEsR0FBVSxTQUFBLEdBQUE7QUFDUixXQUFPLElBQUMsQ0FBQSxLQUFLLENBQUMsS0FBZCxDQURRO0VBQUEsQ0ExQ1YsQ0FBQTs7b0JBQUE7O0lBbkJGLENBQUE7O0FBQUEsTUFnRk0sQ0FBQyxPQUFQLEdBQWlCLFVBaEZqQixDQUFBOzs7O0FDQUE7QUFBQSxrQkFBQTtBQUNBO0FBQUE7Ozs7Ozs7Ozs7R0FEQTtBQUFBLElBQUEsZ0JBQUE7O0FBQUEsVUFhQSxHQUFhLE9BQUEsQ0FBUSxpQkFBUixDQWJiLENBQUE7O0FBQUE7QUFnQmUsRUFBQSxjQUFBLEdBQUE7QUFDWCxJQUFBLElBQUMsQ0FBQSxXQUFELEdBQWUsd0JBQWYsQ0FBQTtBQUFBLElBQ0EsSUFBQyxDQUFBLFFBQUQsR0FBWSxNQURaLENBQUE7QUFBQSxJQUVBLElBQUMsQ0FBQSxJQUFELEdBQVEsa0JBRlIsQ0FBQTtBQUFBLElBR0EsSUFBQyxDQUFBLElBQUQsR0FBUSxVQUhSLENBQUE7QUFBQSxJQUlBLElBQUMsQ0FBQSxLQUFELEdBQVMsS0FKVCxDQUFBO0FBQUEsSUFLQSxJQUFDLENBQUEsSUFBRCxHQUFRLFlBTFIsQ0FBQTtBQUFBLElBTUEsSUFBQyxDQUFBLEdBQUQsR0FBTyxFQU5QLENBRFc7RUFBQSxDQUFiOztBQVNBO0FBQUE7O0tBVEE7O0FBQUEsaUJBWUEsS0FBQSxHQUFPLFNBQUMsSUFBRCxHQUFBO0FBQ0wsUUFBQSxhQUFBO0FBQUEsSUFBQSxJQUFHLE1BQUEsQ0FBQSxJQUFXLENBQUMsTUFBWixLQUFzQixNQUF0QixJQUFtQyxJQUFJLENBQUMsTUFBTCxLQUFlLElBQXJEO0FBQ0UsTUFBQSxJQUFJLENBQUMsTUFBTCxHQUFjLElBQWQsQ0FERjtLQUFBO0FBQUEsSUFFQSxhQUFBLEdBQWdCLElBQUMsQ0FBQSxpQkFBRCxDQUFtQixJQUFJLENBQUMsYUFBeEIsQ0FGaEIsQ0FBQTtXQUdBLElBQUMsQ0FBQSxNQUFELENBQ0k7QUFBQSxNQUFBLEtBQUEsRUFBTyxhQUFQO0FBQUEsTUFDQSxPQUFBLEVBQVMsSUFBQyxDQUFBLGVBQWUsQ0FBQyxJQUFqQixDQUFzQixJQUF0QixDQURUO0FBQUEsTUFFQSxNQUFBLEVBQVEsSUFBSSxDQUFDLE1BRmI7S0FESixFQUpLO0VBQUEsQ0FaUCxDQUFBOztBQXFCQTtBQUFBOztLQXJCQTs7QUFBQSxpQkF3QkEsaUJBQUEsR0FBbUIsU0FBQyxJQUFELEdBQUE7V0FDakIsSUFBSSxDQUFDLE9BQUwsQ0FBYSxPQUFiLEVBQXNCLEVBQXRCLEVBRGlCO0VBQUEsQ0F4Qm5CLENBQUE7O0FBMkJBO0FBQUE7O0tBM0JBOztBQUFBLGlCQThCQSxNQUFBLEdBQVEsU0FBQyxNQUFELEdBQUE7V0FFTixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUMsUUFBQSxFQUFVLEdBQVg7S0FBeEIsRUFBeUMsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsS0FBRCxHQUFBO0FBQ3ZDLFlBQUEsMEJBQUE7QUFBQSxRQUFBLElBQUcsUUFBQSxLQUFZLEVBQWY7QUFDRSxVQUFBLFFBQUEsR0FBVyxHQUFYLENBREY7U0FBQTtBQUFBLFFBRUEsS0FBQyxDQUFBLFdBQUQsQ0FBYSxLQUFLLENBQUMsUUFBbkIsQ0FGQSxDQUFBO0FBQUEsUUFHQSxHQUFBLEdBQU0sS0FBQyxDQUFBLE9BQUQsQ0FBUyxNQUFNLENBQUMsS0FBaEIsQ0FITixDQUFBO0FBQUEsUUFLQSxXQUFBLEdBQWMsTUFBTSxDQUFDLE9BTHJCLENBQUE7QUFBQSxRQU1BLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLFNBQUMsUUFBRCxHQUFBO0FBQ2YsY0FBQSxVQUFBO0FBQUEsVUFBQSxVQUFBLEdBQWEsS0FBQyxDQUFBLEtBQUQsQ0FBTyxRQUFQLEVBQWlCLE1BQU0sQ0FBQyxNQUF4QixDQUFiLENBQUE7aUJBQ0EsV0FBQSxDQUFZLFVBQVosRUFGZTtRQUFBLENBTmpCLENBQUE7ZUFXQSxLQUFDLENBQUEsT0FBRCxDQUNFO0FBQUEsVUFBQSxHQUFBLEVBQUssR0FBTDtBQUFBLFVBQ0EsT0FBQSxFQUFTLE1BQU0sQ0FBQyxPQURoQjtBQUFBLFVBRUEsS0FBQSxFQUFPLE1BQU0sQ0FBQyxLQUZkO1NBREYsRUFadUM7TUFBQSxFQUFBO0lBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUF6QyxFQUZNO0VBQUEsQ0E5QlIsQ0FBQTs7QUFBQSxpQkFtREEsV0FBQSxHQUFhLFNBQUMsUUFBRCxHQUFBO0FBQ1gsSUFBQSxJQUFDLENBQUEsZUFBRCxHQUFtQixRQUFuQixDQUFBO1dBQ0EsSUFBQyxDQUFBLElBQUQsR0FBUSxXQUFBLEdBQWMsU0FGWDtFQUFBLENBbkRiLENBQUE7O0FBdURBO0FBQUE7OztLQXZEQTs7QUFBQSxpQkEyREEsT0FBQSxHQUFTLFNBQUMsSUFBRCxHQUFBO0FBQ1AsUUFBQSxHQUFBO0FBQUEsSUFBQSxHQUFBLEdBQU0sSUFBQyxDQUFBLEdBQUQsR0FBVyxJQUFBLGNBQUEsQ0FBQSxDQUFqQixDQUFBO0FBQUEsSUFDQSxHQUFHLENBQUMsa0JBQUosR0FBeUIsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsQ0FBRCxHQUFBO0FBQ3ZCLFFBQUEsR0FBQSxHQUFNLEtBQUMsQ0FBQSxHQUFQLENBQUE7QUFDQSxRQUFBLElBQUcsR0FBRyxDQUFDLFVBQUosR0FBaUIsQ0FBcEI7QUFBQTtTQUFBLE1BRUssSUFBRyxHQUFHLENBQUMsTUFBSixLQUFjLEdBQWpCO0FBQ0gsVUFBQSxLQUFDLENBQUEsWUFBRCxDQUFjLEdBQWQsQ0FBQSxDQUFBO0FBQ0EsVUFBQSxJQUFJLE1BQUEsQ0FBQSxJQUFXLENBQUMsS0FBWixLQUFxQixVQUF6QjtBQUNFLFlBQUEsSUFBSSxDQUFDLEtBQUwsQ0FBQSxDQUFBLENBREY7V0FGRztTQUFBLE1BS0EsSUFBRyxHQUFHLENBQUMsVUFBSixLQUFrQixDQUFyQjtBQUNELGlCQUFPLElBQUksQ0FBQyxPQUFMLENBQWEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUF0QixDQUFQLENBREM7U0FUa0I7TUFBQSxFQUFBO0lBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUR6QixDQUFBO0FBQUEsSUFhQSxHQUFHLENBQUMsSUFBSixDQUFTLEtBQVQsRUFBZ0IsSUFBSSxDQUFDLEdBQXJCLEVBQTBCLElBQTFCLENBYkEsQ0FBQTtXQWNBLEdBQUcsQ0FBQyxJQUFKLENBQUEsRUFmTztFQUFBLENBM0RULENBQUE7O0FBQUEsaUJBNkVBLE9BQUEsR0FBUyxTQUFDLEtBQUQsR0FBQTtBQUNQLFFBQUEsR0FBQTtBQUFBLElBQUEsR0FBQSxHQUFNLENBQUMsSUFBQyxDQUFBLFFBQUYsRUFBWSxLQUFaLEVBQ0ksSUFBQyxDQUFBLElBREwsRUFFSSxJQUFDLENBQUEsSUFGTCxFQUdJLElBQUMsQ0FBQSxJQUhMLEVBSUksSUFBQyxDQUFBLEtBSkwsRUFLSSxJQUFDLENBQUEsZUFBRCxDQUFpQixLQUFqQixDQUxKLENBTUMsQ0FBQyxJQU5GLENBTU8sRUFOUCxDQUFOLENBQUE7QUFRQSxXQUFPLEdBQVAsQ0FUTztFQUFBLENBN0VULENBQUE7O0FBQUEsaUJBeUZBLGVBQUEsR0FBaUIsU0FBQyxLQUFELEdBQUE7QUFFZixRQUFBLG1CQUFBO0FBQUEsSUFBQSxHQUFBLEdBQU0sa0JBQUEsQ0FBbUIsS0FBbkIsQ0FBTixDQUFBO0FBQ0EsU0FBQSxrQkFBQTs4QkFBQTtBQUNFLE1BQUEsSUFBRyxNQUFBLENBQUEsSUFBQSxLQUFlLFFBQWxCO0FBRUUsUUFBQSxFQUFBLEdBQUssSUFBSSxDQUFDLEdBQVYsQ0FBQTtBQUFBLFFBQ0EsT0FBTyxDQUFDLEdBQVIsQ0FBWSxLQUFaLEVBQW1CLEVBQW5CLENBREEsQ0FGRjtPQUFBLE1BQUE7QUFLRSxRQUFBLE9BQU8sQ0FBQyxHQUFSLENBQVksT0FBWixFQUFxQixFQUFyQixDQUFBLENBQUE7QUFBQSxRQUdBLEVBQUEsR0FBSyxrQkFBQSxDQUFtQixJQUFuQixDQUhMLENBTEY7T0FBQTtBQUFBLE1BU0EsR0FBQSxHQUFNLEdBQUcsQ0FBQyxPQUFKLENBQVksSUFBWixFQUFrQixFQUFsQixDQVROLENBREY7QUFBQSxLQURBO0FBWUEsV0FBTyxHQUFQLENBZGU7RUFBQSxDQXpGakIsQ0FBQTs7QUFBQSxpQkF5R0EsWUFBQSxHQUFjLFNBQUMsR0FBRCxHQUFBO1dBQ1osT0FBTyxDQUFDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCLEdBQXJCLEVBRFk7RUFBQSxDQXpHZCxDQUFBOztBQTRHQTtBQUFBOztLQTVHQTs7QUFBQSxpQkErR0EsZUFBQSxHQUFpQixTQUFDLFVBQUQsR0FBQTtBQUNmLElBQUEsSUFBRyxVQUFIO2FBQ0UsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFaLENBQXdCLElBQXhCLEVBQThCLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLEdBQUQsR0FBQTtpQkFDNUIsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFaLENBQXdCLEdBQUcsQ0FBQyxFQUE1QixFQUFnQztBQUFBLFlBQzlCLE1BQUEsRUFBUSxLQUFDLENBQUEsV0FBRCxDQUFhLFVBQWIsQ0FEc0I7QUFBQSxZQUU5QixJQUFBLEVBQU0sVUFBVSxDQUFDLFNBRmE7QUFBQSxZQUc5QixPQUFBLEVBQVMsQ0FBQSxVQUFXLENBQUMsU0FBUyxDQUFDLFFBQXJCLENBQThCLGVBQTlCLENBSG9CO1dBQWhDLEVBRDRCO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBOUIsRUFERjtLQURlO0VBQUEsQ0EvR2pCLENBQUE7O0FBQUEsaUJBeUhBLFdBQUEsR0FBYSxTQUFDLFVBQUQsR0FBQTtBQUNYLFFBQUEsSUFBQTtBQUFBLElBQUEsaUVBQW1CLENBQUUseUJBQWxCLEtBQTRCLENBQS9CO2FBQ0UsZ0JBREY7S0FBQSxNQUFBO2FBR0UsZUFIRjtLQURXO0VBQUEsQ0F6SGIsQ0FBQTs7QUErSEE7QUFBQTs7S0EvSEE7O0FBQUEsaUJBa0lBLEtBQUEsR0FBTyxTQUFDLFFBQUQsRUFBVyxNQUFYLEVBQW1CLFNBQW5CLEdBQUE7QUFDSCxRQUFBLGFBQUE7O01BRHNCLFlBQVk7S0FDbEM7QUFBQSxJQUFBLEdBQUEsR0FBTSxJQUFDLENBQUEsWUFBRCxDQUFjLFFBQWQsQ0FBTixDQUFBO0FBQUEsSUFDQSxRQUFBLEdBQVcsSUFBQyxDQUFBLFlBQUQsQ0FBYyxHQUFkLENBRFgsQ0FBQTtBQUVBLElBQUEsSUFBRyxRQUFIO0FBQ0UsTUFBQSxTQUFBLEdBQVksUUFBUSxDQUFDLGFBQVQsQ0FBdUIsc0JBQXZCLENBQVosQ0FBQTtBQUNBLE1BQUEsSUFBRyxTQUFIO0FBQ0UsUUFBQSxTQUFTLENBQUMsU0FBVixHQUFzQixJQUFDLENBQUEsV0FBdkIsQ0FBQTtBQUFBLFFBQ0EsU0FBUyxDQUFDLFlBQVYsQ0FBdUIsYUFBdkIsRUFBc0MsR0FBdEMsQ0FEQSxDQUFBO0FBQUEsUUFFQSxJQUFDLENBQUEsU0FBRCxDQUFXLFNBQVgsQ0FGQSxDQUFBO0FBQUEsUUFHQSxJQUFDLENBQUEsUUFBRCxDQUFVLFNBQVYsQ0FIQSxDQURGO09BQUEsTUFLSyxJQUFHLENBQUEsTUFBSDtBQUNILFFBQUEsU0FBQSxHQUFZLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCLENBQVosQ0FBQTtBQUFBLFFBQ0EsU0FBUyxDQUFDLFNBQVYsR0FBc0IsZUFEdEIsQ0FBQTtBQUFBLFFBRUEsU0FBUyxDQUFDLFNBQVYsR0FBc0Isb0NBRnRCLENBREc7T0FQUDtLQUZBO0FBY0EsV0FBTyxTQUFQLENBZkc7RUFBQSxDQWxJUCxDQUFBOztBQW1KQTtBQUFBOztLQW5KQTs7QUFBQSxpQkFzSkEsWUFBQSxHQUFjLFNBQUMsQ0FBRCxHQUFBO0FBQ1osUUFBQSxlQUFBO0FBQUEsSUFBQSxHQUFBLEdBQU0sUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBTixDQUFBO0FBQUEsSUFDQSxHQUFHLENBQUMsU0FBSixHQUFnQixDQURoQixDQUFBO0FBQUEsSUFFQSxPQUFBLEdBQVUsR0FBRyxDQUFDLG9CQUFKLENBQXlCLFFBQXpCLENBRlYsQ0FBQTtBQUFBLElBR0EsQ0FBQSxHQUFJLE9BQU8sQ0FBQyxNQUhaLENBQUE7QUFJQSxXQUFNLENBQUEsRUFBTixHQUFBO0FBQ0UsTUFBQSxPQUFRLENBQUEsQ0FBQSxDQUFFLENBQUMsVUFBVSxDQUFDLFdBQXRCLENBQWtDLE9BQVEsQ0FBQSxDQUFBLENBQTFDLENBQUEsQ0FERjtJQUFBLENBSkE7QUFNQSxXQUFPLEdBQUcsQ0FBQyxTQUFYLENBUFk7RUFBQSxDQXRKZCxDQUFBOztBQUFBLGlCQStKQSxZQUFBLEdBQWMsU0FBQyxHQUFELEVBQU0sUUFBTixHQUFBO0FBQ1osUUFBQSxHQUFBOztNQURrQixXQUFXO0tBQzdCO0FBQUEsSUFBQSxHQUFBLEdBQU0sUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBTixDQUFBO0FBQUEsSUFDQSxHQUFHLENBQUMsU0FBSixHQUFnQixHQURoQixDQUFBO0FBQUEsSUFFQSxRQUFBLEdBQVcsUUFBUSxDQUFDLHNCQUFULENBQUEsQ0FGWCxDQUFBO0FBR0EsV0FBUSxHQUFHLENBQUMsVUFBWixHQUFBO0FBQ0UsTUFBQSxRQUFRLENBQUMsV0FBVCxDQUFzQixHQUFHLENBQUMsVUFBMUIsQ0FBQSxDQURGO0lBQUEsQ0FIQTtBQUtBLFdBQU8sUUFBUCxDQU5ZO0VBQUEsQ0EvSmQsQ0FBQTs7QUFBQSxpQkF1S0EsU0FBQSxHQUFXLFNBQUMsUUFBRCxHQUFBOztNQUFDLFdBQVM7S0FDbkI7QUFBQSxJQUFBLElBQUksQ0FBQyxNQUFMLENBQVksUUFBWixFQUFzQixLQUF0QixFQUE2QixLQUE3QixDQUFBLENBQUE7QUFDQSxXQUFPLFFBQVAsQ0FGUztFQUFBLENBdktYLENBQUE7O0FBQUEsaUJBMktBLFFBQUEsR0FBVSxTQUFDLFFBQUQsR0FBQTs7TUFBQyxXQUFTO0tBQ2xCO0FBQUEsSUFBQSxJQUFJLENBQUMsTUFBTCxDQUFZLFFBQVosRUFBc0IsR0FBdEIsRUFBMkIsTUFBM0IsQ0FBQSxDQUFBO0FBQ0EsV0FBTyxRQUFQLENBRlE7RUFBQSxDQTNLVixDQUFBOztBQUFBLGlCQStLQSxNQUFBLEdBQVEsU0FBQyxRQUFELEVBQWdCLEdBQWhCLEVBQXFCLElBQXJCLEdBQUE7QUFDTixRQUFBLGdDQUFBOztNQURPLFdBQVM7S0FDaEI7QUFBQSxJQUFBLElBQUcsUUFBSDtBQUNFLE1BQUEsSUFBQSxHQUFRLFFBQVEsQ0FBQyxnQkFBVCxDQUEwQixHQUExQixDQUFSLENBQUE7QUFBQSxNQUNBLE1BQUEsR0FBUyxRQUFRLENBQUMsYUFBVCxDQUF1QixHQUF2QixDQURULENBQUE7QUFFQTtXQUFBLDJDQUFBO3VCQUFBO0FBQ0UsUUFBQSxNQUFNLENBQUMsSUFBUCxHQUFjLEdBQUksQ0FBQSxJQUFBLENBQWxCLENBQUE7QUFBQSxRQUNBLE1BQU0sQ0FBQyxJQUFQLEdBQWMsSUFBQyxDQUFBLElBRGYsQ0FBQTtBQUFBLFFBRUEsTUFBTSxDQUFDLFFBQVAsR0FBa0IsSUFBQyxDQUFBLFFBRm5CLENBQUE7QUFJQSxRQUFBLElBQUcsR0FBRyxDQUFDLE9BQUosS0FBZSxHQUFsQjtBQUNFLFVBQUEsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFkLENBQWtCLFVBQWxCLENBQUEsQ0FBQTtBQUNBLFVBQUEsSUFBRyxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQWhCLENBQXdCLE9BQXhCLENBQUEsS0FBc0MsQ0FBQSxDQUF6QztBQUNFLFlBQUEsTUFBTSxDQUFDLFFBQVAsR0FBa0IsSUFBQSxHQUFPLE1BQU0sQ0FBQyxRQUFoQyxDQUFBO0FBQUEsWUFDQSxHQUFHLENBQUMsWUFBSixDQUFpQixRQUFqQixFQUEyQixRQUEzQixDQURBLENBREY7V0FGRjtTQUFBLE1BS0ssSUFBRyxHQUFHLENBQUMsT0FBSixLQUFlLEtBQWxCO0FBQ0gsVUFBQSxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQWQsQ0FBa0IsU0FBbEIsQ0FBQSxDQURHO1NBVEw7QUFBQSxzQkFZQSxHQUFHLENBQUMsWUFBSixDQUFpQixJQUFqQixFQUF1QixNQUFNLENBQUMsSUFBOUIsRUFaQSxDQURGO0FBQUE7c0JBSEY7S0FETTtFQUFBLENBL0tSLENBQUE7O2NBQUE7O0lBaEJGLENBQUE7O0FBQUEsTUFvTk0sQ0FBQyxPQUFQLEdBQWlCLEdBQUEsQ0FBQSxJQXBOakIsQ0FBQTs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpfXZhciBmPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChmLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGYsZi5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCJ2YXIgQ0hBUl9DT0RFUyA9IHtcbiAgLy8gdHVya2lzaGRpY3Rpb25hcnkgY29kaW5nc1xuICAnJUM0JUIxJzogJyVGRCcsIC8vxLEgKExvd2VyY2FzZSBpLWRvdGxlc3MpICBhY3R1YWxseSBpdCBpcyAmIzMwNTsgYnV0IHR1cmtpc2hkaWN0aW9uYXJ5IG5lZWQgaXQgdGhpcyB3YXkgXG4gICclQzUlOUYnOiAnJUZFJywgLy/Fn1xuICAnJUM0JTlGJzogJyVGMCcsIC8vxJ8gIChzaWxlbnQgY2hhcmFjdGVyKVxuICAnJUMzJUE3JzogJyVFNycsIC8vw6dcbiAgJyVDMyVCNic6ICclRjYnLCAvL8O2XG4gICclQzMlQkMnOiAnJUZDJywgLy/DvFxuICAnJUMzJUEyJzogJyVFMicsIC8vIMOiXG5cbiAgIC8vICcnIDogJycsIC8vw4dcbiAgIC8vICcnIDogJycsIC8vxJ5cbiAgIC8vICcnIDogJycsIC8vw5ZcbiAgIC8vICcnIDogJycsIC8vxZ5cbiAgIC8vICcnIDogJycsIC8vw5xcbiAgIC8vICcnIDogJycsIC8vxLBcbiAgIC8vICcnIDogJycsIC8vw4Jcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBDSEFSX0NPREVTOyIsIi8qXHIgIE11bHRpdHJhbiBkZXBlbmRzIG9uIGh0bWwtZXNjYXBpbmcgKG5vdCBVVEYtOCkgcnVsZXMgZm9yIHNwZWNpYWwgc3ltYm9sc1xyICDDoCwgw6gsIMOsLCDDsiwgw7kgLSDDgCwgw4gsIMOMLCDDkiwgw5lcciAgw6EsIMOpLCDDrSwgw7MsIMO6LCDDvSAtIMOBLCDDiSwgw40sIMOTLCDDmiwgw51cciAgw6IsIMOqLCDDriwgw7QsIMO7IMOCLCDDiiwgw44sIMOULCDDm1xyICDDoywgw7EsIMO1IMODLCDDkSwgw5VcciAgw6QsIMOrLCDDrywgw7YsIMO8LCDDvyDDhCwgw4ssIMOPLCDDliwgw5wsXHIgIMOlLCDDhVxyICDDpiwgw4ZcciAgw6csIMOHXHIgIMOwLCDDkFxyICDDuCwgw5hcciAgwr8gwqEgw59cciovXHJ2YXIgQ0hBUl9DT0RFUyA9IHtcciAgLy9ydXNzaWFuXHIgICclRDElOEEnOiB7dmFsOiclRkEnLCBsYW5nOidydSd9LCAvLyDRilxyICAnJUQwJUFBJzoge3ZhbDonJURBJywgbGFuZzoncnUnfSwvLyDQqlxyXHIgICclQzMlODAnOiAnJiMxOTI7JywgLy8gw4BcciAgJyVDMyU4MSc6ICcmIzE5MzsnLCAvLyDDgVxyICAnJUMzJTgyJzogJyYjMTk0OycsIC8vIMOCXHIgICclQzMlODMnOiAnJiMxOTU7JywgLy8gw4NcciAgJyVDMyU4NCc6ICcmIzE5NjsnLCAvLyDDhFxyICAnJUMzJTg1JzogJyYjMTk3OycsIC8vIMOFXHIgICclQzMlODYnOiAnJiMxOTg7JywgLy8gw4ZcclxyICAnJUMzJTg3JzogJyYjMTk5OycsIC8vIMOHXHIgICclQzMlODgnOiAnJiMyMDA7JywgLy8gw4hcciAgJyVDMyU4OSc6ICcmIzIwMTsnLCAvLyDDiVxyICAnJUMzJThBJzogJyYjMjAyOycsIC8vIMOKXHIgICclQzMlOEInOiAnJiMyMDM7JywgLy8gw4tcclxyICAnJUMzJThDJzogJyYjMjA0OycsIC8vIMOMXHIgICclQzMlOEQnOiAnJiMyMDU7JywgLy8gw41cciAgJyVDMyU4RSc6ICcmIzIwNjsnLCAvLyDDjlxyICAnJUMzJThGJzogJyYjMjA3OycsIC8vIMOPXHJcciAgJyVDMyU5MSc6ICcmIzIwOTsnLCAvLyDDkVxyICAnJUMzJTkyJzogJyYjMjEwOycsIC8vIMOSXHIgICclQzMlOTMnOiAnJiMyMTE7JywgLy8gw5NcciAgJyVDMyU5NCc6ICcmIzIxMjsnLCAvLyDDlFxyICAnJUMzJTk1JzogJyYjMjEzOycsIC8vIMOVXHIgICclQzMlOTYnOiAnJiMyMTQ7JywgLy8gw5ZcclxyICAnJUMzJTk5JzogJyYjMjE3OycsIC8vIMOZXHIgICclQzMlOUEnOiAnJiMyMTg7JywgLy8gw5pcciAgJyVDMyU5Qic6ICcmIzIxOTsnLCAvLyDDm1xyICAnJUMzJTlDJzogJyYjMjIwOycsIC8vIMOcXHJcclxyICAnJUMzJUEwJzogJyYjMjI0OycsIC8vIMOgXHIgICclQzMlQTEnOiAnJiMyMjU7JywgLy8gw6FcciAgJyVDMyVBMic6ICcmIzIyNjsnLCAvLyDDolxyICAnJUMzJUEzJzogJyYjMjI3OycsIC8vIMOjXHIgICclQzMlQTQnOiAnJiMyMjg7JywgLy8gw6RcciAgJyVDMyVBNSc6ICcmIzIyOTsnLCAvLyDDpVxyICAnJUMzJUE2JzogJyYjMjMwOycsIC8vIMOmXHIgICclQzMlQTcnOiAnJiMyMzE7JywgLy8gw6dcclxyXHIgICclQzMlQTgnOiAnJiMyMzI7JywgLy8gw6hcciAgJyVDMyVBOSc6ICcmIzIzMzsnLCAvLyDDqVxyICAnJUMzJUFBJzogJyYjMjM0OycsIC8vIMOqXHIgICclQzMlQUInOiAnJiMyMzU7JywgLy8gw6tcclxyICAnJUMzJUFDJzogJyYjMjM2OycsIC8vIMOsXHIgICclQzMlQUQnOiAnJiMyMzc7JywgLy8gw61cciAgJyVDMyVBRSc6ICcmIzIzODsnLCAvLyDDrlxyICAnJUMzJUFGJzogJyYjMjM5OycsIC8vIMOvXHJcciAgJyVDMyVCMCc6ICcmIzI0MDsnLCAvLyDDsFxyICAnJUMzJUIxJzogJyYjMjQxOycsIC8vIMOxXHJcciAgJyVDMyVCMic6ICcmIzI0MjsnLCAvLyDDslxyICAnJUMzJUIzJzogJyYjMjQzOycsIC8vIMOzXHIgICclQzMlQjQnOiAnJiMyNDQ7JywgLy8gw7RcciAgJyVDMyVCNSc6ICcmIzI0NTsnLCAvLyDDtVxyICAnJUMzJUI2JzogJyYjMjQ2OycsIC8vIMO2XHJcciAgJyVDMyVCOSc6ICcmIzI0OTsnLCAvLyDDuVxyICAnJUMzJUJBJzogJyYjMjUwOycsIC8vIMO6XHIgICclQzMlQkInOiAnJiMyNTE7JywgLy8gw7tcciAgJyVDMyVCQyc6ICcmIzI1MjsnLCAvLyDDvFxyICAnJUMzJUJGJzogJyYjMjU1OycsIC8vIMO/XHIgICclQzUlQjgnOiAnJiMzNzY7JywgLy8gxbhcclxyICAnJUMzJTlGJzogJyYjMjIzOycsIC8vIMOfXHJcciAgJyVDMiVCRic6ICcmIzE5MTsnLCAvLyDCv1xyICAnJUMyJUExJzogJyYjMTYxOycsIC8vIMKhXHJ9O1xyXHJtb2R1bGUuZXhwb3J0cyA9IENIQVJfQ09ERVM7XHIiLCIjIyNcbiAgRHJvcGRvd24gbGFuZ3VhZ2UgbWVudVxuICBAcGFyYW0gb3B0cyB0YWtlcyBlbGVtZW50IGFuZCBvblNlbGVjdCBoYW5kbGVyXG4gIGV4YW1wbGU6XG4gIG5ldyBEcm9wZG93bih7XG4gICBlbDogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJyNtZW51Jyk7XG4gICBvblNlbGVjdDogZnVuY3Rpb24gKCkge31cbiAgfSlcbiMjI1xuTEFOR19DT0RFID1cbiAgJzEnOiAnRW5nJ1xuICAnMic6ICdSdXMnXG4gICczJzogJ0dlcidcbiAgJzQnOiAnRnJlJ1xuICAnNSc6ICdTcGEnXG4gICcyMyc6ICdJdGEnXG4gICcyNCc6ICdEdXQnXG4gICcyNic6ICdFc3QnXG4gICcyNyc6ICdMYXYnXG4gICczMSc6ICdBZnInXG4gICczNCc6ICdFcG8nXG4gICczNSc6ICdYYWwnLFxuICAnMTAwMCc6ICdUdXInXG5cbkRJQ1RfQ09ERSA9XG4gICcxJzogJ211bHRpdHJhbidcbiAgJzEwMDAnOiAndHVya2lzaCdcblxuY2xhc3MgRHJvcGRvd25cbiAgY29uc3RydWN0b3I6IChvcHRzKSAtPlxuICAgIEBlbCA9IG9wdHMuZWwgb3IgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgICAjIG9uU2VsZWN0IGhhbmRsZXIgc2V0IGJ5IGFnZ3JlZ2F0ZSBjbGFzc1xuICAgIEBvblNlbGVjdCA9IG9wdHMub25TZWxlY3RcblxuICAgIEBtZW51ID0gQGVsLnF1ZXJ5U2VsZWN0b3IoJy5kcm9wZG93bi1tZW51JylcbiAgICBpZiBAbWVudVxuICAgICAgQG1lbnUuc3R5bGUuZGlzcGxheSA9ICdub25lJ1xuICAgICAgQGl0ZW1zID0gQG1lbnUuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSgnbGFuZ3VhZ2UtdHlwZScpXG4gICAgICBAYnV0dG9uID0gQGVsLnF1ZXJ5U2VsZWN0b3IoJy5kcm9wZG93bi10b2dnbGUnKVxuICAgICAgQGFkZExpc3RlbmVycygpXG4gICAgICBAaW5pdExhbmd1YWdlKClcblxuICBhZGRMaXN0ZW5lcnM6IC0+XG4gICAgQGJ1dHRvbi5hZGRFdmVudExpc3RlbmVyICdjbGljaycsIChlKSA9PiBAdG9nZ2xlKGUpXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lciAnY2xpY2snLCAoZSkgPT4gQGhpZGUoZSlcbiAgICBAbWVudS5hZGRFdmVudExpc3RlbmVyICdjbGljaycsIChlKSA9PiBAY2hvb3NlKGUpXG5cbiAgIyBPbiBpbml0IHRyeWluZyB0byBnZXQgY3VycmVudCBsYW5ndWFnZSBmcm9tIHN0b3JhZ2Ugb3IgdXNpbmcgZGVmYXVsdCggMTplbmdsaXNoKVxuICBpbml0TGFuZ3VhZ2U6IC0+XG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoeyBsYW5ndWFnZTogJzEnfSwgKHN0b3JlKSA9PlxuICAgICAgQHNldFRpdGxlKHN0b3JlLmxhbmd1YWdlKTtcbiAgICApXG5cbiAgdG9nZ2xlOiAoZSkgLT5cbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG4gICAgQHNldEFjdGl2ZUl0ZW0oKVxuICAgIGlmIEBtZW51IGFuZCBAbWVudS5zdHlsZS5kaXNwbGF5IGlzICdub25lJ1xuICAgICAgQHNob3coKVxuICAgIGVsc2VcbiAgICAgIEBoaWRlKClcblxuICAjIFJlYWQgY3VycmVudCBsYW5ndWFnZSBmcm9tIENocm9tZSBTdG9yYWdlIGFuZCBjb2xvciBhY3RpdmUgbGluZVxuICBzZXRBY3RpdmVJdGVtOiAtPlxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0IHtsYW5ndWFnZTogJzEnfSwgKHN0b3JlKSA9PlxuICAgICAgZm9yIGl0ZW0gaW4gQGl0ZW1zXG4gICAgICAgIGlmIGl0ZW0uZ2V0QXR0cmlidXRlKCdkYXRhLXZhbCcpID09IHN0b3JlLmxhbmd1YWdlXG4gICAgICAgICAgaXRlbS5jbGFzc0xpc3QuYWRkKCdhY3RpdmUnKVxuICAgICAgICBlbHNlXG4gICAgICAgICAgaXRlbS5jbGFzc0xpc3QucmVtb3ZlKCdhY3RpdmUnKVxuXG4gIGhpZGU6IC0+XG4gICAgQG1lbnUuc3R5bGUuZGlzcGxheSA9ICdub25lJ1xuXG4gIHNob3c6IC0+XG4gICAgQG1lbnUuc3R5bGUuZGlzcGxheSA9ICdibG9jaydcblxuICAjIFNhdmVzIGNob3NlbiBsYW5ndWFnZSB0byBjaHJvbWUuc3RvcmFnZSBhbmQgZGVjaWRlIHdoaWNoIGRpY3Rpb25hcnkgdG8gdXNlXG4gICMgVGhlbiBjYWxsZWQgb25TZWxlY3QgaGFuZGxlciBvZiB0aGUgY29udGFpbmVyIGNsYXNzXG4gIGNob29zZTogKGUpIC0+XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKVxuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGxhbmd1YWdlID0gZS50YXJnZXQuZ2V0QXR0cmlidXRlKCdkYXRhLXZhbCcpXG4gICAgZGljdGlvbmFyeSA9IEBnZXREaWN0aW9uYXJ5KGxhbmd1YWdlKVxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuc2V0KHtsYW5ndWFnZTogbGFuZ3VhZ2UsIGRpY3Rpb25hcnk6IGRpY3Rpb25hcnl9LCBAb25TZWxlY3QpXG4gICAgQHNldFRpdGxlKGxhbmd1YWdlKVxuICAgIEBoaWRlKClcblxuICAjIFNvbWUgbGFuZ3VhZ2VzIGFyZSBub3QgcHJlc2VudCBpbiBtdWx0aXRyYW4gKGUuZy4gdHVya2lzaClcbiAgIyBzbyB3ZSBjaG9vc2UgYW5vdGhlciBzZXJ2aWNlXG4gIGdldERpY3Rpb25hcnk6IChsYW5nKSAtPlxuICAgIGNvbnNvbGUubG9nKCdjaG9vc2UgZGljdDogZm9yJyxsYW5nKTtcbiAgICBkaWN0ID0gRElDVF9DT0RFW2xhbmddIHx8ICdtdWx0aXRyYW4nXG4gICAgY29uc29sZS5sb2coJ2RpY3QnLGRpY3QpXG4gICAgcmV0dXJuIGRpY3RcblxuICAjU2V0IGN1cnJlbnQgbGFuZ3VhZ2UgbGFiZWxcbiAgc2V0VGl0bGU6IChsYW5ndWFnZSkgLT5cbiAgICBodG1sID0gTEFOR19DT0RFW2xhbmd1YWdlXSArICcgPHNwYW4gY2xhc3M9XCJjYXJldFwiPjwvc3Bhbj4nXG4gICAgQGJ1dHRvbi5pbm5lckhUTUwgPSBodG1sXG5cblxubW9kdWxlLmV4cG9ydHMgPSBEcm9wZG93biIsIiMjI1xuICBFeHRlbnNpb24gcG9wdXAgd2luZG93XG4gIFNob3dzIHNlYXJjaCBmb3JtIGFuZCBkcm9wZG93biBtZW51IHdpdGggbGFuZ3VhZ2VzXG4jIyNcblNlYXJjaEZvcm0gPSByZXF1aXJlKCcuL3NlYXJjaF9mb3JtLmNvZmZlZScpXG5cbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIgXCJET01Db250ZW50TG9hZGVkXCIsIC0+XG4gIGZvcm0gPSBuZXcgU2VhcmNoRm9ybSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndHJhbi1mb3JtJylcbiAgbGluayA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdoZWFkZXItbGluaycpXG4gIGlmIGxpbmtcbiAgICBsaW5rLmFkZEV2ZW50TGlzdGVuZXIgJ2NsaWNrJywgKGUpIC0+XG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICBocmVmID0gZS50YXJnZXQuZ2V0QXR0cmlidXRlKCdocmVmJykgKyBmb3JtLmdldFZhbHVlKClcbiAgICAgIGNocm9tZS50YWJzLmNyZWF0ZSh7IHVybDogaHJlZiB9KVxuIiwiIyMjXG4gIFNlcnZlcyBzZWFyY2ggaW5wdXQgYW5kIGZvcm1cblxuICBAcGFyYW0gZm9ybSBET00gZWxlbW50XG4gIEBjb25zdHJ1Y3RvclxuIyMjXG5Ecm9wZG93biA9IHJlcXVpcmUoJy4vZHJvcGRvd24uY29mZmVlJylcblxuI3RyYW5zbGF0ZSBlbmdpbmVzXG50cmFuID0gcmVxdWlyZSgnLi4vdHJhbi5jb2ZmZWUnKVxudHVya2lzaGRpY3Rpb25hcnkgPSByZXF1aXJlKCcuLi90dXJraXNoZGljdGlvbmFyeS5qcycpXG5cblxuI1RyYW5zbGF0ZSBlbmdpbmVzXG5UUkFOU0xBVEVfRU5HSU5FUyA9XG4gICdtdWx0aXRyYW4nOiB0cmFuXG4gICd0dXJraXNoJzogdHVya2lzaGRpY3Rpb25hcnlcblxuY2xhc3MgU2VhcmNoRm9ybVxuICBjb25zdHJ1Y3RvcjogKEBmb3JtKSAtPlxuICAgIEBpbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0cmFuc2xhdGUtdHh0JylcbiAgICBAaW5wdXQuZm9jdXMoKVxuXG4gICAgQHJlc3VsdCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyZXN1bHQnKVxuICAgIEBhZGRMaXN0ZW5lcnMoKTtcbiAgICBAZHJvcGRvd24gPSBuZXcgRHJvcGRvd24oe1xuICAgICAgZWw6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5kcm9wZG93bi1lbCcpLFxuICAgICAgb25TZWxlY3Q6ID0+IEBzZWFyY2goKVxuICAgIH0pO1xuXG4gIGFkZExpc3RlbmVyczogLT5cbiAgICBpZiBAZm9ybSBhbmQgQHJlc3VsdFxuICAgICAgQGZvcm0uYWRkRXZlbnRMaXN0ZW5lciAnc3VibWl0JywgKGUpID0+IEBzZWFyY2goZSlcbiAgICAgIEByZXN1bHQuYWRkRXZlbnRMaXN0ZW5lciAnY2xpY2snLCAoZSkgPT4gQHJlc3VsdENsaWNrSGFuZGxlcihlKVxuXG4gIHNlYXJjaDogKGUpIC0+XG4gICAgZSAmJiBlLnByZXZlbnREZWZhdWx0ICYmIGUucHJldmVudERlZmF1bHQoKVxuICAgIGlmIEBpbnB1dC52YWx1ZS5sZW5ndGggPiAwXG4gICAgICAjY2hvb3NlIGVuZ2luZSBhbmQgc2VhcmNoIGZvciB0cmFuc2xhdGlvbiAoYnkgZGVmYXVsdCBlbmdsaXNoLW11bHRpdHJhbilcbiAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHtsYW5ndWFnZTogJzEnLCBkaWN0aW9uYXJ5OiAnbXVsdGl0cmFuJ30sIChpdGVtcykgPT5cbiAgICAgICAgY29uc29sZS5sb2coJ0lURU1TOicsIGl0ZW1zKTtcbiAgICAgICAgVFJBTlNMQVRFX0VOR0lORVNbaXRlbXMuZGljdGlvbmFyeV0uc2VhcmNoXG4gICAgICAgICAgdmFsdWU6IEBpbnB1dC52YWx1ZVxuICAgICAgICAgIHN1Y2Nlc3M6IEBzdWNjZXNzSGFuZGxlci5iaW5kKEApXG4gICAgICApXG5cbiAgc3VjY2Vzc0hhbmRsZXI6IChyZXNwb25zZSkgLT5cbiAgICAgIEBjbGVhbihAcmVzdWx0KVxuICAgICAgQHJlc3VsdC5hcHBlbmRDaGlsZChyZXNwb25zZSlcblxuICBjbGVhbjogKGVsKSAtPlxuICAgIHdoaWxlIChlbC5sYXN0Q2hpbGQpXG4gICAgICBlbC5yZW1vdmVDaGlsZChlbC5sYXN0Q2hpbGQpXG5cbiAgcmVzdWx0Q2xpY2tIYW5kbGVyOiAoZSkgLT5cbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgbGlua1RhZ3MgPSBbJ0EnLCAnYSddXG4gICAgaWYgZS50YXJnZXQudGFnTmFtZSBpbiBsaW5rVGFnc1xuICAgICAgQGlucHV0LnZhbHVlID0gZS50YXJnZXQuaW5uZXJUZXh0O1xuICAgICAgQHNlYXJjaChlKVxuXG4gIGdldFZhbHVlOiAtPlxuICAgIHJldHVybiBAaW5wdXQudmFsdWVcblxuICAjIGlucHV0SGFuZGxlcjogKGUpIC0+XG4gICMgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7bGFuZ3VhZ2U6ICcxJywgZGljdGlvbmFyeTogJ211bHRpdHJhbid9LCAoaXRlbXMpID0+XG4gICMgICAgIFRSQU5TTEFURV9FTkdJTkVTW2l0ZW1zLmRpY3Rpb25hcnldLnJlcXVlc3RcbiAgIyAgICAgICB2YWx1ZTogQGlucHV0LnZhbHVlXG4gICMgICAgICAgc3VjY2VzczogQHN1Y2Nlc3NIYW5kbGVyLmJpbmQoQClcbiAgIyAgICAgICBlcnJvcjogcGFyYW1zLmVycm9yXG4gICMgICApXG4gICAgIyB2YWx1ZSA9IEBpbnB1dC52YWx1ZVxuICAgICMgdHJhbi5yZXF1ZXN0KFxuICAgICMgICB1cmw6IHVybCxcbiAgICAjICAgc3VjY2VzczogcGFyYW1zLnN1Y2Nlc3MsXG4gICAgIyAgIGVycm9yOiBwYXJhbXMuZXJyb3JcbiAgICAjIClcblxuXG5cbm1vZHVsZS5leHBvcnRzID0gU2VhcmNoRm9ybVxuIiwiIyMjZ2xvYmFsIGNocm9tZSMjI1xuIyMjXG4gIE11bHRpdHJhbi5ydSB0cmFuc2xhdGUgZW5naW5lXG4gIFByb3ZpZGVzIHByb2dyYW0gaW50ZXJmYWNlIGZvciBtYWtpbmcgdHJhbnNsYXRlIHF1ZXJpZXMgdG8gbXVsdGl0cmFuIGFuZCBnZXQgY2xlYW4gcmVzcG9uc2VcblxuICBBbGwgZW5naW5lcyBtdXN0IGZvbGxvdyBjb21tb24gaW50ZXJmYWNlIGFuZCBwcm92aWRlIG1ldGhvZHM6XG4gICAgLSBzZWFyY2ggKGxhbmd1YW5nZSwgc3VjY2Vzc0hhbmRsZXIpICBjbGVhbiB0cmFuc2xhdGlvbiBtdXN0IGJlIHBhc3NlZCBpbnRvIHN1Y2Nlc3NIYW5kbGVyXG4gICAgLSBjbGlja1xuXG4gIFRyYW5zbGF0aW9uLW1vZHVsZSB0aGF0IG1ha2VzIHJlcXVlc3RzIHRvIGxhbmd1YWdlLWVuZ2luZSxcbiAgcGFyc2VzIHJlc3VsdHMgYW5kIHNlbmRzIHBsdWdpbi1nbG9iYWwgbWVzc2FnZSB3aXRoIHRyYW5zbGF0aW9uIGRhdGFcbiMjI1xuXG5DSEFSX0NPREVTID0gcmVxdWlyZSgnLi9jaGFyLWNvZGVzLmpzJyk7XG5cbmNsYXNzIFRyYW5cbiAgY29uc3RydWN0b3I6IC0+XG4gICAgQFRBQkxFX0NMQVNTID0gXCJfX19tdHRfdHJhbnNsYXRlX3RhYmxlXCJcbiAgICBAcHJvdG9jb2wgPSAnaHR0cCdcbiAgICBAaG9zdCA9ICd3d3cubXVsdGl0cmFuLnJ1J1xuICAgIEBwYXRoID0gJy9jL20uZXhlJ1xuICAgIEBxdWVyeSA9ICcmcz0nXG4gICAgQGxhbmcgPSAnP2wxPTImbDI9MScgI2Zyb20gcnVzc2lhbiB0byBlbmdsaXNoIGJ5IGRlZmF1bHRcbiAgICBAeGhyID0ge31cblxuICAjIyNcbiAgICBDb250ZXh0IG1lbnUgY2xpY2sgaGFuZGxlclxuICAjIyNcbiAgY2xpY2s6IChkYXRhKSAtPlxuICAgIGlmIHR5cGVvZiBkYXRhLnNpbGVudCA9PSB1bmRlZmluZWQgfHwgZGF0YS5zaWxlbnQgPT0gbnVsbFxuICAgICAgZGF0YS5zaWxlbnQgPSB0cnVlICMgdHJ1ZSBieSBkZWZhdWx0XG4gICAgc2VsZWN0aW9uVGV4dCA9IEByZW1vdmVIeXBoZW5hdGlvbiBkYXRhLnNlbGVjdGlvblRleHRcbiAgICBAc2VhcmNoXG4gICAgICAgIHZhbHVlOiBzZWxlY3Rpb25UZXh0XG4gICAgICAgIHN1Y2Nlc3M6IEBzdWNjZXNzdEhhbmRsZXIuYmluZCh0aGlzKVxuICAgICAgICBzaWxlbnQ6IGRhdGEuc2lsZW50ICAjIGlmIHRyYW5zbGF0aW9uIGZhaWxlZCBkbyBub3Qgc2hvdyBkaWFsb2dcblxuICAjIyNcbiAgICBEaXNjYXJkIHNvZnQgaHlwaGVuIGNoYXJhY3RlciAoVSswMEFELCAmc2h5OykgZnJvbSB0aGUgaW5wdXRcbiAgIyMjXG4gIHJlbW92ZUh5cGhlbmF0aW9uOiAodGV4dCkgLT5cbiAgICB0ZXh0LnJlcGxhY2UgL1xceGFkL2csICcnXG5cbiAgIyMjXG4gICAgSW5pdGlhdGUgdHJhbnNsYXRpb24gc2VhcmNoXG4gICMjI1xuICBzZWFyY2g6IChwYXJhbXMpIC0+XG4gICAgI3ZhbHVlLCBjYWxsYmFjaywgZXJyXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoe2xhbmd1YWdlOiAnMSd9LCAoaXRlbXMpID0+XG4gICAgICBpZiBsYW5ndWFnZSBpcyAnJ1xuICAgICAgICBsYW5ndWFnZSA9ICcxJ1xuICAgICAgQHNldExhbmd1YWdlKGl0ZW1zLmxhbmd1YWdlKVxuICAgICAgdXJsID0gQG1ha2VVcmwocGFyYW1zLnZhbHVlKTtcbiAgICAgICMgZGVjb3JhdGUgc3VjY2VzcyB0byBtYWtlIHByZWxpbWluYXJ5IHBhcnNpbmdcbiAgICAgIG9yaWdTdWNjZXNzID0gcGFyYW1zLnN1Y2Nlc3NcbiAgICAgIHBhcmFtcy5zdWNjZXNzID0gKHJlc3BvbnNlKSA9PlxuICAgICAgICB0cmFuc2xhdGVkID0gQHBhcnNlKHJlc3BvbnNlLCBwYXJhbXMuc2lsZW50KVxuICAgICAgICBvcmlnU3VjY2Vzcyh0cmFuc2xhdGVkKVxuXG4gICAgICAjIG1ha2UgcmVxdWVzdCAoR0VUIHJlcXVlc3Qgd2l0aCBxdWVyeSBwYXJhbWV0ZXJzIGluIHVybClcbiAgICAgIEByZXF1ZXN0KFxuICAgICAgICB1cmw6IHVybCxcbiAgICAgICAgc3VjY2VzczogcGFyYW1zLnN1Y2Nlc3MsXG4gICAgICAgIGVycm9yOiBwYXJhbXMuZXJyb3JcbiAgICAgIClcbiAgICApXG5cbiAgc2V0TGFuZ3VhZ2U6IChsYW5ndWFnZSkgLT5cbiAgICBAY3VycmVudExhbmd1YWdlID0gbGFuZ3VhZ2VcbiAgICBAbGFuZyA9ICc/bDE9MiZsMj0nICsgbGFuZ3VhZ2VcblxuICAjIyNcbiAgICBSZXF1ZXN0IHRyYW5zbGF0aW9uIGFuZCBydW4gY2FsbGJhY2sgZnVuY3Rpb25cbiAgICBwYXNzaW5nIHRyYW5zbGF0ZWQgcmVzdWx0IG9yIGVycm9yIHRvIGNhbGxiYWNrXG4gICMjI1xuICByZXF1ZXN0OiAob3B0cykgLT5cbiAgICB4aHIgPSBAeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KClcbiAgICB4aHIub25yZWFkeXN0YXRlY2hhbmdlID0gKGUpID0+XG4gICAgICB4aHIgPSBAeGhyXG4gICAgICBpZiB4aHIucmVhZHlTdGF0ZSA8IDRcbiAgICAgICAgcmV0dXJuXG4gICAgICBlbHNlIGlmIHhoci5zdGF0dXMgIT0gMjAwXG4gICAgICAgIEBlcnJvckhhbmRsZXIoeGhyKVxuICAgICAgICBpZiAodHlwZW9mIG9wdHMuZXJyb3IgPT0gJ2Z1bmN0aW9uJylcbiAgICAgICAgICBvcHRzLmVycm9yKClcbiAgICAgICAgcmV0dXJuXG4gICAgICBlbHNlIGlmIHhoci5yZWFkeVN0YXRlID09IDRcbiAgICAgICAgICByZXR1cm4gb3B0cy5zdWNjZXNzKGUudGFyZ2V0LnJlc3BvbnNlKVxuXG4gICAgeGhyLm9wZW4oXCJHRVRcIiwgb3B0cy51cmwsIHRydWUpO1xuICAgIHhoci5zZW5kKCk7XG5cblxuICBtYWtlVXJsOiAodmFsdWUpIC0+XG4gICAgdXJsID0gW0Bwcm90b2NvbCwgJzovLycsXG4gICAgICAgICAgICAgIEBob3N0LFxuICAgICAgICAgICAgICBAcGF0aCxcbiAgICAgICAgICAgICAgQGxhbmcsXG4gICAgICAgICAgICAgIEBxdWVyeSxcbiAgICAgICAgICAgICAgQGdldEVuY29kZWRWYWx1ZSh2YWx1ZSlcbiAgICAgICAgICBdLmpvaW4oJycpXG5cbiAgICByZXR1cm4gdXJsO1xuXG4gICMgUmVwbGFjZSBzcGVjaWFsIGxhbmd1YWdlIGNoYXJhY3RlcnMgdG8gaHRtbCBjb2Rlc1xuICBnZXRFbmNvZGVkVmFsdWU6ICh2YWx1ZSkgLT5cbiAgICAjIHRvIGZpbmQgc3BlYyBzeW1ib2xzIHdlIGZpcnN0IGVuY29kZSB0aGVtIChyYXcgc2VhcmNoIGZvciB0aGF0IHN5bWJvbCBkb2Vzbid0IHdvcilcbiAgICB2YWwgPSBlbmNvZGVVUklDb21wb25lbnQodmFsdWUpXG4gICAgZm9yIGNoYXIsIGNvZGUgb2YgQ0hBUl9DT0RFU1xuICAgICAgaWYgdHlwZW9mIGNvZGUgPT0gJ29iamVjdCdcbiAgICAgICAgIyBydXNzaWFuIGhhcyBzcGVjaWFsIGNvZGVzXG4gICAgICAgIGNjID0gY29kZS52YWxcbiAgICAgICAgY29uc29sZS5sb2coJ3J1cycsIGNjKTtcbiAgICAgIGVsc2VcbiAgICAgICAgY29uc29sZS5sb2coJ2xhdGluJywgY2MpXG4gICAgICAgICMgZm9yIGFsbCBsYW5ncyBleGNlcHQgcnVzc2lhbiBlbmNvZGUgaHRtbC1jb2RlcyBuZWVkZWRcbiAgICAgICAgIyDQtNC70Y8g0LLRgdC10YUg0L7RgdGC0LDQu9GM0L3Ri9GFINGP0LfRi9C60L7QslxuICAgICAgICBjYyA9IGVuY29kZVVSSUNvbXBvbmVudChjb2RlKVxuICAgICAgdmFsID0gdmFsLnJlcGxhY2UoY2hhciwgY2MpXG4gICAgcmV0dXJuIHZhbFxuXG4gIGVycm9ySGFuZGxlcjogKHhocikgLT5cbiAgICBjb25zb2xlLmxvZygnZXJyb3InLCB4aHIpXG5cbiAgIyMjXG4gICBSZWNlaXZpbmcgZGF0YSBmcm9tIHRyYW5zbGF0aW9uLWVuZ2luZSBhbmQgc2VuZCByZWFkeSBtZXNzYWdlIHdpdGggZGF0YVxuICAjIyNcbiAgc3VjY2Vzc3RIYW5kbGVyOiAodHJhbnNsYXRlZCkgLT5cbiAgICBpZiB0cmFuc2xhdGVkXG4gICAgICBjaHJvbWUudGFicy5nZXRTZWxlY3RlZChudWxsLCAodGFiKSA9PlxuICAgICAgICBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWIuaWQsIHtcbiAgICAgICAgICBhY3Rpb246IEBtZXNzYWdlVHlwZSB0cmFuc2xhdGVkXG4gICAgICAgICAgZGF0YTogdHJhbnNsYXRlZC5vdXRlckhUTUwsXG4gICAgICAgICAgc3VjY2VzczogIXRyYW5zbGF0ZWQuY2xhc3NMaXN0LmNvbnRhaW5zKCdmYWlsVHJhbnNsYXRlJylcbiAgICAgICAgfSlcbiAgICAgIClcblxuICBtZXNzYWdlVHlwZTogKHRyYW5zbGF0ZWQpIC0+XG4gICAgaWYgdHJhbnNsYXRlZD8ucm93cz8ubGVuZ3RoID09IDFcbiAgICAgICdzaW1pbGFyX3dvcmRzJ1xuICAgIGVsc2VcbiAgICAgICdvcGVuX3Rvb2x0aXAnXG5cbiAgIyMjXG4gICAgUGFyc2UgcmVzcG9uc2UgZnJvbSB0cmFuc2xhdGlvbiBlbmdpbmVcbiAgIyMjXG4gIHBhcnNlOiAocmVzcG9uc2UsIHNpbGVudCwgdHJhbnNsYXRlID0gbnVsbCkgLT5cbiAgICAgIGRvYyA9IEBzdHJpcFNjcmlwdHMocmVzcG9uc2UpXG4gICAgICBmcmFnbWVudCA9IEBtYWtlRnJhZ21lbnQoZG9jKVxuICAgICAgaWYgZnJhZ21lbnRcbiAgICAgICAgdHJhbnNsYXRlID0gZnJhZ21lbnQucXVlcnlTZWxlY3RvcignI3RyYW5zbGF0aW9uIH4gdGFibGUnKVxuICAgICAgICBpZiB0cmFuc2xhdGVcbiAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gQFRBQkxFX0NMQVNTO1xuICAgICAgICAgIHRyYW5zbGF0ZS5zZXRBdHRyaWJ1dGUoXCJjZWxscGFkZGluZ1wiLCBcIjVcIilcbiAgICAgICAgICBAZml4SW1hZ2VzKHRyYW5zbGF0ZSlcbiAgICAgICAgICBAZml4TGlua3ModHJhbnNsYXRlKVxuICAgICAgICBlbHNlIGlmIG5vdCBzaWxlbnRcbiAgICAgICAgICB0cmFuc2xhdGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSAnZmFpbFRyYW5zbGF0ZSdcbiAgICAgICAgICB0cmFuc2xhdGUuaW5uZXJUZXh0ID0gXCJVbmZvcnR1bmF0ZWx5LCBjb3VsZCBub3QgdHJhbnNsYXRlXCJcblxuICAgICAgcmV0dXJuIHRyYW5zbGF0ZTtcblxuICAjIyNcbiAgICBTdHJpcCBzY3JpcHQgdGFncyBmcm9tIHJlc3BvbnNlIGh0bWxcbiAgIyMjXG4gIHN0cmlwU2NyaXB0czogKHMpIC0+XG4gICAgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgICBkaXYuaW5uZXJIVE1MID0gc1xuICAgIHNjcmlwdHMgPSBkaXYuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ3NjcmlwdCcpXG4gICAgaSA9IHNjcmlwdHMubGVuZ3RoXG4gICAgd2hpbGUgaS0tXG4gICAgICBzY3JpcHRzW2ldLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc2NyaXB0c1tpXSlcbiAgICByZXR1cm4gZGl2LmlubmVySFRNTDtcblxuICBtYWtlRnJhZ21lbnQ6IChkb2MsIGZyYWdtZW50ID0gbnVsbCkgLT5cbiAgICBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpXG4gICAgZGl2LmlubmVySFRNTCA9IGRvY1xuICAgIGZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpXG4gICAgd2hpbGUgKCBkaXYuZmlyc3RDaGlsZCApXG4gICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZCggZGl2LmZpcnN0Q2hpbGQgKVxuICAgIHJldHVybiBmcmFnbWVudFxuXG4gIGZpeEltYWdlczogKGZyYWdtZW50PW51bGwpIC0+XG4gICAgdGhpcy5maXhVcmwoZnJhZ21lbnQsICdpbWcnLCAnc3JjJyk7XG4gICAgcmV0dXJuIGZyYWdtZW50O1xuXG4gIGZpeExpbmtzOiAoZnJhZ21lbnQ9bnVsbCkgLT5cbiAgICB0aGlzLmZpeFVybChmcmFnbWVudCwgJ2EnLCAnaHJlZicpXG4gICAgcmV0dXJuIGZyYWdtZW50XG5cbiAgZml4VXJsOiAoZnJhZ21lbnQ9bnVsbCwgdGFnLCBhdHRyKSAtPlxuICAgIGlmIGZyYWdtZW50XG4gICAgICB0YWdzID0gIGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3JBbGwodGFnKVxuICAgICAgcGFyc2VyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpXG4gICAgICBmb3IgdGFnIGluIHRhZ3NcbiAgICAgICAgcGFyc2VyLmhyZWYgPSB0YWdbYXR0cl1cbiAgICAgICAgcGFyc2VyLmhvc3QgPSBAaG9zdFxuICAgICAgICBwYXJzZXIucHJvdG9jb2wgPSBAcHJvdG9jb2xcbiAgICAgICAgI2ZpeCByZWxhdGl2ZSBsaW5rc1xuICAgICAgICBpZiB0YWcudGFnTmFtZSA9PSAnQSdcbiAgICAgICAgICB0YWcuY2xhc3NMaXN0LmFkZCAnbXR0X2xpbmsnXG4gICAgICAgICAgaWYgcGFyc2VyLnBhdGhuYW1lLmluZGV4T2YoJ20uZXhlJykgaXNudCAtMVxuICAgICAgICAgICAgcGFyc2VyLnBhdGhuYW1lID0gJy9jJyArIHBhcnNlci5wYXRobmFtZVxuICAgICAgICAgICAgdGFnLnNldEF0dHJpYnV0ZSgndGFyZ2V0JywgJ19ibGFuaycpXG4gICAgICAgIGVsc2UgaWYgdGFnLnRhZ05hbWUgPT0gJ0lNRydcbiAgICAgICAgICB0YWcuY2xhc3NMaXN0LmFkZCAnbXR0X2ltZydcblxuICAgICAgICB0YWcuc2V0QXR0cmlidXRlKGF0dHIsIHBhcnNlci5ocmVmKVxuXG5cblxubW9kdWxlLmV4cG9ydHMgPSBuZXcgVHJhbiIsIlwidXNlIHN0cmljdFwiO1xuXG52YXIgX3Byb3RvdHlwZVByb3BlcnRpZXMgPSBmdW5jdGlvbiAoY2hpbGQsIHN0YXRpY1Byb3BzLCBpbnN0YW5jZVByb3BzKSB7XG4gIGlmIChzdGF0aWNQcm9wcykgT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoY2hpbGQsIHN0YXRpY1Byb3BzKTtcbiAgaWYgKGluc3RhbmNlUHJvcHMpIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGNoaWxkLnByb3RvdHlwZSwgaW5zdGFuY2VQcm9wcyk7XG59O1xuXG4vKlxuICBUcmFuc2xhdGlvbiBlbmdpbmU6IGh0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0XG4gIEZvciB0cmFuc2xhdGluZyB0dXJraXNoLXJ1c3NpYW4gYW5kIHZpY2UgdmVyc2FcbiovXG52YXIgQ0hBUl9DT0RFUyA9IHJlcXVpcmUoXCIuL2NoYXItY29kZXMtdHVyay5qc1wiKTtcblxudmFyIFR1cmtpc2hEaWN0aW9uYXJ5ID0gKGZ1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gVHVya2lzaERpY3Rpb25hcnkoKSB7XG4gICAgdGhpcy5ob3N0ID0gXCJodHRwOi8vd3d3LnR1cmtpc2hkaWN0aW9uYXJ5Lm5ldC8/d29yZD0lRkNcIjtcbiAgICB0aGlzLnBhdGggPSBcIlwiO1xuICAgIHRoaXMucHJvdG9jb2wgPSBcImh0dHBcIjtcbiAgICB0aGlzLnF1ZXJ5ID0gXCImcz1cIjtcbiAgICB0aGlzLlRBQkxFX0NMQVNTID0gXCJfX19tdHRfdHJhbnNsYXRlX3RhYmxlXCI7XG4gICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSB0cnVlO1xuICB9XG5cbiAgX3Byb3RvdHlwZVByb3BlcnRpZXMoVHVya2lzaERpY3Rpb25hcnksIG51bGwsIHtcbiAgICBzZWFyY2g6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBzZWFyY2goZGF0YSkge1xuICAgICAgICBkYXRhLnVybCA9IHRoaXMubWFrZVVybChkYXRhLnZhbHVlKTtcbiAgICAgICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSBmYWxzZTtcbiAgICAgICAgcmV0dXJuIHRoaXMucmVxdWVzdChkYXRhKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHRyYW5zbGF0ZToge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHRyYW5zbGF0ZShkYXRhKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwicmVxdWVzdCBkYXRhOlwiLCBkYXRhKTtcbiAgICAgICAgZGF0YS51cmwgPSB0aGlzLm1ha2VVcmwoZGF0YS5zZWxlY3Rpb25UZXh0KTtcbiAgICAgICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSB0cnVlO1xuICAgICAgICB0aGlzLnJlcXVlc3QoZGF0YSk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBtYWtlVXJsOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZVVybCh0ZXh0KSB7XG4gICAgICAgIHZhciB0ZXh0ID0gdGhpcy5nZXRFbmNvZGVkVmFsdWUodGV4dCk7XG4gICAgICAgIHJldHVybiBbXCJodHRwOi8vd3d3LnR1cmtpc2hkaWN0aW9uYXJ5Lm5ldC8/d29yZD1cIiwgdGV4dF0uam9pbihcIlwiKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIGdldEVuY29kZWRWYWx1ZToge1xuICAgICAgLy8gUmVwbGFjZSBzcGVjaWFsIGxhbmd1YWdlIGNoYXJhY3RlcnMgdG8gaHRtbCBjb2Rlc1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIGdldEVuY29kZWRWYWx1ZSh2YWx1ZSkge1xuICAgICAgICAvLyB0byBmaW5kIHNwZWMgc3ltYm9scyB3ZSBmaXJzdCBlbmNvZGUgdGhlbSAocmF3IHNlYXJjaCBmb3IgdGhhdCBzeW1ib2wgZG9lc24ndCB3b3IpXG4gICAgICAgIHZhciB2YWwgPSBlbmNvZGVVUklDb21wb25lbnQodmFsdWUpO1xuICAgICAgICBmb3IgKHZhciBjaGFyIGluIENIQVJfQ09ERVMpIHtcbiAgICAgICAgICB2YWwgPSB2YWwucmVwbGFjZShjaGFyLCBDSEFSX0NPREVTW2NoYXJdKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdmFsO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcmVxdWVzdDoge1xuXG4gICAgICAvKlxuICAgICAgICBSZXF1ZXN0IHRyYW5zbGF0aW9uIGFuZCBydW4gY2FsbGJhY2sgZnVuY3Rpb25cbiAgICAgICAgcGFzc2luZyB0cmFuc2xhdGVkIHJlc3VsdCBvciBlcnJvciB0byBjYWxsYmFja1xuICAgICAgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiByZXF1ZXN0KG9wdHMpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJzdGFydCByZXF1ZXN0XCIpO1xuICAgICAgICB0aGlzLnhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgICB0aGlzLnhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSB0aGlzLm9uUmVhZHlTdGF0ZUNoYW5nZS5iaW5kKHRoaXMsIG9wdHMpO1xuICAgICAgICB0aGlzLnhoci5vcGVuKFwiR0VUXCIsIG9wdHMudXJsLCB0cnVlKTtcbiAgICAgICAgdGhpcy54aHIuc2VuZCgpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgb25SZWFkeVN0YXRlQ2hhbmdlOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gb25SZWFkeVN0YXRlQ2hhbmdlKG9wdHMsIGUpIHtcbiAgICAgICAgdmFyIHhociA9IHRoaXMueGhyO1xuICAgICAgICBpZiAoeGhyLnJlYWR5U3RhdGUgPCA0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9IGVsc2UgaWYgKHhoci5zdGF0dXMgIT0gMjAwKSB7XG4gICAgICAgICAgdGhpcy5lcnJvckhhbmRsZXIoeGhyKTtcbiAgICAgICAgICByZXR1cm4gb3B0cy5lcnJvciAmJiBvcHRzLmVycm9yKCk7XG4gICAgICAgIH0gZWxzZSBpZiAoeGhyLnJlYWR5U3RhdGUgPT0gNCkge1xuICAgICAgICAgIHZhciB0cmFuc2xhdGlvbiA9IHRoaXMuc3VjY2Vzc0hhbmRsZXIoZS50YXJnZXQucmVzcG9uc2UpO1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwic3VjY2VzcyB0dXJraXNoIHRyYW5zbGF0ZVwiLCB0cmFuc2xhdGlvbik7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJjYWxsXCIsIG9wdHMuc3VjY2Vzcyk7XG4gICAgICAgICAgcmV0dXJuIG9wdHMuc3VjY2VzcyAmJiBvcHRzLnN1Y2Nlc3ModHJhbnNsYXRpb24pO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBzdWNjZXNzSGFuZGxlcjoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHN1Y2Nlc3NIYW5kbGVyKHJlc3BvbnNlKSB7XG4gICAgICAgIHZhciBkYXRhID0gdGhpcy5wYXJzZShyZXNwb25zZSk7XG4gICAgICAgIGlmICh0aGlzLm5lZWRfcHVibGlzaCkge1xuICAgICAgICAgIGNocm9tZS50YWJzLmdldFNlbGVjdGVkKG51bGwsIHRoaXMucHVibGlzaFRyYW5zbGF0aW9uLmJpbmQodGhpcywgZGF0YSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcHVibGlzaFRyYW5zbGF0aW9uOiB7XG5cbiAgICAgIC8qIHB1Ymxpc2ggc3VjY2Vzc2Z1bHkgdHJhbnNsYXRlZCB0ZXh0IGFsbCBvdmVyIGV4dGVuc2lvbiAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHB1Ymxpc2hUcmFuc2xhdGlvbih0cmFuc2xhdGlvbiwgdGFiKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwicHVibGlzaCB0cmFuc2xhdGlvblwiKTtcbiAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgYWN0aW9uOiBcIm9wZW5fdG9vbHRpcFwiLFxuICAgICAgICAgIGRhdGE6IHRyYW5zbGF0aW9uLm91dGVySFRNTCxcbiAgICAgICAgICBzdWNjZXNzOiAhdHJhbnNsYXRpb24uY2xhc3NMaXN0LmNvbnRhaW5zKFwiZmFpbFRyYW5zbGF0ZVwiKVxuICAgICAgICB9KTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIGVycm9ySGFuZGxlcjoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIGVycm9ySGFuZGxlcihyZXNwb25zZSkge1xuICAgICAgICBjb25zb2xlLmxvZyhcImVycm9yIGFqYXhcIiwgcmVzcG9uc2UpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcGFyc2U6IHtcblxuICAgICAgLyogUGFyc2UgcmVzcG9uc2UgZnJvbSB0cmFuc2xhdGlvbiBlbmdpbmUgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBwYXJzZShyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUpIHtcbiAgICAgICAgdmFyIGRvYyA9IHRoaXMuc3RyaXBTY3JpcHRzKHJlc3BvbnNlKSxcbiAgICAgICAgICAgIGZyYWdtZW50ID0gdGhpcy5tYWtlRnJhZ21lbnQoZG9jKTtcbiAgICAgICAgaWYgKGZyYWdtZW50KSB7XG4gICAgICAgICAgdHJhbnNsYXRlID0gZnJhZ21lbnQucXVlcnlTZWxlY3RvcihcIiNtZWFuaW5nX2RpdiA+IHRhYmxlXCIpO1xuICAgICAgICAgIGlmICh0cmFuc2xhdGUpIHtcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSB0aGlzLlRBQkxFX0NMQVNTO1xuICAgICAgICAgICAgdHJhbnNsYXRlLnNldEF0dHJpYnV0ZShcImNlbGxwYWRkaW5nXCIsIFwiNVwiKTtcbiAgICAgICAgICAgIC8vIEBmaXhJbWFnZXModHJhbnNsYXRlKVxuICAgICAgICAgICAgLy8gQGZpeExpbmtzKHRyYW5zbGF0ZSlcbiAgICAgICAgICB9IGVsc2UgaWYgKCFzaWxlbnQpIHtcbiAgICAgICAgICAgIHRyYW5zbGF0ZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gXCJmYWlsVHJhbnNsYXRlXCI7XG4gICAgICAgICAgICB0cmFuc2xhdGUuaW5uZXJUZXh0ID0gXCJVbmZvcnR1bmF0ZWx5LCBjb3VsZCBub3QgdHJhbnNsYXRlXCI7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cmFuc2xhdGU7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBzdHJpcFNjcmlwdHM6IHtcblxuICAgICAgLy9UT0RPIGV4dHJhY3QgdG8gYmFzZSBlbmdpbmUgY2xhc3NcbiAgICAgIC8qIHJlbW92ZXMgPHNjcmlwdD4gdGFncyBmcm9tIGh0bWwgY29kZSAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHN0cmlwU2NyaXB0cyhodG1sKSB7XG4gICAgICAgIHZhciBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcbiAgICAgICAgdmFyIHNjcmlwdHMgPSBkaXYuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJzY3JpcHRcIik7XG4gICAgICAgIHZhciBpID0gc2NyaXB0cy5sZW5ndGg7XG4gICAgICAgIHdoaWxlIChpLS0pIHNjcmlwdHNbaV0ucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChzY3JpcHRzW2ldKTtcbiAgICAgICAgcmV0dXJuIGRpdi5pbm5lckhUTUw7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBtYWtlRnJhZ21lbnQ6IHtcblxuICAgICAgLy9UT0RPIGV4dHJhY3QgdG8gYmFzZSBlbmdpbmUgY2xhc3NcbiAgICAgIC8qIGNyZWF0ZXMgdGVtcCBvYmplY3QgdG8gcGFyc2UgdHJhbnNsYXRpb24gZnJvbSBwYWdlIFxuICAgICAgICAoc2luY2UgaXQncyBub3QgYSBmcmllbmRseSBhcGkpIFxuICAgICAgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlRnJhZ21lbnQoaHRtbCkge1xuICAgICAgICB2YXIgZnJhZ21lbnQsXG4gICAgICAgICAgICBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcbiAgICAgICAgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG4gICAgICAgIHdoaWxlIChkaXYuZmlyc3RDaGlsZCkge1xuICAgICAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKGRpdi5maXJzdENoaWxkKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfVxuICB9KTtcblxuICByZXR1cm4gVHVya2lzaERpY3Rpb25hcnk7XG59KSgpO1xuXG4vLyBTaW5nbGV0b25lXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBUdXJraXNoRGljdGlvbmFyeSgpOyJdfQ==
