(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
// turkishdictionary codings
var DICT = {
    304: '%DD', //i
    350: '%DE', //S
    286: '%D0', //G
    287: '%F0', //G
    351: '%FE', //S
    305: '%FD', //I
    252: '%FC', //ü
    220: '%DC', //Ü
    231: '%E7', //ç
    199: '%C7', //Ç
    246: '%F6', //ö
    214: '%D6', //Ö
    39: '',  //'
};

module.exports = DICT;
},{}],2:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/var CHAR_CODES = {  //russian  '%D1%8A': {val:'%FA', lang:'ru'}, // ъ  '%D0%AA': {val:'%DA', lang:'ru'},// Ъ  '%C3%80': '&#192;', // À  '%C3%81': '&#193;', // Á  '%C3%82': '&#194;', // Â  '%C3%83': '&#195;', // Ã  '%C3%84': '&#196;', // Ä  '%C3%85': '&#197;', // Å  '%C3%86': '&#198;', // Æ  '%C3%87': '&#199;', // Ç  '%C3%88': '&#200;', // È  '%C3%89': '&#201;', // É  '%C3%8A': '&#202;', // Ê  '%C3%8B': '&#203;', // Ë  '%C3%8C': '&#204;', // Ì  '%C3%8D': '&#205;', // Í  '%C3%8E': '&#206;', // Î  '%C3%8F': '&#207;', // Ï  '%C3%91': '&#209;', // Ñ  '%C3%92': '&#210;', // Ò  '%C3%93': '&#211;', // Ó  '%C3%94': '&#212;', // Ô  '%C3%95': '&#213;', // Õ  '%C3%96': '&#214;', // Ö  '%C3%99': '&#217;', // Ù  '%C3%9A': '&#218;', // Ú  '%C3%9B': '&#219;', // Û  '%C3%9C': '&#220;', // Ü  '%C3%A0': '&#224;', // à  '%C3%A1': '&#225;', // á  '%C3%A2': '&#226;', // â  '%C3%A3': '&#227;', // ã  '%C3%A4': '&#228;', // ä  '%C3%A5': '&#229;', // å  '%C3%A6': '&#230;', // æ  '%C3%A7': '&#231;', // ç  '%C3%A8': '&#232;', // è  '%C3%A9': '&#233;', // é  '%C3%AA': '&#234;', // ê  '%C3%AB': '&#235;', // ë  '%C3%AC': '&#236;', // ì  '%C3%AD': '&#237;', // í  '%C3%AE': '&#238;', // î  '%C3%AF': '&#239;', // ï  '%C3%B0': '&#240;', // ð  '%C3%B1': '&#241;', // ñ  '%C3%B2': '&#242;', // ò  '%C3%B3': '&#243;', // ó  '%C3%B4': '&#244;', // ô  '%C3%B5': '&#245;', // õ  '%C3%B6': '&#246;', // ö  '%C3%B9': '&#249;', // ù  '%C3%BA': '&#250;', // ú  '%C3%BB': '&#251;', // û  '%C3%BC': '&#252;', // ü  '%C3%BF': '&#255;', // ÿ  '%C5%B8': '&#376;', // Ÿ  '%C3%9F': '&#223;', // ß  '%C2%BF': '&#191;', // ¿  '%C2%A1': '&#161;', // ¡};module.exports = CHAR_CODES;
},{}],3:[function(require,module,exports){

/*
  Dropdown language menu
  @param opts takes element and onSelect handler
  example:
  new Dropdown({
   el: document.getElementById('#menu');
   onSelect: function () {}
  })
 */
var DICT_CODE, Dropdown, LANG_CODE;

LANG_CODE = {
  '1': 'Eng',
  '2': 'Rus',
  '3': 'Ger',
  '4': 'Fre',
  '5': 'Spa',
  '23': 'Ita',
  '24': 'Dut',
  '26': 'Est',
  '27': 'Lav',
  '31': 'Afr',
  '34': 'Epo',
  '35': 'Xal',
  '1000': 'Tur'
};

DICT_CODE = {
  '1': 'multitran',
  '1000': 'turkish'
};

Dropdown = (function() {
  function Dropdown(opts) {
    this.el = opts.el || document.createElement('div');
    this.onSelect = opts.onSelect;
    this.menu = this.el.querySelector('.dropdown-menu');
    if (this.menu) {
      this.menu.style.display = 'none';
      this.items = this.menu.getElementsByClassName('language-type');
      this.button = this.el.querySelector('.dropdown-toggle');
      this.addListeners();
      this.initLanguage();
    }
  }

  Dropdown.prototype.addListeners = function() {
    this.button.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.toggle(e);
      };
    })(this));
    document.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.hide(e);
      };
    })(this));
    return this.menu.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.choose(e);
      };
    })(this));
  };

  Dropdown.prototype.initLanguage = function() {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(store) {
        return _this.setTitle(store.language);
      };
    })(this));
  };

  Dropdown.prototype.toggle = function(e) {
    e.stopPropagation();
    this.setActiveItem();
    if (this.menu && this.menu.style.display === 'none') {
      return this.show();
    } else {
      return this.hide();
    }
  };

  Dropdown.prototype.setActiveItem = function() {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(store) {
        var item, _i, _len, _ref, _results;
        _ref = _this.items;
        _results = [];
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          item = _ref[_i];
          if (item.getAttribute('data-val') === store.language) {
            _results.push(item.classList.add('active'));
          } else {
            _results.push(item.classList.remove('active'));
          }
        }
        return _results;
      };
    })(this));
  };

  Dropdown.prototype.hide = function() {
    return this.menu.style.display = 'none';
  };

  Dropdown.prototype.show = function() {
    return this.menu.style.display = 'block';
  };

  Dropdown.prototype.choose = function(e) {
    var dictionary, language;
    e.stopPropagation();
    e.preventDefault();
    language = e.target.getAttribute('data-val');
    dictionary = this.getDictionary(language);
    chrome.storage.sync.set({
      language: language,
      dictionary: dictionary
    }, this.onSelect);
    this.setTitle(language);
    return this.hide();
  };

  Dropdown.prototype.getDictionary = function(lang) {
    var dict;
    console.log('choose dict: for', lang);
    dict = DICT_CODE[lang] || 'multitran';
    console.log('dict', dict);
    return dict;
  };

  Dropdown.prototype.setTitle = function(language) {
    var html;
    html = LANG_CODE[language] + ' <span class="caret"></span>';
    return this.button.innerHTML = html;
  };

  return Dropdown;

})();

module.exports = Dropdown;


},{}],4:[function(require,module,exports){

/*
  Extension popup window
  Shows search form and dropdown menu with languages
 */
var SearchForm;

SearchForm = require('./search_form.coffee');

document.addEventListener("DOMContentLoaded", function() {
  var form, link;
  form = new SearchForm(document.getElementById('tran-form'));
  link = document.getElementById('header-link');
  if (link) {
    return link.addEventListener('click', function(e) {
      var href;
      e.preventDefault();
      href = e.target.getAttribute('href') + form.getValue();
      return chrome.tabs.create({
        url: href
      });
    });
  }
});


},{"./search_form.coffee":5}],5:[function(require,module,exports){

/*
  Serves search input and form

  @param form DOM elemnt
  @constructor
 */
var Dropdown, SearchForm, TRANSLATE_ENGINES, tran, turkishdictionary,
  __indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

Dropdown = require('./dropdown.coffee');

tran = require('../tran.coffee');

turkishdictionary = require('../turkishdictionary.js');

TRANSLATE_ENGINES = {
  'multitran': tran,
  'turkish': turkishdictionary
};

SearchForm = (function() {
  function SearchForm(form) {
    this.form = form;
    this.input = document.getElementById('translate-txt');
    this.input.focus();
    this.result = document.getElementById('result');
    this.addListeners();
    this.dropdown = new Dropdown({
      el: document.querySelector('.dropdown-el'),
      onSelect: (function(_this) {
        return function() {
          return _this.search();
        };
      })(this)
    });
  }

  SearchForm.prototype.addListeners = function() {
    if (this.form && this.result) {
      this.form.addEventListener('submit', (function(_this) {
        return function(e) {
          return _this.search(e);
        };
      })(this));
      return this.result.addEventListener('click', (function(_this) {
        return function(e) {
          return _this.resultClickHandler(e);
        };
      })(this));
    }
  };

  SearchForm.prototype.search = function(e) {
    e && e.preventDefault && e.preventDefault();
    if (this.input.value.length > 0) {
      return chrome.storage.sync.get({
        language: '1',
        dictionary: 'multitran'
      }, (function(_this) {
        return function(items) {
          console.log('ITEMS:', items);
          return TRANSLATE_ENGINES[items.dictionary].search({
            value: _this.input.value,
            success: _this.successHandler.bind(_this)
          });
        };
      })(this));
    }
  };

  SearchForm.prototype.successHandler = function(response) {
    this.clean(this.result);
    return this.result.appendChild(response);
  };

  SearchForm.prototype.clean = function(el) {
    var _results;
    _results = [];
    while (el.lastChild) {
      _results.push(el.removeChild(el.lastChild));
    }
    return _results;
  };

  SearchForm.prototype.resultClickHandler = function(e) {
    var linkTags, _ref;
    e.preventDefault();
    linkTags = ['A', 'a'];
    if (_ref = e.target.tagName, __indexOf.call(linkTags, _ref) >= 0) {
      this.input.value = e.target.innerText;
      return this.search(e);
    }
  };

  SearchForm.prototype.getValue = function() {
    return this.input.value;
  };

  return SearchForm;

})();

module.exports = SearchForm;


},{"../tran.coffee":6,"../turkishdictionary.js":7,"./dropdown.coffee":3}],6:[function(require,module,exports){

/*global chrome */

/*
  Multitran.ru translate engine
  Provides program interface for making translate queries to multitran and get clean response

  All engines must follow common interface and provide methods:
    - search (languange, successHandler)  clean translation must be passed into successHandler
    - click

  Translation-module that makes requests to language-engine,
  parses results and sends plugin-global message with translation data
 */
var CHAR_CODES, Tran;

CHAR_CODES = require('./char-codes.js');

Tran = (function() {
  function Tran() {
    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1';
    this.xhr = {};
  }


  /*
    Context menu click handler
   */

  Tran.prototype.click = function(data) {
    var selectionText;
    if (typeof data.silent === void 0 || data.silent === null) {
      data.silent = true;
    }
    selectionText = this.removeHyphenation(data.selectionText);
    return this.search({
      value: selectionText,
      success: this.successtHandler.bind(this),
      silent: data.silent
    });
  };


  /*
    Discard soft hyphen character (U+00AD, &shy;) from the input
   */

  Tran.prototype.removeHyphenation = function(text) {
    return text.replace(/\xad/g, '');
  };


  /*
    Initiate translation search
   */

  Tran.prototype.search = function(params) {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(items) {
        var language, origSuccess, url;
        if (language === '') {
          language = '1';
        }
        _this.setLanguage(items.language);
        url = _this.makeUrl(params.value);
        origSuccess = params.success;
        params.success = function(response) {
          var translated;
          translated = _this.parse(response, params.silent);
          return origSuccess(translated);
        };
        return _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      };
    })(this));
  };

  Tran.prototype.setLanguage = function(language) {
    this.currentLanguage = language;
    return this.lang = '?l1=2&l2=' + language;
  };


  /*
    Request translation and run callback function
    passing translated result or error to callback
   */

  Tran.prototype.request = function(opts) {
    var xhr;
    xhr = this.xhr = new XMLHttpRequest();
    xhr.onreadystatechange = (function(_this) {
      return function(e) {
        xhr = _this.xhr;
        if (xhr.readyState < 4) {

        } else if (xhr.status !== 200) {
          _this.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error();
          }
        } else if (xhr.readyState === 4) {
          return opts.success(e.target.response);
        }
      };
    })(this);
    xhr.open("GET", opts.url, true);
    return xhr.send();
  };

  Tran.prototype.makeUrl = function(value) {
    var url;
    url = [this.protocol, '://', this.host, this.path, this.lang, this.query, this.getEncodedValue(value)].join('');
    return url;
  };

  Tran.prototype.getEncodedValue = function(value) {
    var cc, char, code, val;
    val = encodeURIComponent(value);
    for (char in CHAR_CODES) {
      code = CHAR_CODES[char];
      if (typeof code === 'object') {
        cc = code.val;
      } else {
        cc = encodeURIComponent(code);
      }
      val = val.replace(char, cc);
    }
    return val;
  };

  Tran.prototype.errorHandler = function(xhr) {
    return console.log('error', xhr);
  };


  /*
   Receiving data from translation-engine and send ready message with data
   */

  Tran.prototype.successtHandler = function(translated) {
    if (translated) {
      return chrome.tabs.getSelected(null, (function(_this) {
        return function(tab) {
          return chrome.tabs.sendMessage(tab.id, {
            action: _this.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        };
      })(this));
    }
  };

  Tran.prototype.messageType = function(translated) {
    var _ref;
    if ((translated != null ? (_ref = translated.rows) != null ? _ref.length : void 0 : void 0) === 1) {
      return 'similar_words';
    } else {
      return 'open_tooltip';
    }
  };


  /*
    Parse response from translation engine
   */

  Tran.prototype.parse = function(response, silent, translate) {
    var doc, fragment;
    if (translate == null) {
      translate = null;
    }
    doc = this.stripScripts(response);
    fragment = this.makeFragment(doc);
    if (fragment) {
      translate = fragment.querySelector('#translation ~ table');
      if (translate) {
        translate.className = this.TABLE_CLASS;
        translate.setAttribute("cellpadding", "5");
        this.fixImages(translate);
        this.fixLinks(translate);
      } else if (!silent) {
        translate = document.createElement('div');
        translate.className = 'failTranslate';
        translate.innerText = "Unfortunately, could not translate";
      }
    }
    return translate;
  };


  /*
    Strip script tags from response html
   */

  Tran.prototype.stripScripts = function(s) {
    var div, i, scripts;
    div = document.createElement('div');
    div.innerHTML = s;
    scripts = div.getElementsByTagName('script');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
    return div.innerHTML;
  };

  Tran.prototype.makeFragment = function(doc, fragment) {
    var div;
    if (fragment == null) {
      fragment = null;
    }
    div = document.createElement("div");
    div.innerHTML = doc;
    fragment = document.createDocumentFragment();
    while (div.firstChild) {
      fragment.appendChild(div.firstChild);
    }
    return fragment;
  };

  Tran.prototype.fixImages = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'img', 'src');
    return fragment;
  };

  Tran.prototype.fixLinks = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'a', 'href');
    return fragment;
  };

  Tran.prototype.fixUrl = function(fragment, tag, attr) {
    var parser, tags, _i, _len, _results;
    if (fragment == null) {
      fragment = null;
    }
    if (fragment) {
      tags = fragment.querySelectorAll(tag);
      parser = document.createElement('a');
      _results = [];
      for (_i = 0, _len = tags.length; _i < _len; _i++) {
        tag = tags[_i];
        parser.href = tag[attr];
        parser.host = this.host;
        parser.protocol = this.protocol;
        if (tag.tagName === 'A') {
          tag.classList.add('mtt_link');
          if (parser.pathname.indexOf('m.exe') !== -1) {
            parser.pathname = '/c' + parser.pathname;
            tag.setAttribute('target', '_blank');
          }
        } else if (tag.tagName === 'IMG') {
          tag.classList.add('mtt_img');
        }
        _results.push(tag.setAttribute(attr, parser.href));
      }
      return _results;
    }
  };

  return Tran;

})();

module.exports = new Tran;


},{"./char-codes.js":2}],7:[function(require,module,exports){
"use strict";

var _prototypeProperties = function (child, staticProps, instanceProps) {
  if (staticProps) Object.defineProperties(child, staticProps);
  if (instanceProps) Object.defineProperties(child.prototype, instanceProps);
};

/*
  Translation engine: http://www.turkishdictionary.net
  For translating turkish-russian and vice versa
*/
var CHAR_CODES = require("./char-codes-turk.js");

var TurkishDictionary = (function () {
  function TurkishDictionary() {
    this.host = "http://www.turkishdictionary.net/?word=%FC";
    this.path = "";
    this.protocol = "http";
    this.query = "&s=";
    this.TABLE_CLASS = "___mtt_translate_table";
    // this flag indicates that if translation was successful then publish it all over extension
    this.need_publish = true;
  }

  _prototypeProperties(TurkishDictionary, null, {
    search: {
      value: function search(data) {
        data.url = this.makeUrl(data.value);
        this.need_publish = false;
        return this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    translate: {
      value: function translate(data) {
        data.url = this.makeUrl(data.selectionText);
        this.need_publish = true;
        this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeUrl: {
      value: function makeUrl(text) {
        var text = this.getEncodedValue(text);
        return ["http://www.turkishdictionary.net/?word=", text].join("");
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    getEncodedValue: {


      // Replace special language characters to html codes
      value: function getEncodedValue(value) {
        // to find spec symbols we first encode them (raw search for that symbol doesn't wor)
        return this.makeStringTransferable(value);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeStringTransferable: {

      /** converting script from the turkishdict */
      value: function makeStringTransferable(inputText) {
        var text = "";
        if (inputText.length > 0) {
          text = inputText;
          for (var i = 0; i < text.length; i++) {
            if (CHAR_CODES[text.charCodeAt(i)]) {
              text = text.substring(0, i) + CHAR_CODES[text.charCodeAt(i)] + text.substring(i + 1, text.length);
            } else if (text.charAt(i) == " ") {
              // replace spaces
              text = text.substring(0, i) + "___" + text.substring(i + 1, text.length);
            }
          }
        }
        return text;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    request: {

      /*
        Request translation and run callback function
        passing translated result or error to callback
      */
      value: function request(opts) {
        console.log("start request");
        this.xhr = new XMLHttpRequest();
        this.xhr.onreadystatechange = this.onReadyStateChange.bind(this, opts);
        this.xhr.open("GET", opts.url, true);
        this.xhr.send();
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    onReadyStateChange: {
      value: function onReadyStateChange(opts, e) {
        var xhr = this.xhr;
        if (xhr.readyState < 4) {
          return;
        } else if (xhr.status != 200) {
          this.errorHandler(xhr);
          return opts.error && opts.error();
        } else if (xhr.readyState == 4) {
          var translation = this.successHandler(e.target.response);
          console.log("success turkish translate", translation);
          console.log("call", opts.success);
          return opts.success && opts.success(translation);
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    successHandler: {
      value: function successHandler(response) {
        var data = this.parse(response);
        if (this.need_publish) {
          chrome.tabs.getSelected(null, this.publishTranslation.bind(this, data));
        }
        return data;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    publishTranslation: {

      /* publish successfuly translated text all over extension */
      value: function publishTranslation(translation, tab) {
        console.log("publish translation");
        chrome.tabs.sendMessage(tab.id, {
          action: this.tooltipAction(translation),
          data: translation.outerHTML,
          success: !translation.classList.contains("failTranslate")
        });
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    tooltipAction: {
      value: function tooltipAction(translation) {
        if (translation.textContent.trim().indexOf("was not found in our dictionary") != -1) {
          console.log("similar words");
          return "similar_words";
        } else {
          console.log("open tooltip");
          return "open_tooltip";
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    errorHandler: {
      value: function errorHandler(response) {
        console.log("error ajax", response);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parse: {

      /* Parse response from translation engine */
      value: function parse(response, silent, translate) {
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);
        if (fragment) {
          translate = fragment.querySelector("#meaning_div > table");
          if (translate) {
            translate.className = this.TABLE_CLASS;
            translate.setAttribute("cellpadding", "5");
            // @fixImages(translate)
            // @fixLinks(translate)
          } else if (!silent) {
            translate = document.createElement("div");
            translate.className = "failTranslate";
            translate.innerText = "Unfortunately, could not translate";
          }
        }
        return translate;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parseText: {

      /** parsing of terrible html markup */
      value: function parseText(response, silent, translate) {
        var _this = this;
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);

        if (fragment) {
          var i;
          var _ret = (function () {
            var stopIndex = null;
            var tr = fragment.querySelectorAll("#meaning_div>table>tbody>tr");
            tr = Array.prototype.slice.call(tr);

            var trans = tr.filter(function (tr, index) {
              if (!isNaN(parseInt(stopIndex, 10)) && index >= stopIndex) {
                return;
              } else {
                tr = $(tr);
                // take every row before next section (which is English->English)
                if (tr.attr("bgcolor") == "e0e6ff") {
                  stopIndex = index;return;
                } else {
                  return $.trim(tr.find("td").text()).length;
                }
              }
            });
            trans = trans.slice(1, trans.length - 1);
            trans = trans.filter(function (el, indx) {
              return indx % 2;
            });
            var frag = _this.fragmentFromList(trans);
            var fonts = frag.querySelectorAll("font");
            var text = "";
            for (i = 0; i < fonts.length; i++) {
              text += " " + fonts[i].textContent.trim();
            }
            return {
              v: text
            };
          })();

          if (typeof _ret === "object") return _ret.v;
        } else {
          throw "HTML fragment could not be parsed";
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    stripScripts: {

      //TODO extract to base engine class
      /* removes <script> tags from html code */
      value: function stripScripts(html) {
        var div = document.createElement("div");
        div.innerHTML = html;
        var scripts = div.getElementsByTagName("script");
        var i = scripts.length;
        while (i--) scripts[i].parentNode.removeChild(scripts[i]);
        return div.innerHTML;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeFragment: {

      //TODO extract to base engine class
      /* creates temp object to parse translation from page 
        (since it's not a friendly api) 
      */
      value: function makeFragment(html) {
        var fragment = document.createDocumentFragment(),
            div = document.createElement("div");
        div.innerHTML = html;
        while (div.firstChild) {
          fragment.appendChild(div.firstChild);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    fragmentFromList: {

      /** create fragment from list of DOM elements */
      value: function fragmentFromList(list) {
        var fragment = document.createDocumentFragment(),
            len = list.length;
        while (len--) {
          fragment.appendChild(list[len]);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    }
  });

  return TurkishDictionary;
})();

// Singletone
module.exports = new TurkishDictionary();
},{"./char-codes-turk.js":1}]},{},[4])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvY2hhci1jb2Rlcy10dXJrLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy9jaGFyLWNvZGVzLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy9wb3B1cC9kcm9wZG93bi5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXZlbG9wbWVudC90cmFuL2pzL3BvcHVwL3BvcHVwLmNvZmZlZSIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvcG9wdXAvc2VhcmNoX2Zvcm0uY29mZmVlIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy90cmFuLmNvZmZlZSIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvdHVya2lzaGRpY3Rpb25hcnkuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDakJBOztBQ0FBO0FBQUE7Ozs7Ozs7O0dBQUE7QUFBQSxJQUFBLDhCQUFBOztBQUFBLFNBU0EsR0FDRTtBQUFBLEVBQUEsR0FBQSxFQUFLLEtBQUw7QUFBQSxFQUNBLEdBQUEsRUFBSyxLQURMO0FBQUEsRUFFQSxHQUFBLEVBQUssS0FGTDtBQUFBLEVBR0EsR0FBQSxFQUFLLEtBSEw7QUFBQSxFQUlBLEdBQUEsRUFBSyxLQUpMO0FBQUEsRUFLQSxJQUFBLEVBQU0sS0FMTjtBQUFBLEVBTUEsSUFBQSxFQUFNLEtBTk47QUFBQSxFQU9BLElBQUEsRUFBTSxLQVBOO0FBQUEsRUFRQSxJQUFBLEVBQU0sS0FSTjtBQUFBLEVBU0EsSUFBQSxFQUFNLEtBVE47QUFBQSxFQVVBLElBQUEsRUFBTSxLQVZOO0FBQUEsRUFXQSxJQUFBLEVBQU0sS0FYTjtBQUFBLEVBWUEsTUFBQSxFQUFRLEtBWlI7Q0FWRixDQUFBOztBQUFBLFNBd0JBLEdBQ0U7QUFBQSxFQUFBLEdBQUEsRUFBSyxXQUFMO0FBQUEsRUFDQSxNQUFBLEVBQVEsU0FEUjtDQXpCRixDQUFBOztBQUFBO0FBNkJlLEVBQUEsa0JBQUMsSUFBRCxHQUFBO0FBQ1gsSUFBQSxJQUFDLENBQUEsRUFBRCxHQUFNLElBQUksQ0FBQyxFQUFMLElBQVcsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBakIsQ0FBQTtBQUFBLElBRUEsSUFBQyxDQUFBLFFBQUQsR0FBWSxJQUFJLENBQUMsUUFGakIsQ0FBQTtBQUFBLElBSUEsSUFBQyxDQUFBLElBQUQsR0FBUSxJQUFDLENBQUEsRUFBRSxDQUFDLGFBQUosQ0FBa0IsZ0JBQWxCLENBSlIsQ0FBQTtBQUtBLElBQUEsSUFBRyxJQUFDLENBQUEsSUFBSjtBQUNFLE1BQUEsSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWixHQUFzQixNQUF0QixDQUFBO0FBQUEsTUFDQSxJQUFDLENBQUEsS0FBRCxHQUFTLElBQUMsQ0FBQSxJQUFJLENBQUMsc0JBQU4sQ0FBNkIsZUFBN0IsQ0FEVCxDQUFBO0FBQUEsTUFFQSxJQUFDLENBQUEsTUFBRCxHQUFVLElBQUMsQ0FBQSxFQUFFLENBQUMsYUFBSixDQUFrQixrQkFBbEIsQ0FGVixDQUFBO0FBQUEsTUFHQSxJQUFDLENBQUEsWUFBRCxDQUFBLENBSEEsQ0FBQTtBQUFBLE1BSUEsSUFBQyxDQUFBLFlBQUQsQ0FBQSxDQUpBLENBREY7S0FOVztFQUFBLENBQWI7O0FBQUEscUJBYUEsWUFBQSxHQUFjLFNBQUEsR0FBQTtBQUNaLElBQUEsSUFBQyxDQUFBLE1BQU0sQ0FBQyxnQkFBUixDQUF5QixPQUF6QixFQUFrQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7ZUFBTyxLQUFDLENBQUEsTUFBRCxDQUFRLENBQVIsRUFBUDtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxDLENBQUEsQ0FBQTtBQUFBLElBQ0EsUUFBUSxDQUFDLGdCQUFULENBQTBCLE9BQTFCLEVBQW1DLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLENBQUQsR0FBQTtlQUFPLEtBQUMsQ0FBQSxJQUFELENBQU0sQ0FBTixFQUFQO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbkMsQ0FEQSxDQUFBO1dBRUEsSUFBQyxDQUFBLElBQUksQ0FBQyxnQkFBTixDQUF1QixPQUF2QixFQUFnQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7ZUFBTyxLQUFDLENBQUEsTUFBRCxDQUFRLENBQVIsRUFBUDtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWhDLEVBSFk7RUFBQSxDQWJkLENBQUE7O0FBQUEscUJBbUJBLFlBQUEsR0FBYyxTQUFBLEdBQUE7V0FDWixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUUsUUFBQSxFQUFVLEdBQVo7S0FBeEIsRUFBMEMsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsS0FBRCxHQUFBO2VBQ3hDLEtBQUMsQ0FBQSxRQUFELENBQVUsS0FBSyxDQUFDLFFBQWhCLEVBRHdDO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBMUMsRUFEWTtFQUFBLENBbkJkLENBQUE7O0FBQUEscUJBd0JBLE1BQUEsR0FBUSxTQUFDLENBQUQsR0FBQTtBQUNOLElBQUEsQ0FBQyxDQUFDLGVBQUYsQ0FBQSxDQUFBLENBQUE7QUFBQSxJQUNBLElBQUMsQ0FBQSxhQUFELENBQUEsQ0FEQSxDQUFBO0FBRUEsSUFBQSxJQUFHLElBQUMsQ0FBQSxJQUFELElBQVUsSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWixLQUF1QixNQUFwQzthQUNFLElBQUMsQ0FBQSxJQUFELENBQUEsRUFERjtLQUFBLE1BQUE7YUFHRSxJQUFDLENBQUEsSUFBRCxDQUFBLEVBSEY7S0FITTtFQUFBLENBeEJSLENBQUE7O0FBQUEscUJBaUNBLGFBQUEsR0FBZSxTQUFBLEdBQUE7V0FDYixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUMsUUFBQSxFQUFVLEdBQVg7S0FBeEIsRUFBeUMsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsS0FBRCxHQUFBO0FBQ3ZDLFlBQUEsOEJBQUE7QUFBQTtBQUFBO2FBQUEsMkNBQUE7MEJBQUE7QUFDRSxVQUFBLElBQUcsSUFBSSxDQUFDLFlBQUwsQ0FBa0IsVUFBbEIsQ0FBQSxLQUFpQyxLQUFLLENBQUMsUUFBMUM7MEJBQ0UsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFmLENBQW1CLFFBQW5CLEdBREY7V0FBQSxNQUFBOzBCQUdFLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBZixDQUFzQixRQUF0QixHQUhGO1dBREY7QUFBQTt3QkFEdUM7TUFBQSxFQUFBO0lBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUF6QyxFQURhO0VBQUEsQ0FqQ2YsQ0FBQTs7QUFBQSxxQkF5Q0EsSUFBQSxHQUFNLFNBQUEsR0FBQTtXQUNKLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQVosR0FBc0IsT0FEbEI7RUFBQSxDQXpDTixDQUFBOztBQUFBLHFCQTRDQSxJQUFBLEdBQU0sU0FBQSxHQUFBO1dBQ0osSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWixHQUFzQixRQURsQjtFQUFBLENBNUNOLENBQUE7O0FBQUEscUJBaURBLE1BQUEsR0FBUSxTQUFDLENBQUQsR0FBQTtBQUNOLFFBQUEsb0JBQUE7QUFBQSxJQUFBLENBQUMsQ0FBQyxlQUFGLENBQUEsQ0FBQSxDQUFBO0FBQUEsSUFDQSxDQUFDLENBQUMsY0FBRixDQUFBLENBREEsQ0FBQTtBQUFBLElBRUEsUUFBQSxHQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBVCxDQUFzQixVQUF0QixDQUZYLENBQUE7QUFBQSxJQUdBLFVBQUEsR0FBYSxJQUFDLENBQUEsYUFBRCxDQUFlLFFBQWYsQ0FIYixDQUFBO0FBQUEsSUFJQSxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUMsUUFBQSxFQUFVLFFBQVg7QUFBQSxNQUFxQixVQUFBLEVBQVksVUFBakM7S0FBeEIsRUFBc0UsSUFBQyxDQUFBLFFBQXZFLENBSkEsQ0FBQTtBQUFBLElBS0EsSUFBQyxDQUFBLFFBQUQsQ0FBVSxRQUFWLENBTEEsQ0FBQTtXQU1BLElBQUMsQ0FBQSxJQUFELENBQUEsRUFQTTtFQUFBLENBakRSLENBQUE7O0FBQUEscUJBNERBLGFBQUEsR0FBZSxTQUFDLElBQUQsR0FBQTtBQUNiLFFBQUEsSUFBQTtBQUFBLElBQUEsT0FBTyxDQUFDLEdBQVIsQ0FBWSxrQkFBWixFQUErQixJQUEvQixDQUFBLENBQUE7QUFBQSxJQUNBLElBQUEsR0FBTyxTQUFVLENBQUEsSUFBQSxDQUFWLElBQW1CLFdBRDFCLENBQUE7QUFBQSxJQUVBLE9BQU8sQ0FBQyxHQUFSLENBQVksTUFBWixFQUFtQixJQUFuQixDQUZBLENBQUE7QUFHQSxXQUFPLElBQVAsQ0FKYTtFQUFBLENBNURmLENBQUE7O0FBQUEscUJBbUVBLFFBQUEsR0FBVSxTQUFDLFFBQUQsR0FBQTtBQUNSLFFBQUEsSUFBQTtBQUFBLElBQUEsSUFBQSxHQUFPLFNBQVUsQ0FBQSxRQUFBLENBQVYsR0FBc0IsOEJBQTdCLENBQUE7V0FDQSxJQUFDLENBQUEsTUFBTSxDQUFDLFNBQVIsR0FBb0IsS0FGWjtFQUFBLENBbkVWLENBQUE7O2tCQUFBOztJQTdCRixDQUFBOztBQUFBLE1BcUdNLENBQUMsT0FBUCxHQUFpQixRQXJHakIsQ0FBQTs7OztBQ0FBO0FBQUE7OztHQUFBO0FBQUEsSUFBQSxVQUFBOztBQUFBLFVBSUEsR0FBYSxPQUFBLENBQVEsc0JBQVIsQ0FKYixDQUFBOztBQUFBLFFBTVEsQ0FBQyxnQkFBVCxDQUEwQixrQkFBMUIsRUFBOEMsU0FBQSxHQUFBO0FBQzVDLE1BQUEsVUFBQTtBQUFBLEVBQUEsSUFBQSxHQUFXLElBQUEsVUFBQSxDQUFXLFFBQVEsQ0FBQyxjQUFULENBQXdCLFdBQXhCLENBQVgsQ0FBWCxDQUFBO0FBQUEsRUFDQSxJQUFBLEdBQU8sUUFBUSxDQUFDLGNBQVQsQ0FBd0IsYUFBeEIsQ0FEUCxDQUFBO0FBRUEsRUFBQSxJQUFHLElBQUg7V0FDRSxJQUFJLENBQUMsZ0JBQUwsQ0FBc0IsT0FBdEIsRUFBK0IsU0FBQyxDQUFELEdBQUE7QUFDN0IsVUFBQSxJQUFBO0FBQUEsTUFBQSxDQUFDLENBQUMsY0FBRixDQUFBLENBQUEsQ0FBQTtBQUFBLE1BQ0EsSUFBQSxHQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBVCxDQUFzQixNQUF0QixDQUFBLEdBQWdDLElBQUksQ0FBQyxRQUFMLENBQUEsQ0FEdkMsQ0FBQTthQUVBLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBWixDQUFtQjtBQUFBLFFBQUUsR0FBQSxFQUFLLElBQVA7T0FBbkIsRUFINkI7SUFBQSxDQUEvQixFQURGO0dBSDRDO0FBQUEsQ0FBOUMsQ0FOQSxDQUFBOzs7O0FDQUE7QUFBQTs7Ozs7R0FBQTtBQUFBLElBQUEsZ0VBQUE7RUFBQSxxSkFBQTs7QUFBQSxRQU1BLEdBQVcsT0FBQSxDQUFRLG1CQUFSLENBTlgsQ0FBQTs7QUFBQSxJQVNBLEdBQU8sT0FBQSxDQUFRLGdCQUFSLENBVFAsQ0FBQTs7QUFBQSxpQkFVQSxHQUFvQixPQUFBLENBQVEseUJBQVIsQ0FWcEIsQ0FBQTs7QUFBQSxpQkFjQSxHQUNFO0FBQUEsRUFBQSxXQUFBLEVBQWEsSUFBYjtBQUFBLEVBQ0EsU0FBQSxFQUFXLGlCQURYO0NBZkYsQ0FBQTs7QUFBQTtBQW1CZSxFQUFBLG9CQUFFLElBQUYsR0FBQTtBQUNYLElBRFksSUFBQyxDQUFBLE9BQUEsSUFDYixDQUFBO0FBQUEsSUFBQSxJQUFDLENBQUEsS0FBRCxHQUFTLFFBQVEsQ0FBQyxjQUFULENBQXdCLGVBQXhCLENBQVQsQ0FBQTtBQUFBLElBQ0EsSUFBQyxDQUFBLEtBQUssQ0FBQyxLQUFQLENBQUEsQ0FEQSxDQUFBO0FBQUEsSUFHQSxJQUFDLENBQUEsTUFBRCxHQUFVLFFBQVEsQ0FBQyxjQUFULENBQXdCLFFBQXhCLENBSFYsQ0FBQTtBQUFBLElBSUEsSUFBQyxDQUFBLFlBQUQsQ0FBQSxDQUpBLENBQUE7QUFBQSxJQUtBLElBQUMsQ0FBQSxRQUFELEdBQWdCLElBQUEsUUFBQSxDQUFTO0FBQUEsTUFDdkIsRUFBQSxFQUFJLFFBQVEsQ0FBQyxhQUFULENBQXVCLGNBQXZCLENBRG1CO0FBQUEsTUFFdkIsUUFBQSxFQUFVLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFBLEdBQUE7aUJBQUcsS0FBQyxDQUFBLE1BQUQsQ0FBQSxFQUFIO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FGYTtLQUFULENBTGhCLENBRFc7RUFBQSxDQUFiOztBQUFBLHVCQVdBLFlBQUEsR0FBYyxTQUFBLEdBQUE7QUFDWixJQUFBLElBQUcsSUFBQyxDQUFBLElBQUQsSUFBVSxJQUFDLENBQUEsTUFBZDtBQUNFLE1BQUEsSUFBQyxDQUFBLElBQUksQ0FBQyxnQkFBTixDQUF1QixRQUF2QixFQUFpQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxDQUFELEdBQUE7aUJBQU8sS0FBQyxDQUFBLE1BQUQsQ0FBUSxDQUFSLEVBQVA7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFqQyxDQUFBLENBQUE7YUFDQSxJQUFDLENBQUEsTUFBTSxDQUFDLGdCQUFSLENBQXlCLE9BQXpCLEVBQWtDLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLENBQUQsR0FBQTtpQkFBTyxLQUFDLENBQUEsa0JBQUQsQ0FBb0IsQ0FBcEIsRUFBUDtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxDLEVBRkY7S0FEWTtFQUFBLENBWGQsQ0FBQTs7QUFBQSx1QkFnQkEsTUFBQSxHQUFRLFNBQUMsQ0FBRCxHQUFBO0FBQ04sSUFBQSxDQUFBLElBQUssQ0FBQyxDQUFDLGNBQVAsSUFBeUIsQ0FBQyxDQUFDLGNBQUYsQ0FBQSxDQUF6QixDQUFBO0FBQ0EsSUFBQSxJQUFHLElBQUMsQ0FBQSxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQWIsR0FBc0IsQ0FBekI7YUFFRSxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLFFBQUMsUUFBQSxFQUFVLEdBQVg7QUFBQSxRQUFnQixVQUFBLEVBQVksV0FBNUI7T0FBeEIsRUFBa0UsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsS0FBRCxHQUFBO0FBQ2hFLFVBQUEsT0FBTyxDQUFDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCLEtBQXRCLENBQUEsQ0FBQTtpQkFDQSxpQkFBa0IsQ0FBQSxLQUFLLENBQUMsVUFBTixDQUFpQixDQUFDLE1BQXBDLENBQ0U7QUFBQSxZQUFBLEtBQUEsRUFBTyxLQUFDLENBQUEsS0FBSyxDQUFDLEtBQWQ7QUFBQSxZQUNBLE9BQUEsRUFBUyxLQUFDLENBQUEsY0FBYyxDQUFDLElBQWhCLENBQXFCLEtBQXJCLENBRFQ7V0FERixFQUZnRTtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxFLEVBRkY7S0FGTTtFQUFBLENBaEJSLENBQUE7O0FBQUEsdUJBMkJBLGNBQUEsR0FBZ0IsU0FBQyxRQUFELEdBQUE7QUFDWixJQUFBLElBQUMsQ0FBQSxLQUFELENBQU8sSUFBQyxDQUFBLE1BQVIsQ0FBQSxDQUFBO1dBQ0EsSUFBQyxDQUFBLE1BQU0sQ0FBQyxXQUFSLENBQW9CLFFBQXBCLEVBRlk7RUFBQSxDQTNCaEIsQ0FBQTs7QUFBQSx1QkErQkEsS0FBQSxHQUFPLFNBQUMsRUFBRCxHQUFBO0FBQ0wsUUFBQSxRQUFBO0FBQUE7V0FBTyxFQUFFLENBQUMsU0FBVixHQUFBO0FBQ0Usb0JBQUEsRUFBRSxDQUFDLFdBQUgsQ0FBZSxFQUFFLENBQUMsU0FBbEIsRUFBQSxDQURGO0lBQUEsQ0FBQTtvQkFESztFQUFBLENBL0JQLENBQUE7O0FBQUEsdUJBbUNBLGtCQUFBLEdBQW9CLFNBQUMsQ0FBRCxHQUFBO0FBQ2xCLFFBQUEsY0FBQTtBQUFBLElBQUEsQ0FBQyxDQUFDLGNBQUYsQ0FBQSxDQUFBLENBQUE7QUFBQSxJQUNBLFFBQUEsR0FBVyxDQUFDLEdBQUQsRUFBTSxHQUFOLENBRFgsQ0FBQTtBQUVBLElBQUEsV0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQVQsRUFBQSxlQUFvQixRQUFwQixFQUFBLElBQUEsTUFBSDtBQUNFLE1BQUEsSUFBQyxDQUFBLEtBQUssQ0FBQyxLQUFQLEdBQWUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUF4QixDQUFBO2FBQ0EsSUFBQyxDQUFBLE1BQUQsQ0FBUSxDQUFSLEVBRkY7S0FIa0I7RUFBQSxDQW5DcEIsQ0FBQTs7QUFBQSx1QkEwQ0EsUUFBQSxHQUFVLFNBQUEsR0FBQTtBQUNSLFdBQU8sSUFBQyxDQUFBLEtBQUssQ0FBQyxLQUFkLENBRFE7RUFBQSxDQTFDVixDQUFBOztvQkFBQTs7SUFuQkYsQ0FBQTs7QUFBQSxNQWlFTSxDQUFDLE9BQVAsR0FBaUIsVUFqRWpCLENBQUE7Ozs7QUNBQTtBQUFBLGtCQUFBO0FBQ0E7QUFBQTs7Ozs7Ozs7OztHQURBO0FBQUEsSUFBQSxnQkFBQTs7QUFBQSxVQWFBLEdBQWEsT0FBQSxDQUFRLGlCQUFSLENBYmIsQ0FBQTs7QUFBQTtBQWdCZSxFQUFBLGNBQUEsR0FBQTtBQUNYLElBQUEsSUFBQyxDQUFBLFdBQUQsR0FBZSx3QkFBZixDQUFBO0FBQUEsSUFDQSxJQUFDLENBQUEsUUFBRCxHQUFZLE1BRFosQ0FBQTtBQUFBLElBRUEsSUFBQyxDQUFBLElBQUQsR0FBUSxrQkFGUixDQUFBO0FBQUEsSUFHQSxJQUFDLENBQUEsSUFBRCxHQUFRLFVBSFIsQ0FBQTtBQUFBLElBSUEsSUFBQyxDQUFBLEtBQUQsR0FBUyxLQUpULENBQUE7QUFBQSxJQUtBLElBQUMsQ0FBQSxJQUFELEdBQVEsWUFMUixDQUFBO0FBQUEsSUFNQSxJQUFDLENBQUEsR0FBRCxHQUFPLEVBTlAsQ0FEVztFQUFBLENBQWI7O0FBU0E7QUFBQTs7S0FUQTs7QUFBQSxpQkFZQSxLQUFBLEdBQU8sU0FBQyxJQUFELEdBQUE7QUFDTCxRQUFBLGFBQUE7QUFBQSxJQUFBLElBQUcsTUFBQSxDQUFBLElBQVcsQ0FBQyxNQUFaLEtBQXNCLE1BQXRCLElBQW1DLElBQUksQ0FBQyxNQUFMLEtBQWUsSUFBckQ7QUFDRSxNQUFBLElBQUksQ0FBQyxNQUFMLEdBQWMsSUFBZCxDQURGO0tBQUE7QUFBQSxJQUVBLGFBQUEsR0FBZ0IsSUFBQyxDQUFBLGlCQUFELENBQW1CLElBQUksQ0FBQyxhQUF4QixDQUZoQixDQUFBO1dBR0EsSUFBQyxDQUFBLE1BQUQsQ0FDSTtBQUFBLE1BQUEsS0FBQSxFQUFPLGFBQVA7QUFBQSxNQUNBLE9BQUEsRUFBUyxJQUFDLENBQUEsZUFBZSxDQUFDLElBQWpCLENBQXNCLElBQXRCLENBRFQ7QUFBQSxNQUVBLE1BQUEsRUFBUSxJQUFJLENBQUMsTUFGYjtLQURKLEVBSks7RUFBQSxDQVpQLENBQUE7O0FBcUJBO0FBQUE7O0tBckJBOztBQUFBLGlCQXdCQSxpQkFBQSxHQUFtQixTQUFDLElBQUQsR0FBQTtXQUNqQixJQUFJLENBQUMsT0FBTCxDQUFhLE9BQWIsRUFBc0IsRUFBdEIsRUFEaUI7RUFBQSxDQXhCbkIsQ0FBQTs7QUEyQkE7QUFBQTs7S0EzQkE7O0FBQUEsaUJBOEJBLE1BQUEsR0FBUSxTQUFDLE1BQUQsR0FBQTtXQUVOLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsTUFBQyxRQUFBLEVBQVUsR0FBWDtLQUF4QixFQUF5QyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxLQUFELEdBQUE7QUFDdkMsWUFBQSwwQkFBQTtBQUFBLFFBQUEsSUFBRyxRQUFBLEtBQVksRUFBZjtBQUNFLFVBQUEsUUFBQSxHQUFXLEdBQVgsQ0FERjtTQUFBO0FBQUEsUUFFQSxLQUFDLENBQUEsV0FBRCxDQUFhLEtBQUssQ0FBQyxRQUFuQixDQUZBLENBQUE7QUFBQSxRQUdBLEdBQUEsR0FBTSxLQUFDLENBQUEsT0FBRCxDQUFTLE1BQU0sQ0FBQyxLQUFoQixDQUhOLENBQUE7QUFBQSxRQUtBLFdBQUEsR0FBYyxNQUFNLENBQUMsT0FMckIsQ0FBQTtBQUFBLFFBTUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsU0FBQyxRQUFELEdBQUE7QUFDZixjQUFBLFVBQUE7QUFBQSxVQUFBLFVBQUEsR0FBYSxLQUFDLENBQUEsS0FBRCxDQUFPLFFBQVAsRUFBaUIsTUFBTSxDQUFDLE1BQXhCLENBQWIsQ0FBQTtpQkFDQSxXQUFBLENBQVksVUFBWixFQUZlO1FBQUEsQ0FOakIsQ0FBQTtlQVdBLEtBQUMsQ0FBQSxPQUFELENBQ0U7QUFBQSxVQUFBLEdBQUEsRUFBSyxHQUFMO0FBQUEsVUFDQSxPQUFBLEVBQVMsTUFBTSxDQUFDLE9BRGhCO0FBQUEsVUFFQSxLQUFBLEVBQU8sTUFBTSxDQUFDLEtBRmQ7U0FERixFQVp1QztNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpDLEVBRk07RUFBQSxDQTlCUixDQUFBOztBQUFBLGlCQW1EQSxXQUFBLEdBQWEsU0FBQyxRQUFELEdBQUE7QUFDWCxJQUFBLElBQUMsQ0FBQSxlQUFELEdBQW1CLFFBQW5CLENBQUE7V0FDQSxJQUFDLENBQUEsSUFBRCxHQUFRLFdBQUEsR0FBYyxTQUZYO0VBQUEsQ0FuRGIsQ0FBQTs7QUF1REE7QUFBQTs7O0tBdkRBOztBQUFBLGlCQTJEQSxPQUFBLEdBQVMsU0FBQyxJQUFELEdBQUE7QUFDUCxRQUFBLEdBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxJQUFDLENBQUEsR0FBRCxHQUFXLElBQUEsY0FBQSxDQUFBLENBQWpCLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxrQkFBSixHQUF5QixDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7QUFDdkIsUUFBQSxHQUFBLEdBQU0sS0FBQyxDQUFBLEdBQVAsQ0FBQTtBQUNBLFFBQUEsSUFBRyxHQUFHLENBQUMsVUFBSixHQUFpQixDQUFwQjtBQUFBO1NBQUEsTUFFSyxJQUFHLEdBQUcsQ0FBQyxNQUFKLEtBQWMsR0FBakI7QUFDSCxVQUFBLEtBQUMsQ0FBQSxZQUFELENBQWMsR0FBZCxDQUFBLENBQUE7QUFDQSxVQUFBLElBQUksTUFBQSxDQUFBLElBQVcsQ0FBQyxLQUFaLEtBQXFCLFVBQXpCO0FBQ0UsWUFBQSxJQUFJLENBQUMsS0FBTCxDQUFBLENBQUEsQ0FERjtXQUZHO1NBQUEsTUFLQSxJQUFHLEdBQUcsQ0FBQyxVQUFKLEtBQWtCLENBQXJCO0FBQ0QsaUJBQU8sSUFBSSxDQUFDLE9BQUwsQ0FBYSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQXRCLENBQVAsQ0FEQztTQVRrQjtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRHpCLENBQUE7QUFBQSxJQWFBLEdBQUcsQ0FBQyxJQUFKLENBQVMsS0FBVCxFQUFnQixJQUFJLENBQUMsR0FBckIsRUFBMEIsSUFBMUIsQ0FiQSxDQUFBO1dBY0EsR0FBRyxDQUFDLElBQUosQ0FBQSxFQWZPO0VBQUEsQ0EzRFQsQ0FBQTs7QUFBQSxpQkE2RUEsT0FBQSxHQUFTLFNBQUMsS0FBRCxHQUFBO0FBQ1AsUUFBQSxHQUFBO0FBQUEsSUFBQSxHQUFBLEdBQU0sQ0FBQyxJQUFDLENBQUEsUUFBRixFQUFZLEtBQVosRUFDSSxJQUFDLENBQUEsSUFETCxFQUVJLElBQUMsQ0FBQSxJQUZMLEVBR0ksSUFBQyxDQUFBLElBSEwsRUFJSSxJQUFDLENBQUEsS0FKTCxFQUtJLElBQUMsQ0FBQSxlQUFELENBQWlCLEtBQWpCLENBTEosQ0FNQyxDQUFDLElBTkYsQ0FNTyxFQU5QLENBQU4sQ0FBQTtBQVFBLFdBQU8sR0FBUCxDQVRPO0VBQUEsQ0E3RVQsQ0FBQTs7QUFBQSxpQkF5RkEsZUFBQSxHQUFpQixTQUFDLEtBQUQsR0FBQTtBQUVmLFFBQUEsbUJBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxrQkFBQSxDQUFtQixLQUFuQixDQUFOLENBQUE7QUFDQSxTQUFBLGtCQUFBOzhCQUFBO0FBQ0UsTUFBQSxJQUFHLE1BQUEsQ0FBQSxJQUFBLEtBQWUsUUFBbEI7QUFFRSxRQUFBLEVBQUEsR0FBSyxJQUFJLENBQUMsR0FBVixDQUZGO09BQUEsTUFBQTtBQU1FLFFBQUEsRUFBQSxHQUFLLGtCQUFBLENBQW1CLElBQW5CLENBQUwsQ0FORjtPQUFBO0FBQUEsTUFPQSxHQUFBLEdBQU0sR0FBRyxDQUFDLE9BQUosQ0FBWSxJQUFaLEVBQWtCLEVBQWxCLENBUE4sQ0FERjtBQUFBLEtBREE7QUFVQSxXQUFPLEdBQVAsQ0FaZTtFQUFBLENBekZqQixDQUFBOztBQUFBLGlCQXVHQSxZQUFBLEdBQWMsU0FBQyxHQUFELEdBQUE7V0FDWixPQUFPLENBQUMsR0FBUixDQUFZLE9BQVosRUFBcUIsR0FBckIsRUFEWTtFQUFBLENBdkdkLENBQUE7O0FBMEdBO0FBQUE7O0tBMUdBOztBQUFBLGlCQTZHQSxlQUFBLEdBQWlCLFNBQUMsVUFBRCxHQUFBO0FBQ2YsSUFBQSxJQUFHLFVBQUg7YUFDRSxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVosQ0FBd0IsSUFBeEIsRUFBOEIsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsR0FBRCxHQUFBO2lCQUM1QixNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVosQ0FBd0IsR0FBRyxDQUFDLEVBQTVCLEVBQWdDO0FBQUEsWUFDOUIsTUFBQSxFQUFRLEtBQUMsQ0FBQSxXQUFELENBQWEsVUFBYixDQURzQjtBQUFBLFlBRTlCLElBQUEsRUFBTSxVQUFVLENBQUMsU0FGYTtBQUFBLFlBRzlCLE9BQUEsRUFBUyxDQUFBLFVBQVcsQ0FBQyxTQUFTLENBQUMsUUFBckIsQ0FBOEIsZUFBOUIsQ0FIb0I7V0FBaEMsRUFENEI7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUE5QixFQURGO0tBRGU7RUFBQSxDQTdHakIsQ0FBQTs7QUFBQSxpQkF1SEEsV0FBQSxHQUFhLFNBQUMsVUFBRCxHQUFBO0FBQ1gsUUFBQSxJQUFBO0FBQUEsSUFBQSxpRUFBbUIsQ0FBRSx5QkFBbEIsS0FBNEIsQ0FBL0I7YUFDRSxnQkFERjtLQUFBLE1BQUE7YUFHRSxlQUhGO0tBRFc7RUFBQSxDQXZIYixDQUFBOztBQTZIQTtBQUFBOztLQTdIQTs7QUFBQSxpQkFnSUEsS0FBQSxHQUFPLFNBQUMsUUFBRCxFQUFXLE1BQVgsRUFBbUIsU0FBbkIsR0FBQTtBQUNILFFBQUEsYUFBQTs7TUFEc0IsWUFBWTtLQUNsQztBQUFBLElBQUEsR0FBQSxHQUFNLElBQUMsQ0FBQSxZQUFELENBQWMsUUFBZCxDQUFOLENBQUE7QUFBQSxJQUNBLFFBQUEsR0FBVyxJQUFDLENBQUEsWUFBRCxDQUFjLEdBQWQsQ0FEWCxDQUFBO0FBRUEsSUFBQSxJQUFHLFFBQUg7QUFDRSxNQUFBLFNBQUEsR0FBWSxRQUFRLENBQUMsYUFBVCxDQUF1QixzQkFBdkIsQ0FBWixDQUFBO0FBQ0EsTUFBQSxJQUFHLFNBQUg7QUFDRSxRQUFBLFNBQVMsQ0FBQyxTQUFWLEdBQXNCLElBQUMsQ0FBQSxXQUF2QixDQUFBO0FBQUEsUUFDQSxTQUFTLENBQUMsWUFBVixDQUF1QixhQUF2QixFQUFzQyxHQUF0QyxDQURBLENBQUE7QUFBQSxRQUVBLElBQUMsQ0FBQSxTQUFELENBQVcsU0FBWCxDQUZBLENBQUE7QUFBQSxRQUdBLElBQUMsQ0FBQSxRQUFELENBQVUsU0FBVixDQUhBLENBREY7T0FBQSxNQUtLLElBQUcsQ0FBQSxNQUFIO0FBQ0gsUUFBQSxTQUFBLEdBQVksUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBWixDQUFBO0FBQUEsUUFDQSxTQUFTLENBQUMsU0FBVixHQUFzQixlQUR0QixDQUFBO0FBQUEsUUFFQSxTQUFTLENBQUMsU0FBVixHQUFzQixvQ0FGdEIsQ0FERztPQVBQO0tBRkE7QUFjQSxXQUFPLFNBQVAsQ0FmRztFQUFBLENBaElQLENBQUE7O0FBaUpBO0FBQUE7O0tBakpBOztBQUFBLGlCQW9KQSxZQUFBLEdBQWMsU0FBQyxDQUFELEdBQUE7QUFDWixRQUFBLGVBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFOLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxTQUFKLEdBQWdCLENBRGhCLENBQUE7QUFBQSxJQUVBLE9BQUEsR0FBVSxHQUFHLENBQUMsb0JBQUosQ0FBeUIsUUFBekIsQ0FGVixDQUFBO0FBQUEsSUFHQSxDQUFBLEdBQUksT0FBTyxDQUFDLE1BSFosQ0FBQTtBQUlBLFdBQU0sQ0FBQSxFQUFOLEdBQUE7QUFDRSxNQUFBLE9BQVEsQ0FBQSxDQUFBLENBQUUsQ0FBQyxVQUFVLENBQUMsV0FBdEIsQ0FBa0MsT0FBUSxDQUFBLENBQUEsQ0FBMUMsQ0FBQSxDQURGO0lBQUEsQ0FKQTtBQU1BLFdBQU8sR0FBRyxDQUFDLFNBQVgsQ0FQWTtFQUFBLENBcEpkLENBQUE7O0FBQUEsaUJBNkpBLFlBQUEsR0FBYyxTQUFDLEdBQUQsRUFBTSxRQUFOLEdBQUE7QUFDWixRQUFBLEdBQUE7O01BRGtCLFdBQVc7S0FDN0I7QUFBQSxJQUFBLEdBQUEsR0FBTSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFOLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxTQUFKLEdBQWdCLEdBRGhCLENBQUE7QUFBQSxJQUVBLFFBQUEsR0FBVyxRQUFRLENBQUMsc0JBQVQsQ0FBQSxDQUZYLENBQUE7QUFHQSxXQUFRLEdBQUcsQ0FBQyxVQUFaLEdBQUE7QUFDRSxNQUFBLFFBQVEsQ0FBQyxXQUFULENBQXNCLEdBQUcsQ0FBQyxVQUExQixDQUFBLENBREY7SUFBQSxDQUhBO0FBS0EsV0FBTyxRQUFQLENBTlk7RUFBQSxDQTdKZCxDQUFBOztBQUFBLGlCQXFLQSxTQUFBLEdBQVcsU0FBQyxRQUFELEdBQUE7O01BQUMsV0FBUztLQUNuQjtBQUFBLElBQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxRQUFaLEVBQXNCLEtBQXRCLEVBQTZCLEtBQTdCLENBQUEsQ0FBQTtBQUNBLFdBQU8sUUFBUCxDQUZTO0VBQUEsQ0FyS1gsQ0FBQTs7QUFBQSxpQkF5S0EsUUFBQSxHQUFVLFNBQUMsUUFBRCxHQUFBOztNQUFDLFdBQVM7S0FDbEI7QUFBQSxJQUFBLElBQUksQ0FBQyxNQUFMLENBQVksUUFBWixFQUFzQixHQUF0QixFQUEyQixNQUEzQixDQUFBLENBQUE7QUFDQSxXQUFPLFFBQVAsQ0FGUTtFQUFBLENBektWLENBQUE7O0FBQUEsaUJBNktBLE1BQUEsR0FBUSxTQUFDLFFBQUQsRUFBZ0IsR0FBaEIsRUFBcUIsSUFBckIsR0FBQTtBQUNOLFFBQUEsZ0NBQUE7O01BRE8sV0FBUztLQUNoQjtBQUFBLElBQUEsSUFBRyxRQUFIO0FBQ0UsTUFBQSxJQUFBLEdBQVEsUUFBUSxDQUFDLGdCQUFULENBQTBCLEdBQTFCLENBQVIsQ0FBQTtBQUFBLE1BQ0EsTUFBQSxHQUFTLFFBQVEsQ0FBQyxhQUFULENBQXVCLEdBQXZCLENBRFQsQ0FBQTtBQUVBO1dBQUEsMkNBQUE7dUJBQUE7QUFDRSxRQUFBLE1BQU0sQ0FBQyxJQUFQLEdBQWMsR0FBSSxDQUFBLElBQUEsQ0FBbEIsQ0FBQTtBQUFBLFFBQ0EsTUFBTSxDQUFDLElBQVAsR0FBYyxJQUFDLENBQUEsSUFEZixDQUFBO0FBQUEsUUFFQSxNQUFNLENBQUMsUUFBUCxHQUFrQixJQUFDLENBQUEsUUFGbkIsQ0FBQTtBQUlBLFFBQUEsSUFBRyxHQUFHLENBQUMsT0FBSixLQUFlLEdBQWxCO0FBQ0UsVUFBQSxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQWQsQ0FBa0IsVUFBbEIsQ0FBQSxDQUFBO0FBQ0EsVUFBQSxJQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBaEIsQ0FBd0IsT0FBeEIsQ0FBQSxLQUFzQyxDQUFBLENBQXpDO0FBQ0UsWUFBQSxNQUFNLENBQUMsUUFBUCxHQUFrQixJQUFBLEdBQU8sTUFBTSxDQUFDLFFBQWhDLENBQUE7QUFBQSxZQUNBLEdBQUcsQ0FBQyxZQUFKLENBQWlCLFFBQWpCLEVBQTJCLFFBQTNCLENBREEsQ0FERjtXQUZGO1NBQUEsTUFLSyxJQUFHLEdBQUcsQ0FBQyxPQUFKLEtBQWUsS0FBbEI7QUFDSCxVQUFBLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBZCxDQUFrQixTQUFsQixDQUFBLENBREc7U0FUTDtBQUFBLHNCQVlBLEdBQUcsQ0FBQyxZQUFKLENBQWlCLElBQWpCLEVBQXVCLE1BQU0sQ0FBQyxJQUE5QixFQVpBLENBREY7QUFBQTtzQkFIRjtLQURNO0VBQUEsQ0E3S1IsQ0FBQTs7Y0FBQTs7SUFoQkYsQ0FBQTs7QUFBQSxNQWtOTSxDQUFDLE9BQVAsR0FBaUIsR0FBQSxDQUFBLElBbE5qQixDQUFBOzs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKX12YXIgZj1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwoZi5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxmLGYuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiLy8gdHVya2lzaGRpY3Rpb25hcnkgY29kaW5nc1xudmFyIERJQ1QgPSB7XG4gICAgMzA0OiAnJUREJywgLy9pXG4gICAgMzUwOiAnJURFJywgLy9TXG4gICAgMjg2OiAnJUQwJywgLy9HXG4gICAgMjg3OiAnJUYwJywgLy9HXG4gICAgMzUxOiAnJUZFJywgLy9TXG4gICAgMzA1OiAnJUZEJywgLy9JXG4gICAgMjUyOiAnJUZDJywgLy/DvFxuICAgIDIyMDogJyVEQycsIC8vw5xcbiAgICAyMzE6ICclRTcnLCAvL8OnXG4gICAgMTk5OiAnJUM3JywgLy/Dh1xuICAgIDI0NjogJyVGNicsIC8vw7ZcbiAgICAyMTQ6ICclRDYnLCAvL8OWXG4gICAgMzk6ICcnLCAgLy8nXG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IERJQ1Q7IiwiLypcciAgTXVsdGl0cmFuIGRlcGVuZHMgb24gaHRtbC1lc2NhcGluZyAobm90IFVURi04KSBydWxlcyBmb3Igc3BlY2lhbCBzeW1ib2xzXHIgIMOgLCDDqCwgw6wsIMOyLCDDuSAtIMOALCDDiCwgw4wsIMOSLCDDmVxyICDDoSwgw6ksIMOtLCDDsywgw7osIMO9IC0gw4EsIMOJLCDDjSwgw5MsIMOaLCDDnVxyICDDoiwgw6osIMOuLCDDtCwgw7sgw4IsIMOKLCDDjiwgw5QsIMObXHIgIMOjLCDDsSwgw7Ugw4MsIMORLCDDlVxyICDDpCwgw6ssIMOvLCDDtiwgw7wsIMO/IMOELCDDiywgw48sIMOWLCDDnCxcciAgw6UsIMOFXHIgIMOmLCDDhlxyICDDpywgw4dcciAgw7AsIMOQXHIgIMO4LCDDmFxyICDCvyDCoSDDn1xyKi9ccnZhciBDSEFSX0NPREVTID0ge1xyICAvL3J1c3NpYW5cciAgJyVEMSU4QSc6IHt2YWw6JyVGQScsIGxhbmc6J3J1J30sIC8vINGKXHIgICclRDAlQUEnOiB7dmFsOiclREEnLCBsYW5nOidydSd9LC8vINCqXHJcciAgJyVDMyU4MCc6ICcmIzE5MjsnLCAvLyDDgFxyICAnJUMzJTgxJzogJyYjMTkzOycsIC8vIMOBXHIgICclQzMlODInOiAnJiMxOTQ7JywgLy8gw4JcciAgJyVDMyU4Myc6ICcmIzE5NTsnLCAvLyDDg1xyICAnJUMzJTg0JzogJyYjMTk2OycsIC8vIMOEXHIgICclQzMlODUnOiAnJiMxOTc7JywgLy8gw4VcciAgJyVDMyU4Nic6ICcmIzE5ODsnLCAvLyDDhlxyXHIgICclQzMlODcnOiAnJiMxOTk7JywgLy8gw4dcciAgJyVDMyU4OCc6ICcmIzIwMDsnLCAvLyDDiFxyICAnJUMzJTg5JzogJyYjMjAxOycsIC8vIMOJXHIgICclQzMlOEEnOiAnJiMyMDI7JywgLy8gw4pcciAgJyVDMyU4Qic6ICcmIzIwMzsnLCAvLyDDi1xyXHIgICclQzMlOEMnOiAnJiMyMDQ7JywgLy8gw4xcciAgJyVDMyU4RCc6ICcmIzIwNTsnLCAvLyDDjVxyICAnJUMzJThFJzogJyYjMjA2OycsIC8vIMOOXHIgICclQzMlOEYnOiAnJiMyMDc7JywgLy8gw49cclxyICAnJUMzJTkxJzogJyYjMjA5OycsIC8vIMORXHIgICclQzMlOTInOiAnJiMyMTA7JywgLy8gw5JcciAgJyVDMyU5Myc6ICcmIzIxMTsnLCAvLyDDk1xyICAnJUMzJTk0JzogJyYjMjEyOycsIC8vIMOUXHIgICclQzMlOTUnOiAnJiMyMTM7JywgLy8gw5VcciAgJyVDMyU5Nic6ICcmIzIxNDsnLCAvLyDDllxyXHIgICclQzMlOTknOiAnJiMyMTc7JywgLy8gw5lcciAgJyVDMyU5QSc6ICcmIzIxODsnLCAvLyDDmlxyICAnJUMzJTlCJzogJyYjMjE5OycsIC8vIMObXHIgICclQzMlOUMnOiAnJiMyMjA7JywgLy8gw5xcclxyXHIgICclQzMlQTAnOiAnJiMyMjQ7JywgLy8gw6BcciAgJyVDMyVBMSc6ICcmIzIyNTsnLCAvLyDDoVxyICAnJUMzJUEyJzogJyYjMjI2OycsIC8vIMOiXHIgICclQzMlQTMnOiAnJiMyMjc7JywgLy8gw6NcciAgJyVDMyVBNCc6ICcmIzIyODsnLCAvLyDDpFxyICAnJUMzJUE1JzogJyYjMjI5OycsIC8vIMOlXHIgICclQzMlQTYnOiAnJiMyMzA7JywgLy8gw6ZcciAgJyVDMyVBNyc6ICcmIzIzMTsnLCAvLyDDp1xyXHJcciAgJyVDMyVBOCc6ICcmIzIzMjsnLCAvLyDDqFxyICAnJUMzJUE5JzogJyYjMjMzOycsIC8vIMOpXHIgICclQzMlQUEnOiAnJiMyMzQ7JywgLy8gw6pcciAgJyVDMyVBQic6ICcmIzIzNTsnLCAvLyDDq1xyXHIgICclQzMlQUMnOiAnJiMyMzY7JywgLy8gw6xcciAgJyVDMyVBRCc6ICcmIzIzNzsnLCAvLyDDrVxyICAnJUMzJUFFJzogJyYjMjM4OycsIC8vIMOuXHIgICclQzMlQUYnOiAnJiMyMzk7JywgLy8gw69cclxyICAnJUMzJUIwJzogJyYjMjQwOycsIC8vIMOwXHIgICclQzMlQjEnOiAnJiMyNDE7JywgLy8gw7FcclxyICAnJUMzJUIyJzogJyYjMjQyOycsIC8vIMOyXHIgICclQzMlQjMnOiAnJiMyNDM7JywgLy8gw7NcciAgJyVDMyVCNCc6ICcmIzI0NDsnLCAvLyDDtFxyICAnJUMzJUI1JzogJyYjMjQ1OycsIC8vIMO1XHIgICclQzMlQjYnOiAnJiMyNDY7JywgLy8gw7ZcclxyICAnJUMzJUI5JzogJyYjMjQ5OycsIC8vIMO5XHIgICclQzMlQkEnOiAnJiMyNTA7JywgLy8gw7pcciAgJyVDMyVCQic6ICcmIzI1MTsnLCAvLyDDu1xyICAnJUMzJUJDJzogJyYjMjUyOycsIC8vIMO8XHIgICclQzMlQkYnOiAnJiMyNTU7JywgLy8gw79cciAgJyVDNSVCOCc6ICcmIzM3NjsnLCAvLyDFuFxyXHIgICclQzMlOUYnOiAnJiMyMjM7JywgLy8gw59cclxyICAnJUMyJUJGJzogJyYjMTkxOycsIC8vIMK/XHIgICclQzIlQTEnOiAnJiMxNjE7JywgLy8gwqFccn07XHJccm1vZHVsZS5leHBvcnRzID0gQ0hBUl9DT0RFUztcciIsIiMjI1xuICBEcm9wZG93biBsYW5ndWFnZSBtZW51XG4gIEBwYXJhbSBvcHRzIHRha2VzIGVsZW1lbnQgYW5kIG9uU2VsZWN0IGhhbmRsZXJcbiAgZXhhbXBsZTpcbiAgbmV3IERyb3Bkb3duKHtcbiAgIGVsOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnI21lbnUnKTtcbiAgIG9uU2VsZWN0OiBmdW5jdGlvbiAoKSB7fVxuICB9KVxuIyMjXG5MQU5HX0NPREUgPVxuICAnMSc6ICdFbmcnXG4gICcyJzogJ1J1cydcbiAgJzMnOiAnR2VyJ1xuICAnNCc6ICdGcmUnXG4gICc1JzogJ1NwYSdcbiAgJzIzJzogJ0l0YSdcbiAgJzI0JzogJ0R1dCdcbiAgJzI2JzogJ0VzdCdcbiAgJzI3JzogJ0xhdidcbiAgJzMxJzogJ0FmcidcbiAgJzM0JzogJ0VwbydcbiAgJzM1JzogJ1hhbCcsXG4gICcxMDAwJzogJ1R1cidcblxuRElDVF9DT0RFID1cbiAgJzEnOiAnbXVsdGl0cmFuJ1xuICAnMTAwMCc6ICd0dXJraXNoJ1xuXG5jbGFzcyBEcm9wZG93blxuICBjb25zdHJ1Y3RvcjogKG9wdHMpIC0+XG4gICAgQGVsID0gb3B0cy5lbCBvciBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICAgICMgb25TZWxlY3QgaGFuZGxlciBzZXQgYnkgYWdncmVnYXRlIGNsYXNzXG4gICAgQG9uU2VsZWN0ID0gb3B0cy5vblNlbGVjdFxuXG4gICAgQG1lbnUgPSBAZWwucXVlcnlTZWxlY3RvcignLmRyb3Bkb3duLW1lbnUnKVxuICAgIGlmIEBtZW51XG4gICAgICBAbWVudS5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnXG4gICAgICBAaXRlbXMgPSBAbWVudS5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCdsYW5ndWFnZS10eXBlJylcbiAgICAgIEBidXR0b24gPSBAZWwucXVlcnlTZWxlY3RvcignLmRyb3Bkb3duLXRvZ2dsZScpXG4gICAgICBAYWRkTGlzdGVuZXJzKClcbiAgICAgIEBpbml0TGFuZ3VhZ2UoKVxuXG4gIGFkZExpc3RlbmVyczogLT5cbiAgICBAYnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIgJ2NsaWNrJywgKGUpID0+IEB0b2dnbGUoZSlcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyICdjbGljaycsIChlKSA9PiBAaGlkZShlKVxuICAgIEBtZW51LmFkZEV2ZW50TGlzdGVuZXIgJ2NsaWNrJywgKGUpID0+IEBjaG9vc2UoZSlcblxuICAjIE9uIGluaXQgdHJ5aW5nIHRvIGdldCBjdXJyZW50IGxhbmd1YWdlIGZyb20gc3RvcmFnZSBvciB1c2luZyBkZWZhdWx0KCAxOmVuZ2xpc2gpXG4gIGluaXRMYW5ndWFnZTogLT5cbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7IGxhbmd1YWdlOiAnMSd9LCAoc3RvcmUpID0+XG4gICAgICBAc2V0VGl0bGUoc3RvcmUubGFuZ3VhZ2UpO1xuICAgIClcblxuICB0b2dnbGU6IChlKSAtPlxuICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcbiAgICBAc2V0QWN0aXZlSXRlbSgpXG4gICAgaWYgQG1lbnUgYW5kIEBtZW51LnN0eWxlLmRpc3BsYXkgaXMgJ25vbmUnXG4gICAgICBAc2hvdygpXG4gICAgZWxzZVxuICAgICAgQGhpZGUoKVxuXG4gICMgUmVhZCBjdXJyZW50IGxhbmd1YWdlIGZyb20gQ2hyb21lIFN0b3JhZ2UgYW5kIGNvbG9yIGFjdGl2ZSBsaW5lXG4gIHNldEFjdGl2ZUl0ZW06IC0+XG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQge2xhbmd1YWdlOiAnMSd9LCAoc3RvcmUpID0+XG4gICAgICBmb3IgaXRlbSBpbiBAaXRlbXNcbiAgICAgICAgaWYgaXRlbS5nZXRBdHRyaWJ1dGUoJ2RhdGEtdmFsJykgPT0gc3RvcmUubGFuZ3VhZ2VcbiAgICAgICAgICBpdGVtLmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpXG4gICAgICAgIGVsc2VcbiAgICAgICAgICBpdGVtLmNsYXNzTGlzdC5yZW1vdmUoJ2FjdGl2ZScpXG5cbiAgaGlkZTogLT5cbiAgICBAbWVudS5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnXG5cbiAgc2hvdzogLT5cbiAgICBAbWVudS5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJ1xuXG4gICMgU2F2ZXMgY2hvc2VuIGxhbmd1YWdlIHRvIGNocm9tZS5zdG9yYWdlIGFuZCBkZWNpZGUgd2hpY2ggZGljdGlvbmFyeSB0byB1c2VcbiAgIyBUaGVuIGNhbGxlZCBvblNlbGVjdCBoYW5kbGVyIG9mIHRoZSBjb250YWluZXIgY2xhc3NcbiAgY2hvb3NlOiAoZSkgLT5cbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgbGFuZ3VhZ2UgPSBlLnRhcmdldC5nZXRBdHRyaWJ1dGUoJ2RhdGEtdmFsJylcbiAgICBkaWN0aW9uYXJ5ID0gQGdldERpY3Rpb25hcnkobGFuZ3VhZ2UpXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5zZXQoe2xhbmd1YWdlOiBsYW5ndWFnZSwgZGljdGlvbmFyeTogZGljdGlvbmFyeX0sIEBvblNlbGVjdClcbiAgICBAc2V0VGl0bGUobGFuZ3VhZ2UpXG4gICAgQGhpZGUoKVxuXG4gICMgU29tZSBsYW5ndWFnZXMgYXJlIG5vdCBwcmVzZW50IGluIG11bHRpdHJhbiAoZS5nLiB0dXJraXNoKVxuICAjIHNvIHdlIGNob29zZSBhbm90aGVyIHNlcnZpY2VcbiAgZ2V0RGljdGlvbmFyeTogKGxhbmcpIC0+XG4gICAgY29uc29sZS5sb2coJ2Nob29zZSBkaWN0OiBmb3InLGxhbmcpO1xuICAgIGRpY3QgPSBESUNUX0NPREVbbGFuZ10gfHwgJ211bHRpdHJhbidcbiAgICBjb25zb2xlLmxvZygnZGljdCcsZGljdClcbiAgICByZXR1cm4gZGljdFxuXG4gICNTZXQgY3VycmVudCBsYW5ndWFnZSBsYWJlbFxuICBzZXRUaXRsZTogKGxhbmd1YWdlKSAtPlxuICAgIGh0bWwgPSBMQU5HX0NPREVbbGFuZ3VhZ2VdICsgJyA8c3BhbiBjbGFzcz1cImNhcmV0XCI+PC9zcGFuPidcbiAgICBAYnV0dG9uLmlubmVySFRNTCA9IGh0bWxcblxuXG5tb2R1bGUuZXhwb3J0cyA9IERyb3Bkb3duIiwiIyMjXG4gIEV4dGVuc2lvbiBwb3B1cCB3aW5kb3dcbiAgU2hvd3Mgc2VhcmNoIGZvcm0gYW5kIGRyb3Bkb3duIG1lbnUgd2l0aCBsYW5ndWFnZXNcbiMjI1xuU2VhcmNoRm9ybSA9IHJlcXVpcmUoJy4vc2VhcmNoX2Zvcm0uY29mZmVlJylcblxuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lciBcIkRPTUNvbnRlbnRMb2FkZWRcIiwgLT5cbiAgZm9ybSA9IG5ldyBTZWFyY2hGb3JtIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0cmFuLWZvcm0nKVxuICBsaW5rID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2hlYWRlci1saW5rJylcbiAgaWYgbGlua1xuICAgIGxpbmsuYWRkRXZlbnRMaXN0ZW5lciAnY2xpY2snLCAoZSkgLT5cbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGhyZWYgPSBlLnRhcmdldC5nZXRBdHRyaWJ1dGUoJ2hyZWYnKSArIGZvcm0uZ2V0VmFsdWUoKVxuICAgICAgY2hyb21lLnRhYnMuY3JlYXRlKHsgdXJsOiBocmVmIH0pXG4iLCIjIyNcbiAgU2VydmVzIHNlYXJjaCBpbnB1dCBhbmQgZm9ybVxuXG4gIEBwYXJhbSBmb3JtIERPTSBlbGVtbnRcbiAgQGNvbnN0cnVjdG9yXG4jIyNcbkRyb3Bkb3duID0gcmVxdWlyZSgnLi9kcm9wZG93bi5jb2ZmZWUnKVxuXG4jdHJhbnNsYXRlIGVuZ2luZXNcbnRyYW4gPSByZXF1aXJlKCcuLi90cmFuLmNvZmZlZScpXG50dXJraXNoZGljdGlvbmFyeSA9IHJlcXVpcmUoJy4uL3R1cmtpc2hkaWN0aW9uYXJ5LmpzJylcblxuXG4jVHJhbnNsYXRlIGVuZ2luZXNcblRSQU5TTEFURV9FTkdJTkVTID1cbiAgJ211bHRpdHJhbic6IHRyYW5cbiAgJ3R1cmtpc2gnOiB0dXJraXNoZGljdGlvbmFyeVxuXG5jbGFzcyBTZWFyY2hGb3JtXG4gIGNvbnN0cnVjdG9yOiAoQGZvcm0pIC0+XG4gICAgQGlucHV0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RyYW5zbGF0ZS10eHQnKVxuICAgIEBpbnB1dC5mb2N1cygpXG5cbiAgICBAcmVzdWx0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jlc3VsdCcpXG4gICAgQGFkZExpc3RlbmVycygpO1xuICAgIEBkcm9wZG93biA9IG5ldyBEcm9wZG93bih7XG4gICAgICBlbDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmRyb3Bkb3duLWVsJyksXG4gICAgICBvblNlbGVjdDogPT4gQHNlYXJjaCgpXG4gICAgfSk7XG5cbiAgYWRkTGlzdGVuZXJzOiAtPlxuICAgIGlmIEBmb3JtIGFuZCBAcmVzdWx0XG4gICAgICBAZm9ybS5hZGRFdmVudExpc3RlbmVyICdzdWJtaXQnLCAoZSkgPT4gQHNlYXJjaChlKVxuICAgICAgQHJlc3VsdC5hZGRFdmVudExpc3RlbmVyICdjbGljaycsIChlKSA9PiBAcmVzdWx0Q2xpY2tIYW5kbGVyKGUpXG5cbiAgc2VhcmNoOiAoZSkgLT5cbiAgICBlICYmIGUucHJldmVudERlZmF1bHQgJiYgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgaWYgQGlucHV0LnZhbHVlLmxlbmd0aCA+IDBcbiAgICAgICNjaG9vc2UgZW5naW5lIGFuZCBzZWFyY2ggZm9yIHRyYW5zbGF0aW9uIChieSBkZWZhdWx0IGVuZ2xpc2gtbXVsdGl0cmFuKVxuICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoe2xhbmd1YWdlOiAnMScsIGRpY3Rpb25hcnk6ICdtdWx0aXRyYW4nfSwgKGl0ZW1zKSA9PlxuICAgICAgICBjb25zb2xlLmxvZygnSVRFTVM6JywgaXRlbXMpO1xuICAgICAgICBUUkFOU0xBVEVfRU5HSU5FU1tpdGVtcy5kaWN0aW9uYXJ5XS5zZWFyY2hcbiAgICAgICAgICB2YWx1ZTogQGlucHV0LnZhbHVlXG4gICAgICAgICAgc3VjY2VzczogQHN1Y2Nlc3NIYW5kbGVyLmJpbmQoQClcbiAgICAgIClcblxuICBzdWNjZXNzSGFuZGxlcjogKHJlc3BvbnNlKSAtPlxuICAgICAgQGNsZWFuKEByZXN1bHQpXG4gICAgICBAcmVzdWx0LmFwcGVuZENoaWxkKHJlc3BvbnNlKVxuXG4gIGNsZWFuOiAoZWwpIC0+XG4gICAgd2hpbGUgKGVsLmxhc3RDaGlsZClcbiAgICAgIGVsLnJlbW92ZUNoaWxkKGVsLmxhc3RDaGlsZClcblxuICByZXN1bHRDbGlja0hhbmRsZXI6IChlKSAtPlxuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBsaW5rVGFncyA9IFsnQScsICdhJ11cbiAgICBpZiBlLnRhcmdldC50YWdOYW1lIGluIGxpbmtUYWdzXG4gICAgICBAaW5wdXQudmFsdWUgPSBlLnRhcmdldC5pbm5lclRleHQ7XG4gICAgICBAc2VhcmNoKGUpXG5cbiAgZ2V0VmFsdWU6IC0+XG4gICAgcmV0dXJuIEBpbnB1dC52YWx1ZVxuXG5cbm1vZHVsZS5leHBvcnRzID0gU2VhcmNoRm9ybVxuIiwiIyMjZ2xvYmFsIGNocm9tZSMjI1xuIyMjXG4gIE11bHRpdHJhbi5ydSB0cmFuc2xhdGUgZW5naW5lXG4gIFByb3ZpZGVzIHByb2dyYW0gaW50ZXJmYWNlIGZvciBtYWtpbmcgdHJhbnNsYXRlIHF1ZXJpZXMgdG8gbXVsdGl0cmFuIGFuZCBnZXQgY2xlYW4gcmVzcG9uc2VcblxuICBBbGwgZW5naW5lcyBtdXN0IGZvbGxvdyBjb21tb24gaW50ZXJmYWNlIGFuZCBwcm92aWRlIG1ldGhvZHM6XG4gICAgLSBzZWFyY2ggKGxhbmd1YW5nZSwgc3VjY2Vzc0hhbmRsZXIpICBjbGVhbiB0cmFuc2xhdGlvbiBtdXN0IGJlIHBhc3NlZCBpbnRvIHN1Y2Nlc3NIYW5kbGVyXG4gICAgLSBjbGlja1xuXG4gIFRyYW5zbGF0aW9uLW1vZHVsZSB0aGF0IG1ha2VzIHJlcXVlc3RzIHRvIGxhbmd1YWdlLWVuZ2luZSxcbiAgcGFyc2VzIHJlc3VsdHMgYW5kIHNlbmRzIHBsdWdpbi1nbG9iYWwgbWVzc2FnZSB3aXRoIHRyYW5zbGF0aW9uIGRhdGFcbiMjI1xuXG5DSEFSX0NPREVTID0gcmVxdWlyZSgnLi9jaGFyLWNvZGVzLmpzJyk7XG5cbmNsYXNzIFRyYW5cbiAgY29uc3RydWN0b3I6IC0+XG4gICAgQFRBQkxFX0NMQVNTID0gXCJfX19tdHRfdHJhbnNsYXRlX3RhYmxlXCJcbiAgICBAcHJvdG9jb2wgPSAnaHR0cCdcbiAgICBAaG9zdCA9ICd3d3cubXVsdGl0cmFuLnJ1J1xuICAgIEBwYXRoID0gJy9jL20uZXhlJ1xuICAgIEBxdWVyeSA9ICcmcz0nXG4gICAgQGxhbmcgPSAnP2wxPTImbDI9MScgI2Zyb20gcnVzc2lhbiB0byBlbmdsaXNoIGJ5IGRlZmF1bHRcbiAgICBAeGhyID0ge31cblxuICAjIyNcbiAgICBDb250ZXh0IG1lbnUgY2xpY2sgaGFuZGxlclxuICAjIyNcbiAgY2xpY2s6IChkYXRhKSAtPlxuICAgIGlmIHR5cGVvZiBkYXRhLnNpbGVudCA9PSB1bmRlZmluZWQgfHwgZGF0YS5zaWxlbnQgPT0gbnVsbFxuICAgICAgZGF0YS5zaWxlbnQgPSB0cnVlICMgdHJ1ZSBieSBkZWZhdWx0XG4gICAgc2VsZWN0aW9uVGV4dCA9IEByZW1vdmVIeXBoZW5hdGlvbiBkYXRhLnNlbGVjdGlvblRleHRcbiAgICBAc2VhcmNoXG4gICAgICAgIHZhbHVlOiBzZWxlY3Rpb25UZXh0XG4gICAgICAgIHN1Y2Nlc3M6IEBzdWNjZXNzdEhhbmRsZXIuYmluZCh0aGlzKVxuICAgICAgICBzaWxlbnQ6IGRhdGEuc2lsZW50ICAjIGlmIHRyYW5zbGF0aW9uIGZhaWxlZCBkbyBub3Qgc2hvdyBkaWFsb2dcblxuICAjIyNcbiAgICBEaXNjYXJkIHNvZnQgaHlwaGVuIGNoYXJhY3RlciAoVSswMEFELCAmc2h5OykgZnJvbSB0aGUgaW5wdXRcbiAgIyMjXG4gIHJlbW92ZUh5cGhlbmF0aW9uOiAodGV4dCkgLT5cbiAgICB0ZXh0LnJlcGxhY2UgL1xceGFkL2csICcnXG5cbiAgIyMjXG4gICAgSW5pdGlhdGUgdHJhbnNsYXRpb24gc2VhcmNoXG4gICMjI1xuICBzZWFyY2g6IChwYXJhbXMpIC0+XG4gICAgI3ZhbHVlLCBjYWxsYmFjaywgZXJyXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoe2xhbmd1YWdlOiAnMSd9LCAoaXRlbXMpID0+XG4gICAgICBpZiBsYW5ndWFnZSBpcyAnJ1xuICAgICAgICBsYW5ndWFnZSA9ICcxJ1xuICAgICAgQHNldExhbmd1YWdlKGl0ZW1zLmxhbmd1YWdlKVxuICAgICAgdXJsID0gQG1ha2VVcmwocGFyYW1zLnZhbHVlKTtcbiAgICAgICMgZGVjb3JhdGUgc3VjY2VzcyB0byBtYWtlIHByZWxpbWluYXJ5IHBhcnNpbmdcbiAgICAgIG9yaWdTdWNjZXNzID0gcGFyYW1zLnN1Y2Nlc3NcbiAgICAgIHBhcmFtcy5zdWNjZXNzID0gKHJlc3BvbnNlKSA9PlxuICAgICAgICB0cmFuc2xhdGVkID0gQHBhcnNlKHJlc3BvbnNlLCBwYXJhbXMuc2lsZW50KVxuICAgICAgICBvcmlnU3VjY2Vzcyh0cmFuc2xhdGVkKVxuXG4gICAgICAjIG1ha2UgcmVxdWVzdCAoR0VUIHJlcXVlc3Qgd2l0aCBxdWVyeSBwYXJhbWV0ZXJzIGluIHVybClcbiAgICAgIEByZXF1ZXN0KFxuICAgICAgICB1cmw6IHVybCxcbiAgICAgICAgc3VjY2VzczogcGFyYW1zLnN1Y2Nlc3MsXG4gICAgICAgIGVycm9yOiBwYXJhbXMuZXJyb3JcbiAgICAgIClcbiAgICApXG5cbiAgc2V0TGFuZ3VhZ2U6IChsYW5ndWFnZSkgLT5cbiAgICBAY3VycmVudExhbmd1YWdlID0gbGFuZ3VhZ2VcbiAgICBAbGFuZyA9ICc/bDE9MiZsMj0nICsgbGFuZ3VhZ2VcblxuICAjIyNcbiAgICBSZXF1ZXN0IHRyYW5zbGF0aW9uIGFuZCBydW4gY2FsbGJhY2sgZnVuY3Rpb25cbiAgICBwYXNzaW5nIHRyYW5zbGF0ZWQgcmVzdWx0IG9yIGVycm9yIHRvIGNhbGxiYWNrXG4gICMjI1xuICByZXF1ZXN0OiAob3B0cykgLT5cbiAgICB4aHIgPSBAeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KClcbiAgICB4aHIub25yZWFkeXN0YXRlY2hhbmdlID0gKGUpID0+XG4gICAgICB4aHIgPSBAeGhyXG4gICAgICBpZiB4aHIucmVhZHlTdGF0ZSA8IDRcbiAgICAgICAgcmV0dXJuXG4gICAgICBlbHNlIGlmIHhoci5zdGF0dXMgIT0gMjAwXG4gICAgICAgIEBlcnJvckhhbmRsZXIoeGhyKVxuICAgICAgICBpZiAodHlwZW9mIG9wdHMuZXJyb3IgPT0gJ2Z1bmN0aW9uJylcbiAgICAgICAgICBvcHRzLmVycm9yKClcbiAgICAgICAgcmV0dXJuXG4gICAgICBlbHNlIGlmIHhoci5yZWFkeVN0YXRlID09IDRcbiAgICAgICAgICByZXR1cm4gb3B0cy5zdWNjZXNzKGUudGFyZ2V0LnJlc3BvbnNlKVxuXG4gICAgeGhyLm9wZW4oXCJHRVRcIiwgb3B0cy51cmwsIHRydWUpO1xuICAgIHhoci5zZW5kKCk7XG5cblxuICBtYWtlVXJsOiAodmFsdWUpIC0+XG4gICAgdXJsID0gW0Bwcm90b2NvbCwgJzovLycsXG4gICAgICAgICAgICAgIEBob3N0LFxuICAgICAgICAgICAgICBAcGF0aCxcbiAgICAgICAgICAgICAgQGxhbmcsXG4gICAgICAgICAgICAgIEBxdWVyeSxcbiAgICAgICAgICAgICAgQGdldEVuY29kZWRWYWx1ZSh2YWx1ZSlcbiAgICAgICAgICBdLmpvaW4oJycpXG5cbiAgICByZXR1cm4gdXJsO1xuXG4gICMgUmVwbGFjZSBzcGVjaWFsIGxhbmd1YWdlIGNoYXJhY3RlcnMgdG8gaHRtbCBjb2Rlc1xuICBnZXRFbmNvZGVkVmFsdWU6ICh2YWx1ZSkgLT5cbiAgICAjIHRvIGZpbmQgc3BlYyBzeW1ib2xzIHdlIGZpcnN0IGVuY29kZSB0aGVtIChyYXcgc2VhcmNoIGZvciB0aGF0IHN5bWJvbCBkb2Vzbid0IHdvcilcbiAgICB2YWwgPSBlbmNvZGVVUklDb21wb25lbnQodmFsdWUpXG4gICAgZm9yIGNoYXIsIGNvZGUgb2YgQ0hBUl9DT0RFU1xuICAgICAgaWYgdHlwZW9mIGNvZGUgPT0gJ29iamVjdCdcbiAgICAgICAgIyBydXNzaWFuIGhhcyBzcGVjaWFsIGNvZGVzXG4gICAgICAgIGNjID0gY29kZS52YWxcbiAgICAgIGVsc2VcbiAgICAgICAgIyBmb3IgYWxsIGxhbmdzIGV4Y2VwdCBydXNzaWFuIGVuY29kZSBodG1sLWNvZGVzIG5lZWRlZFxuICAgICAgICAjINC00LvRjyDQstGB0LXRhSDQvtGB0YLQsNC70YzQvdGL0YUg0Y/Qt9GL0LrQvtCyXG4gICAgICAgIGNjID0gZW5jb2RlVVJJQ29tcG9uZW50KGNvZGUpXG4gICAgICB2YWwgPSB2YWwucmVwbGFjZShjaGFyLCBjYylcbiAgICByZXR1cm4gdmFsXG5cbiAgZXJyb3JIYW5kbGVyOiAoeGhyKSAtPlxuICAgIGNvbnNvbGUubG9nKCdlcnJvcicsIHhocilcblxuICAjIyNcbiAgIFJlY2VpdmluZyBkYXRhIGZyb20gdHJhbnNsYXRpb24tZW5naW5lIGFuZCBzZW5kIHJlYWR5IG1lc3NhZ2Ugd2l0aCBkYXRhXG4gICMjI1xuICBzdWNjZXNzdEhhbmRsZXI6ICh0cmFuc2xhdGVkKSAtPlxuICAgIGlmIHRyYW5zbGF0ZWRcbiAgICAgIGNocm9tZS50YWJzLmdldFNlbGVjdGVkKG51bGwsICh0YWIpID0+XG4gICAgICAgIGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhYi5pZCwge1xuICAgICAgICAgIGFjdGlvbjogQG1lc3NhZ2VUeXBlIHRyYW5zbGF0ZWRcbiAgICAgICAgICBkYXRhOiB0cmFuc2xhdGVkLm91dGVySFRNTCxcbiAgICAgICAgICBzdWNjZXNzOiAhdHJhbnNsYXRlZC5jbGFzc0xpc3QuY29udGFpbnMoJ2ZhaWxUcmFuc2xhdGUnKVxuICAgICAgICB9KVxuICAgICAgKVxuXG4gIG1lc3NhZ2VUeXBlOiAodHJhbnNsYXRlZCkgLT5cbiAgICBpZiB0cmFuc2xhdGVkPy5yb3dzPy5sZW5ndGggPT0gMVxuICAgICAgJ3NpbWlsYXJfd29yZHMnXG4gICAgZWxzZVxuICAgICAgJ29wZW5fdG9vbHRpcCdcblxuICAjIyNcbiAgICBQYXJzZSByZXNwb25zZSBmcm9tIHRyYW5zbGF0aW9uIGVuZ2luZVxuICAjIyNcbiAgcGFyc2U6IChyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUgPSBudWxsKSAtPlxuICAgICAgZG9jID0gQHN0cmlwU2NyaXB0cyhyZXNwb25zZSlcbiAgICAgIGZyYWdtZW50ID0gQG1ha2VGcmFnbWVudChkb2MpXG4gICAgICBpZiBmcmFnbWVudFxuICAgICAgICB0cmFuc2xhdGUgPSBmcmFnbWVudC5xdWVyeVNlbGVjdG9yKCcjdHJhbnNsYXRpb24gfiB0YWJsZScpXG4gICAgICAgIGlmIHRyYW5zbGF0ZVxuICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSBAVEFCTEVfQ0xBU1M7XG4gICAgICAgICAgdHJhbnNsYXRlLnNldEF0dHJpYnV0ZShcImNlbGxwYWRkaW5nXCIsIFwiNVwiKVxuICAgICAgICAgIEBmaXhJbWFnZXModHJhbnNsYXRlKVxuICAgICAgICAgIEBmaXhMaW5rcyh0cmFuc2xhdGUpXG4gICAgICAgIGVsc2UgaWYgbm90IHNpbGVudFxuICAgICAgICAgIHRyYW5zbGF0ZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9ICdmYWlsVHJhbnNsYXRlJ1xuICAgICAgICAgIHRyYW5zbGF0ZS5pbm5lclRleHQgPSBcIlVuZm9ydHVuYXRlbHksIGNvdWxkIG5vdCB0cmFuc2xhdGVcIlxuXG4gICAgICByZXR1cm4gdHJhbnNsYXRlO1xuXG4gICMjI1xuICAgIFN0cmlwIHNjcmlwdCB0YWdzIGZyb20gcmVzcG9uc2UgaHRtbFxuICAjIyNcbiAgc3RyaXBTY3JpcHRzOiAocykgLT5cbiAgICBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICAgIGRpdi5pbm5lckhUTUwgPSBzXG4gICAgc2NyaXB0cyA9IGRpdi5nZXRFbGVtZW50c0J5VGFnTmFtZSgnc2NyaXB0JylcbiAgICBpID0gc2NyaXB0cy5sZW5ndGhcbiAgICB3aGlsZSBpLS1cbiAgICAgIHNjcmlwdHNbaV0ucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChzY3JpcHRzW2ldKVxuICAgIHJldHVybiBkaXYuaW5uZXJIVE1MO1xuXG4gIG1ha2VGcmFnbWVudDogKGRvYywgZnJhZ21lbnQgPSBudWxsKSAtPlxuICAgIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIilcbiAgICBkaXYuaW5uZXJIVE1MID0gZG9jXG4gICAgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KClcbiAgICB3aGlsZSAoIGRpdi5maXJzdENoaWxkIClcbiAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKCBkaXYuZmlyc3RDaGlsZCApXG4gICAgcmV0dXJuIGZyYWdtZW50XG5cbiAgZml4SW1hZ2VzOiAoZnJhZ21lbnQ9bnVsbCkgLT5cbiAgICB0aGlzLmZpeFVybChmcmFnbWVudCwgJ2ltZycsICdzcmMnKTtcbiAgICByZXR1cm4gZnJhZ21lbnQ7XG5cbiAgZml4TGlua3M6IChmcmFnbWVudD1udWxsKSAtPlxuICAgIHRoaXMuZml4VXJsKGZyYWdtZW50LCAnYScsICdocmVmJylcbiAgICByZXR1cm4gZnJhZ21lbnRcblxuICBmaXhVcmw6IChmcmFnbWVudD1udWxsLCB0YWcsIGF0dHIpIC0+XG4gICAgaWYgZnJhZ21lbnRcbiAgICAgIHRhZ3MgPSAgZnJhZ21lbnQucXVlcnlTZWxlY3RvckFsbCh0YWcpXG4gICAgICBwYXJzZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJylcbiAgICAgIGZvciB0YWcgaW4gdGFnc1xuICAgICAgICBwYXJzZXIuaHJlZiA9IHRhZ1thdHRyXVxuICAgICAgICBwYXJzZXIuaG9zdCA9IEBob3N0XG4gICAgICAgIHBhcnNlci5wcm90b2NvbCA9IEBwcm90b2NvbFxuICAgICAgICAjZml4IHJlbGF0aXZlIGxpbmtzXG4gICAgICAgIGlmIHRhZy50YWdOYW1lID09ICdBJ1xuICAgICAgICAgIHRhZy5jbGFzc0xpc3QuYWRkICdtdHRfbGluaydcbiAgICAgICAgICBpZiBwYXJzZXIucGF0aG5hbWUuaW5kZXhPZignbS5leGUnKSBpc250IC0xXG4gICAgICAgICAgICBwYXJzZXIucGF0aG5hbWUgPSAnL2MnICsgcGFyc2VyLnBhdGhuYW1lXG4gICAgICAgICAgICB0YWcuc2V0QXR0cmlidXRlKCd0YXJnZXQnLCAnX2JsYW5rJylcbiAgICAgICAgZWxzZSBpZiB0YWcudGFnTmFtZSA9PSAnSU1HJ1xuICAgICAgICAgIHRhZy5jbGFzc0xpc3QuYWRkICdtdHRfaW1nJ1xuXG4gICAgICAgIHRhZy5zZXRBdHRyaWJ1dGUoYXR0ciwgcGFyc2VyLmhyZWYpXG5cblxuXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBUcmFuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbnZhciBfcHJvdG90eXBlUHJvcGVydGllcyA9IGZ1bmN0aW9uIChjaGlsZCwgc3RhdGljUHJvcHMsIGluc3RhbmNlUHJvcHMpIHtcbiAgaWYgKHN0YXRpY1Byb3BzKSBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhjaGlsZCwgc3RhdGljUHJvcHMpO1xuICBpZiAoaW5zdGFuY2VQcm9wcykgT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoY2hpbGQucHJvdG90eXBlLCBpbnN0YW5jZVByb3BzKTtcbn07XG5cbi8qXG4gIFRyYW5zbGF0aW9uIGVuZ2luZTogaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXRcbiAgRm9yIHRyYW5zbGF0aW5nIHR1cmtpc2gtcnVzc2lhbiBhbmQgdmljZSB2ZXJzYVxuKi9cbnZhciBDSEFSX0NPREVTID0gcmVxdWlyZShcIi4vY2hhci1jb2Rlcy10dXJrLmpzXCIpO1xuXG52YXIgVHVya2lzaERpY3Rpb25hcnkgPSAoZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBUdXJraXNoRGljdGlvbmFyeSgpIHtcbiAgICB0aGlzLmhvc3QgPSBcImh0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0Lz93b3JkPSVGQ1wiO1xuICAgIHRoaXMucGF0aCA9IFwiXCI7XG4gICAgdGhpcy5wcm90b2NvbCA9IFwiaHR0cFwiO1xuICAgIHRoaXMucXVlcnkgPSBcIiZzPVwiO1xuICAgIHRoaXMuVEFCTEVfQ0xBU1MgPSBcIl9fX210dF90cmFuc2xhdGVfdGFibGVcIjtcbiAgICAvLyB0aGlzIGZsYWcgaW5kaWNhdGVzIHRoYXQgaWYgdHJhbnNsYXRpb24gd2FzIHN1Y2Nlc3NmdWwgdGhlbiBwdWJsaXNoIGl0IGFsbCBvdmVyIGV4dGVuc2lvblxuICAgIHRoaXMubmVlZF9wdWJsaXNoID0gdHJ1ZTtcbiAgfVxuXG4gIF9wcm90b3R5cGVQcm9wZXJ0aWVzKFR1cmtpc2hEaWN0aW9uYXJ5LCBudWxsLCB7XG4gICAgc2VhcmNoOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gc2VhcmNoKGRhdGEpIHtcbiAgICAgICAgZGF0YS51cmwgPSB0aGlzLm1ha2VVcmwoZGF0YS52YWx1ZSk7XG4gICAgICAgIHRoaXMubmVlZF9wdWJsaXNoID0gZmFsc2U7XG4gICAgICAgIHJldHVybiB0aGlzLnJlcXVlc3QoZGF0YSk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICB0cmFuc2xhdGU6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiB0cmFuc2xhdGUoZGF0YSkge1xuICAgICAgICBkYXRhLnVybCA9IHRoaXMubWFrZVVybChkYXRhLnNlbGVjdGlvblRleHQpO1xuICAgICAgICB0aGlzLm5lZWRfcHVibGlzaCA9IHRydWU7XG4gICAgICAgIHRoaXMucmVxdWVzdChkYXRhKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIG1ha2VVcmw6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlVXJsKHRleHQpIHtcbiAgICAgICAgdmFyIHRleHQgPSB0aGlzLmdldEVuY29kZWRWYWx1ZSh0ZXh0KTtcbiAgICAgICAgcmV0dXJuIFtcImh0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0Lz93b3JkPVwiLCB0ZXh0XS5qb2luKFwiXCIpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgZ2V0RW5jb2RlZFZhbHVlOiB7XG5cblxuICAgICAgLy8gUmVwbGFjZSBzcGVjaWFsIGxhbmd1YWdlIGNoYXJhY3RlcnMgdG8gaHRtbCBjb2Rlc1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIGdldEVuY29kZWRWYWx1ZSh2YWx1ZSkge1xuICAgICAgICAvLyB0byBmaW5kIHNwZWMgc3ltYm9scyB3ZSBmaXJzdCBlbmNvZGUgdGhlbSAocmF3IHNlYXJjaCBmb3IgdGhhdCBzeW1ib2wgZG9lc24ndCB3b3IpXG4gICAgICAgIHJldHVybiB0aGlzLm1ha2VTdHJpbmdUcmFuc2ZlcmFibGUodmFsdWUpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgbWFrZVN0cmluZ1RyYW5zZmVyYWJsZToge1xuXG4gICAgICAvKiogY29udmVydGluZyBzY3JpcHQgZnJvbSB0aGUgdHVya2lzaGRpY3QgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlU3RyaW5nVHJhbnNmZXJhYmxlKGlucHV0VGV4dCkge1xuICAgICAgICB2YXIgdGV4dCA9IFwiXCI7XG4gICAgICAgIGlmIChpbnB1dFRleHQubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHRleHQgPSBpbnB1dFRleHQ7XG4gICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0ZXh0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoQ0hBUl9DT0RFU1t0ZXh0LmNoYXJDb2RlQXQoaSldKSB7XG4gICAgICAgICAgICAgIHRleHQgPSB0ZXh0LnN1YnN0cmluZygwLCBpKSArIENIQVJfQ09ERVNbdGV4dC5jaGFyQ29kZUF0KGkpXSArIHRleHQuc3Vic3RyaW5nKGkgKyAxLCB0ZXh0Lmxlbmd0aCk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHRleHQuY2hhckF0KGkpID09IFwiIFwiKSB7XG4gICAgICAgICAgICAgIC8vIHJlcGxhY2Ugc3BhY2VzXG4gICAgICAgICAgICAgIHRleHQgPSB0ZXh0LnN1YnN0cmluZygwLCBpKSArIFwiX19fXCIgKyB0ZXh0LnN1YnN0cmluZyhpICsgMSwgdGV4dC5sZW5ndGgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGV4dDtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHJlcXVlc3Q6IHtcblxuICAgICAgLypcbiAgICAgICAgUmVxdWVzdCB0cmFuc2xhdGlvbiBhbmQgcnVuIGNhbGxiYWNrIGZ1bmN0aW9uXG4gICAgICAgIHBhc3NpbmcgdHJhbnNsYXRlZCByZXN1bHQgb3IgZXJyb3IgdG8gY2FsbGJhY2tcbiAgICAgICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gcmVxdWVzdChvcHRzKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwic3RhcnQgcmVxdWVzdFwiKTtcbiAgICAgICAgdGhpcy54aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgICAgdGhpcy54aHIub25yZWFkeXN0YXRlY2hhbmdlID0gdGhpcy5vblJlYWR5U3RhdGVDaGFuZ2UuYmluZCh0aGlzLCBvcHRzKTtcbiAgICAgICAgdGhpcy54aHIub3BlbihcIkdFVFwiLCBvcHRzLnVybCwgdHJ1ZSk7XG4gICAgICAgIHRoaXMueGhyLnNlbmQoKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIG9uUmVhZHlTdGF0ZUNoYW5nZToge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIG9uUmVhZHlTdGF0ZUNoYW5nZShvcHRzLCBlKSB7XG4gICAgICAgIHZhciB4aHIgPSB0aGlzLnhocjtcbiAgICAgICAgaWYgKHhoci5yZWFkeVN0YXRlIDwgNCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSBlbHNlIGlmICh4aHIuc3RhdHVzICE9IDIwMCkge1xuICAgICAgICAgIHRoaXMuZXJyb3JIYW5kbGVyKHhocik7XG4gICAgICAgICAgcmV0dXJuIG9wdHMuZXJyb3IgJiYgb3B0cy5lcnJvcigpO1xuICAgICAgICB9IGVsc2UgaWYgKHhoci5yZWFkeVN0YXRlID09IDQpIHtcbiAgICAgICAgICB2YXIgdHJhbnNsYXRpb24gPSB0aGlzLnN1Y2Nlc3NIYW5kbGVyKGUudGFyZ2V0LnJlc3BvbnNlKTtcbiAgICAgICAgICBjb25zb2xlLmxvZyhcInN1Y2Nlc3MgdHVya2lzaCB0cmFuc2xhdGVcIiwgdHJhbnNsYXRpb24pO1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwiY2FsbFwiLCBvcHRzLnN1Y2Nlc3MpO1xuICAgICAgICAgIHJldHVybiBvcHRzLnN1Y2Nlc3MgJiYgb3B0cy5zdWNjZXNzKHRyYW5zbGF0aW9uKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgc3VjY2Vzc0hhbmRsZXI6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBzdWNjZXNzSGFuZGxlcihyZXNwb25zZSkge1xuICAgICAgICB2YXIgZGF0YSA9IHRoaXMucGFyc2UocmVzcG9uc2UpO1xuICAgICAgICBpZiAodGhpcy5uZWVkX3B1Ymxpc2gpIHtcbiAgICAgICAgICBjaHJvbWUudGFicy5nZXRTZWxlY3RlZChudWxsLCB0aGlzLnB1Ymxpc2hUcmFuc2xhdGlvbi5iaW5kKHRoaXMsIGRhdGEpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZGF0YTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHB1Ymxpc2hUcmFuc2xhdGlvbjoge1xuXG4gICAgICAvKiBwdWJsaXNoIHN1Y2Nlc3NmdWx5IHRyYW5zbGF0ZWQgdGV4dCBhbGwgb3ZlciBleHRlbnNpb24gKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBwdWJsaXNoVHJhbnNsYXRpb24odHJhbnNsYXRpb24sIHRhYikge1xuICAgICAgICBjb25zb2xlLmxvZyhcInB1Ymxpc2ggdHJhbnNsYXRpb25cIik7XG4gICAgICAgIGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhYi5pZCwge1xuICAgICAgICAgIGFjdGlvbjogdGhpcy50b29sdGlwQWN0aW9uKHRyYW5zbGF0aW9uKSxcbiAgICAgICAgICBkYXRhOiB0cmFuc2xhdGlvbi5vdXRlckhUTUwsXG4gICAgICAgICAgc3VjY2VzczogIXRyYW5zbGF0aW9uLmNsYXNzTGlzdC5jb250YWlucyhcImZhaWxUcmFuc2xhdGVcIilcbiAgICAgICAgfSk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICB0b29sdGlwQWN0aW9uOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gdG9vbHRpcEFjdGlvbih0cmFuc2xhdGlvbikge1xuICAgICAgICBpZiAodHJhbnNsYXRpb24udGV4dENvbnRlbnQudHJpbSgpLmluZGV4T2YoXCJ3YXMgbm90IGZvdW5kIGluIG91ciBkaWN0aW9uYXJ5XCIpICE9IC0xKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJzaW1pbGFyIHdvcmRzXCIpO1xuICAgICAgICAgIHJldHVybiBcInNpbWlsYXJfd29yZHNcIjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIm9wZW4gdG9vbHRpcFwiKTtcbiAgICAgICAgICByZXR1cm4gXCJvcGVuX3Rvb2x0aXBcIjtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgZXJyb3JIYW5kbGVyOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gZXJyb3JIYW5kbGVyKHJlc3BvbnNlKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiZXJyb3IgYWpheFwiLCByZXNwb25zZSk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBwYXJzZToge1xuXG4gICAgICAvKiBQYXJzZSByZXNwb25zZSBmcm9tIHRyYW5zbGF0aW9uIGVuZ2luZSAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHBhcnNlKHJlc3BvbnNlLCBzaWxlbnQsIHRyYW5zbGF0ZSkge1xuICAgICAgICB2YXIgZG9jID0gdGhpcy5zdHJpcFNjcmlwdHMocmVzcG9uc2UpLFxuICAgICAgICAgICAgZnJhZ21lbnQgPSB0aGlzLm1ha2VGcmFnbWVudChkb2MpO1xuICAgICAgICBpZiAoZnJhZ21lbnQpIHtcbiAgICAgICAgICB0cmFuc2xhdGUgPSBmcmFnbWVudC5xdWVyeVNlbGVjdG9yKFwiI21lYW5pbmdfZGl2ID4gdGFibGVcIik7XG4gICAgICAgICAgaWYgKHRyYW5zbGF0ZSkge1xuICAgICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9IHRoaXMuVEFCTEVfQ0xBU1M7XG4gICAgICAgICAgICB0cmFuc2xhdGUuc2V0QXR0cmlidXRlKFwiY2VsbHBhZGRpbmdcIiwgXCI1XCIpO1xuICAgICAgICAgICAgLy8gQGZpeEltYWdlcyh0cmFuc2xhdGUpXG4gICAgICAgICAgICAvLyBAZml4TGlua3ModHJhbnNsYXRlKVxuICAgICAgICAgIH0gZWxzZSBpZiAoIXNpbGVudCkge1xuICAgICAgICAgICAgdHJhbnNsYXRlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSBcImZhaWxUcmFuc2xhdGVcIjtcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5pbm5lclRleHQgPSBcIlVuZm9ydHVuYXRlbHksIGNvdWxkIG5vdCB0cmFuc2xhdGVcIjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRyYW5zbGF0ZTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHBhcnNlVGV4dDoge1xuXG4gICAgICAvKiogcGFyc2luZyBvZiB0ZXJyaWJsZSBodG1sIG1hcmt1cCAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHBhcnNlVGV4dChyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgdmFyIGRvYyA9IHRoaXMuc3RyaXBTY3JpcHRzKHJlc3BvbnNlKSxcbiAgICAgICAgICAgIGZyYWdtZW50ID0gdGhpcy5tYWtlRnJhZ21lbnQoZG9jKTtcblxuICAgICAgICBpZiAoZnJhZ21lbnQpIHtcbiAgICAgICAgICB2YXIgaTtcbiAgICAgICAgICB2YXIgX3JldCA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgc3RvcEluZGV4ID0gbnVsbDtcbiAgICAgICAgICAgIHZhciB0ciA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIjbWVhbmluZ19kaXY+dGFibGU+dGJvZHk+dHJcIik7XG4gICAgICAgICAgICB0ciA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKHRyKTtcblxuICAgICAgICAgICAgdmFyIHRyYW5zID0gdHIuZmlsdGVyKGZ1bmN0aW9uICh0ciwgaW5kZXgpIHtcbiAgICAgICAgICAgICAgaWYgKCFpc05hTihwYXJzZUludChzdG9wSW5kZXgsIDEwKSkgJiYgaW5kZXggPj0gc3RvcEluZGV4KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRyID0gJCh0cik7XG4gICAgICAgICAgICAgICAgLy8gdGFrZSBldmVyeSByb3cgYmVmb3JlIG5leHQgc2VjdGlvbiAod2hpY2ggaXMgRW5nbGlzaC0+RW5nbGlzaClcbiAgICAgICAgICAgICAgICBpZiAodHIuYXR0cihcImJnY29sb3JcIikgPT0gXCJlMGU2ZmZcIikge1xuICAgICAgICAgICAgICAgICAgc3RvcEluZGV4ID0gaW5kZXg7cmV0dXJuO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gJC50cmltKHRyLmZpbmQoXCJ0ZFwiKS50ZXh0KCkpLmxlbmd0aDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdHJhbnMgPSB0cmFucy5zbGljZSgxLCB0cmFucy5sZW5ndGggLSAxKTtcbiAgICAgICAgICAgIHRyYW5zID0gdHJhbnMuZmlsdGVyKGZ1bmN0aW9uIChlbCwgaW5keCkge1xuICAgICAgICAgICAgICByZXR1cm4gaW5keCAlIDI7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHZhciBmcmFnID0gX3RoaXMuZnJhZ21lbnRGcm9tTGlzdCh0cmFucyk7XG4gICAgICAgICAgICB2YXIgZm9udHMgPSBmcmFnLnF1ZXJ5U2VsZWN0b3JBbGwoXCJmb250XCIpO1xuICAgICAgICAgICAgdmFyIHRleHQgPSBcIlwiO1xuICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IGZvbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgIHRleHQgKz0gXCIgXCIgKyBmb250c1tpXS50ZXh0Q29udGVudC50cmltKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICB2OiB0ZXh0XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH0pKCk7XG5cbiAgICAgICAgICBpZiAodHlwZW9mIF9yZXQgPT09IFwib2JqZWN0XCIpIHJldHVybiBfcmV0LnY7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhyb3cgXCJIVE1MIGZyYWdtZW50IGNvdWxkIG5vdCBiZSBwYXJzZWRcIjtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgc3RyaXBTY3JpcHRzOiB7XG5cbiAgICAgIC8vVE9ETyBleHRyYWN0IHRvIGJhc2UgZW5naW5lIGNsYXNzXG4gICAgICAvKiByZW1vdmVzIDxzY3JpcHQ+IHRhZ3MgZnJvbSBodG1sIGNvZGUgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBzdHJpcFNjcmlwdHMoaHRtbCkge1xuICAgICAgICB2YXIgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgZGl2LmlubmVySFRNTCA9IGh0bWw7XG4gICAgICAgIHZhciBzY3JpcHRzID0gZGl2LmdldEVsZW1lbnRzQnlUYWdOYW1lKFwic2NyaXB0XCIpO1xuICAgICAgICB2YXIgaSA9IHNjcmlwdHMubGVuZ3RoO1xuICAgICAgICB3aGlsZSAoaS0tKSBzY3JpcHRzW2ldLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc2NyaXB0c1tpXSk7XG4gICAgICAgIHJldHVybiBkaXYuaW5uZXJIVE1MO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgbWFrZUZyYWdtZW50OiB7XG5cbiAgICAgIC8vVE9ETyBleHRyYWN0IHRvIGJhc2UgZW5naW5lIGNsYXNzXG4gICAgICAvKiBjcmVhdGVzIHRlbXAgb2JqZWN0IHRvIHBhcnNlIHRyYW5zbGF0aW9uIGZyb20gcGFnZSBcbiAgICAgICAgKHNpbmNlIGl0J3Mgbm90IGEgZnJpZW5kbHkgYXBpKSBcbiAgICAgICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZUZyYWdtZW50KGh0bWwpIHtcbiAgICAgICAgdmFyIGZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpLFxuICAgICAgICAgICAgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgZGl2LmlubmVySFRNTCA9IGh0bWw7XG4gICAgICAgIHdoaWxlIChkaXYuZmlyc3RDaGlsZCkge1xuICAgICAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKGRpdi5maXJzdENoaWxkKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBmcmFnbWVudEZyb21MaXN0OiB7XG5cbiAgICAgIC8qKiBjcmVhdGUgZnJhZ21lbnQgZnJvbSBsaXN0IG9mIERPTSBlbGVtZW50cyAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIGZyYWdtZW50RnJvbUxpc3QobGlzdCkge1xuICAgICAgICB2YXIgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCksXG4gICAgICAgICAgICBsZW4gPSBsaXN0Lmxlbmd0aDtcbiAgICAgICAgd2hpbGUgKGxlbi0tKSB7XG4gICAgICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQobGlzdFtsZW5dKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfVxuICB9KTtcblxuICByZXR1cm4gVHVya2lzaERpY3Rpb25hcnk7XG59KSgpO1xuXG4vLyBTaW5nbGV0b25lXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBUdXJraXNoRGljdGlvbmFyeSgpOyJdfQ==
