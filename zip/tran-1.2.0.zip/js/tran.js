(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/var CHAR_CODES = {  //russian  '%D1%8A': {val:'%FA', lang:'ru'}, // ъ  '%D0%AA': {val:'%DA', lang:'ru'},// Ъ  '%C3%80': '&#192;', // À  '%C3%81': '&#193;', // Á  '%C3%82': '&#194;', // Â  '%C3%83': '&#195;', // Ã  '%C3%84': '&#196;', // Ä  '%C3%85': '&#197;', // Å  '%C3%86': '&#198;', // Æ  '%C3%87': '&#199;', // Ç  '%C3%88': '&#200;', // È  '%C3%89': '&#201;', // É  '%C3%8A': '&#202;', // Ê  '%C3%8B': '&#203;', // Ë  '%C3%8C': '&#204;', // Ì  '%C3%8D': '&#205;', // Í  '%C3%8E': '&#206;', // Î  '%C3%8F': '&#207;', // Ï  '%C3%91': '&#209;', // Ñ  '%C3%92': '&#210;', // Ò  '%C3%93': '&#211;', // Ó  '%C3%94': '&#212;', // Ô  '%C3%95': '&#213;', // Õ  '%C3%96': '&#214;', // Ö  '%C3%99': '&#217;', // Ù  '%C3%9A': '&#218;', // Ú  '%C3%9B': '&#219;', // Û  '%C3%9C': '&#220;', // Ü  '%C3%A0': '&#224;', // à  '%C3%A1': '&#225;', // á  '%C3%A2': '&#226;', // â  '%C3%A3': '&#227;', // ã  '%C3%A4': '&#228;', // ä  '%C3%A5': '&#229;', // å  '%C3%A6': '&#230;', // æ  '%C3%A7': '&#231;', // ç  '%C3%A8': '&#232;', // è  '%C3%A9': '&#233;', // é  '%C3%AA': '&#234;', // ê  '%C3%AB': '&#235;', // ë  '%C3%AC': '&#236;', // ì  '%C3%AD': '&#237;', // í  '%C3%AE': '&#238;', // î  '%C3%AF': '&#239;', // ï  '%C3%B0': '&#240;', // ð  '%C3%B1': '&#241;', // ñ  '%C3%B2': '&#242;', // ò  '%C3%B3': '&#243;', // ó  '%C3%B4': '&#244;', // ô  '%C3%B5': '&#245;', // õ  '%C3%B6': '&#246;', // ö  '%C3%B9': '&#249;', // ù  '%C3%BA': '&#250;', // ú  '%C3%BB': '&#251;', // û  '%C3%BC': '&#252;', // ü  '%C3%BF': '&#255;', // ÿ  '%C5%B8': '&#376;', // Ÿ  '%C3%9F': '&#223;', // ß  '%C2%BF': '&#191;', // ¿  '%C2%A1': '&#161;', // ¡};module.exports = CHAR_CODES;
},{}],2:[function(require,module,exports){

/*global chrome */

/*
  Multitran.ru translate engine
  Provides program interface for making translate queries to multitran and get clean response

  All engines must follow common interface and provide methods:
    - search (languange, successHandler)  clean translation must be passed into successHandler
    - click

  Translation-module that makes requests to language-engine,
  parses results and sends plugin-global message with translation data
 */
var CHAR_CODES, Tran;

CHAR_CODES = require('./char-codes.js');

Tran = (function() {
  function Tran() {
    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1';
    this.xhr = {};
  }


  /*
    Context menu click handler
   */

  Tran.prototype.click = function(data) {
    var selectionText;
    if (typeof data.silent === void 0 || data.silent === null) {
      data.silent = true;
    }
    selectionText = this.removeHyphenation(data.selectionText);
    return this.search({
      value: selectionText,
      success: this.successtHandler.bind(this),
      silent: data.silent
    });
  };


  /*
    Discard soft hyphen character (U+00AD, &shy;) from the input
   */

  Tran.prototype.removeHyphenation = function(text) {
    return text.replace(/\xad/g, '');
  };


  /*
    Initiate translation search
   */

  Tran.prototype.search = function(params) {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(items) {
        var language, origSuccess, url;
        if (language === '') {
          language = '1';
        }
        _this.setLanguage(items.language);
        url = _this.makeUrl(params.value);
        origSuccess = params.success;
        params.success = function(response) {
          var translated;
          translated = _this.parse(response, params.silent);
          return origSuccess(translated);
        };
        return _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      };
    })(this));
  };

  Tran.prototype.setLanguage = function(language) {
    this.currentLanguage = language;
    return this.lang = '?l1=2&l2=' + language;
  };


  /*
    Request translation and run callback function
    passing translated result or error to callback
   */

  Tran.prototype.request = function(opts) {
    var xhr;
    xhr = this.xhr = new XMLHttpRequest();
    xhr.onreadystatechange = (function(_this) {
      return function(e) {
        xhr = _this.xhr;
        if (xhr.readyState < 4) {

        } else if (xhr.status !== 200) {
          _this.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error();
          }
        } else if (xhr.readyState === 4) {
          return opts.success(e.target.response);
        }
      };
    })(this);
    xhr.open("GET", opts.url, true);
    return xhr.send();
  };

  Tran.prototype.makeUrl = function(value) {
    var url;
    url = [this.protocol, '://', this.host, this.path, this.lang, this.query, this.getEncodedValue(value)].join('');
    return url;
  };

  Tran.prototype.getEncodedValue = function(value) {
    var cc, char, code, val;
    val = encodeURIComponent(value);
    for (char in CHAR_CODES) {
      code = CHAR_CODES[char];
      if (typeof code === 'object') {
        cc = code.val;
      } else {
        cc = encodeURIComponent(code);
      }
      val = val.replace(char, cc);
    }
    return val;
  };

  Tran.prototype.errorHandler = function(xhr) {
    return console.log('error', xhr);
  };


  /*
   Receiving data from translation-engine and send ready message with data
   */

  Tran.prototype.successtHandler = function(translated) {
    if (translated) {
      return chrome.tabs.getSelected(null, (function(_this) {
        return function(tab) {
          return chrome.tabs.sendMessage(tab.id, {
            action: _this.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        };
      })(this));
    }
  };

  Tran.prototype.messageType = function(translated) {
    var _ref;
    if ((translated != null ? (_ref = translated.rows) != null ? _ref.length : void 0 : void 0) === 1) {
      return 'similar_words';
    } else {
      return 'open_tooltip';
    }
  };


  /*
    Parse response from translation engine
   */

  Tran.prototype.parse = function(response, silent, translate) {
    var doc, fragment;
    if (translate == null) {
      translate = null;
    }
    doc = this.stripScripts(response);
    fragment = this.makeFragment(doc);
    if (fragment) {
      translate = fragment.querySelector('#translation ~ table');
      if (translate) {
        translate.className = this.TABLE_CLASS;
        translate.setAttribute("cellpadding", "5");
        this.fixImages(translate);
        this.fixLinks(translate);
      } else if (!silent) {
        translate = document.createElement('div');
        translate.className = 'failTranslate';
        translate.innerText = "Unfortunately, could not translate";
      }
    }
    return translate;
  };


  /*
    Strip script tags from response html
   */

  Tran.prototype.stripScripts = function(s) {
    var div, i, scripts;
    div = document.createElement('div');
    div.innerHTML = s;
    scripts = div.getElementsByTagName('script');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
    return div.innerHTML;
  };

  Tran.prototype.makeFragment = function(doc, fragment) {
    var div;
    if (fragment == null) {
      fragment = null;
    }
    div = document.createElement("div");
    div.innerHTML = doc;
    fragment = document.createDocumentFragment();
    while (div.firstChild) {
      fragment.appendChild(div.firstChild);
    }
    return fragment;
  };

  Tran.prototype.fixImages = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'img', 'src');
    return fragment;
  };

  Tran.prototype.fixLinks = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'a', 'href');
    return fragment;
  };

  Tran.prototype.fixUrl = function(fragment, tag, attr) {
    var parser, tags, _i, _len, _results;
    if (fragment == null) {
      fragment = null;
    }
    if (fragment) {
      tags = fragment.querySelectorAll(tag);
      parser = document.createElement('a');
      _results = [];
      for (_i = 0, _len = tags.length; _i < _len; _i++) {
        tag = tags[_i];
        parser.href = tag[attr];
        parser.host = this.host;
        parser.protocol = this.protocol;
        if (tag.tagName === 'A') {
          tag.classList.add('mtt_link');
          if (parser.pathname.indexOf('m.exe') !== -1) {
            parser.pathname = '/c' + parser.pathname;
            tag.setAttribute('target', '_blank');
          }
        } else if (tag.tagName === 'IMG') {
          tag.classList.add('mtt_img');
        }
        _results.push(tag.setAttribute(attr, parser.href));
      }
      return _results;
    }
  };

  return Tran;

})();

module.exports = new Tran;


},{"./char-codes.js":1}]},{},[2])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvY2hhci1jb2Rlcy5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvdHJhbi5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTs7QUNBQTtBQUFBLGtCQUFBO0FBQ0E7QUFBQTs7Ozs7Ozs7OztHQURBO0FBQUEsSUFBQSxnQkFBQTs7QUFBQSxVQWFBLEdBQWEsT0FBQSxDQUFRLGlCQUFSLENBYmIsQ0FBQTs7QUFBQTtBQWdCZSxFQUFBLGNBQUEsR0FBQTtBQUNYLElBQUEsSUFBQyxDQUFBLFdBQUQsR0FBZSx3QkFBZixDQUFBO0FBQUEsSUFDQSxJQUFDLENBQUEsUUFBRCxHQUFZLE1BRFosQ0FBQTtBQUFBLElBRUEsSUFBQyxDQUFBLElBQUQsR0FBUSxrQkFGUixDQUFBO0FBQUEsSUFHQSxJQUFDLENBQUEsSUFBRCxHQUFRLFVBSFIsQ0FBQTtBQUFBLElBSUEsSUFBQyxDQUFBLEtBQUQsR0FBUyxLQUpULENBQUE7QUFBQSxJQUtBLElBQUMsQ0FBQSxJQUFELEdBQVEsWUFMUixDQUFBO0FBQUEsSUFNQSxJQUFDLENBQUEsR0FBRCxHQUFPLEVBTlAsQ0FEVztFQUFBLENBQWI7O0FBU0E7QUFBQTs7S0FUQTs7QUFBQSxpQkFZQSxLQUFBLEdBQU8sU0FBQyxJQUFELEdBQUE7QUFDTCxRQUFBLGFBQUE7QUFBQSxJQUFBLElBQUcsTUFBQSxDQUFBLElBQVcsQ0FBQyxNQUFaLEtBQXNCLE1BQXRCLElBQW1DLElBQUksQ0FBQyxNQUFMLEtBQWUsSUFBckQ7QUFDRSxNQUFBLElBQUksQ0FBQyxNQUFMLEdBQWMsSUFBZCxDQURGO0tBQUE7QUFBQSxJQUVBLGFBQUEsR0FBZ0IsSUFBQyxDQUFBLGlCQUFELENBQW1CLElBQUksQ0FBQyxhQUF4QixDQUZoQixDQUFBO1dBR0EsSUFBQyxDQUFBLE1BQUQsQ0FDSTtBQUFBLE1BQUEsS0FBQSxFQUFPLGFBQVA7QUFBQSxNQUNBLE9BQUEsRUFBUyxJQUFDLENBQUEsZUFBZSxDQUFDLElBQWpCLENBQXNCLElBQXRCLENBRFQ7QUFBQSxNQUVBLE1BQUEsRUFBUSxJQUFJLENBQUMsTUFGYjtLQURKLEVBSks7RUFBQSxDQVpQLENBQUE7O0FBcUJBO0FBQUE7O0tBckJBOztBQUFBLGlCQXdCQSxpQkFBQSxHQUFtQixTQUFDLElBQUQsR0FBQTtXQUNqQixJQUFJLENBQUMsT0FBTCxDQUFhLE9BQWIsRUFBc0IsRUFBdEIsRUFEaUI7RUFBQSxDQXhCbkIsQ0FBQTs7QUEyQkE7QUFBQTs7S0EzQkE7O0FBQUEsaUJBOEJBLE1BQUEsR0FBUSxTQUFDLE1BQUQsR0FBQTtXQUVOLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsTUFBQyxRQUFBLEVBQVUsR0FBWDtLQUF4QixFQUF5QyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxLQUFELEdBQUE7QUFDdkMsWUFBQSwwQkFBQTtBQUFBLFFBQUEsSUFBRyxRQUFBLEtBQVksRUFBZjtBQUNFLFVBQUEsUUFBQSxHQUFXLEdBQVgsQ0FERjtTQUFBO0FBQUEsUUFFQSxLQUFDLENBQUEsV0FBRCxDQUFhLEtBQUssQ0FBQyxRQUFuQixDQUZBLENBQUE7QUFBQSxRQUdBLEdBQUEsR0FBTSxLQUFDLENBQUEsT0FBRCxDQUFTLE1BQU0sQ0FBQyxLQUFoQixDQUhOLENBQUE7QUFBQSxRQUtBLFdBQUEsR0FBYyxNQUFNLENBQUMsT0FMckIsQ0FBQTtBQUFBLFFBTUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsU0FBQyxRQUFELEdBQUE7QUFDZixjQUFBLFVBQUE7QUFBQSxVQUFBLFVBQUEsR0FBYSxLQUFDLENBQUEsS0FBRCxDQUFPLFFBQVAsRUFBaUIsTUFBTSxDQUFDLE1BQXhCLENBQWIsQ0FBQTtpQkFDQSxXQUFBLENBQVksVUFBWixFQUZlO1FBQUEsQ0FOakIsQ0FBQTtlQVdBLEtBQUMsQ0FBQSxPQUFELENBQ0U7QUFBQSxVQUFBLEdBQUEsRUFBSyxHQUFMO0FBQUEsVUFDQSxPQUFBLEVBQVMsTUFBTSxDQUFDLE9BRGhCO0FBQUEsVUFFQSxLQUFBLEVBQU8sTUFBTSxDQUFDLEtBRmQ7U0FERixFQVp1QztNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpDLEVBRk07RUFBQSxDQTlCUixDQUFBOztBQUFBLGlCQW1EQSxXQUFBLEdBQWEsU0FBQyxRQUFELEdBQUE7QUFDWCxJQUFBLElBQUMsQ0FBQSxlQUFELEdBQW1CLFFBQW5CLENBQUE7V0FDQSxJQUFDLENBQUEsSUFBRCxHQUFRLFdBQUEsR0FBYyxTQUZYO0VBQUEsQ0FuRGIsQ0FBQTs7QUF1REE7QUFBQTs7O0tBdkRBOztBQUFBLGlCQTJEQSxPQUFBLEdBQVMsU0FBQyxJQUFELEdBQUE7QUFDUCxRQUFBLEdBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxJQUFDLENBQUEsR0FBRCxHQUFXLElBQUEsY0FBQSxDQUFBLENBQWpCLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxrQkFBSixHQUF5QixDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7QUFDdkIsUUFBQSxHQUFBLEdBQU0sS0FBQyxDQUFBLEdBQVAsQ0FBQTtBQUNBLFFBQUEsSUFBRyxHQUFHLENBQUMsVUFBSixHQUFpQixDQUFwQjtBQUFBO1NBQUEsTUFFSyxJQUFHLEdBQUcsQ0FBQyxNQUFKLEtBQWMsR0FBakI7QUFDSCxVQUFBLEtBQUMsQ0FBQSxZQUFELENBQWMsR0FBZCxDQUFBLENBQUE7QUFDQSxVQUFBLElBQUksTUFBQSxDQUFBLElBQVcsQ0FBQyxLQUFaLEtBQXFCLFVBQXpCO0FBQ0UsWUFBQSxJQUFJLENBQUMsS0FBTCxDQUFBLENBQUEsQ0FERjtXQUZHO1NBQUEsTUFLQSxJQUFHLEdBQUcsQ0FBQyxVQUFKLEtBQWtCLENBQXJCO0FBQ0QsaUJBQU8sSUFBSSxDQUFDLE9BQUwsQ0FBYSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQXRCLENBQVAsQ0FEQztTQVRrQjtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRHpCLENBQUE7QUFBQSxJQWFBLEdBQUcsQ0FBQyxJQUFKLENBQVMsS0FBVCxFQUFnQixJQUFJLENBQUMsR0FBckIsRUFBMEIsSUFBMUIsQ0FiQSxDQUFBO1dBY0EsR0FBRyxDQUFDLElBQUosQ0FBQSxFQWZPO0VBQUEsQ0EzRFQsQ0FBQTs7QUFBQSxpQkE2RUEsT0FBQSxHQUFTLFNBQUMsS0FBRCxHQUFBO0FBQ1AsUUFBQSxHQUFBO0FBQUEsSUFBQSxHQUFBLEdBQU0sQ0FBQyxJQUFDLENBQUEsUUFBRixFQUFZLEtBQVosRUFDSSxJQUFDLENBQUEsSUFETCxFQUVJLElBQUMsQ0FBQSxJQUZMLEVBR0ksSUFBQyxDQUFBLElBSEwsRUFJSSxJQUFDLENBQUEsS0FKTCxFQUtJLElBQUMsQ0FBQSxlQUFELENBQWlCLEtBQWpCLENBTEosQ0FNQyxDQUFDLElBTkYsQ0FNTyxFQU5QLENBQU4sQ0FBQTtBQVFBLFdBQU8sR0FBUCxDQVRPO0VBQUEsQ0E3RVQsQ0FBQTs7QUFBQSxpQkF5RkEsZUFBQSxHQUFpQixTQUFDLEtBQUQsR0FBQTtBQUVmLFFBQUEsbUJBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxrQkFBQSxDQUFtQixLQUFuQixDQUFOLENBQUE7QUFDQSxTQUFBLGtCQUFBOzhCQUFBO0FBQ0UsTUFBQSxJQUFHLE1BQUEsQ0FBQSxJQUFBLEtBQWUsUUFBbEI7QUFFRSxRQUFBLEVBQUEsR0FBSyxJQUFJLENBQUMsR0FBVixDQUZGO09BQUEsTUFBQTtBQU1FLFFBQUEsRUFBQSxHQUFLLGtCQUFBLENBQW1CLElBQW5CLENBQUwsQ0FORjtPQUFBO0FBQUEsTUFPQSxHQUFBLEdBQU0sR0FBRyxDQUFDLE9BQUosQ0FBWSxJQUFaLEVBQWtCLEVBQWxCLENBUE4sQ0FERjtBQUFBLEtBREE7QUFVQSxXQUFPLEdBQVAsQ0FaZTtFQUFBLENBekZqQixDQUFBOztBQUFBLGlCQXVHQSxZQUFBLEdBQWMsU0FBQyxHQUFELEdBQUE7V0FDWixPQUFPLENBQUMsR0FBUixDQUFZLE9BQVosRUFBcUIsR0FBckIsRUFEWTtFQUFBLENBdkdkLENBQUE7O0FBMEdBO0FBQUE7O0tBMUdBOztBQUFBLGlCQTZHQSxlQUFBLEdBQWlCLFNBQUMsVUFBRCxHQUFBO0FBQ2YsSUFBQSxJQUFHLFVBQUg7YUFDRSxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVosQ0FBd0IsSUFBeEIsRUFBOEIsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsR0FBRCxHQUFBO2lCQUM1QixNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVosQ0FBd0IsR0FBRyxDQUFDLEVBQTVCLEVBQWdDO0FBQUEsWUFDOUIsTUFBQSxFQUFRLEtBQUMsQ0FBQSxXQUFELENBQWEsVUFBYixDQURzQjtBQUFBLFlBRTlCLElBQUEsRUFBTSxVQUFVLENBQUMsU0FGYTtBQUFBLFlBRzlCLE9BQUEsRUFBUyxDQUFBLFVBQVcsQ0FBQyxTQUFTLENBQUMsUUFBckIsQ0FBOEIsZUFBOUIsQ0FIb0I7V0FBaEMsRUFENEI7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUE5QixFQURGO0tBRGU7RUFBQSxDQTdHakIsQ0FBQTs7QUFBQSxpQkF1SEEsV0FBQSxHQUFhLFNBQUMsVUFBRCxHQUFBO0FBQ1gsUUFBQSxJQUFBO0FBQUEsSUFBQSxpRUFBbUIsQ0FBRSx5QkFBbEIsS0FBNEIsQ0FBL0I7YUFDRSxnQkFERjtLQUFBLE1BQUE7YUFHRSxlQUhGO0tBRFc7RUFBQSxDQXZIYixDQUFBOztBQTZIQTtBQUFBOztLQTdIQTs7QUFBQSxpQkFnSUEsS0FBQSxHQUFPLFNBQUMsUUFBRCxFQUFXLE1BQVgsRUFBbUIsU0FBbkIsR0FBQTtBQUNILFFBQUEsYUFBQTs7TUFEc0IsWUFBWTtLQUNsQztBQUFBLElBQUEsR0FBQSxHQUFNLElBQUMsQ0FBQSxZQUFELENBQWMsUUFBZCxDQUFOLENBQUE7QUFBQSxJQUNBLFFBQUEsR0FBVyxJQUFDLENBQUEsWUFBRCxDQUFjLEdBQWQsQ0FEWCxDQUFBO0FBRUEsSUFBQSxJQUFHLFFBQUg7QUFDRSxNQUFBLFNBQUEsR0FBWSxRQUFRLENBQUMsYUFBVCxDQUF1QixzQkFBdkIsQ0FBWixDQUFBO0FBQ0EsTUFBQSxJQUFHLFNBQUg7QUFDRSxRQUFBLFNBQVMsQ0FBQyxTQUFWLEdBQXNCLElBQUMsQ0FBQSxXQUF2QixDQUFBO0FBQUEsUUFDQSxTQUFTLENBQUMsWUFBVixDQUF1QixhQUF2QixFQUFzQyxHQUF0QyxDQURBLENBQUE7QUFBQSxRQUVBLElBQUMsQ0FBQSxTQUFELENBQVcsU0FBWCxDQUZBLENBQUE7QUFBQSxRQUdBLElBQUMsQ0FBQSxRQUFELENBQVUsU0FBVixDQUhBLENBREY7T0FBQSxNQUtLLElBQUcsQ0FBQSxNQUFIO0FBQ0gsUUFBQSxTQUFBLEdBQVksUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBWixDQUFBO0FBQUEsUUFDQSxTQUFTLENBQUMsU0FBVixHQUFzQixlQUR0QixDQUFBO0FBQUEsUUFFQSxTQUFTLENBQUMsU0FBVixHQUFzQixvQ0FGdEIsQ0FERztPQVBQO0tBRkE7QUFjQSxXQUFPLFNBQVAsQ0FmRztFQUFBLENBaElQLENBQUE7O0FBaUpBO0FBQUE7O0tBakpBOztBQUFBLGlCQW9KQSxZQUFBLEdBQWMsU0FBQyxDQUFELEdBQUE7QUFDWixRQUFBLGVBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFOLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxTQUFKLEdBQWdCLENBRGhCLENBQUE7QUFBQSxJQUVBLE9BQUEsR0FBVSxHQUFHLENBQUMsb0JBQUosQ0FBeUIsUUFBekIsQ0FGVixDQUFBO0FBQUEsSUFHQSxDQUFBLEdBQUksT0FBTyxDQUFDLE1BSFosQ0FBQTtBQUlBLFdBQU0sQ0FBQSxFQUFOLEdBQUE7QUFDRSxNQUFBLE9BQVEsQ0FBQSxDQUFBLENBQUUsQ0FBQyxVQUFVLENBQUMsV0FBdEIsQ0FBa0MsT0FBUSxDQUFBLENBQUEsQ0FBMUMsQ0FBQSxDQURGO0lBQUEsQ0FKQTtBQU1BLFdBQU8sR0FBRyxDQUFDLFNBQVgsQ0FQWTtFQUFBLENBcEpkLENBQUE7O0FBQUEsaUJBNkpBLFlBQUEsR0FBYyxTQUFDLEdBQUQsRUFBTSxRQUFOLEdBQUE7QUFDWixRQUFBLEdBQUE7O01BRGtCLFdBQVc7S0FDN0I7QUFBQSxJQUFBLEdBQUEsR0FBTSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFOLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxTQUFKLEdBQWdCLEdBRGhCLENBQUE7QUFBQSxJQUVBLFFBQUEsR0FBVyxRQUFRLENBQUMsc0JBQVQsQ0FBQSxDQUZYLENBQUE7QUFHQSxXQUFRLEdBQUcsQ0FBQyxVQUFaLEdBQUE7QUFDRSxNQUFBLFFBQVEsQ0FBQyxXQUFULENBQXNCLEdBQUcsQ0FBQyxVQUExQixDQUFBLENBREY7SUFBQSxDQUhBO0FBS0EsV0FBTyxRQUFQLENBTlk7RUFBQSxDQTdKZCxDQUFBOztBQUFBLGlCQXFLQSxTQUFBLEdBQVcsU0FBQyxRQUFELEdBQUE7O01BQUMsV0FBUztLQUNuQjtBQUFBLElBQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxRQUFaLEVBQXNCLEtBQXRCLEVBQTZCLEtBQTdCLENBQUEsQ0FBQTtBQUNBLFdBQU8sUUFBUCxDQUZTO0VBQUEsQ0FyS1gsQ0FBQTs7QUFBQSxpQkF5S0EsUUFBQSxHQUFVLFNBQUMsUUFBRCxHQUFBOztNQUFDLFdBQVM7S0FDbEI7QUFBQSxJQUFBLElBQUksQ0FBQyxNQUFMLENBQVksUUFBWixFQUFzQixHQUF0QixFQUEyQixNQUEzQixDQUFBLENBQUE7QUFDQSxXQUFPLFFBQVAsQ0FGUTtFQUFBLENBektWLENBQUE7O0FBQUEsaUJBNktBLE1BQUEsR0FBUSxTQUFDLFFBQUQsRUFBZ0IsR0FBaEIsRUFBcUIsSUFBckIsR0FBQTtBQUNOLFFBQUEsZ0NBQUE7O01BRE8sV0FBUztLQUNoQjtBQUFBLElBQUEsSUFBRyxRQUFIO0FBQ0UsTUFBQSxJQUFBLEdBQVEsUUFBUSxDQUFDLGdCQUFULENBQTBCLEdBQTFCLENBQVIsQ0FBQTtBQUFBLE1BQ0EsTUFBQSxHQUFTLFFBQVEsQ0FBQyxhQUFULENBQXVCLEdBQXZCLENBRFQsQ0FBQTtBQUVBO1dBQUEsMkNBQUE7dUJBQUE7QUFDRSxRQUFBLE1BQU0sQ0FBQyxJQUFQLEdBQWMsR0FBSSxDQUFBLElBQUEsQ0FBbEIsQ0FBQTtBQUFBLFFBQ0EsTUFBTSxDQUFDLElBQVAsR0FBYyxJQUFDLENBQUEsSUFEZixDQUFBO0FBQUEsUUFFQSxNQUFNLENBQUMsUUFBUCxHQUFrQixJQUFDLENBQUEsUUFGbkIsQ0FBQTtBQUlBLFFBQUEsSUFBRyxHQUFHLENBQUMsT0FBSixLQUFlLEdBQWxCO0FBQ0UsVUFBQSxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQWQsQ0FBa0IsVUFBbEIsQ0FBQSxDQUFBO0FBQ0EsVUFBQSxJQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBaEIsQ0FBd0IsT0FBeEIsQ0FBQSxLQUFzQyxDQUFBLENBQXpDO0FBQ0UsWUFBQSxNQUFNLENBQUMsUUFBUCxHQUFrQixJQUFBLEdBQU8sTUFBTSxDQUFDLFFBQWhDLENBQUE7QUFBQSxZQUNBLEdBQUcsQ0FBQyxZQUFKLENBQWlCLFFBQWpCLEVBQTJCLFFBQTNCLENBREEsQ0FERjtXQUZGO1NBQUEsTUFLSyxJQUFHLEdBQUcsQ0FBQyxPQUFKLEtBQWUsS0FBbEI7QUFDSCxVQUFBLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBZCxDQUFrQixTQUFsQixDQUFBLENBREc7U0FUTDtBQUFBLHNCQVlBLEdBQUcsQ0FBQyxZQUFKLENBQWlCLElBQWpCLEVBQXVCLE1BQU0sQ0FBQyxJQUE5QixFQVpBLENBREY7QUFBQTtzQkFIRjtLQURNO0VBQUEsQ0E3S1IsQ0FBQTs7Y0FBQTs7SUFoQkYsQ0FBQTs7QUFBQSxNQWtOTSxDQUFDLE9BQVAsR0FBaUIsR0FBQSxDQUFBLElBbE5qQixDQUFBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3Rocm93IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIil9dmFyIGY9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGYuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sZixmLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIi8qXHIgIE11bHRpdHJhbiBkZXBlbmRzIG9uIGh0bWwtZXNjYXBpbmcgKG5vdCBVVEYtOCkgcnVsZXMgZm9yIHNwZWNpYWwgc3ltYm9sc1xyICDDoCwgw6gsIMOsLCDDsiwgw7kgLSDDgCwgw4gsIMOMLCDDkiwgw5lcciAgw6EsIMOpLCDDrSwgw7MsIMO6LCDDvSAtIMOBLCDDiSwgw40sIMOTLCDDmiwgw51cciAgw6IsIMOqLCDDriwgw7QsIMO7IMOCLCDDiiwgw44sIMOULCDDm1xyICDDoywgw7EsIMO1IMODLCDDkSwgw5VcciAgw6QsIMOrLCDDrywgw7YsIMO8LCDDvyDDhCwgw4ssIMOPLCDDliwgw5wsXHIgIMOlLCDDhVxyICDDpiwgw4ZcciAgw6csIMOHXHIgIMOwLCDDkFxyICDDuCwgw5hcciAgwr8gwqEgw59cciovXHJ2YXIgQ0hBUl9DT0RFUyA9IHtcciAgLy9ydXNzaWFuXHIgICclRDElOEEnOiB7dmFsOiclRkEnLCBsYW5nOidydSd9LCAvLyDRilxyICAnJUQwJUFBJzoge3ZhbDonJURBJywgbGFuZzoncnUnfSwvLyDQqlxyXHIgICclQzMlODAnOiAnJiMxOTI7JywgLy8gw4BcciAgJyVDMyU4MSc6ICcmIzE5MzsnLCAvLyDDgVxyICAnJUMzJTgyJzogJyYjMTk0OycsIC8vIMOCXHIgICclQzMlODMnOiAnJiMxOTU7JywgLy8gw4NcciAgJyVDMyU4NCc6ICcmIzE5NjsnLCAvLyDDhFxyICAnJUMzJTg1JzogJyYjMTk3OycsIC8vIMOFXHIgICclQzMlODYnOiAnJiMxOTg7JywgLy8gw4ZcclxyICAnJUMzJTg3JzogJyYjMTk5OycsIC8vIMOHXHIgICclQzMlODgnOiAnJiMyMDA7JywgLy8gw4hcciAgJyVDMyU4OSc6ICcmIzIwMTsnLCAvLyDDiVxyICAnJUMzJThBJzogJyYjMjAyOycsIC8vIMOKXHIgICclQzMlOEInOiAnJiMyMDM7JywgLy8gw4tcclxyICAnJUMzJThDJzogJyYjMjA0OycsIC8vIMOMXHIgICclQzMlOEQnOiAnJiMyMDU7JywgLy8gw41cciAgJyVDMyU4RSc6ICcmIzIwNjsnLCAvLyDDjlxyICAnJUMzJThGJzogJyYjMjA3OycsIC8vIMOPXHJcciAgJyVDMyU5MSc6ICcmIzIwOTsnLCAvLyDDkVxyICAnJUMzJTkyJzogJyYjMjEwOycsIC8vIMOSXHIgICclQzMlOTMnOiAnJiMyMTE7JywgLy8gw5NcciAgJyVDMyU5NCc6ICcmIzIxMjsnLCAvLyDDlFxyICAnJUMzJTk1JzogJyYjMjEzOycsIC8vIMOVXHIgICclQzMlOTYnOiAnJiMyMTQ7JywgLy8gw5ZcclxyICAnJUMzJTk5JzogJyYjMjE3OycsIC8vIMOZXHIgICclQzMlOUEnOiAnJiMyMTg7JywgLy8gw5pcciAgJyVDMyU5Qic6ICcmIzIxOTsnLCAvLyDDm1xyICAnJUMzJTlDJzogJyYjMjIwOycsIC8vIMOcXHJcclxyICAnJUMzJUEwJzogJyYjMjI0OycsIC8vIMOgXHIgICclQzMlQTEnOiAnJiMyMjU7JywgLy8gw6FcciAgJyVDMyVBMic6ICcmIzIyNjsnLCAvLyDDolxyICAnJUMzJUEzJzogJyYjMjI3OycsIC8vIMOjXHIgICclQzMlQTQnOiAnJiMyMjg7JywgLy8gw6RcciAgJyVDMyVBNSc6ICcmIzIyOTsnLCAvLyDDpVxyICAnJUMzJUE2JzogJyYjMjMwOycsIC8vIMOmXHIgICclQzMlQTcnOiAnJiMyMzE7JywgLy8gw6dcclxyXHIgICclQzMlQTgnOiAnJiMyMzI7JywgLy8gw6hcciAgJyVDMyVBOSc6ICcmIzIzMzsnLCAvLyDDqVxyICAnJUMzJUFBJzogJyYjMjM0OycsIC8vIMOqXHIgICclQzMlQUInOiAnJiMyMzU7JywgLy8gw6tcclxyICAnJUMzJUFDJzogJyYjMjM2OycsIC8vIMOsXHIgICclQzMlQUQnOiAnJiMyMzc7JywgLy8gw61cciAgJyVDMyVBRSc6ICcmIzIzODsnLCAvLyDDrlxyICAnJUMzJUFGJzogJyYjMjM5OycsIC8vIMOvXHJcciAgJyVDMyVCMCc6ICcmIzI0MDsnLCAvLyDDsFxyICAnJUMzJUIxJzogJyYjMjQxOycsIC8vIMOxXHJcciAgJyVDMyVCMic6ICcmIzI0MjsnLCAvLyDDslxyICAnJUMzJUIzJzogJyYjMjQzOycsIC8vIMOzXHIgICclQzMlQjQnOiAnJiMyNDQ7JywgLy8gw7RcciAgJyVDMyVCNSc6ICcmIzI0NTsnLCAvLyDDtVxyICAnJUMzJUI2JzogJyYjMjQ2OycsIC8vIMO2XHJcciAgJyVDMyVCOSc6ICcmIzI0OTsnLCAvLyDDuVxyICAnJUMzJUJBJzogJyYjMjUwOycsIC8vIMO6XHIgICclQzMlQkInOiAnJiMyNTE7JywgLy8gw7tcciAgJyVDMyVCQyc6ICcmIzI1MjsnLCAvLyDDvFxyICAnJUMzJUJGJzogJyYjMjU1OycsIC8vIMO/XHIgICclQzUlQjgnOiAnJiMzNzY7JywgLy8gxbhcclxyICAnJUMzJTlGJzogJyYjMjIzOycsIC8vIMOfXHJcciAgJyVDMiVCRic6ICcmIzE5MTsnLCAvLyDCv1xyICAnJUMyJUExJzogJyYjMTYxOycsIC8vIMKhXHJ9O1xyXHJtb2R1bGUuZXhwb3J0cyA9IENIQVJfQ09ERVM7XHIiLCIjIyNnbG9iYWwgY2hyb21lIyMjXG4jIyNcbiAgTXVsdGl0cmFuLnJ1IHRyYW5zbGF0ZSBlbmdpbmVcbiAgUHJvdmlkZXMgcHJvZ3JhbSBpbnRlcmZhY2UgZm9yIG1ha2luZyB0cmFuc2xhdGUgcXVlcmllcyB0byBtdWx0aXRyYW4gYW5kIGdldCBjbGVhbiByZXNwb25zZVxuXG4gIEFsbCBlbmdpbmVzIG11c3QgZm9sbG93IGNvbW1vbiBpbnRlcmZhY2UgYW5kIHByb3ZpZGUgbWV0aG9kczpcbiAgICAtIHNlYXJjaCAobGFuZ3VhbmdlLCBzdWNjZXNzSGFuZGxlcikgIGNsZWFuIHRyYW5zbGF0aW9uIG11c3QgYmUgcGFzc2VkIGludG8gc3VjY2Vzc0hhbmRsZXJcbiAgICAtIGNsaWNrXG5cbiAgVHJhbnNsYXRpb24tbW9kdWxlIHRoYXQgbWFrZXMgcmVxdWVzdHMgdG8gbGFuZ3VhZ2UtZW5naW5lLFxuICBwYXJzZXMgcmVzdWx0cyBhbmQgc2VuZHMgcGx1Z2luLWdsb2JhbCBtZXNzYWdlIHdpdGggdHJhbnNsYXRpb24gZGF0YVxuIyMjXG5cbkNIQVJfQ09ERVMgPSByZXF1aXJlKCcuL2NoYXItY29kZXMuanMnKTtcblxuY2xhc3MgVHJhblxuICBjb25zdHJ1Y3RvcjogLT5cbiAgICBAVEFCTEVfQ0xBU1MgPSBcIl9fX210dF90cmFuc2xhdGVfdGFibGVcIlxuICAgIEBwcm90b2NvbCA9ICdodHRwJ1xuICAgIEBob3N0ID0gJ3d3dy5tdWx0aXRyYW4ucnUnXG4gICAgQHBhdGggPSAnL2MvbS5leGUnXG4gICAgQHF1ZXJ5ID0gJyZzPSdcbiAgICBAbGFuZyA9ICc/bDE9MiZsMj0xJyAjZnJvbSBydXNzaWFuIHRvIGVuZ2xpc2ggYnkgZGVmYXVsdFxuICAgIEB4aHIgPSB7fVxuXG4gICMjI1xuICAgIENvbnRleHQgbWVudSBjbGljayBoYW5kbGVyXG4gICMjI1xuICBjbGljazogKGRhdGEpIC0+XG4gICAgaWYgdHlwZW9mIGRhdGEuc2lsZW50ID09IHVuZGVmaW5lZCB8fCBkYXRhLnNpbGVudCA9PSBudWxsXG4gICAgICBkYXRhLnNpbGVudCA9IHRydWUgIyB0cnVlIGJ5IGRlZmF1bHRcbiAgICBzZWxlY3Rpb25UZXh0ID0gQHJlbW92ZUh5cGhlbmF0aW9uIGRhdGEuc2VsZWN0aW9uVGV4dFxuICAgIEBzZWFyY2hcbiAgICAgICAgdmFsdWU6IHNlbGVjdGlvblRleHRcbiAgICAgICAgc3VjY2VzczogQHN1Y2Nlc3N0SGFuZGxlci5iaW5kKHRoaXMpXG4gICAgICAgIHNpbGVudDogZGF0YS5zaWxlbnQgICMgaWYgdHJhbnNsYXRpb24gZmFpbGVkIGRvIG5vdCBzaG93IGRpYWxvZ1xuXG4gICMjI1xuICAgIERpc2NhcmQgc29mdCBoeXBoZW4gY2hhcmFjdGVyIChVKzAwQUQsICZzaHk7KSBmcm9tIHRoZSBpbnB1dFxuICAjIyNcbiAgcmVtb3ZlSHlwaGVuYXRpb246ICh0ZXh0KSAtPlxuICAgIHRleHQucmVwbGFjZSAvXFx4YWQvZywgJydcblxuICAjIyNcbiAgICBJbml0aWF0ZSB0cmFuc2xhdGlvbiBzZWFyY2hcbiAgIyMjXG4gIHNlYXJjaDogKHBhcmFtcykgLT5cbiAgICAjdmFsdWUsIGNhbGxiYWNrLCBlcnJcbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7bGFuZ3VhZ2U6ICcxJ30sIChpdGVtcykgPT5cbiAgICAgIGlmIGxhbmd1YWdlIGlzICcnXG4gICAgICAgIGxhbmd1YWdlID0gJzEnXG4gICAgICBAc2V0TGFuZ3VhZ2UoaXRlbXMubGFuZ3VhZ2UpXG4gICAgICB1cmwgPSBAbWFrZVVybChwYXJhbXMudmFsdWUpO1xuICAgICAgIyBkZWNvcmF0ZSBzdWNjZXNzIHRvIG1ha2UgcHJlbGltaW5hcnkgcGFyc2luZ1xuICAgICAgb3JpZ1N1Y2Nlc3MgPSBwYXJhbXMuc3VjY2Vzc1xuICAgICAgcGFyYW1zLnN1Y2Nlc3MgPSAocmVzcG9uc2UpID0+XG4gICAgICAgIHRyYW5zbGF0ZWQgPSBAcGFyc2UocmVzcG9uc2UsIHBhcmFtcy5zaWxlbnQpXG4gICAgICAgIG9yaWdTdWNjZXNzKHRyYW5zbGF0ZWQpXG5cbiAgICAgICMgbWFrZSByZXF1ZXN0IChHRVQgcmVxdWVzdCB3aXRoIHF1ZXJ5IHBhcmFtZXRlcnMgaW4gdXJsKVxuICAgICAgQHJlcXVlc3QoXG4gICAgICAgIHVybDogdXJsLFxuICAgICAgICBzdWNjZXNzOiBwYXJhbXMuc3VjY2VzcyxcbiAgICAgICAgZXJyb3I6IHBhcmFtcy5lcnJvclxuICAgICAgKVxuICAgIClcblxuICBzZXRMYW5ndWFnZTogKGxhbmd1YWdlKSAtPlxuICAgIEBjdXJyZW50TGFuZ3VhZ2UgPSBsYW5ndWFnZVxuICAgIEBsYW5nID0gJz9sMT0yJmwyPScgKyBsYW5ndWFnZVxuXG4gICMjI1xuICAgIFJlcXVlc3QgdHJhbnNsYXRpb24gYW5kIHJ1biBjYWxsYmFjayBmdW5jdGlvblxuICAgIHBhc3NpbmcgdHJhbnNsYXRlZCByZXN1bHQgb3IgZXJyb3IgdG8gY2FsbGJhY2tcbiAgIyMjXG4gIHJlcXVlc3Q6IChvcHRzKSAtPlxuICAgIHhociA9IEB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKVxuICAgIHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSAoZSkgPT5cbiAgICAgIHhociA9IEB4aHJcbiAgICAgIGlmIHhoci5yZWFkeVN0YXRlIDwgNFxuICAgICAgICByZXR1cm5cbiAgICAgIGVsc2UgaWYgeGhyLnN0YXR1cyAhPSAyMDBcbiAgICAgICAgQGVycm9ySGFuZGxlcih4aHIpXG4gICAgICAgIGlmICh0eXBlb2Ygb3B0cy5lcnJvciA9PSAnZnVuY3Rpb24nKVxuICAgICAgICAgIG9wdHMuZXJyb3IoKVxuICAgICAgICByZXR1cm5cbiAgICAgIGVsc2UgaWYgeGhyLnJlYWR5U3RhdGUgPT0gNFxuICAgICAgICAgIHJldHVybiBvcHRzLnN1Y2Nlc3MoZS50YXJnZXQucmVzcG9uc2UpXG5cbiAgICB4aHIub3BlbihcIkdFVFwiLCBvcHRzLnVybCwgdHJ1ZSk7XG4gICAgeGhyLnNlbmQoKTtcblxuXG4gIG1ha2VVcmw6ICh2YWx1ZSkgLT5cbiAgICB1cmwgPSBbQHByb3RvY29sLCAnOi8vJyxcbiAgICAgICAgICAgICAgQGhvc3QsXG4gICAgICAgICAgICAgIEBwYXRoLFxuICAgICAgICAgICAgICBAbGFuZyxcbiAgICAgICAgICAgICAgQHF1ZXJ5LFxuICAgICAgICAgICAgICBAZ2V0RW5jb2RlZFZhbHVlKHZhbHVlKVxuICAgICAgICAgIF0uam9pbignJylcblxuICAgIHJldHVybiB1cmw7XG5cbiAgIyBSZXBsYWNlIHNwZWNpYWwgbGFuZ3VhZ2UgY2hhcmFjdGVycyB0byBodG1sIGNvZGVzXG4gIGdldEVuY29kZWRWYWx1ZTogKHZhbHVlKSAtPlxuICAgICMgdG8gZmluZCBzcGVjIHN5bWJvbHMgd2UgZmlyc3QgZW5jb2RlIHRoZW0gKHJhdyBzZWFyY2ggZm9yIHRoYXQgc3ltYm9sIGRvZXNuJ3Qgd29yKVxuICAgIHZhbCA9IGVuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSlcbiAgICBmb3IgY2hhciwgY29kZSBvZiBDSEFSX0NPREVTXG4gICAgICBpZiB0eXBlb2YgY29kZSA9PSAnb2JqZWN0J1xuICAgICAgICAjIHJ1c3NpYW4gaGFzIHNwZWNpYWwgY29kZXNcbiAgICAgICAgY2MgPSBjb2RlLnZhbFxuICAgICAgZWxzZVxuICAgICAgICAjIGZvciBhbGwgbGFuZ3MgZXhjZXB0IHJ1c3NpYW4gZW5jb2RlIGh0bWwtY29kZXMgbmVlZGVkXG4gICAgICAgICMg0LTQu9GPINCy0YHQtdGFINC+0YHRgtCw0LvRjNC90YvRhSDRj9C30YvQutC+0LJcbiAgICAgICAgY2MgPSBlbmNvZGVVUklDb21wb25lbnQoY29kZSlcbiAgICAgIHZhbCA9IHZhbC5yZXBsYWNlKGNoYXIsIGNjKVxuICAgIHJldHVybiB2YWxcblxuICBlcnJvckhhbmRsZXI6ICh4aHIpIC0+XG4gICAgY29uc29sZS5sb2coJ2Vycm9yJywgeGhyKVxuXG4gICMjI1xuICAgUmVjZWl2aW5nIGRhdGEgZnJvbSB0cmFuc2xhdGlvbi1lbmdpbmUgYW5kIHNlbmQgcmVhZHkgbWVzc2FnZSB3aXRoIGRhdGFcbiAgIyMjXG4gIHN1Y2Nlc3N0SGFuZGxlcjogKHRyYW5zbGF0ZWQpIC0+XG4gICAgaWYgdHJhbnNsYXRlZFxuICAgICAgY2hyb21lLnRhYnMuZ2V0U2VsZWN0ZWQobnVsbCwgKHRhYikgPT5cbiAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgYWN0aW9uOiBAbWVzc2FnZVR5cGUgdHJhbnNsYXRlZFxuICAgICAgICAgIGRhdGE6IHRyYW5zbGF0ZWQub3V0ZXJIVE1MLFxuICAgICAgICAgIHN1Y2Nlc3M6ICF0cmFuc2xhdGVkLmNsYXNzTGlzdC5jb250YWlucygnZmFpbFRyYW5zbGF0ZScpXG4gICAgICAgIH0pXG4gICAgICApXG5cbiAgbWVzc2FnZVR5cGU6ICh0cmFuc2xhdGVkKSAtPlxuICAgIGlmIHRyYW5zbGF0ZWQ/LnJvd3M/Lmxlbmd0aCA9PSAxXG4gICAgICAnc2ltaWxhcl93b3JkcydcbiAgICBlbHNlXG4gICAgICAnb3Blbl90b29sdGlwJ1xuXG4gICMjI1xuICAgIFBhcnNlIHJlc3BvbnNlIGZyb20gdHJhbnNsYXRpb24gZW5naW5lXG4gICMjI1xuICBwYXJzZTogKHJlc3BvbnNlLCBzaWxlbnQsIHRyYW5zbGF0ZSA9IG51bGwpIC0+XG4gICAgICBkb2MgPSBAc3RyaXBTY3JpcHRzKHJlc3BvbnNlKVxuICAgICAgZnJhZ21lbnQgPSBAbWFrZUZyYWdtZW50KGRvYylcbiAgICAgIGlmIGZyYWdtZW50XG4gICAgICAgIHRyYW5zbGF0ZSA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3IoJyN0cmFuc2xhdGlvbiB+IHRhYmxlJylcbiAgICAgICAgaWYgdHJhbnNsYXRlXG4gICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9IEBUQUJMRV9DTEFTUztcbiAgICAgICAgICB0cmFuc2xhdGUuc2V0QXR0cmlidXRlKFwiY2VsbHBhZGRpbmdcIiwgXCI1XCIpXG4gICAgICAgICAgQGZpeEltYWdlcyh0cmFuc2xhdGUpXG4gICAgICAgICAgQGZpeExpbmtzKHRyYW5zbGF0ZSlcbiAgICAgICAgZWxzZSBpZiBub3Qgc2lsZW50XG4gICAgICAgICAgdHJhbnNsYXRlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gJ2ZhaWxUcmFuc2xhdGUnXG4gICAgICAgICAgdHJhbnNsYXRlLmlubmVyVGV4dCA9IFwiVW5mb3J0dW5hdGVseSwgY291bGQgbm90IHRyYW5zbGF0ZVwiXG5cbiAgICAgIHJldHVybiB0cmFuc2xhdGU7XG5cbiAgIyMjXG4gICAgU3RyaXAgc2NyaXB0IHRhZ3MgZnJvbSByZXNwb25zZSBodG1sXG4gICMjI1xuICBzdHJpcFNjcmlwdHM6IChzKSAtPlxuICAgIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgZGl2LmlubmVySFRNTCA9IHNcbiAgICBzY3JpcHRzID0gZGl2LmdldEVsZW1lbnRzQnlUYWdOYW1lKCdzY3JpcHQnKVxuICAgIGkgPSBzY3JpcHRzLmxlbmd0aFxuICAgIHdoaWxlIGktLVxuICAgICAgc2NyaXB0c1tpXS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHNjcmlwdHNbaV0pXG4gICAgcmV0dXJuIGRpdi5pbm5lckhUTUw7XG5cbiAgbWFrZUZyYWdtZW50OiAoZG9jLCBmcmFnbWVudCA9IG51bGwpIC0+XG4gICAgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKVxuICAgIGRpdi5pbm5lckhUTUwgPSBkb2NcbiAgICBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKVxuICAgIHdoaWxlICggZGl2LmZpcnN0Q2hpbGQgKVxuICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoIGRpdi5maXJzdENoaWxkIClcbiAgICByZXR1cm4gZnJhZ21lbnRcblxuICBmaXhJbWFnZXM6IChmcmFnbWVudD1udWxsKSAtPlxuICAgIHRoaXMuZml4VXJsKGZyYWdtZW50LCAnaW1nJywgJ3NyYycpO1xuICAgIHJldHVybiBmcmFnbWVudDtcblxuICBmaXhMaW5rczogKGZyYWdtZW50PW51bGwpIC0+XG4gICAgdGhpcy5maXhVcmwoZnJhZ21lbnQsICdhJywgJ2hyZWYnKVxuICAgIHJldHVybiBmcmFnbWVudFxuXG4gIGZpeFVybDogKGZyYWdtZW50PW51bGwsIHRhZywgYXR0cikgLT5cbiAgICBpZiBmcmFnbWVudFxuICAgICAgdGFncyA9ICBmcmFnbWVudC5xdWVyeVNlbGVjdG9yQWxsKHRhZylcbiAgICAgIHBhcnNlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKVxuICAgICAgZm9yIHRhZyBpbiB0YWdzXG4gICAgICAgIHBhcnNlci5ocmVmID0gdGFnW2F0dHJdXG4gICAgICAgIHBhcnNlci5ob3N0ID0gQGhvc3RcbiAgICAgICAgcGFyc2VyLnByb3RvY29sID0gQHByb3RvY29sXG4gICAgICAgICNmaXggcmVsYXRpdmUgbGlua3NcbiAgICAgICAgaWYgdGFnLnRhZ05hbWUgPT0gJ0EnXG4gICAgICAgICAgdGFnLmNsYXNzTGlzdC5hZGQgJ210dF9saW5rJ1xuICAgICAgICAgIGlmIHBhcnNlci5wYXRobmFtZS5pbmRleE9mKCdtLmV4ZScpIGlzbnQgLTFcbiAgICAgICAgICAgIHBhcnNlci5wYXRobmFtZSA9ICcvYycgKyBwYXJzZXIucGF0aG5hbWVcbiAgICAgICAgICAgIHRhZy5zZXRBdHRyaWJ1dGUoJ3RhcmdldCcsICdfYmxhbmsnKVxuICAgICAgICBlbHNlIGlmIHRhZy50YWdOYW1lID09ICdJTUcnXG4gICAgICAgICAgdGFnLmNsYXNzTGlzdC5hZGQgJ210dF9pbWcnXG5cbiAgICAgICAgdGFnLnNldEF0dHJpYnV0ZShhdHRyLCBwYXJzZXIuaHJlZilcblxuXG5cbm1vZHVsZS5leHBvcnRzID0gbmV3IFRyYW4iXX0=
