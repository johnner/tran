(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){

/*global tran, chrome */
var CHAR_CODES, tran, turkishDictionary;

CHAR_CODES = require('./char-codes.js');

tran = require('./tran.coffee');

turkishDictionary = require('./turkishdictionary.js');

chrome.contextMenus.create({
  title: 'Multitran: "%s"',
  contexts: ["page", "frame", "editable", "image", "video", "audio", "link", "selection"],
  onclick: function(data) {
    data.silent = false;
    return tran.click(data);
  }
});


/*
 Can't get chrome.storage directly from content_script
 so content_script sends request message and then background script
 responds with storage value
 */

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.method === "get_fast_option") {
    chrome.storage.sync.get({
      fast: true
    }, function(items) {
      return sendResponse({
        fast: items.fast
      });
    });
  } else if (request.method === 'request_search') {
    chrome.storage.sync.get({
      language: '1',
      fast: true
    }, function(items) {
      request.data.silent = true;
      if (parseInt(items.language, 10) === 1000) {
        turkishDictionary.translate(request.data);
      } else {
        tran.click(request.data);
      }
      return true;
    });
  }
  return true;
});


},{"./char-codes.js":3,"./tran.coffee":4,"./turkishdictionary.js":5}],2:[function(require,module,exports){
// turkishdictionary codings
var DICT = {
    304: '%DD', //i
    350: '%DE', //S
    286: '%D0', //G
    287: '%F0', //G
    351: '%FE', //S
    305: '%FD', //I
    252: '%FC', //ü
    220: '%DC', //Ü
    231: '%E7', //ç
    199: '%C7', //Ç
    246: '%F6', //ö
    214: '%D6', //Ö
    39: '',  //'
};

module.exports = DICT;
},{}],3:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/var CHAR_CODES = {  //russian  '%D1%8A': {val:'%FA', lang:'ru'}, // ъ  '%D0%AA': {val:'%DA', lang:'ru'},// Ъ  '%C3%80': '&#192;', // À  '%C3%81': '&#193;', // Á  '%C3%82': '&#194;', // Â  '%C3%83': '&#195;', // Ã  '%C3%84': '&#196;', // Ä  '%C3%85': '&#197;', // Å  '%C3%86': '&#198;', // Æ  '%C3%87': '&#199;', // Ç  '%C3%88': '&#200;', // È  '%C3%89': '&#201;', // É  '%C3%8A': '&#202;', // Ê  '%C3%8B': '&#203;', // Ë  '%C3%8C': '&#204;', // Ì  '%C3%8D': '&#205;', // Í  '%C3%8E': '&#206;', // Î  '%C3%8F': '&#207;', // Ï  '%C3%91': '&#209;', // Ñ  '%C3%92': '&#210;', // Ò  '%C3%93': '&#211;', // Ó  '%C3%94': '&#212;', // Ô  '%C3%95': '&#213;', // Õ  '%C3%96': '&#214;', // Ö  '%C3%99': '&#217;', // Ù  '%C3%9A': '&#218;', // Ú  '%C3%9B': '&#219;', // Û  '%C3%9C': '&#220;', // Ü  '%C3%A0': '&#224;', // à  '%C3%A1': '&#225;', // á  '%C3%A2': '&#226;', // â  '%C3%A3': '&#227;', // ã  '%C3%A4': '&#228;', // ä  '%C3%A5': '&#229;', // å  '%C3%A6': '&#230;', // æ  '%C3%A7': '&#231;', // ç  '%C3%A8': '&#232;', // è  '%C3%A9': '&#233;', // é  '%C3%AA': '&#234;', // ê  '%C3%AB': '&#235;', // ë  '%C3%AC': '&#236;', // ì  '%C3%AD': '&#237;', // í  '%C3%AE': '&#238;', // î  '%C3%AF': '&#239;', // ï  '%C3%B0': '&#240;', // ð  '%C3%B1': '&#241;', // ñ  '%C3%B2': '&#242;', // ò  '%C3%B3': '&#243;', // ó  '%C3%B4': '&#244;', // ô  '%C3%B5': '&#245;', // õ  '%C3%B6': '&#246;', // ö  '%C3%B9': '&#249;', // ù  '%C3%BA': '&#250;', // ú  '%C3%BB': '&#251;', // û  '%C3%BC': '&#252;', // ü  '%C3%BF': '&#255;', // ÿ  '%C5%B8': '&#376;', // Ÿ  '%C3%9F': '&#223;', // ß  '%C2%BF': '&#191;', // ¿  '%C2%A1': '&#161;', // ¡};module.exports = CHAR_CODES;
},{}],4:[function(require,module,exports){

/*global chrome */

/*
  Multitran.ru translate engine
  Provides program interface for making translate queries to multitran and get clean response

  All engines must follow common interface and provide methods:
    - search (languange, successHandler)  clean translation must be passed into successHandler
    - click

  Translation-module that makes requests to language-engine,
  parses results and sends plugin-global message with translation data
 */
var CHAR_CODES, Tran;

CHAR_CODES = require('./char-codes.js');

Tran = (function() {
  function Tran() {
    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1';
    this.xhr = {};
  }


  /*
    Context menu click handler
   */

  Tran.prototype.click = function(data) {
    var selectionText;
    if (typeof data.silent === void 0 || data.silent === null) {
      data.silent = true;
    }
    selectionText = this.removeHyphenation(data.selectionText);
    return this.search({
      value: selectionText,
      success: this.successtHandler.bind(this),
      silent: data.silent
    });
  };


  /*
    Discard soft hyphen character (U+00AD, &shy;) from the input
   */

  Tran.prototype.removeHyphenation = function(text) {
    return text.replace(/\xad/g, '');
  };


  /*
    Initiate translation search
   */

  Tran.prototype.search = function(params) {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(items) {
        var language, origSuccess, url;
        if (language === '') {
          language = '1';
        }
        _this.setLanguage(items.language);
        url = _this.makeUrl(params.value);
        origSuccess = params.success;
        params.success = function(response) {
          var translated;
          translated = _this.parse(response, params.silent);
          return origSuccess(translated);
        };
        return _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      };
    })(this));
  };

  Tran.prototype.setLanguage = function(language) {
    this.currentLanguage = language;
    return this.lang = '?l1=2&l2=' + language;
  };


  /*
    Request translation and run callback function
    passing translated result or error to callback
   */

  Tran.prototype.request = function(opts) {
    var xhr;
    xhr = this.xhr = new XMLHttpRequest();
    xhr.onreadystatechange = (function(_this) {
      return function(e) {
        xhr = _this.xhr;
        if (xhr.readyState < 4) {

        } else if (xhr.status !== 200) {
          _this.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error();
          }
        } else if (xhr.readyState === 4) {
          return opts.success(e.target.response);
        }
      };
    })(this);
    xhr.open("GET", opts.url, true);
    return xhr.send();
  };

  Tran.prototype.makeUrl = function(value) {
    var url;
    url = [this.protocol, '://', this.host, this.path, this.lang, this.query, this.getEncodedValue(value)].join('');
    return url;
  };

  Tran.prototype.getEncodedValue = function(value) {
    var cc, char, code, val;
    val = encodeURIComponent(value);
    for (char in CHAR_CODES) {
      code = CHAR_CODES[char];
      if (typeof code === 'object') {
        cc = code.val;
      } else {
        cc = encodeURIComponent(code);
      }
      val = val.replace(char, cc);
    }
    return val;
  };

  Tran.prototype.errorHandler = function(xhr) {
    return console.log('error', xhr);
  };


  /*
   Receiving data from translation-engine and send ready message with data
   */

  Tran.prototype.successtHandler = function(translated) {
    if (translated) {
      return chrome.tabs.getSelected(null, (function(_this) {
        return function(tab) {
          return chrome.tabs.sendMessage(tab.id, {
            action: _this.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        };
      })(this));
    }
  };

  Tran.prototype.messageType = function(translated) {
    var _ref;
    if ((translated != null ? (_ref = translated.rows) != null ? _ref.length : void 0 : void 0) === 1) {
      return 'similar_words';
    } else {
      return 'open_tooltip';
    }
  };


  /*
    Parse response from translation engine
   */

  Tran.prototype.parse = function(response, silent, translate) {
    var doc, fragment;
    if (translate == null) {
      translate = null;
    }
    doc = this.stripScripts(response);
    fragment = this.makeFragment(doc);
    if (fragment) {
      translate = fragment.querySelector('#translation ~ table');
      if (translate) {
        translate.className = this.TABLE_CLASS;
        translate.setAttribute("cellpadding", "5");
        this.fixImages(translate);
        this.fixLinks(translate);
      } else if (!silent) {
        translate = document.createElement('div');
        translate.className = 'failTranslate';
        translate.innerText = "Unfortunately, could not translate";
      }
    }
    return translate;
  };


  /*
    Strip script tags from response html
   */

  Tran.prototype.stripScripts = function(s) {
    var div, i, scripts;
    div = document.createElement('div');
    div.innerHTML = s;
    scripts = div.getElementsByTagName('script');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
    return div.innerHTML;
  };

  Tran.prototype.makeFragment = function(doc, fragment) {
    var div;
    if (fragment == null) {
      fragment = null;
    }
    div = document.createElement("div");
    div.innerHTML = doc;
    fragment = document.createDocumentFragment();
    while (div.firstChild) {
      fragment.appendChild(div.firstChild);
    }
    return fragment;
  };

  Tran.prototype.fixImages = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'img', 'src');
    return fragment;
  };

  Tran.prototype.fixLinks = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'a', 'href');
    return fragment;
  };

  Tran.prototype.fixUrl = function(fragment, tag, attr) {
    var parser, tags, _i, _len, _results;
    if (fragment == null) {
      fragment = null;
    }
    if (fragment) {
      tags = fragment.querySelectorAll(tag);
      parser = document.createElement('a');
      _results = [];
      for (_i = 0, _len = tags.length; _i < _len; _i++) {
        tag = tags[_i];
        parser.href = tag[attr];
        parser.host = this.host;
        parser.protocol = this.protocol;
        if (tag.tagName === 'A') {
          tag.classList.add('mtt_link');
          if (parser.pathname.indexOf('m.exe') !== -1) {
            parser.pathname = '/c' + parser.pathname;
            tag.setAttribute('target', '_blank');
          }
        } else if (tag.tagName === 'IMG') {
          tag.classList.add('mtt_img');
        }
        _results.push(tag.setAttribute(attr, parser.href));
      }
      return _results;
    }
  };

  return Tran;

})();

module.exports = new Tran;


},{"./char-codes.js":3}],5:[function(require,module,exports){
"use strict";

var _prototypeProperties = function (child, staticProps, instanceProps) {
  if (staticProps) Object.defineProperties(child, staticProps);
  if (instanceProps) Object.defineProperties(child.prototype, instanceProps);
};

/*
  Translation engine: http://www.turkishdictionary.net
  For translating turkish-russian and vice versa
*/
var CHAR_CODES = require("./char-codes-turk.js");

var TurkishDictionary = (function () {
  function TurkishDictionary() {
    this.host = "http://www.turkishdictionary.net/?word=%FC";
    this.path = "";
    this.protocol = "http";
    this.query = "&s=";
    this.TABLE_CLASS = "___mtt_translate_table";
    // this flag indicates that if translation was successful then publish it all over extension
    this.need_publish = true;
  }

  _prototypeProperties(TurkishDictionary, null, {
    search: {
      value: function search(data) {
        data.url = this.makeUrl(data.value);
        this.need_publish = false;
        return this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    translate: {
      value: function translate(data) {
        data.url = this.makeUrl(data.selectionText);
        this.need_publish = true;
        this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeUrl: {
      value: function makeUrl(text) {
        var text = this.getEncodedValue(text);
        return ["http://www.turkishdictionary.net/?word=", text].join("");
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    getEncodedValue: {


      // Replace special language characters to html codes
      value: function getEncodedValue(value) {
        // to find spec symbols we first encode them (raw search for that symbol doesn't wor)
        return this.makeStringTransferable(value);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeStringTransferable: {

      /** converting script from the turkishdict */
      value: function makeStringTransferable(inputText) {
        var text = "";
        if (inputText.length > 0) {
          text = inputText;
          for (var i = 0; i < text.length; i++) {
            if (CHAR_CODES[text.charCodeAt(i)]) {
              text = text.substring(0, i) + CHAR_CODES[text.charCodeAt(i)] + text.substring(i + 1, text.length);
            } else if (text.charAt(i) == " ") {
              // replace spaces
              text = text.substring(0, i) + "___" + text.substring(i + 1, text.length);
            }
          }
        }
        return text;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    request: {

      /*
        Request translation and run callback function
        passing translated result or error to callback
      */
      value: function request(opts) {
        console.log("start request");
        this.xhr = new XMLHttpRequest();
        this.xhr.onreadystatechange = this.onReadyStateChange.bind(this, opts);
        this.xhr.open("GET", opts.url, true);
        this.xhr.send();
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    onReadyStateChange: {
      value: function onReadyStateChange(opts, e) {
        var xhr = this.xhr;
        if (xhr.readyState < 4) {
          return;
        } else if (xhr.status != 200) {
          this.errorHandler(xhr);
          return opts.error && opts.error();
        } else if (xhr.readyState == 4) {
          var translation = this.successHandler(e.target.response);
          console.log("success turkish translate", translation);
          console.log("call", opts.success);
          return opts.success && opts.success(translation);
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    successHandler: {
      value: function successHandler(response) {
        var data = this.parse(response);
        if (this.need_publish) {
          chrome.tabs.getSelected(null, this.publishTranslation.bind(this, data));
        }
        return data;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    publishTranslation: {

      /* publish successfuly translated text all over extension */
      value: function publishTranslation(translation, tab) {
        console.log("publish translation");
        chrome.tabs.sendMessage(tab.id, {
          action: this.tooltipAction(translation),
          data: translation.outerHTML,
          success: !translation.classList.contains("failTranslate")
        });
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    tooltipAction: {
      value: function tooltipAction(translation) {
        if (translation.textContent.trim().indexOf("was not found in our dictionary") != -1) {
          console.log("similar words");
          return "similar_words";
        } else {
          console.log("open tooltip");
          return "open_tooltip";
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    errorHandler: {
      value: function errorHandler(response) {
        console.log("error ajax", response);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parse: {

      /* Parse response from translation engine */
      value: function parse(response, silent, translate) {
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);
        if (fragment) {
          translate = fragment.querySelector("#meaning_div > table");
          if (translate) {
            translate.className = this.TABLE_CLASS;
            translate.setAttribute("cellpadding", "5");
            // @fixImages(translate)
            // @fixLinks(translate)
          } else if (!silent) {
            translate = document.createElement("div");
            translate.className = "failTranslate";
            translate.innerText = "Unfortunately, could not translate";
          }
        }
        return translate;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parseText: {

      /** parsing of terrible html markup */
      value: function parseText(response, silent, translate) {
        var _this = this;
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);

        if (fragment) {
          var i;
          var _ret = (function () {
            var stopIndex = null;
            var tr = fragment.querySelectorAll("#meaning_div>table>tbody>tr");
            tr = Array.prototype.slice.call(tr);

            var trans = tr.filter(function (tr, index) {
              if (!isNaN(parseInt(stopIndex, 10)) && index >= stopIndex) {
                return;
              } else {
                tr = $(tr);
                // take every row before next section (which is English->English)
                if (tr.attr("bgcolor") == "e0e6ff") {
                  stopIndex = index;return;
                } else {
                  return $.trim(tr.find("td").text()).length;
                }
              }
            });
            trans = trans.slice(1, trans.length - 1);
            trans = trans.filter(function (el, indx) {
              return indx % 2;
            });
            var frag = _this.fragmentFromList(trans);
            var fonts = frag.querySelectorAll("font");
            var text = "";
            for (i = 0; i < fonts.length; i++) {
              text += " " + fonts[i].textContent.trim();
            }
            return {
              v: text
            };
          })();

          if (typeof _ret === "object") return _ret.v;
        } else {
          throw "HTML fragment could not be parsed";
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    stripScripts: {

      //TODO extract to base engine class
      /* removes <script> tags from html code */
      value: function stripScripts(html) {
        var div = document.createElement("div");
        div.innerHTML = html;
        var scripts = div.getElementsByTagName("script");
        var i = scripts.length;
        while (i--) scripts[i].parentNode.removeChild(scripts[i]);
        return div.innerHTML;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeFragment: {

      //TODO extract to base engine class
      /* creates temp object to parse translation from page 
        (since it's not a friendly api) 
      */
      value: function makeFragment(html) {
        var fragment = document.createDocumentFragment(),
            div = document.createElement("div");
        div.innerHTML = html;
        while (div.firstChild) {
          fragment.appendChild(div.firstChild);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    fragmentFromList: {

      /** create fragment from list of DOM elements */
      value: function fragmentFromList(list) {
        var fragment = document.createDocumentFragment(),
            len = list.length;
        while (len--) {
          fragment.appendChild(list[len]);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    }
  });

  return TurkishDictionary;
})();

// Singletone
module.exports = new TurkishDictionary();
},{"./char-codes-turk.js":2}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvYmFja2dyb3VuZC5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXZlbG9wbWVudC90cmFuL2pzL2NoYXItY29kZXMtdHVyay5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvY2hhci1jb2Rlcy5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvdHJhbi5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXZlbG9wbWVudC90cmFuL2pzL3R1cmtpc2hkaWN0aW9uYXJ5LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFBQSx3QkFBQTtBQUFBLElBQUEsbUNBQUE7O0FBQUEsVUFHQSxHQUFhLE9BQUEsQ0FBUSxpQkFBUixDQUhiLENBQUE7O0FBQUEsSUFLQSxHQUFPLE9BQUEsQ0FBUSxlQUFSLENBTFAsQ0FBQTs7QUFBQSxpQkFNQSxHQUFvQixPQUFBLENBQVEsd0JBQVIsQ0FOcEIsQ0FBQTs7QUFBQSxNQVNNLENBQUMsWUFBWSxDQUFDLE1BQXBCLENBQ0U7QUFBQSxFQUFBLEtBQUEsRUFBUSxpQkFBUjtBQUFBLEVBQ0EsUUFBQSxFQUFVLENBQUMsTUFBRCxFQUFTLE9BQVQsRUFBa0IsVUFBbEIsRUFBOEIsT0FBOUIsRUFBdUMsT0FBdkMsRUFBZ0QsT0FBaEQsRUFBeUQsTUFBekQsRUFBaUUsV0FBakUsQ0FEVjtBQUFBLEVBRUEsT0FBQSxFQUFVLFNBQUMsSUFBRCxHQUFBO0FBQ1IsSUFBQSxJQUFJLENBQUMsTUFBTCxHQUFjLEtBQWQsQ0FBQTtXQUNBLElBQUksQ0FBQyxLQUFMLENBQVcsSUFBWCxFQUZRO0VBQUEsQ0FGVjtDQURGLENBVEEsQ0FBQTs7QUFpQkE7QUFBQTs7OztHQWpCQTs7QUFBQSxNQXNCTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsV0FBekIsQ0FBcUMsU0FBQyxPQUFELEVBQVUsTUFBVixFQUFrQixZQUFsQixHQUFBO0FBQ25DLEVBQUEsSUFBRyxPQUFPLENBQUMsTUFBUixLQUFrQixpQkFBckI7QUFDRSxJQUFBLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsTUFBQSxJQUFBLEVBQU0sSUFBTjtLQUF4QixFQUFvQyxTQUFDLEtBQUQsR0FBQTthQUNoQyxZQUFBLENBQWE7QUFBQSxRQUFBLElBQUEsRUFBTSxLQUFLLENBQUMsSUFBWjtPQUFiLEVBRGdDO0lBQUEsQ0FBcEMsQ0FBQSxDQURGO0dBQUEsTUFPSyxJQUFHLE9BQU8sQ0FBQyxNQUFSLEtBQWtCLGdCQUFyQjtBQUNILElBQUEsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBcEIsQ0FBd0I7QUFBQSxNQUFFLFFBQUEsRUFBVSxHQUFaO0FBQUEsTUFBaUIsSUFBQSxFQUFNLElBQXZCO0tBQXhCLEVBQXNELFNBQUMsS0FBRCxHQUFBO0FBQ3BELE1BQUEsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFiLEdBQXNCLElBQXRCLENBQUE7QUFDQSxNQUFBLElBQUcsUUFBQSxDQUFTLEtBQUssQ0FBQyxRQUFmLEVBQXdCLEVBQXhCLENBQUEsS0FBK0IsSUFBbEM7QUFDRSxRQUFBLGlCQUFpQixDQUFDLFNBQWxCLENBQTRCLE9BQU8sQ0FBQyxJQUFwQyxDQUFBLENBREY7T0FBQSxNQUFBO0FBR0UsUUFBQSxJQUFJLENBQUMsS0FBTCxDQUFXLE9BQU8sQ0FBQyxJQUFuQixDQUFBLENBSEY7T0FEQTtBQUtBLGFBQU8sSUFBUCxDQU5vRDtJQUFBLENBQXRELENBQUEsQ0FERztHQVBMO1NBZ0JBLEtBakJtQztBQUFBLENBQXJDLENBdEJBLENBQUE7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDakJBOztBQ0FBO0FBQUEsa0JBQUE7QUFDQTtBQUFBOzs7Ozs7Ozs7O0dBREE7QUFBQSxJQUFBLGdCQUFBOztBQUFBLFVBYUEsR0FBYSxPQUFBLENBQVEsaUJBQVIsQ0FiYixDQUFBOztBQUFBO0FBZ0JlLEVBQUEsY0FBQSxHQUFBO0FBQ1gsSUFBQSxJQUFDLENBQUEsV0FBRCxHQUFlLHdCQUFmLENBQUE7QUFBQSxJQUNBLElBQUMsQ0FBQSxRQUFELEdBQVksTUFEWixDQUFBO0FBQUEsSUFFQSxJQUFDLENBQUEsSUFBRCxHQUFRLGtCQUZSLENBQUE7QUFBQSxJQUdBLElBQUMsQ0FBQSxJQUFELEdBQVEsVUFIUixDQUFBO0FBQUEsSUFJQSxJQUFDLENBQUEsS0FBRCxHQUFTLEtBSlQsQ0FBQTtBQUFBLElBS0EsSUFBQyxDQUFBLElBQUQsR0FBUSxZQUxSLENBQUE7QUFBQSxJQU1BLElBQUMsQ0FBQSxHQUFELEdBQU8sRUFOUCxDQURXO0VBQUEsQ0FBYjs7QUFTQTtBQUFBOztLQVRBOztBQUFBLGlCQVlBLEtBQUEsR0FBTyxTQUFDLElBQUQsR0FBQTtBQUNMLFFBQUEsYUFBQTtBQUFBLElBQUEsSUFBRyxNQUFBLENBQUEsSUFBVyxDQUFDLE1BQVosS0FBc0IsTUFBdEIsSUFBbUMsSUFBSSxDQUFDLE1BQUwsS0FBZSxJQUFyRDtBQUNFLE1BQUEsSUFBSSxDQUFDLE1BQUwsR0FBYyxJQUFkLENBREY7S0FBQTtBQUFBLElBRUEsYUFBQSxHQUFnQixJQUFDLENBQUEsaUJBQUQsQ0FBbUIsSUFBSSxDQUFDLGFBQXhCLENBRmhCLENBQUE7V0FHQSxJQUFDLENBQUEsTUFBRCxDQUNJO0FBQUEsTUFBQSxLQUFBLEVBQU8sYUFBUDtBQUFBLE1BQ0EsT0FBQSxFQUFTLElBQUMsQ0FBQSxlQUFlLENBQUMsSUFBakIsQ0FBc0IsSUFBdEIsQ0FEVDtBQUFBLE1BRUEsTUFBQSxFQUFRLElBQUksQ0FBQyxNQUZiO0tBREosRUFKSztFQUFBLENBWlAsQ0FBQTs7QUFxQkE7QUFBQTs7S0FyQkE7O0FBQUEsaUJBd0JBLGlCQUFBLEdBQW1CLFNBQUMsSUFBRCxHQUFBO1dBQ2pCLElBQUksQ0FBQyxPQUFMLENBQWEsT0FBYixFQUFzQixFQUF0QixFQURpQjtFQUFBLENBeEJuQixDQUFBOztBQTJCQTtBQUFBOztLQTNCQTs7QUFBQSxpQkE4QkEsTUFBQSxHQUFRLFNBQUMsTUFBRCxHQUFBO1dBRU4sTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBcEIsQ0FBd0I7QUFBQSxNQUFDLFFBQUEsRUFBVSxHQUFYO0tBQXhCLEVBQXlDLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLEtBQUQsR0FBQTtBQUN2QyxZQUFBLDBCQUFBO0FBQUEsUUFBQSxJQUFHLFFBQUEsS0FBWSxFQUFmO0FBQ0UsVUFBQSxRQUFBLEdBQVcsR0FBWCxDQURGO1NBQUE7QUFBQSxRQUVBLEtBQUMsQ0FBQSxXQUFELENBQWEsS0FBSyxDQUFDLFFBQW5CLENBRkEsQ0FBQTtBQUFBLFFBR0EsR0FBQSxHQUFNLEtBQUMsQ0FBQSxPQUFELENBQVMsTUFBTSxDQUFDLEtBQWhCLENBSE4sQ0FBQTtBQUFBLFFBS0EsV0FBQSxHQUFjLE1BQU0sQ0FBQyxPQUxyQixDQUFBO0FBQUEsUUFNQSxNQUFNLENBQUMsT0FBUCxHQUFpQixTQUFDLFFBQUQsR0FBQTtBQUNmLGNBQUEsVUFBQTtBQUFBLFVBQUEsVUFBQSxHQUFhLEtBQUMsQ0FBQSxLQUFELENBQU8sUUFBUCxFQUFpQixNQUFNLENBQUMsTUFBeEIsQ0FBYixDQUFBO2lCQUNBLFdBQUEsQ0FBWSxVQUFaLEVBRmU7UUFBQSxDQU5qQixDQUFBO2VBV0EsS0FBQyxDQUFBLE9BQUQsQ0FDRTtBQUFBLFVBQUEsR0FBQSxFQUFLLEdBQUw7QUFBQSxVQUNBLE9BQUEsRUFBUyxNQUFNLENBQUMsT0FEaEI7QUFBQSxVQUVBLEtBQUEsRUFBTyxNQUFNLENBQUMsS0FGZDtTQURGLEVBWnVDO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBekMsRUFGTTtFQUFBLENBOUJSLENBQUE7O0FBQUEsaUJBbURBLFdBQUEsR0FBYSxTQUFDLFFBQUQsR0FBQTtBQUNYLElBQUEsSUFBQyxDQUFBLGVBQUQsR0FBbUIsUUFBbkIsQ0FBQTtXQUNBLElBQUMsQ0FBQSxJQUFELEdBQVEsV0FBQSxHQUFjLFNBRlg7RUFBQSxDQW5EYixDQUFBOztBQXVEQTtBQUFBOzs7S0F2REE7O0FBQUEsaUJBMkRBLE9BQUEsR0FBUyxTQUFDLElBQUQsR0FBQTtBQUNQLFFBQUEsR0FBQTtBQUFBLElBQUEsR0FBQSxHQUFNLElBQUMsQ0FBQSxHQUFELEdBQVcsSUFBQSxjQUFBLENBQUEsQ0FBakIsQ0FBQTtBQUFBLElBQ0EsR0FBRyxDQUFDLGtCQUFKLEdBQXlCLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLENBQUQsR0FBQTtBQUN2QixRQUFBLEdBQUEsR0FBTSxLQUFDLENBQUEsR0FBUCxDQUFBO0FBQ0EsUUFBQSxJQUFHLEdBQUcsQ0FBQyxVQUFKLEdBQWlCLENBQXBCO0FBQUE7U0FBQSxNQUVLLElBQUcsR0FBRyxDQUFDLE1BQUosS0FBYyxHQUFqQjtBQUNILFVBQUEsS0FBQyxDQUFBLFlBQUQsQ0FBYyxHQUFkLENBQUEsQ0FBQTtBQUNBLFVBQUEsSUFBSSxNQUFBLENBQUEsSUFBVyxDQUFDLEtBQVosS0FBcUIsVUFBekI7QUFDRSxZQUFBLElBQUksQ0FBQyxLQUFMLENBQUEsQ0FBQSxDQURGO1dBRkc7U0FBQSxNQUtBLElBQUcsR0FBRyxDQUFDLFVBQUosS0FBa0IsQ0FBckI7QUFDRCxpQkFBTyxJQUFJLENBQUMsT0FBTCxDQUFhLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBdEIsQ0FBUCxDQURDO1NBVGtCO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FEekIsQ0FBQTtBQUFBLElBYUEsR0FBRyxDQUFDLElBQUosQ0FBUyxLQUFULEVBQWdCLElBQUksQ0FBQyxHQUFyQixFQUEwQixJQUExQixDQWJBLENBQUE7V0FjQSxHQUFHLENBQUMsSUFBSixDQUFBLEVBZk87RUFBQSxDQTNEVCxDQUFBOztBQUFBLGlCQTZFQSxPQUFBLEdBQVMsU0FBQyxLQUFELEdBQUE7QUFDUCxRQUFBLEdBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxDQUFDLElBQUMsQ0FBQSxRQUFGLEVBQVksS0FBWixFQUNJLElBQUMsQ0FBQSxJQURMLEVBRUksSUFBQyxDQUFBLElBRkwsRUFHSSxJQUFDLENBQUEsSUFITCxFQUlJLElBQUMsQ0FBQSxLQUpMLEVBS0ksSUFBQyxDQUFBLGVBQUQsQ0FBaUIsS0FBakIsQ0FMSixDQU1DLENBQUMsSUFORixDQU1PLEVBTlAsQ0FBTixDQUFBO0FBUUEsV0FBTyxHQUFQLENBVE87RUFBQSxDQTdFVCxDQUFBOztBQUFBLGlCQXlGQSxlQUFBLEdBQWlCLFNBQUMsS0FBRCxHQUFBO0FBRWYsUUFBQSxtQkFBQTtBQUFBLElBQUEsR0FBQSxHQUFNLGtCQUFBLENBQW1CLEtBQW5CLENBQU4sQ0FBQTtBQUNBLFNBQUEsa0JBQUE7OEJBQUE7QUFDRSxNQUFBLElBQUcsTUFBQSxDQUFBLElBQUEsS0FBZSxRQUFsQjtBQUVFLFFBQUEsRUFBQSxHQUFLLElBQUksQ0FBQyxHQUFWLENBRkY7T0FBQSxNQUFBO0FBTUUsUUFBQSxFQUFBLEdBQUssa0JBQUEsQ0FBbUIsSUFBbkIsQ0FBTCxDQU5GO09BQUE7QUFBQSxNQU9BLEdBQUEsR0FBTSxHQUFHLENBQUMsT0FBSixDQUFZLElBQVosRUFBa0IsRUFBbEIsQ0FQTixDQURGO0FBQUEsS0FEQTtBQVVBLFdBQU8sR0FBUCxDQVplO0VBQUEsQ0F6RmpCLENBQUE7O0FBQUEsaUJBdUdBLFlBQUEsR0FBYyxTQUFDLEdBQUQsR0FBQTtXQUNaLE9BQU8sQ0FBQyxHQUFSLENBQVksT0FBWixFQUFxQixHQUFyQixFQURZO0VBQUEsQ0F2R2QsQ0FBQTs7QUEwR0E7QUFBQTs7S0ExR0E7O0FBQUEsaUJBNkdBLGVBQUEsR0FBaUIsU0FBQyxVQUFELEdBQUE7QUFDZixJQUFBLElBQUcsVUFBSDthQUNFLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBWixDQUF3QixJQUF4QixFQUE4QixDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxHQUFELEdBQUE7aUJBQzVCLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBWixDQUF3QixHQUFHLENBQUMsRUFBNUIsRUFBZ0M7QUFBQSxZQUM5QixNQUFBLEVBQVEsS0FBQyxDQUFBLFdBQUQsQ0FBYSxVQUFiLENBRHNCO0FBQUEsWUFFOUIsSUFBQSxFQUFNLFVBQVUsQ0FBQyxTQUZhO0FBQUEsWUFHOUIsT0FBQSxFQUFTLENBQUEsVUFBVyxDQUFDLFNBQVMsQ0FBQyxRQUFyQixDQUE4QixlQUE5QixDQUhvQjtXQUFoQyxFQUQ0QjtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQTlCLEVBREY7S0FEZTtFQUFBLENBN0dqQixDQUFBOztBQUFBLGlCQXVIQSxXQUFBLEdBQWEsU0FBQyxVQUFELEdBQUE7QUFDWCxRQUFBLElBQUE7QUFBQSxJQUFBLGlFQUFtQixDQUFFLHlCQUFsQixLQUE0QixDQUEvQjthQUNFLGdCQURGO0tBQUEsTUFBQTthQUdFLGVBSEY7S0FEVztFQUFBLENBdkhiLENBQUE7O0FBNkhBO0FBQUE7O0tBN0hBOztBQUFBLGlCQWdJQSxLQUFBLEdBQU8sU0FBQyxRQUFELEVBQVcsTUFBWCxFQUFtQixTQUFuQixHQUFBO0FBQ0gsUUFBQSxhQUFBOztNQURzQixZQUFZO0tBQ2xDO0FBQUEsSUFBQSxHQUFBLEdBQU0sSUFBQyxDQUFBLFlBQUQsQ0FBYyxRQUFkLENBQU4sQ0FBQTtBQUFBLElBQ0EsUUFBQSxHQUFXLElBQUMsQ0FBQSxZQUFELENBQWMsR0FBZCxDQURYLENBQUE7QUFFQSxJQUFBLElBQUcsUUFBSDtBQUNFLE1BQUEsU0FBQSxHQUFZLFFBQVEsQ0FBQyxhQUFULENBQXVCLHNCQUF2QixDQUFaLENBQUE7QUFDQSxNQUFBLElBQUcsU0FBSDtBQUNFLFFBQUEsU0FBUyxDQUFDLFNBQVYsR0FBc0IsSUFBQyxDQUFBLFdBQXZCLENBQUE7QUFBQSxRQUNBLFNBQVMsQ0FBQyxZQUFWLENBQXVCLGFBQXZCLEVBQXNDLEdBQXRDLENBREEsQ0FBQTtBQUFBLFFBRUEsSUFBQyxDQUFBLFNBQUQsQ0FBVyxTQUFYLENBRkEsQ0FBQTtBQUFBLFFBR0EsSUFBQyxDQUFBLFFBQUQsQ0FBVSxTQUFWLENBSEEsQ0FERjtPQUFBLE1BS0ssSUFBRyxDQUFBLE1BQUg7QUFDSCxRQUFBLFNBQUEsR0FBWSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFaLENBQUE7QUFBQSxRQUNBLFNBQVMsQ0FBQyxTQUFWLEdBQXNCLGVBRHRCLENBQUE7QUFBQSxRQUVBLFNBQVMsQ0FBQyxTQUFWLEdBQXNCLG9DQUZ0QixDQURHO09BUFA7S0FGQTtBQWNBLFdBQU8sU0FBUCxDQWZHO0VBQUEsQ0FoSVAsQ0FBQTs7QUFpSkE7QUFBQTs7S0FqSkE7O0FBQUEsaUJBb0pBLFlBQUEsR0FBYyxTQUFDLENBQUQsR0FBQTtBQUNaLFFBQUEsZUFBQTtBQUFBLElBQUEsR0FBQSxHQUFNLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCLENBQU4sQ0FBQTtBQUFBLElBQ0EsR0FBRyxDQUFDLFNBQUosR0FBZ0IsQ0FEaEIsQ0FBQTtBQUFBLElBRUEsT0FBQSxHQUFVLEdBQUcsQ0FBQyxvQkFBSixDQUF5QixRQUF6QixDQUZWLENBQUE7QUFBQSxJQUdBLENBQUEsR0FBSSxPQUFPLENBQUMsTUFIWixDQUFBO0FBSUEsV0FBTSxDQUFBLEVBQU4sR0FBQTtBQUNFLE1BQUEsT0FBUSxDQUFBLENBQUEsQ0FBRSxDQUFDLFVBQVUsQ0FBQyxXQUF0QixDQUFrQyxPQUFRLENBQUEsQ0FBQSxDQUExQyxDQUFBLENBREY7SUFBQSxDQUpBO0FBTUEsV0FBTyxHQUFHLENBQUMsU0FBWCxDQVBZO0VBQUEsQ0FwSmQsQ0FBQTs7QUFBQSxpQkE2SkEsWUFBQSxHQUFjLFNBQUMsR0FBRCxFQUFNLFFBQU4sR0FBQTtBQUNaLFFBQUEsR0FBQTs7TUFEa0IsV0FBVztLQUM3QjtBQUFBLElBQUEsR0FBQSxHQUFNLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCLENBQU4sQ0FBQTtBQUFBLElBQ0EsR0FBRyxDQUFDLFNBQUosR0FBZ0IsR0FEaEIsQ0FBQTtBQUFBLElBRUEsUUFBQSxHQUFXLFFBQVEsQ0FBQyxzQkFBVCxDQUFBLENBRlgsQ0FBQTtBQUdBLFdBQVEsR0FBRyxDQUFDLFVBQVosR0FBQTtBQUNFLE1BQUEsUUFBUSxDQUFDLFdBQVQsQ0FBc0IsR0FBRyxDQUFDLFVBQTFCLENBQUEsQ0FERjtJQUFBLENBSEE7QUFLQSxXQUFPLFFBQVAsQ0FOWTtFQUFBLENBN0pkLENBQUE7O0FBQUEsaUJBcUtBLFNBQUEsR0FBVyxTQUFDLFFBQUQsR0FBQTs7TUFBQyxXQUFTO0tBQ25CO0FBQUEsSUFBQSxJQUFJLENBQUMsTUFBTCxDQUFZLFFBQVosRUFBc0IsS0FBdEIsRUFBNkIsS0FBN0IsQ0FBQSxDQUFBO0FBQ0EsV0FBTyxRQUFQLENBRlM7RUFBQSxDQXJLWCxDQUFBOztBQUFBLGlCQXlLQSxRQUFBLEdBQVUsU0FBQyxRQUFELEdBQUE7O01BQUMsV0FBUztLQUNsQjtBQUFBLElBQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxRQUFaLEVBQXNCLEdBQXRCLEVBQTJCLE1BQTNCLENBQUEsQ0FBQTtBQUNBLFdBQU8sUUFBUCxDQUZRO0VBQUEsQ0F6S1YsQ0FBQTs7QUFBQSxpQkE2S0EsTUFBQSxHQUFRLFNBQUMsUUFBRCxFQUFnQixHQUFoQixFQUFxQixJQUFyQixHQUFBO0FBQ04sUUFBQSxnQ0FBQTs7TUFETyxXQUFTO0tBQ2hCO0FBQUEsSUFBQSxJQUFHLFFBQUg7QUFDRSxNQUFBLElBQUEsR0FBUSxRQUFRLENBQUMsZ0JBQVQsQ0FBMEIsR0FBMUIsQ0FBUixDQUFBO0FBQUEsTUFDQSxNQUFBLEdBQVMsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsR0FBdkIsQ0FEVCxDQUFBO0FBRUE7V0FBQSwyQ0FBQTt1QkFBQTtBQUNFLFFBQUEsTUFBTSxDQUFDLElBQVAsR0FBYyxHQUFJLENBQUEsSUFBQSxDQUFsQixDQUFBO0FBQUEsUUFDQSxNQUFNLENBQUMsSUFBUCxHQUFjLElBQUMsQ0FBQSxJQURmLENBQUE7QUFBQSxRQUVBLE1BQU0sQ0FBQyxRQUFQLEdBQWtCLElBQUMsQ0FBQSxRQUZuQixDQUFBO0FBSUEsUUFBQSxJQUFHLEdBQUcsQ0FBQyxPQUFKLEtBQWUsR0FBbEI7QUFDRSxVQUFBLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBZCxDQUFrQixVQUFsQixDQUFBLENBQUE7QUFDQSxVQUFBLElBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFoQixDQUF3QixPQUF4QixDQUFBLEtBQXNDLENBQUEsQ0FBekM7QUFDRSxZQUFBLE1BQU0sQ0FBQyxRQUFQLEdBQWtCLElBQUEsR0FBTyxNQUFNLENBQUMsUUFBaEMsQ0FBQTtBQUFBLFlBQ0EsR0FBRyxDQUFDLFlBQUosQ0FBaUIsUUFBakIsRUFBMkIsUUFBM0IsQ0FEQSxDQURGO1dBRkY7U0FBQSxNQUtLLElBQUcsR0FBRyxDQUFDLE9BQUosS0FBZSxLQUFsQjtBQUNILFVBQUEsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFkLENBQWtCLFNBQWxCLENBQUEsQ0FERztTQVRMO0FBQUEsc0JBWUEsR0FBRyxDQUFDLFlBQUosQ0FBaUIsSUFBakIsRUFBdUIsTUFBTSxDQUFDLElBQTlCLEVBWkEsQ0FERjtBQUFBO3NCQUhGO0tBRE07RUFBQSxDQTdLUixDQUFBOztjQUFBOztJQWhCRixDQUFBOztBQUFBLE1Ba05NLENBQUMsT0FBUCxHQUFpQixHQUFBLENBQUEsSUFsTmpCLENBQUE7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpfXZhciBmPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChmLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGYsZi5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCIjIyNnbG9iYWwgdHJhbiwgY2hyb21lIyMjXG5cbiNsb2FkIGVuZ2luZXNcbkNIQVJfQ09ERVMgPSByZXF1aXJlKCcuL2NoYXItY29kZXMuanMnKTtcblxudHJhbiA9IHJlcXVpcmUoJy4vdHJhbi5jb2ZmZWUnKSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIyBtdWx0aXRyYW4ucnVcbnR1cmtpc2hEaWN0aW9uYXJ5ID0gcmVxdWlyZSgnLi90dXJraXNoZGljdGlvbmFyeS5qcycpICAgIyB0dXJraXNoZGljdGlvbmFyeS5uZXRcblxuI2dlbmVyYXRlcyBhIGNvbnRleHQgbWVudVxuY2hyb21lLmNvbnRleHRNZW51cy5jcmVhdGUoXG4gIHRpdGxlOiAgJ011bHRpdHJhbjogXCIlc1wiJ1xuICBjb250ZXh0czogW1wicGFnZVwiLCBcImZyYW1lXCIsIFwiZWRpdGFibGVcIiwgXCJpbWFnZVwiLCBcInZpZGVvXCIsIFwiYXVkaW9cIiwgXCJsaW5rXCIsIFwic2VsZWN0aW9uXCJdXG4gIG9uY2xpY2s6ICAoZGF0YSkgLT5cbiAgICBkYXRhLnNpbGVudCA9IGZhbHNlXG4gICAgdHJhbi5jbGljayhkYXRhKVxuKVxuXG4jIyNcbiBDYW4ndCBnZXQgY2hyb21lLnN0b3JhZ2UgZGlyZWN0bHkgZnJvbSBjb250ZW50X3NjcmlwdFxuIHNvIGNvbnRlbnRfc2NyaXB0IHNlbmRzIHJlcXVlc3QgbWVzc2FnZSBhbmQgdGhlbiBiYWNrZ3JvdW5kIHNjcmlwdFxuIHJlc3BvbmRzIHdpdGggc3RvcmFnZSB2YWx1ZVxuIyMjXG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIgKHJlcXVlc3QsIHNlbmRlciwgc2VuZFJlc3BvbnNlKSAtPlxuICBpZiByZXF1ZXN0Lm1ldGhvZCA9PSBcImdldF9mYXN0X29wdGlvblwiXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoZmFzdDogdHJ1ZSwgKGl0ZW1zKSAtPlxuICAgICAgICBzZW5kUmVzcG9uc2UoZmFzdDogaXRlbXMuZmFzdClcbiAgICAgICAgI3JldHVybiB0cnVlXG4gICAgKVxuICAjRmFzdCB0cmFuc2xhdGlvbiBpbml0aWF0ZSBzZWFyY2ggd2l0aCAncmVxdWVzdF9zZWFyY2gnIG1lc3NhZ2UgZnJvbVxuICAjY29udGVudF9zY3JpcHRcbiAgZWxzZSBpZiByZXF1ZXN0Lm1ldGhvZCA9PSAncmVxdWVzdF9zZWFyY2gnXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoeyBsYW5ndWFnZTogJzEnLCBmYXN0OiB0cnVlfSwgKGl0ZW1zKSAtPlxuICAgICAgcmVxdWVzdC5kYXRhLnNpbGVudCA9IHRydWVcbiAgICAgIGlmIHBhcnNlSW50KGl0ZW1zLmxhbmd1YWdlLDEwKSA9PSAxMDAwXG4gICAgICAgIHR1cmtpc2hEaWN0aW9uYXJ5LnRyYW5zbGF0ZShyZXF1ZXN0LmRhdGEpXG4gICAgICBlbHNlXG4gICAgICAgIHRyYW4uY2xpY2socmVxdWVzdC5kYXRhKVxuICAgICAgcmV0dXJuIHRydWVcbiAgICApXG4gIHRydWVcblxuIiwiLy8gdHVya2lzaGRpY3Rpb25hcnkgY29kaW5nc1xudmFyIERJQ1QgPSB7XG4gICAgMzA0OiAnJUREJywgLy9pXG4gICAgMzUwOiAnJURFJywgLy9TXG4gICAgMjg2OiAnJUQwJywgLy9HXG4gICAgMjg3OiAnJUYwJywgLy9HXG4gICAgMzUxOiAnJUZFJywgLy9TXG4gICAgMzA1OiAnJUZEJywgLy9JXG4gICAgMjUyOiAnJUZDJywgLy/DvFxuICAgIDIyMDogJyVEQycsIC8vw5xcbiAgICAyMzE6ICclRTcnLCAvL8OnXG4gICAgMTk5OiAnJUM3JywgLy/Dh1xuICAgIDI0NjogJyVGNicsIC8vw7ZcbiAgICAyMTQ6ICclRDYnLCAvL8OWXG4gICAgMzk6ICcnLCAgLy8nXG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IERJQ1Q7IiwiLypcciAgTXVsdGl0cmFuIGRlcGVuZHMgb24gaHRtbC1lc2NhcGluZyAobm90IFVURi04KSBydWxlcyBmb3Igc3BlY2lhbCBzeW1ib2xzXHIgIMOgLCDDqCwgw6wsIMOyLCDDuSAtIMOALCDDiCwgw4wsIMOSLCDDmVxyICDDoSwgw6ksIMOtLCDDsywgw7osIMO9IC0gw4EsIMOJLCDDjSwgw5MsIMOaLCDDnVxyICDDoiwgw6osIMOuLCDDtCwgw7sgw4IsIMOKLCDDjiwgw5QsIMObXHIgIMOjLCDDsSwgw7Ugw4MsIMORLCDDlVxyICDDpCwgw6ssIMOvLCDDtiwgw7wsIMO/IMOELCDDiywgw48sIMOWLCDDnCxcciAgw6UsIMOFXHIgIMOmLCDDhlxyICDDpywgw4dcciAgw7AsIMOQXHIgIMO4LCDDmFxyICDCvyDCoSDDn1xyKi9ccnZhciBDSEFSX0NPREVTID0ge1xyICAvL3J1c3NpYW5cciAgJyVEMSU4QSc6IHt2YWw6JyVGQScsIGxhbmc6J3J1J30sIC8vINGKXHIgICclRDAlQUEnOiB7dmFsOiclREEnLCBsYW5nOidydSd9LC8vINCqXHJcciAgJyVDMyU4MCc6ICcmIzE5MjsnLCAvLyDDgFxyICAnJUMzJTgxJzogJyYjMTkzOycsIC8vIMOBXHIgICclQzMlODInOiAnJiMxOTQ7JywgLy8gw4JcciAgJyVDMyU4Myc6ICcmIzE5NTsnLCAvLyDDg1xyICAnJUMzJTg0JzogJyYjMTk2OycsIC8vIMOEXHIgICclQzMlODUnOiAnJiMxOTc7JywgLy8gw4VcciAgJyVDMyU4Nic6ICcmIzE5ODsnLCAvLyDDhlxyXHIgICclQzMlODcnOiAnJiMxOTk7JywgLy8gw4dcciAgJyVDMyU4OCc6ICcmIzIwMDsnLCAvLyDDiFxyICAnJUMzJTg5JzogJyYjMjAxOycsIC8vIMOJXHIgICclQzMlOEEnOiAnJiMyMDI7JywgLy8gw4pcciAgJyVDMyU4Qic6ICcmIzIwMzsnLCAvLyDDi1xyXHIgICclQzMlOEMnOiAnJiMyMDQ7JywgLy8gw4xcciAgJyVDMyU4RCc6ICcmIzIwNTsnLCAvLyDDjVxyICAnJUMzJThFJzogJyYjMjA2OycsIC8vIMOOXHIgICclQzMlOEYnOiAnJiMyMDc7JywgLy8gw49cclxyICAnJUMzJTkxJzogJyYjMjA5OycsIC8vIMORXHIgICclQzMlOTInOiAnJiMyMTA7JywgLy8gw5JcciAgJyVDMyU5Myc6ICcmIzIxMTsnLCAvLyDDk1xyICAnJUMzJTk0JzogJyYjMjEyOycsIC8vIMOUXHIgICclQzMlOTUnOiAnJiMyMTM7JywgLy8gw5VcciAgJyVDMyU5Nic6ICcmIzIxNDsnLCAvLyDDllxyXHIgICclQzMlOTknOiAnJiMyMTc7JywgLy8gw5lcciAgJyVDMyU5QSc6ICcmIzIxODsnLCAvLyDDmlxyICAnJUMzJTlCJzogJyYjMjE5OycsIC8vIMObXHIgICclQzMlOUMnOiAnJiMyMjA7JywgLy8gw5xcclxyXHIgICclQzMlQTAnOiAnJiMyMjQ7JywgLy8gw6BcciAgJyVDMyVBMSc6ICcmIzIyNTsnLCAvLyDDoVxyICAnJUMzJUEyJzogJyYjMjI2OycsIC8vIMOiXHIgICclQzMlQTMnOiAnJiMyMjc7JywgLy8gw6NcciAgJyVDMyVBNCc6ICcmIzIyODsnLCAvLyDDpFxyICAnJUMzJUE1JzogJyYjMjI5OycsIC8vIMOlXHIgICclQzMlQTYnOiAnJiMyMzA7JywgLy8gw6ZcciAgJyVDMyVBNyc6ICcmIzIzMTsnLCAvLyDDp1xyXHJcciAgJyVDMyVBOCc6ICcmIzIzMjsnLCAvLyDDqFxyICAnJUMzJUE5JzogJyYjMjMzOycsIC8vIMOpXHIgICclQzMlQUEnOiAnJiMyMzQ7JywgLy8gw6pcciAgJyVDMyVBQic6ICcmIzIzNTsnLCAvLyDDq1xyXHIgICclQzMlQUMnOiAnJiMyMzY7JywgLy8gw6xcciAgJyVDMyVBRCc6ICcmIzIzNzsnLCAvLyDDrVxyICAnJUMzJUFFJzogJyYjMjM4OycsIC8vIMOuXHIgICclQzMlQUYnOiAnJiMyMzk7JywgLy8gw69cclxyICAnJUMzJUIwJzogJyYjMjQwOycsIC8vIMOwXHIgICclQzMlQjEnOiAnJiMyNDE7JywgLy8gw7FcclxyICAnJUMzJUIyJzogJyYjMjQyOycsIC8vIMOyXHIgICclQzMlQjMnOiAnJiMyNDM7JywgLy8gw7NcciAgJyVDMyVCNCc6ICcmIzI0NDsnLCAvLyDDtFxyICAnJUMzJUI1JzogJyYjMjQ1OycsIC8vIMO1XHIgICclQzMlQjYnOiAnJiMyNDY7JywgLy8gw7ZcclxyICAnJUMzJUI5JzogJyYjMjQ5OycsIC8vIMO5XHIgICclQzMlQkEnOiAnJiMyNTA7JywgLy8gw7pcciAgJyVDMyVCQic6ICcmIzI1MTsnLCAvLyDDu1xyICAnJUMzJUJDJzogJyYjMjUyOycsIC8vIMO8XHIgICclQzMlQkYnOiAnJiMyNTU7JywgLy8gw79cciAgJyVDNSVCOCc6ICcmIzM3NjsnLCAvLyDFuFxyXHIgICclQzMlOUYnOiAnJiMyMjM7JywgLy8gw59cclxyICAnJUMyJUJGJzogJyYjMTkxOycsIC8vIMK/XHIgICclQzIlQTEnOiAnJiMxNjE7JywgLy8gwqFccn07XHJccm1vZHVsZS5leHBvcnRzID0gQ0hBUl9DT0RFUztcciIsIiMjI2dsb2JhbCBjaHJvbWUjIyNcbiMjI1xuICBNdWx0aXRyYW4ucnUgdHJhbnNsYXRlIGVuZ2luZVxuICBQcm92aWRlcyBwcm9ncmFtIGludGVyZmFjZSBmb3IgbWFraW5nIHRyYW5zbGF0ZSBxdWVyaWVzIHRvIG11bHRpdHJhbiBhbmQgZ2V0IGNsZWFuIHJlc3BvbnNlXG5cbiAgQWxsIGVuZ2luZXMgbXVzdCBmb2xsb3cgY29tbW9uIGludGVyZmFjZSBhbmQgcHJvdmlkZSBtZXRob2RzOlxuICAgIC0gc2VhcmNoIChsYW5ndWFuZ2UsIHN1Y2Nlc3NIYW5kbGVyKSAgY2xlYW4gdHJhbnNsYXRpb24gbXVzdCBiZSBwYXNzZWQgaW50byBzdWNjZXNzSGFuZGxlclxuICAgIC0gY2xpY2tcblxuICBUcmFuc2xhdGlvbi1tb2R1bGUgdGhhdCBtYWtlcyByZXF1ZXN0cyB0byBsYW5ndWFnZS1lbmdpbmUsXG4gIHBhcnNlcyByZXN1bHRzIGFuZCBzZW5kcyBwbHVnaW4tZ2xvYmFsIG1lc3NhZ2Ugd2l0aCB0cmFuc2xhdGlvbiBkYXRhXG4jIyNcblxuQ0hBUl9DT0RFUyA9IHJlcXVpcmUoJy4vY2hhci1jb2Rlcy5qcycpO1xuXG5jbGFzcyBUcmFuXG4gIGNvbnN0cnVjdG9yOiAtPlxuICAgIEBUQUJMRV9DTEFTUyA9IFwiX19fbXR0X3RyYW5zbGF0ZV90YWJsZVwiXG4gICAgQHByb3RvY29sID0gJ2h0dHAnXG4gICAgQGhvc3QgPSAnd3d3Lm11bHRpdHJhbi5ydSdcbiAgICBAcGF0aCA9ICcvYy9tLmV4ZSdcbiAgICBAcXVlcnkgPSAnJnM9J1xuICAgIEBsYW5nID0gJz9sMT0yJmwyPTEnICNmcm9tIHJ1c3NpYW4gdG8gZW5nbGlzaCBieSBkZWZhdWx0XG4gICAgQHhociA9IHt9XG5cbiAgIyMjXG4gICAgQ29udGV4dCBtZW51IGNsaWNrIGhhbmRsZXJcbiAgIyMjXG4gIGNsaWNrOiAoZGF0YSkgLT5cbiAgICBpZiB0eXBlb2YgZGF0YS5zaWxlbnQgPT0gdW5kZWZpbmVkIHx8IGRhdGEuc2lsZW50ID09IG51bGxcbiAgICAgIGRhdGEuc2lsZW50ID0gdHJ1ZSAjIHRydWUgYnkgZGVmYXVsdFxuICAgIHNlbGVjdGlvblRleHQgPSBAcmVtb3ZlSHlwaGVuYXRpb24gZGF0YS5zZWxlY3Rpb25UZXh0XG4gICAgQHNlYXJjaFxuICAgICAgICB2YWx1ZTogc2VsZWN0aW9uVGV4dFxuICAgICAgICBzdWNjZXNzOiBAc3VjY2Vzc3RIYW5kbGVyLmJpbmQodGhpcylcbiAgICAgICAgc2lsZW50OiBkYXRhLnNpbGVudCAgIyBpZiB0cmFuc2xhdGlvbiBmYWlsZWQgZG8gbm90IHNob3cgZGlhbG9nXG5cbiAgIyMjXG4gICAgRGlzY2FyZCBzb2Z0IGh5cGhlbiBjaGFyYWN0ZXIgKFUrMDBBRCwgJnNoeTspIGZyb20gdGhlIGlucHV0XG4gICMjI1xuICByZW1vdmVIeXBoZW5hdGlvbjogKHRleHQpIC0+XG4gICAgdGV4dC5yZXBsYWNlIC9cXHhhZC9nLCAnJ1xuXG4gICMjI1xuICAgIEluaXRpYXRlIHRyYW5zbGF0aW9uIHNlYXJjaFxuICAjIyNcbiAgc2VhcmNoOiAocGFyYW1zKSAtPlxuICAgICN2YWx1ZSwgY2FsbGJhY2ssIGVyclxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHtsYW5ndWFnZTogJzEnfSwgKGl0ZW1zKSA9PlxuICAgICAgaWYgbGFuZ3VhZ2UgaXMgJydcbiAgICAgICAgbGFuZ3VhZ2UgPSAnMSdcbiAgICAgIEBzZXRMYW5ndWFnZShpdGVtcy5sYW5ndWFnZSlcbiAgICAgIHVybCA9IEBtYWtlVXJsKHBhcmFtcy52YWx1ZSk7XG4gICAgICAjIGRlY29yYXRlIHN1Y2Nlc3MgdG8gbWFrZSBwcmVsaW1pbmFyeSBwYXJzaW5nXG4gICAgICBvcmlnU3VjY2VzcyA9IHBhcmFtcy5zdWNjZXNzXG4gICAgICBwYXJhbXMuc3VjY2VzcyA9IChyZXNwb25zZSkgPT5cbiAgICAgICAgdHJhbnNsYXRlZCA9IEBwYXJzZShyZXNwb25zZSwgcGFyYW1zLnNpbGVudClcbiAgICAgICAgb3JpZ1N1Y2Nlc3ModHJhbnNsYXRlZClcblxuICAgICAgIyBtYWtlIHJlcXVlc3QgKEdFVCByZXF1ZXN0IHdpdGggcXVlcnkgcGFyYW1ldGVycyBpbiB1cmwpXG4gICAgICBAcmVxdWVzdChcbiAgICAgICAgdXJsOiB1cmwsXG4gICAgICAgIHN1Y2Nlc3M6IHBhcmFtcy5zdWNjZXNzLFxuICAgICAgICBlcnJvcjogcGFyYW1zLmVycm9yXG4gICAgICApXG4gICAgKVxuXG4gIHNldExhbmd1YWdlOiAobGFuZ3VhZ2UpIC0+XG4gICAgQGN1cnJlbnRMYW5ndWFnZSA9IGxhbmd1YWdlXG4gICAgQGxhbmcgPSAnP2wxPTImbDI9JyArIGxhbmd1YWdlXG5cbiAgIyMjXG4gICAgUmVxdWVzdCB0cmFuc2xhdGlvbiBhbmQgcnVuIGNhbGxiYWNrIGZ1bmN0aW9uXG4gICAgcGFzc2luZyB0cmFuc2xhdGVkIHJlc3VsdCBvciBlcnJvciB0byBjYWxsYmFja1xuICAjIyNcbiAgcmVxdWVzdDogKG9wdHMpIC0+XG4gICAgeGhyID0gQHhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpXG4gICAgeGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IChlKSA9PlxuICAgICAgeGhyID0gQHhoclxuICAgICAgaWYgeGhyLnJlYWR5U3RhdGUgPCA0XG4gICAgICAgIHJldHVyblxuICAgICAgZWxzZSBpZiB4aHIuc3RhdHVzICE9IDIwMFxuICAgICAgICBAZXJyb3JIYW5kbGVyKHhocilcbiAgICAgICAgaWYgKHR5cGVvZiBvcHRzLmVycm9yID09ICdmdW5jdGlvbicpXG4gICAgICAgICAgb3B0cy5lcnJvcigpXG4gICAgICAgIHJldHVyblxuICAgICAgZWxzZSBpZiB4aHIucmVhZHlTdGF0ZSA9PSA0XG4gICAgICAgICAgcmV0dXJuIG9wdHMuc3VjY2VzcyhlLnRhcmdldC5yZXNwb25zZSlcblxuICAgIHhoci5vcGVuKFwiR0VUXCIsIG9wdHMudXJsLCB0cnVlKTtcbiAgICB4aHIuc2VuZCgpO1xuXG5cbiAgbWFrZVVybDogKHZhbHVlKSAtPlxuICAgIHVybCA9IFtAcHJvdG9jb2wsICc6Ly8nLFxuICAgICAgICAgICAgICBAaG9zdCxcbiAgICAgICAgICAgICAgQHBhdGgsXG4gICAgICAgICAgICAgIEBsYW5nLFxuICAgICAgICAgICAgICBAcXVlcnksXG4gICAgICAgICAgICAgIEBnZXRFbmNvZGVkVmFsdWUodmFsdWUpXG4gICAgICAgICAgXS5qb2luKCcnKVxuXG4gICAgcmV0dXJuIHVybDtcblxuICAjIFJlcGxhY2Ugc3BlY2lhbCBsYW5ndWFnZSBjaGFyYWN0ZXJzIHRvIGh0bWwgY29kZXNcbiAgZ2V0RW5jb2RlZFZhbHVlOiAodmFsdWUpIC0+XG4gICAgIyB0byBmaW5kIHNwZWMgc3ltYm9scyB3ZSBmaXJzdCBlbmNvZGUgdGhlbSAocmF3IHNlYXJjaCBmb3IgdGhhdCBzeW1ib2wgZG9lc24ndCB3b3IpXG4gICAgdmFsID0gZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKVxuICAgIGZvciBjaGFyLCBjb2RlIG9mIENIQVJfQ09ERVNcbiAgICAgIGlmIHR5cGVvZiBjb2RlID09ICdvYmplY3QnXG4gICAgICAgICMgcnVzc2lhbiBoYXMgc3BlY2lhbCBjb2Rlc1xuICAgICAgICBjYyA9IGNvZGUudmFsXG4gICAgICBlbHNlXG4gICAgICAgICMgZm9yIGFsbCBsYW5ncyBleGNlcHQgcnVzc2lhbiBlbmNvZGUgaHRtbC1jb2RlcyBuZWVkZWRcbiAgICAgICAgIyDQtNC70Y8g0LLRgdC10YUg0L7RgdGC0LDQu9GM0L3Ri9GFINGP0LfRi9C60L7QslxuICAgICAgICBjYyA9IGVuY29kZVVSSUNvbXBvbmVudChjb2RlKVxuICAgICAgdmFsID0gdmFsLnJlcGxhY2UoY2hhciwgY2MpXG4gICAgcmV0dXJuIHZhbFxuXG4gIGVycm9ySGFuZGxlcjogKHhocikgLT5cbiAgICBjb25zb2xlLmxvZygnZXJyb3InLCB4aHIpXG5cbiAgIyMjXG4gICBSZWNlaXZpbmcgZGF0YSBmcm9tIHRyYW5zbGF0aW9uLWVuZ2luZSBhbmQgc2VuZCByZWFkeSBtZXNzYWdlIHdpdGggZGF0YVxuICAjIyNcbiAgc3VjY2Vzc3RIYW5kbGVyOiAodHJhbnNsYXRlZCkgLT5cbiAgICBpZiB0cmFuc2xhdGVkXG4gICAgICBjaHJvbWUudGFicy5nZXRTZWxlY3RlZChudWxsLCAodGFiKSA9PlxuICAgICAgICBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWIuaWQsIHtcbiAgICAgICAgICBhY3Rpb246IEBtZXNzYWdlVHlwZSB0cmFuc2xhdGVkXG4gICAgICAgICAgZGF0YTogdHJhbnNsYXRlZC5vdXRlckhUTUwsXG4gICAgICAgICAgc3VjY2VzczogIXRyYW5zbGF0ZWQuY2xhc3NMaXN0LmNvbnRhaW5zKCdmYWlsVHJhbnNsYXRlJylcbiAgICAgICAgfSlcbiAgICAgIClcblxuICBtZXNzYWdlVHlwZTogKHRyYW5zbGF0ZWQpIC0+XG4gICAgaWYgdHJhbnNsYXRlZD8ucm93cz8ubGVuZ3RoID09IDFcbiAgICAgICdzaW1pbGFyX3dvcmRzJ1xuICAgIGVsc2VcbiAgICAgICdvcGVuX3Rvb2x0aXAnXG5cbiAgIyMjXG4gICAgUGFyc2UgcmVzcG9uc2UgZnJvbSB0cmFuc2xhdGlvbiBlbmdpbmVcbiAgIyMjXG4gIHBhcnNlOiAocmVzcG9uc2UsIHNpbGVudCwgdHJhbnNsYXRlID0gbnVsbCkgLT5cbiAgICAgIGRvYyA9IEBzdHJpcFNjcmlwdHMocmVzcG9uc2UpXG4gICAgICBmcmFnbWVudCA9IEBtYWtlRnJhZ21lbnQoZG9jKVxuICAgICAgaWYgZnJhZ21lbnRcbiAgICAgICAgdHJhbnNsYXRlID0gZnJhZ21lbnQucXVlcnlTZWxlY3RvcignI3RyYW5zbGF0aW9uIH4gdGFibGUnKVxuICAgICAgICBpZiB0cmFuc2xhdGVcbiAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gQFRBQkxFX0NMQVNTO1xuICAgICAgICAgIHRyYW5zbGF0ZS5zZXRBdHRyaWJ1dGUoXCJjZWxscGFkZGluZ1wiLCBcIjVcIilcbiAgICAgICAgICBAZml4SW1hZ2VzKHRyYW5zbGF0ZSlcbiAgICAgICAgICBAZml4TGlua3ModHJhbnNsYXRlKVxuICAgICAgICBlbHNlIGlmIG5vdCBzaWxlbnRcbiAgICAgICAgICB0cmFuc2xhdGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSAnZmFpbFRyYW5zbGF0ZSdcbiAgICAgICAgICB0cmFuc2xhdGUuaW5uZXJUZXh0ID0gXCJVbmZvcnR1bmF0ZWx5LCBjb3VsZCBub3QgdHJhbnNsYXRlXCJcblxuICAgICAgcmV0dXJuIHRyYW5zbGF0ZTtcblxuICAjIyNcbiAgICBTdHJpcCBzY3JpcHQgdGFncyBmcm9tIHJlc3BvbnNlIGh0bWxcbiAgIyMjXG4gIHN0cmlwU2NyaXB0czogKHMpIC0+XG4gICAgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgICBkaXYuaW5uZXJIVE1MID0gc1xuICAgIHNjcmlwdHMgPSBkaXYuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ3NjcmlwdCcpXG4gICAgaSA9IHNjcmlwdHMubGVuZ3RoXG4gICAgd2hpbGUgaS0tXG4gICAgICBzY3JpcHRzW2ldLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc2NyaXB0c1tpXSlcbiAgICByZXR1cm4gZGl2LmlubmVySFRNTDtcblxuICBtYWtlRnJhZ21lbnQ6IChkb2MsIGZyYWdtZW50ID0gbnVsbCkgLT5cbiAgICBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpXG4gICAgZGl2LmlubmVySFRNTCA9IGRvY1xuICAgIGZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpXG4gICAgd2hpbGUgKCBkaXYuZmlyc3RDaGlsZCApXG4gICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZCggZGl2LmZpcnN0Q2hpbGQgKVxuICAgIHJldHVybiBmcmFnbWVudFxuXG4gIGZpeEltYWdlczogKGZyYWdtZW50PW51bGwpIC0+XG4gICAgdGhpcy5maXhVcmwoZnJhZ21lbnQsICdpbWcnLCAnc3JjJyk7XG4gICAgcmV0dXJuIGZyYWdtZW50O1xuXG4gIGZpeExpbmtzOiAoZnJhZ21lbnQ9bnVsbCkgLT5cbiAgICB0aGlzLmZpeFVybChmcmFnbWVudCwgJ2EnLCAnaHJlZicpXG4gICAgcmV0dXJuIGZyYWdtZW50XG5cbiAgZml4VXJsOiAoZnJhZ21lbnQ9bnVsbCwgdGFnLCBhdHRyKSAtPlxuICAgIGlmIGZyYWdtZW50XG4gICAgICB0YWdzID0gIGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3JBbGwodGFnKVxuICAgICAgcGFyc2VyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpXG4gICAgICBmb3IgdGFnIGluIHRhZ3NcbiAgICAgICAgcGFyc2VyLmhyZWYgPSB0YWdbYXR0cl1cbiAgICAgICAgcGFyc2VyLmhvc3QgPSBAaG9zdFxuICAgICAgICBwYXJzZXIucHJvdG9jb2wgPSBAcHJvdG9jb2xcbiAgICAgICAgI2ZpeCByZWxhdGl2ZSBsaW5rc1xuICAgICAgICBpZiB0YWcudGFnTmFtZSA9PSAnQSdcbiAgICAgICAgICB0YWcuY2xhc3NMaXN0LmFkZCAnbXR0X2xpbmsnXG4gICAgICAgICAgaWYgcGFyc2VyLnBhdGhuYW1lLmluZGV4T2YoJ20uZXhlJykgaXNudCAtMVxuICAgICAgICAgICAgcGFyc2VyLnBhdGhuYW1lID0gJy9jJyArIHBhcnNlci5wYXRobmFtZVxuICAgICAgICAgICAgdGFnLnNldEF0dHJpYnV0ZSgndGFyZ2V0JywgJ19ibGFuaycpXG4gICAgICAgIGVsc2UgaWYgdGFnLnRhZ05hbWUgPT0gJ0lNRydcbiAgICAgICAgICB0YWcuY2xhc3NMaXN0LmFkZCAnbXR0X2ltZydcblxuICAgICAgICB0YWcuc2V0QXR0cmlidXRlKGF0dHIsIHBhcnNlci5ocmVmKVxuXG5cblxubW9kdWxlLmV4cG9ydHMgPSBuZXcgVHJhbiIsIlwidXNlIHN0cmljdFwiO1xuXG52YXIgX3Byb3RvdHlwZVByb3BlcnRpZXMgPSBmdW5jdGlvbiAoY2hpbGQsIHN0YXRpY1Byb3BzLCBpbnN0YW5jZVByb3BzKSB7XG4gIGlmIChzdGF0aWNQcm9wcykgT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoY2hpbGQsIHN0YXRpY1Byb3BzKTtcbiAgaWYgKGluc3RhbmNlUHJvcHMpIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGNoaWxkLnByb3RvdHlwZSwgaW5zdGFuY2VQcm9wcyk7XG59O1xuXG4vKlxuICBUcmFuc2xhdGlvbiBlbmdpbmU6IGh0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0XG4gIEZvciB0cmFuc2xhdGluZyB0dXJraXNoLXJ1c3NpYW4gYW5kIHZpY2UgdmVyc2FcbiovXG52YXIgQ0hBUl9DT0RFUyA9IHJlcXVpcmUoXCIuL2NoYXItY29kZXMtdHVyay5qc1wiKTtcblxudmFyIFR1cmtpc2hEaWN0aW9uYXJ5ID0gKGZ1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gVHVya2lzaERpY3Rpb25hcnkoKSB7XG4gICAgdGhpcy5ob3N0ID0gXCJodHRwOi8vd3d3LnR1cmtpc2hkaWN0aW9uYXJ5Lm5ldC8/d29yZD0lRkNcIjtcbiAgICB0aGlzLnBhdGggPSBcIlwiO1xuICAgIHRoaXMucHJvdG9jb2wgPSBcImh0dHBcIjtcbiAgICB0aGlzLnF1ZXJ5ID0gXCImcz1cIjtcbiAgICB0aGlzLlRBQkxFX0NMQVNTID0gXCJfX19tdHRfdHJhbnNsYXRlX3RhYmxlXCI7XG4gICAgLy8gdGhpcyBmbGFnIGluZGljYXRlcyB0aGF0IGlmIHRyYW5zbGF0aW9uIHdhcyBzdWNjZXNzZnVsIHRoZW4gcHVibGlzaCBpdCBhbGwgb3ZlciBleHRlbnNpb25cbiAgICB0aGlzLm5lZWRfcHVibGlzaCA9IHRydWU7XG4gIH1cblxuICBfcHJvdG90eXBlUHJvcGVydGllcyhUdXJraXNoRGljdGlvbmFyeSwgbnVsbCwge1xuICAgIHNlYXJjaDoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHNlYXJjaChkYXRhKSB7XG4gICAgICAgIGRhdGEudXJsID0gdGhpcy5tYWtlVXJsKGRhdGEudmFsdWUpO1xuICAgICAgICB0aGlzLm5lZWRfcHVibGlzaCA9IGZhbHNlO1xuICAgICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KGRhdGEpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgdHJhbnNsYXRlOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gdHJhbnNsYXRlKGRhdGEpIHtcbiAgICAgICAgZGF0YS51cmwgPSB0aGlzLm1ha2VVcmwoZGF0YS5zZWxlY3Rpb25UZXh0KTtcbiAgICAgICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSB0cnVlO1xuICAgICAgICB0aGlzLnJlcXVlc3QoZGF0YSk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBtYWtlVXJsOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZVVybCh0ZXh0KSB7XG4gICAgICAgIHZhciB0ZXh0ID0gdGhpcy5nZXRFbmNvZGVkVmFsdWUodGV4dCk7XG4gICAgICAgIHJldHVybiBbXCJodHRwOi8vd3d3LnR1cmtpc2hkaWN0aW9uYXJ5Lm5ldC8/d29yZD1cIiwgdGV4dF0uam9pbihcIlwiKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIGdldEVuY29kZWRWYWx1ZToge1xuXG5cbiAgICAgIC8vIFJlcGxhY2Ugc3BlY2lhbCBsYW5ndWFnZSBjaGFyYWN0ZXJzIHRvIGh0bWwgY29kZXNcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBnZXRFbmNvZGVkVmFsdWUodmFsdWUpIHtcbiAgICAgICAgLy8gdG8gZmluZCBzcGVjIHN5bWJvbHMgd2UgZmlyc3QgZW5jb2RlIHRoZW0gKHJhdyBzZWFyY2ggZm9yIHRoYXQgc3ltYm9sIGRvZXNuJ3Qgd29yKVxuICAgICAgICByZXR1cm4gdGhpcy5tYWtlU3RyaW5nVHJhbnNmZXJhYmxlKHZhbHVlKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIG1ha2VTdHJpbmdUcmFuc2ZlcmFibGU6IHtcblxuICAgICAgLyoqIGNvbnZlcnRpbmcgc2NyaXB0IGZyb20gdGhlIHR1cmtpc2hkaWN0ICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZVN0cmluZ1RyYW5zZmVyYWJsZShpbnB1dFRleHQpIHtcbiAgICAgICAgdmFyIHRleHQgPSBcIlwiO1xuICAgICAgICBpZiAoaW5wdXRUZXh0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICB0ZXh0ID0gaW5wdXRUZXh0O1xuICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGV4dC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgaWYgKENIQVJfQ09ERVNbdGV4dC5jaGFyQ29kZUF0KGkpXSkge1xuICAgICAgICAgICAgICB0ZXh0ID0gdGV4dC5zdWJzdHJpbmcoMCwgaSkgKyBDSEFSX0NPREVTW3RleHQuY2hhckNvZGVBdChpKV0gKyB0ZXh0LnN1YnN0cmluZyhpICsgMSwgdGV4dC5sZW5ndGgpO1xuICAgICAgICAgICAgfSBlbHNlIGlmICh0ZXh0LmNoYXJBdChpKSA9PSBcIiBcIikge1xuICAgICAgICAgICAgICAvLyByZXBsYWNlIHNwYWNlc1xuICAgICAgICAgICAgICB0ZXh0ID0gdGV4dC5zdWJzdHJpbmcoMCwgaSkgKyBcIl9fX1wiICsgdGV4dC5zdWJzdHJpbmcoaSArIDEsIHRleHQubGVuZ3RoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRleHQ7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICByZXF1ZXN0OiB7XG5cbiAgICAgIC8qXG4gICAgICAgIFJlcXVlc3QgdHJhbnNsYXRpb24gYW5kIHJ1biBjYWxsYmFjayBmdW5jdGlvblxuICAgICAgICBwYXNzaW5nIHRyYW5zbGF0ZWQgcmVzdWx0IG9yIGVycm9yIHRvIGNhbGxiYWNrXG4gICAgICAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHJlcXVlc3Qob3B0cykge1xuICAgICAgICBjb25zb2xlLmxvZyhcInN0YXJ0IHJlcXVlc3RcIik7XG4gICAgICAgIHRoaXMueGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgIHRoaXMueGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IHRoaXMub25SZWFkeVN0YXRlQ2hhbmdlLmJpbmQodGhpcywgb3B0cyk7XG4gICAgICAgIHRoaXMueGhyLm9wZW4oXCJHRVRcIiwgb3B0cy51cmwsIHRydWUpO1xuICAgICAgICB0aGlzLnhoci5zZW5kKCk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBvblJlYWR5U3RhdGVDaGFuZ2U6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBvblJlYWR5U3RhdGVDaGFuZ2Uob3B0cywgZSkge1xuICAgICAgICB2YXIgeGhyID0gdGhpcy54aHI7XG4gICAgICAgIGlmICh4aHIucmVhZHlTdGF0ZSA8IDQpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH0gZWxzZSBpZiAoeGhyLnN0YXR1cyAhPSAyMDApIHtcbiAgICAgICAgICB0aGlzLmVycm9ySGFuZGxlcih4aHIpO1xuICAgICAgICAgIHJldHVybiBvcHRzLmVycm9yICYmIG9wdHMuZXJyb3IoKTtcbiAgICAgICAgfSBlbHNlIGlmICh4aHIucmVhZHlTdGF0ZSA9PSA0KSB7XG4gICAgICAgICAgdmFyIHRyYW5zbGF0aW9uID0gdGhpcy5zdWNjZXNzSGFuZGxlcihlLnRhcmdldC5yZXNwb25zZSk7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJzdWNjZXNzIHR1cmtpc2ggdHJhbnNsYXRlXCIsIHRyYW5zbGF0aW9uKTtcbiAgICAgICAgICBjb25zb2xlLmxvZyhcImNhbGxcIiwgb3B0cy5zdWNjZXNzKTtcbiAgICAgICAgICByZXR1cm4gb3B0cy5zdWNjZXNzICYmIG9wdHMuc3VjY2Vzcyh0cmFuc2xhdGlvbik7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHN1Y2Nlc3NIYW5kbGVyOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gc3VjY2Vzc0hhbmRsZXIocmVzcG9uc2UpIHtcbiAgICAgICAgdmFyIGRhdGEgPSB0aGlzLnBhcnNlKHJlc3BvbnNlKTtcbiAgICAgICAgaWYgKHRoaXMubmVlZF9wdWJsaXNoKSB7XG4gICAgICAgICAgY2hyb21lLnRhYnMuZ2V0U2VsZWN0ZWQobnVsbCwgdGhpcy5wdWJsaXNoVHJhbnNsYXRpb24uYmluZCh0aGlzLCBkYXRhKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBwdWJsaXNoVHJhbnNsYXRpb246IHtcblxuICAgICAgLyogcHVibGlzaCBzdWNjZXNzZnVseSB0cmFuc2xhdGVkIHRleHQgYWxsIG92ZXIgZXh0ZW5zaW9uICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gcHVibGlzaFRyYW5zbGF0aW9uKHRyYW5zbGF0aW9uLCB0YWIpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJwdWJsaXNoIHRyYW5zbGF0aW9uXCIpO1xuICAgICAgICBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWIuaWQsIHtcbiAgICAgICAgICBhY3Rpb246IHRoaXMudG9vbHRpcEFjdGlvbih0cmFuc2xhdGlvbiksXG4gICAgICAgICAgZGF0YTogdHJhbnNsYXRpb24ub3V0ZXJIVE1MLFxuICAgICAgICAgIHN1Y2Nlc3M6ICF0cmFuc2xhdGlvbi5jbGFzc0xpc3QuY29udGFpbnMoXCJmYWlsVHJhbnNsYXRlXCIpXG4gICAgICAgIH0pO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgdG9vbHRpcEFjdGlvbjoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHRvb2x0aXBBY3Rpb24odHJhbnNsYXRpb24pIHtcbiAgICAgICAgaWYgKHRyYW5zbGF0aW9uLnRleHRDb250ZW50LnRyaW0oKS5pbmRleE9mKFwid2FzIG5vdCBmb3VuZCBpbiBvdXIgZGljdGlvbmFyeVwiKSAhPSAtMSkge1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwic2ltaWxhciB3b3Jkc1wiKTtcbiAgICAgICAgICByZXR1cm4gXCJzaW1pbGFyX3dvcmRzXCI7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJvcGVuIHRvb2x0aXBcIik7XG4gICAgICAgICAgcmV0dXJuIFwib3Blbl90b29sdGlwXCI7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIGVycm9ySGFuZGxlcjoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIGVycm9ySGFuZGxlcihyZXNwb25zZSkge1xuICAgICAgICBjb25zb2xlLmxvZyhcImVycm9yIGFqYXhcIiwgcmVzcG9uc2UpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcGFyc2U6IHtcblxuICAgICAgLyogUGFyc2UgcmVzcG9uc2UgZnJvbSB0cmFuc2xhdGlvbiBlbmdpbmUgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBwYXJzZShyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUpIHtcbiAgICAgICAgdmFyIGRvYyA9IHRoaXMuc3RyaXBTY3JpcHRzKHJlc3BvbnNlKSxcbiAgICAgICAgICAgIGZyYWdtZW50ID0gdGhpcy5tYWtlRnJhZ21lbnQoZG9jKTtcbiAgICAgICAgaWYgKGZyYWdtZW50KSB7XG4gICAgICAgICAgdHJhbnNsYXRlID0gZnJhZ21lbnQucXVlcnlTZWxlY3RvcihcIiNtZWFuaW5nX2RpdiA+IHRhYmxlXCIpO1xuICAgICAgICAgIGlmICh0cmFuc2xhdGUpIHtcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSB0aGlzLlRBQkxFX0NMQVNTO1xuICAgICAgICAgICAgdHJhbnNsYXRlLnNldEF0dHJpYnV0ZShcImNlbGxwYWRkaW5nXCIsIFwiNVwiKTtcbiAgICAgICAgICAgIC8vIEBmaXhJbWFnZXModHJhbnNsYXRlKVxuICAgICAgICAgICAgLy8gQGZpeExpbmtzKHRyYW5zbGF0ZSlcbiAgICAgICAgICB9IGVsc2UgaWYgKCFzaWxlbnQpIHtcbiAgICAgICAgICAgIHRyYW5zbGF0ZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gXCJmYWlsVHJhbnNsYXRlXCI7XG4gICAgICAgICAgICB0cmFuc2xhdGUuaW5uZXJUZXh0ID0gXCJVbmZvcnR1bmF0ZWx5LCBjb3VsZCBub3QgdHJhbnNsYXRlXCI7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cmFuc2xhdGU7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBwYXJzZVRleHQ6IHtcblxuICAgICAgLyoqIHBhcnNpbmcgb2YgdGVycmlibGUgaHRtbCBtYXJrdXAgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBwYXJzZVRleHQocmVzcG9uc2UsIHNpbGVudCwgdHJhbnNsYXRlKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIHZhciBkb2MgPSB0aGlzLnN0cmlwU2NyaXB0cyhyZXNwb25zZSksXG4gICAgICAgICAgICBmcmFnbWVudCA9IHRoaXMubWFrZUZyYWdtZW50KGRvYyk7XG5cbiAgICAgICAgaWYgKGZyYWdtZW50KSB7XG4gICAgICAgICAgdmFyIGk7XG4gICAgICAgICAgdmFyIF9yZXQgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIHN0b3BJbmRleCA9IG51bGw7XG4gICAgICAgICAgICB2YXIgdHIgPSBmcmFnbWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiI21lYW5pbmdfZGl2PnRhYmxlPnRib2R5PnRyXCIpO1xuICAgICAgICAgICAgdHIgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbCh0cik7XG5cbiAgICAgICAgICAgIHZhciB0cmFucyA9IHRyLmZpbHRlcihmdW5jdGlvbiAodHIsIGluZGV4KSB7XG4gICAgICAgICAgICAgIGlmICghaXNOYU4ocGFyc2VJbnQoc3RvcEluZGV4LCAxMCkpICYmIGluZGV4ID49IHN0b3BJbmRleCkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0ciA9ICQodHIpO1xuICAgICAgICAgICAgICAgIC8vIHRha2UgZXZlcnkgcm93IGJlZm9yZSBuZXh0IHNlY3Rpb24gKHdoaWNoIGlzIEVuZ2xpc2gtPkVuZ2xpc2gpXG4gICAgICAgICAgICAgICAgaWYgKHRyLmF0dHIoXCJiZ2NvbG9yXCIpID09IFwiZTBlNmZmXCIpIHtcbiAgICAgICAgICAgICAgICAgIHN0b3BJbmRleCA9IGluZGV4O3JldHVybjtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuICQudHJpbSh0ci5maW5kKFwidGRcIikudGV4dCgpKS5sZW5ndGg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRyYW5zID0gdHJhbnMuc2xpY2UoMSwgdHJhbnMubGVuZ3RoIC0gMSk7XG4gICAgICAgICAgICB0cmFucyA9IHRyYW5zLmZpbHRlcihmdW5jdGlvbiAoZWwsIGluZHgpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGluZHggJSAyO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB2YXIgZnJhZyA9IF90aGlzLmZyYWdtZW50RnJvbUxpc3QodHJhbnMpO1xuICAgICAgICAgICAgdmFyIGZvbnRzID0gZnJhZy5xdWVyeVNlbGVjdG9yQWxsKFwiZm9udFwiKTtcbiAgICAgICAgICAgIHZhciB0ZXh0ID0gXCJcIjtcbiAgICAgICAgICAgIGZvciAoaSA9IDA7IGkgPCBmb250cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICB0ZXh0ICs9IFwiIFwiICsgZm9udHNbaV0udGV4dENvbnRlbnQudHJpbSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgdjogdGV4dFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9KSgpO1xuXG4gICAgICAgICAgaWYgKHR5cGVvZiBfcmV0ID09PSBcIm9iamVjdFwiKSByZXR1cm4gX3JldC52O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRocm93IFwiSFRNTCBmcmFnbWVudCBjb3VsZCBub3QgYmUgcGFyc2VkXCI7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHN0cmlwU2NyaXB0czoge1xuXG4gICAgICAvL1RPRE8gZXh0cmFjdCB0byBiYXNlIGVuZ2luZSBjbGFzc1xuICAgICAgLyogcmVtb3ZlcyA8c2NyaXB0PiB0YWdzIGZyb20gaHRtbCBjb2RlICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gc3RyaXBTY3JpcHRzKGh0bWwpIHtcbiAgICAgICAgdmFyIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgIGRpdi5pbm5lckhUTUwgPSBodG1sO1xuICAgICAgICB2YXIgc2NyaXB0cyA9IGRpdi5nZXRFbGVtZW50c0J5VGFnTmFtZShcInNjcmlwdFwiKTtcbiAgICAgICAgdmFyIGkgPSBzY3JpcHRzLmxlbmd0aDtcbiAgICAgICAgd2hpbGUgKGktLSkgc2NyaXB0c1tpXS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHNjcmlwdHNbaV0pO1xuICAgICAgICByZXR1cm4gZGl2LmlubmVySFRNTDtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIG1ha2VGcmFnbWVudDoge1xuXG4gICAgICAvL1RPRE8gZXh0cmFjdCB0byBiYXNlIGVuZ2luZSBjbGFzc1xuICAgICAgLyogY3JlYXRlcyB0ZW1wIG9iamVjdCB0byBwYXJzZSB0cmFuc2xhdGlvbiBmcm9tIHBhZ2UgXG4gICAgICAgIChzaW5jZSBpdCdzIG5vdCBhIGZyaWVuZGx5IGFwaSkgXG4gICAgICAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIG1ha2VGcmFnbWVudChodG1sKSB7XG4gICAgICAgIHZhciBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKSxcbiAgICAgICAgICAgIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgIGRpdi5pbm5lckhUTUwgPSBodG1sO1xuICAgICAgICB3aGlsZSAoZGl2LmZpcnN0Q2hpbGQpIHtcbiAgICAgICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZChkaXYuZmlyc3RDaGlsZCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZyYWdtZW50O1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgZnJhZ21lbnRGcm9tTGlzdDoge1xuXG4gICAgICAvKiogY3JlYXRlIGZyYWdtZW50IGZyb20gbGlzdCBvZiBET00gZWxlbWVudHMgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBmcmFnbWVudEZyb21MaXN0KGxpc3QpIHtcbiAgICAgICAgdmFyIGZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpLFxuICAgICAgICAgICAgbGVuID0gbGlzdC5sZW5ndGg7XG4gICAgICAgIHdoaWxlIChsZW4tLSkge1xuICAgICAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKGxpc3RbbGVuXSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZyYWdtZW50O1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH1cbiAgfSk7XG5cbiAgcmV0dXJuIFR1cmtpc2hEaWN0aW9uYXJ5O1xufSkoKTtcblxuLy8gU2luZ2xldG9uZVxubW9kdWxlLmV4cG9ydHMgPSBuZXcgVHVya2lzaERpY3Rpb25hcnkoKTsiXX0=
