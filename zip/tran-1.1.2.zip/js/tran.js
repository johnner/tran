(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/var CHAR_CODES = {  '%C3%80': '&#192;', // À  '%C3%81': '&#193;', // Á  '%C3%82': '&#194;', // Â  '%C3%83': '&#195;', // Ã  '%C3%84': '&#196;', // Ä  '%C3%85': '&#197;', // Å  '%C3%86': '&#198;', // Æ  '%C3%87': '&#199;', // Ç  '%C3%88': '&#200;', // È  '%C3%89': '&#201;', // É  '%C3%8A': '&#202;', // Ê  '%C3%8B': '&#203;', // Ë  '%C3%8C': '&#204;', // Ì  '%C3%8D': '&#205;', // Í  '%C3%8E': '&#206;', // Î  '%C3%8F': '&#207;', // Ï  '%C3%91': '&#209;', // Ñ  '%C3%92': '&#210;', // Ò  '%C3%93': '&#211;', // Ó  '%C3%94': '&#212;', // Ô  '%C3%95': '&#213;', // Õ  '%C3%96': '&#214;', // Ö  '%C3%99': '&#217;', // Ù  '%C3%9A': '&#218;', // Ú  '%C3%9B': '&#219;', // Û  '%C3%9C': '&#220;', // Ü  '%C3%A0': '&#224;', // à  '%C3%A1': '&#225;', // á  '%C3%A2': '&#226;', // â  '%C3%A3': '&#227;', // ã  '%C3%A4': '&#228;', // ä  '%C3%A5': '&#229;', // å  '%C3%A6': '&#230;', // æ  '%C3%A7': '&#231;', // ç  '%C3%A8': '&#232;', // è  '%C3%A9': '&#233;', // é  '%C3%AA': '&#234;', // ê  '%C3%AB': '&#235;', // ë  '%C3%AC': '&#236;', // ì  '%C3%AD': '&#237;', // í  '%C3%AE': '&#238;', // î  '%C3%AF': '&#239;', // ï  '%C3%B0': '&#240;', // ð  '%C3%B1': '&#241;', // ñ  '%C3%B2': '&#242;', // ò  '%C3%B3': '&#243;', // ó  '%C3%B4': '&#244;', // ô  '%C3%B5': '&#245;', // õ  '%C3%B6': '&#246;', // ö  '%C3%B9': '&#249;', // ù  '%C3%BA': '&#250;', // ú  '%C3%BB': '&#251;', // û  '%C3%BC': '&#252;', // ü  '%C3%BF': '&#255;', // ÿ  '%C5%B8': '&#376;', // Ÿ  '%C3%9F': '&#223;', // ß  '%C2%BF': '&#191;', // ¿  '%C2%A1': '&#161;', // ¡};module.exports = CHAR_CODES;
},{}],2:[function(require,module,exports){

/*global chrome */

/*
  Multitran.ru translate engine
  Provides program interface for making translate queries to multitran and get clean response

  All engines must follow common interface and provide methods:
    - search (languange, successHandler)  clean translation must be passed into successHandler
    - click

  Translation-module that makes requests to language-engine,
  parses results and sends plugin-global message with translation data
 */
var CHAR_CODES, Tran;

CHAR_CODES = require('./char-codes.js');

Tran = (function() {
  function Tran() {
    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1';
    this.xhr = {};
  }


  /*
    Context menu click handler
   */

  Tran.prototype.click = function(data) {
    var selectionText;
    if (typeof data.silent === void 0 || data.silent === null) {
      data.silent = true;
    }
    selectionText = this.removeHyphenation(data.selectionText);
    return this.search({
      value: selectionText,
      success: this.successtHandler.bind(this),
      silent: data.silent
    });
  };


  /*
    Discard soft hyphen character (U+00AD, &shy;) from the input
   */

  Tran.prototype.removeHyphenation = function(text) {
    return text.replace(/\xad/g, '');
  };


  /*
    Initiate translation search
   */

  Tran.prototype.search = function(params) {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(items) {
        var language, origSuccess, url;
        if (language === '') {
          language = '1';
        }
        _this.setLanguage(items.language);
        url = _this.makeUrl(params.value);
        origSuccess = params.success;
        params.success = function(response) {
          var translated;
          translated = _this.parse(response, params.silent);
          return origSuccess(translated);
        };
        return _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      };
    })(this));
  };

  Tran.prototype.setLanguage = function(language) {
    this.currentLanguage = language;
    return this.lang = '?l1=2&l2=' + language;
  };


  /*
    Request translation and run callback function
    passing translated result or error to callback
   */

  Tran.prototype.request = function(opts) {
    var xhr;
    xhr = this.xhr = new XMLHttpRequest();
    xhr.onreadystatechange = (function(_this) {
      return function(e) {
        xhr = _this.xhr;
        if (xhr.readyState < 4) {

        } else if (xhr.status !== 200) {
          _this.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error();
          }
        } else if (xhr.readyState === 4) {
          return opts.success(e.target.response);
        }
      };
    })(this);
    xhr.open("GET", opts.url, true);
    return xhr.send();
  };

  Tran.prototype.makeUrl = function(value) {
    var url;
    url = [this.protocol, '://', this.host, this.path, this.lang, this.query, this.getEncodedValue(value)].join('');
    return url;
  };

  Tran.prototype.getEncodedValue = function(value) {
    var char, code, val;
    val = encodeURIComponent(value);
    for (char in CHAR_CODES) {
      code = CHAR_CODES[char];
      val = val.replace(char, encodeURIComponent(code));
    }
    return val;
  };

  Tran.prototype.errorHandler = function(xhr) {
    return console.log('error', xhr);
  };


  /*
   Receiving data from translation-engine and send ready message with data
   */

  Tran.prototype.successtHandler = function(translated) {
    if (translated) {
      return chrome.tabs.getSelected(null, (function(_this) {
        return function(tab) {
          return chrome.tabs.sendMessage(tab.id, {
            action: _this.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        };
      })(this));
    }
  };

  Tran.prototype.messageType = function(translated) {
    var _ref;
    if ((translated != null ? (_ref = translated.rows) != null ? _ref.length : void 0 : void 0) === 1) {
      return 'similar_words';
    } else {
      return 'open_tooltip';
    }
  };


  /*
    Parse response from translation engine
   */

  Tran.prototype.parse = function(response, silent, translate) {
    var doc, fragment;
    if (translate == null) {
      translate = null;
    }
    doc = this.stripScripts(response);
    fragment = this.makeFragment(doc);
    if (fragment) {
      translate = fragment.querySelector('#translation ~ table');
      if (translate) {
        translate.className = this.TABLE_CLASS;
        translate.setAttribute("cellpadding", "5");
        this.fixImages(translate);
        this.fixLinks(translate);
      } else if (!silent) {
        translate = document.createElement('div');
        translate.className = 'failTranslate';
        translate.innerText = "Unfortunately, could not translate";
      }
    }
    return translate;
  };


  /*
    Strip script tags from response html
   */

  Tran.prototype.stripScripts = function(s) {
    var div, i, scripts;
    div = document.createElement('div');
    div.innerHTML = s;
    scripts = div.getElementsByTagName('script');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
    return div.innerHTML;
  };

  Tran.prototype.makeFragment = function(doc, fragment) {
    var div;
    if (fragment == null) {
      fragment = null;
    }
    div = document.createElement("div");
    div.innerHTML = doc;
    fragment = document.createDocumentFragment();
    while (div.firstChild) {
      fragment.appendChild(div.firstChild);
    }
    return fragment;
  };

  Tran.prototype.fixImages = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'img', 'src');
    return fragment;
  };

  Tran.prototype.fixLinks = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'a', 'href');
    return fragment;
  };

  Tran.prototype.fixUrl = function(fragment, tag, attr) {
    var parser, tags, _i, _len, _results;
    if (fragment == null) {
      fragment = null;
    }
    if (fragment) {
      tags = fragment.querySelectorAll(tag);
      parser = document.createElement('a');
      _results = [];
      for (_i = 0, _len = tags.length; _i < _len; _i++) {
        tag = tags[_i];
        parser.href = tag[attr];
        parser.host = this.host;
        parser.protocol = this.protocol;
        if (tag.tagName === 'A') {
          tag.classList.add('mtt_link');
          if (parser.pathname.indexOf('m.exe') !== -1) {
            parser.pathname = '/c' + parser.pathname;
            tag.setAttribute('target', '_blank');
          }
        } else if (tag.tagName === 'IMG') {
          tag.classList.add('mtt_img');
        }
        _results.push(tag.setAttribute(attr, parser.href));
      }
      return _results;
    }
  };

  return Tran;

})();

module.exports = new Tran;


},{"./char-codes.js":1}]},{},[2])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvY2hhci1jb2Rlcy5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvdHJhbi5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTs7QUNBQTtBQUFBLGtCQUFBO0FBQ0E7QUFBQTs7Ozs7Ozs7OztHQURBO0FBQUEsSUFBQSxnQkFBQTs7QUFBQSxVQWFBLEdBQWEsT0FBQSxDQUFRLGlCQUFSLENBYmIsQ0FBQTs7QUFBQTtBQWdCZSxFQUFBLGNBQUEsR0FBQTtBQUNYLElBQUEsSUFBQyxDQUFBLFdBQUQsR0FBZSx3QkFBZixDQUFBO0FBQUEsSUFDQSxJQUFDLENBQUEsUUFBRCxHQUFZLE1BRFosQ0FBQTtBQUFBLElBRUEsSUFBQyxDQUFBLElBQUQsR0FBUSxrQkFGUixDQUFBO0FBQUEsSUFHQSxJQUFDLENBQUEsSUFBRCxHQUFRLFVBSFIsQ0FBQTtBQUFBLElBSUEsSUFBQyxDQUFBLEtBQUQsR0FBUyxLQUpULENBQUE7QUFBQSxJQUtBLElBQUMsQ0FBQSxJQUFELEdBQVEsWUFMUixDQUFBO0FBQUEsSUFNQSxJQUFDLENBQUEsR0FBRCxHQUFPLEVBTlAsQ0FEVztFQUFBLENBQWI7O0FBU0E7QUFBQTs7S0FUQTs7QUFBQSxpQkFZQSxLQUFBLEdBQU8sU0FBQyxJQUFELEdBQUE7QUFDTCxRQUFBLGFBQUE7QUFBQSxJQUFBLElBQUcsTUFBQSxDQUFBLElBQVcsQ0FBQyxNQUFaLEtBQXNCLE1BQXRCLElBQW1DLElBQUksQ0FBQyxNQUFMLEtBQWUsSUFBckQ7QUFDRSxNQUFBLElBQUksQ0FBQyxNQUFMLEdBQWMsSUFBZCxDQURGO0tBQUE7QUFBQSxJQUVBLGFBQUEsR0FBZ0IsSUFBQyxDQUFBLGlCQUFELENBQW1CLElBQUksQ0FBQyxhQUF4QixDQUZoQixDQUFBO1dBR0EsSUFBQyxDQUFBLE1BQUQsQ0FDSTtBQUFBLE1BQUEsS0FBQSxFQUFPLGFBQVA7QUFBQSxNQUNBLE9BQUEsRUFBUyxJQUFDLENBQUEsZUFBZSxDQUFDLElBQWpCLENBQXNCLElBQXRCLENBRFQ7QUFBQSxNQUVBLE1BQUEsRUFBUSxJQUFJLENBQUMsTUFGYjtLQURKLEVBSks7RUFBQSxDQVpQLENBQUE7O0FBcUJBO0FBQUE7O0tBckJBOztBQUFBLGlCQXdCQSxpQkFBQSxHQUFtQixTQUFDLElBQUQsR0FBQTtXQUNqQixJQUFJLENBQUMsT0FBTCxDQUFhLE9BQWIsRUFBc0IsRUFBdEIsRUFEaUI7RUFBQSxDQXhCbkIsQ0FBQTs7QUEyQkE7QUFBQTs7S0EzQkE7O0FBQUEsaUJBOEJBLE1BQUEsR0FBUSxTQUFDLE1BQUQsR0FBQTtXQUVOLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsTUFBQyxRQUFBLEVBQVUsR0FBWDtLQUF4QixFQUF5QyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxLQUFELEdBQUE7QUFDdkMsWUFBQSwwQkFBQTtBQUFBLFFBQUEsSUFBRyxRQUFBLEtBQVksRUFBZjtBQUNFLFVBQUEsUUFBQSxHQUFXLEdBQVgsQ0FERjtTQUFBO0FBQUEsUUFFQSxLQUFDLENBQUEsV0FBRCxDQUFhLEtBQUssQ0FBQyxRQUFuQixDQUZBLENBQUE7QUFBQSxRQUdBLEdBQUEsR0FBTSxLQUFDLENBQUEsT0FBRCxDQUFTLE1BQU0sQ0FBQyxLQUFoQixDQUhOLENBQUE7QUFBQSxRQUtBLFdBQUEsR0FBYyxNQUFNLENBQUMsT0FMckIsQ0FBQTtBQUFBLFFBTUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsU0FBQyxRQUFELEdBQUE7QUFDZixjQUFBLFVBQUE7QUFBQSxVQUFBLFVBQUEsR0FBYSxLQUFDLENBQUEsS0FBRCxDQUFPLFFBQVAsRUFBaUIsTUFBTSxDQUFDLE1BQXhCLENBQWIsQ0FBQTtpQkFDQSxXQUFBLENBQVksVUFBWixFQUZlO1FBQUEsQ0FOakIsQ0FBQTtlQVdBLEtBQUMsQ0FBQSxPQUFELENBQ0U7QUFBQSxVQUFBLEdBQUEsRUFBSyxHQUFMO0FBQUEsVUFDQSxPQUFBLEVBQVMsTUFBTSxDQUFDLE9BRGhCO0FBQUEsVUFFQSxLQUFBLEVBQU8sTUFBTSxDQUFDLEtBRmQ7U0FERixFQVp1QztNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpDLEVBRk07RUFBQSxDQTlCUixDQUFBOztBQUFBLGlCQW1EQSxXQUFBLEdBQWEsU0FBQyxRQUFELEdBQUE7QUFDWCxJQUFBLElBQUMsQ0FBQSxlQUFELEdBQW1CLFFBQW5CLENBQUE7V0FDQSxJQUFDLENBQUEsSUFBRCxHQUFRLFdBQUEsR0FBYyxTQUZYO0VBQUEsQ0FuRGIsQ0FBQTs7QUF1REE7QUFBQTs7O0tBdkRBOztBQUFBLGlCQTJEQSxPQUFBLEdBQVMsU0FBQyxJQUFELEdBQUE7QUFDUCxRQUFBLEdBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxJQUFDLENBQUEsR0FBRCxHQUFXLElBQUEsY0FBQSxDQUFBLENBQWpCLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxrQkFBSixHQUF5QixDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7QUFDdkIsUUFBQSxHQUFBLEdBQU0sS0FBQyxDQUFBLEdBQVAsQ0FBQTtBQUNBLFFBQUEsSUFBRyxHQUFHLENBQUMsVUFBSixHQUFpQixDQUFwQjtBQUFBO1NBQUEsTUFFSyxJQUFHLEdBQUcsQ0FBQyxNQUFKLEtBQWMsR0FBakI7QUFDSCxVQUFBLEtBQUMsQ0FBQSxZQUFELENBQWMsR0FBZCxDQUFBLENBQUE7QUFDQSxVQUFBLElBQUksTUFBQSxDQUFBLElBQVcsQ0FBQyxLQUFaLEtBQXFCLFVBQXpCO0FBQ0UsWUFBQSxJQUFJLENBQUMsS0FBTCxDQUFBLENBQUEsQ0FERjtXQUZHO1NBQUEsTUFLQSxJQUFHLEdBQUcsQ0FBQyxVQUFKLEtBQWtCLENBQXJCO0FBQ0QsaUJBQU8sSUFBSSxDQUFDLE9BQUwsQ0FBYSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQXRCLENBQVAsQ0FEQztTQVRrQjtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRHpCLENBQUE7QUFBQSxJQWFBLEdBQUcsQ0FBQyxJQUFKLENBQVMsS0FBVCxFQUFnQixJQUFJLENBQUMsR0FBckIsRUFBMEIsSUFBMUIsQ0FiQSxDQUFBO1dBY0EsR0FBRyxDQUFDLElBQUosQ0FBQSxFQWZPO0VBQUEsQ0EzRFQsQ0FBQTs7QUFBQSxpQkE2RUEsT0FBQSxHQUFTLFNBQUMsS0FBRCxHQUFBO0FBQ1AsUUFBQSxHQUFBO0FBQUEsSUFBQSxHQUFBLEdBQU0sQ0FBQyxJQUFDLENBQUEsUUFBRixFQUFZLEtBQVosRUFDSSxJQUFDLENBQUEsSUFETCxFQUVJLElBQUMsQ0FBQSxJQUZMLEVBR0ksSUFBQyxDQUFBLElBSEwsRUFJSSxJQUFDLENBQUEsS0FKTCxFQUtJLElBQUMsQ0FBQSxlQUFELENBQWlCLEtBQWpCLENBTEosQ0FNQyxDQUFDLElBTkYsQ0FNTyxFQU5QLENBQU4sQ0FBQTtBQVFBLFdBQU8sR0FBUCxDQVRPO0VBQUEsQ0E3RVQsQ0FBQTs7QUFBQSxpQkF5RkEsZUFBQSxHQUFpQixTQUFDLEtBQUQsR0FBQTtBQUVmLFFBQUEsZUFBQTtBQUFBLElBQUEsR0FBQSxHQUFNLGtCQUFBLENBQW1CLEtBQW5CLENBQU4sQ0FBQTtBQUNBLFNBQUEsa0JBQUE7OEJBQUE7QUFDRSxNQUFBLEdBQUEsR0FBTSxHQUFHLENBQUMsT0FBSixDQUFZLElBQVosRUFBa0Isa0JBQUEsQ0FBbUIsSUFBbkIsQ0FBbEIsQ0FBTixDQURGO0FBQUEsS0FEQTtBQUdBLFdBQU8sR0FBUCxDQUxlO0VBQUEsQ0F6RmpCLENBQUE7O0FBQUEsaUJBZ0dBLFlBQUEsR0FBYyxTQUFDLEdBQUQsR0FBQTtXQUNaLE9BQU8sQ0FBQyxHQUFSLENBQVksT0FBWixFQUFxQixHQUFyQixFQURZO0VBQUEsQ0FoR2QsQ0FBQTs7QUFtR0E7QUFBQTs7S0FuR0E7O0FBQUEsaUJBc0dBLGVBQUEsR0FBaUIsU0FBQyxVQUFELEdBQUE7QUFDZixJQUFBLElBQUcsVUFBSDthQUNFLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBWixDQUF3QixJQUF4QixFQUE4QixDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxHQUFELEdBQUE7aUJBQzVCLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBWixDQUF3QixHQUFHLENBQUMsRUFBNUIsRUFBZ0M7QUFBQSxZQUM5QixNQUFBLEVBQVEsS0FBQyxDQUFBLFdBQUQsQ0FBYSxVQUFiLENBRHNCO0FBQUEsWUFFOUIsSUFBQSxFQUFNLFVBQVUsQ0FBQyxTQUZhO0FBQUEsWUFHOUIsT0FBQSxFQUFTLENBQUEsVUFBVyxDQUFDLFNBQVMsQ0FBQyxRQUFyQixDQUE4QixlQUE5QixDQUhvQjtXQUFoQyxFQUQ0QjtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQTlCLEVBREY7S0FEZTtFQUFBLENBdEdqQixDQUFBOztBQUFBLGlCQWdIQSxXQUFBLEdBQWEsU0FBQyxVQUFELEdBQUE7QUFDWCxRQUFBLElBQUE7QUFBQSxJQUFBLGlFQUFtQixDQUFFLHlCQUFsQixLQUE0QixDQUEvQjthQUNFLGdCQURGO0tBQUEsTUFBQTthQUdFLGVBSEY7S0FEVztFQUFBLENBaEhiLENBQUE7O0FBc0hBO0FBQUE7O0tBdEhBOztBQUFBLGlCQXlIQSxLQUFBLEdBQU8sU0FBQyxRQUFELEVBQVcsTUFBWCxFQUFtQixTQUFuQixHQUFBO0FBQ0gsUUFBQSxhQUFBOztNQURzQixZQUFZO0tBQ2xDO0FBQUEsSUFBQSxHQUFBLEdBQU0sSUFBQyxDQUFBLFlBQUQsQ0FBYyxRQUFkLENBQU4sQ0FBQTtBQUFBLElBQ0EsUUFBQSxHQUFXLElBQUMsQ0FBQSxZQUFELENBQWMsR0FBZCxDQURYLENBQUE7QUFFQSxJQUFBLElBQUcsUUFBSDtBQUNFLE1BQUEsU0FBQSxHQUFZLFFBQVEsQ0FBQyxhQUFULENBQXVCLHNCQUF2QixDQUFaLENBQUE7QUFDQSxNQUFBLElBQUcsU0FBSDtBQUNFLFFBQUEsU0FBUyxDQUFDLFNBQVYsR0FBc0IsSUFBQyxDQUFBLFdBQXZCLENBQUE7QUFBQSxRQUNBLFNBQVMsQ0FBQyxZQUFWLENBQXVCLGFBQXZCLEVBQXNDLEdBQXRDLENBREEsQ0FBQTtBQUFBLFFBRUEsSUFBQyxDQUFBLFNBQUQsQ0FBVyxTQUFYLENBRkEsQ0FBQTtBQUFBLFFBR0EsSUFBQyxDQUFBLFFBQUQsQ0FBVSxTQUFWLENBSEEsQ0FERjtPQUFBLE1BS0ssSUFBRyxDQUFBLE1BQUg7QUFDSCxRQUFBLFNBQUEsR0FBWSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFaLENBQUE7QUFBQSxRQUNBLFNBQVMsQ0FBQyxTQUFWLEdBQXNCLGVBRHRCLENBQUE7QUFBQSxRQUVBLFNBQVMsQ0FBQyxTQUFWLEdBQXNCLG9DQUZ0QixDQURHO09BUFA7S0FGQTtBQWNBLFdBQU8sU0FBUCxDQWZHO0VBQUEsQ0F6SFAsQ0FBQTs7QUEwSUE7QUFBQTs7S0ExSUE7O0FBQUEsaUJBNklBLFlBQUEsR0FBYyxTQUFDLENBQUQsR0FBQTtBQUNaLFFBQUEsZUFBQTtBQUFBLElBQUEsR0FBQSxHQUFNLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCLENBQU4sQ0FBQTtBQUFBLElBQ0EsR0FBRyxDQUFDLFNBQUosR0FBZ0IsQ0FEaEIsQ0FBQTtBQUFBLElBRUEsT0FBQSxHQUFVLEdBQUcsQ0FBQyxvQkFBSixDQUF5QixRQUF6QixDQUZWLENBQUE7QUFBQSxJQUdBLENBQUEsR0FBSSxPQUFPLENBQUMsTUFIWixDQUFBO0FBSUEsV0FBTSxDQUFBLEVBQU4sR0FBQTtBQUNFLE1BQUEsT0FBUSxDQUFBLENBQUEsQ0FBRSxDQUFDLFVBQVUsQ0FBQyxXQUF0QixDQUFrQyxPQUFRLENBQUEsQ0FBQSxDQUExQyxDQUFBLENBREY7SUFBQSxDQUpBO0FBTUEsV0FBTyxHQUFHLENBQUMsU0FBWCxDQVBZO0VBQUEsQ0E3SWQsQ0FBQTs7QUFBQSxpQkFzSkEsWUFBQSxHQUFjLFNBQUMsR0FBRCxFQUFNLFFBQU4sR0FBQTtBQUNaLFFBQUEsR0FBQTs7TUFEa0IsV0FBVztLQUM3QjtBQUFBLElBQUEsR0FBQSxHQUFNLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCLENBQU4sQ0FBQTtBQUFBLElBQ0EsR0FBRyxDQUFDLFNBQUosR0FBZ0IsR0FEaEIsQ0FBQTtBQUFBLElBRUEsUUFBQSxHQUFXLFFBQVEsQ0FBQyxzQkFBVCxDQUFBLENBRlgsQ0FBQTtBQUdBLFdBQVEsR0FBRyxDQUFDLFVBQVosR0FBQTtBQUNFLE1BQUEsUUFBUSxDQUFDLFdBQVQsQ0FBc0IsR0FBRyxDQUFDLFVBQTFCLENBQUEsQ0FERjtJQUFBLENBSEE7QUFLQSxXQUFPLFFBQVAsQ0FOWTtFQUFBLENBdEpkLENBQUE7O0FBQUEsaUJBOEpBLFNBQUEsR0FBVyxTQUFDLFFBQUQsR0FBQTs7TUFBQyxXQUFTO0tBQ25CO0FBQUEsSUFBQSxJQUFJLENBQUMsTUFBTCxDQUFZLFFBQVosRUFBc0IsS0FBdEIsRUFBNkIsS0FBN0IsQ0FBQSxDQUFBO0FBQ0EsV0FBTyxRQUFQLENBRlM7RUFBQSxDQTlKWCxDQUFBOztBQUFBLGlCQWtLQSxRQUFBLEdBQVUsU0FBQyxRQUFELEdBQUE7O01BQUMsV0FBUztLQUNsQjtBQUFBLElBQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxRQUFaLEVBQXNCLEdBQXRCLEVBQTJCLE1BQTNCLENBQUEsQ0FBQTtBQUNBLFdBQU8sUUFBUCxDQUZRO0VBQUEsQ0FsS1YsQ0FBQTs7QUFBQSxpQkFzS0EsTUFBQSxHQUFRLFNBQUMsUUFBRCxFQUFnQixHQUFoQixFQUFxQixJQUFyQixHQUFBO0FBQ04sUUFBQSxnQ0FBQTs7TUFETyxXQUFTO0tBQ2hCO0FBQUEsSUFBQSxJQUFHLFFBQUg7QUFDRSxNQUFBLElBQUEsR0FBUSxRQUFRLENBQUMsZ0JBQVQsQ0FBMEIsR0FBMUIsQ0FBUixDQUFBO0FBQUEsTUFDQSxNQUFBLEdBQVMsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsR0FBdkIsQ0FEVCxDQUFBO0FBRUE7V0FBQSwyQ0FBQTt1QkFBQTtBQUNFLFFBQUEsTUFBTSxDQUFDLElBQVAsR0FBYyxHQUFJLENBQUEsSUFBQSxDQUFsQixDQUFBO0FBQUEsUUFDQSxNQUFNLENBQUMsSUFBUCxHQUFjLElBQUMsQ0FBQSxJQURmLENBQUE7QUFBQSxRQUVBLE1BQU0sQ0FBQyxRQUFQLEdBQWtCLElBQUMsQ0FBQSxRQUZuQixDQUFBO0FBSUEsUUFBQSxJQUFHLEdBQUcsQ0FBQyxPQUFKLEtBQWUsR0FBbEI7QUFDRSxVQUFBLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBZCxDQUFrQixVQUFsQixDQUFBLENBQUE7QUFDQSxVQUFBLElBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFoQixDQUF3QixPQUF4QixDQUFBLEtBQXNDLENBQUEsQ0FBekM7QUFDRSxZQUFBLE1BQU0sQ0FBQyxRQUFQLEdBQWtCLElBQUEsR0FBTyxNQUFNLENBQUMsUUFBaEMsQ0FBQTtBQUFBLFlBQ0EsR0FBRyxDQUFDLFlBQUosQ0FBaUIsUUFBakIsRUFBMkIsUUFBM0IsQ0FEQSxDQURGO1dBRkY7U0FBQSxNQUtLLElBQUcsR0FBRyxDQUFDLE9BQUosS0FBZSxLQUFsQjtBQUNILFVBQUEsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFkLENBQWtCLFNBQWxCLENBQUEsQ0FERztTQVRMO0FBQUEsc0JBWUEsR0FBRyxDQUFDLFlBQUosQ0FBaUIsSUFBakIsRUFBdUIsTUFBTSxDQUFDLElBQTlCLEVBWkEsQ0FERjtBQUFBO3NCQUhGO0tBRE07RUFBQSxDQXRLUixDQUFBOztjQUFBOztJQWhCRixDQUFBOztBQUFBLE1BMk1NLENBQUMsT0FBUCxHQUFpQixHQUFBLENBQUEsSUEzTWpCLENBQUEiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKX12YXIgZj1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwoZi5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxmLGYuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiLypcciAgTXVsdGl0cmFuIGRlcGVuZHMgb24gaHRtbC1lc2NhcGluZyAobm90IFVURi04KSBydWxlcyBmb3Igc3BlY2lhbCBzeW1ib2xzXHIgIMOgLCDDqCwgw6wsIMOyLCDDuSAtIMOALCDDiCwgw4wsIMOSLCDDmVxyICDDoSwgw6ksIMOtLCDDsywgw7osIMO9IC0gw4EsIMOJLCDDjSwgw5MsIMOaLCDDnVxyICDDoiwgw6osIMOuLCDDtCwgw7sgw4IsIMOKLCDDjiwgw5QsIMObXHIgIMOjLCDDsSwgw7Ugw4MsIMORLCDDlVxyICDDpCwgw6ssIMOvLCDDtiwgw7wsIMO/IMOELCDDiywgw48sIMOWLCDDnCxcciAgw6UsIMOFXHIgIMOmLCDDhlxyICDDpywgw4dcciAgw7AsIMOQXHIgIMO4LCDDmFxyICDCvyDCoSDDn1xyKi9ccnZhciBDSEFSX0NPREVTID0ge1xyICAnJUMzJTgwJzogJyYjMTkyOycsIC8vIMOAXHIgICclQzMlODEnOiAnJiMxOTM7JywgLy8gw4FcciAgJyVDMyU4Mic6ICcmIzE5NDsnLCAvLyDDglxyICAnJUMzJTgzJzogJyYjMTk1OycsIC8vIMODXHIgICclQzMlODQnOiAnJiMxOTY7JywgLy8gw4RcciAgJyVDMyU4NSc6ICcmIzE5NzsnLCAvLyDDhVxyICAnJUMzJTg2JzogJyYjMTk4OycsIC8vIMOGXHJcciAgJyVDMyU4Nyc6ICcmIzE5OTsnLCAvLyDDh1xyICAnJUMzJTg4JzogJyYjMjAwOycsIC8vIMOIXHIgICclQzMlODknOiAnJiMyMDE7JywgLy8gw4lcciAgJyVDMyU4QSc6ICcmIzIwMjsnLCAvLyDDilxyICAnJUMzJThCJzogJyYjMjAzOycsIC8vIMOLXHJcciAgJyVDMyU4Qyc6ICcmIzIwNDsnLCAvLyDDjFxyICAnJUMzJThEJzogJyYjMjA1OycsIC8vIMONXHIgICclQzMlOEUnOiAnJiMyMDY7JywgLy8gw45cciAgJyVDMyU4Ric6ICcmIzIwNzsnLCAvLyDDj1xyXHIgICclQzMlOTEnOiAnJiMyMDk7JywgLy8gw5FcciAgJyVDMyU5Mic6ICcmIzIxMDsnLCAvLyDDklxyICAnJUMzJTkzJzogJyYjMjExOycsIC8vIMOTXHIgICclQzMlOTQnOiAnJiMyMTI7JywgLy8gw5RcciAgJyVDMyU5NSc6ICcmIzIxMzsnLCAvLyDDlVxyICAnJUMzJTk2JzogJyYjMjE0OycsIC8vIMOWXHJcciAgJyVDMyU5OSc6ICcmIzIxNzsnLCAvLyDDmVxyICAnJUMzJTlBJzogJyYjMjE4OycsIC8vIMOaXHIgICclQzMlOUInOiAnJiMyMTk7JywgLy8gw5tcciAgJyVDMyU5Qyc6ICcmIzIyMDsnLCAvLyDDnFxyXHJcciAgJyVDMyVBMCc6ICcmIzIyNDsnLCAvLyDDoFxyICAnJUMzJUExJzogJyYjMjI1OycsIC8vIMOhXHIgICclQzMlQTInOiAnJiMyMjY7JywgLy8gw6JcciAgJyVDMyVBMyc6ICcmIzIyNzsnLCAvLyDDo1xyICAnJUMzJUE0JzogJyYjMjI4OycsIC8vIMOkXHIgICclQzMlQTUnOiAnJiMyMjk7JywgLy8gw6VcciAgJyVDMyVBNic6ICcmIzIzMDsnLCAvLyDDplxyICAnJUMzJUE3JzogJyYjMjMxOycsIC8vIMOnXHJcclxyICAnJUMzJUE4JzogJyYjMjMyOycsIC8vIMOoXHIgICclQzMlQTknOiAnJiMyMzM7JywgLy8gw6lcciAgJyVDMyVBQSc6ICcmIzIzNDsnLCAvLyDDqlxyICAnJUMzJUFCJzogJyYjMjM1OycsIC8vIMOrXHJcciAgJyVDMyVBQyc6ICcmIzIzNjsnLCAvLyDDrFxyICAnJUMzJUFEJzogJyYjMjM3OycsIC8vIMOtXHIgICclQzMlQUUnOiAnJiMyMzg7JywgLy8gw65cciAgJyVDMyVBRic6ICcmIzIzOTsnLCAvLyDDr1xyXHIgICclQzMlQjAnOiAnJiMyNDA7JywgLy8gw7BcciAgJyVDMyVCMSc6ICcmIzI0MTsnLCAvLyDDsVxyXHIgICclQzMlQjInOiAnJiMyNDI7JywgLy8gw7JcciAgJyVDMyVCMyc6ICcmIzI0MzsnLCAvLyDDs1xyICAnJUMzJUI0JzogJyYjMjQ0OycsIC8vIMO0XHIgICclQzMlQjUnOiAnJiMyNDU7JywgLy8gw7VcciAgJyVDMyVCNic6ICcmIzI0NjsnLCAvLyDDtlxyXHIgICclQzMlQjknOiAnJiMyNDk7JywgLy8gw7lcciAgJyVDMyVCQSc6ICcmIzI1MDsnLCAvLyDDulxyICAnJUMzJUJCJzogJyYjMjUxOycsIC8vIMO7XHIgICclQzMlQkMnOiAnJiMyNTI7JywgLy8gw7xcciAgJyVDMyVCRic6ICcmIzI1NTsnLCAvLyDDv1xyICAnJUM1JUI4JzogJyYjMzc2OycsIC8vIMW4XHJcciAgJyVDMyU5Ric6ICcmIzIyMzsnLCAvLyDDn1xyXHIgICclQzIlQkYnOiAnJiMxOTE7JywgLy8gwr9cciAgJyVDMiVBMSc6ICcmIzE2MTsnLCAvLyDCoVxyfTtcclxybW9kdWxlLmV4cG9ydHMgPSBDSEFSX0NPREVTO1xyIiwiIyMjZ2xvYmFsIGNocm9tZSMjI1xuIyMjXG4gIE11bHRpdHJhbi5ydSB0cmFuc2xhdGUgZW5naW5lXG4gIFByb3ZpZGVzIHByb2dyYW0gaW50ZXJmYWNlIGZvciBtYWtpbmcgdHJhbnNsYXRlIHF1ZXJpZXMgdG8gbXVsdGl0cmFuIGFuZCBnZXQgY2xlYW4gcmVzcG9uc2VcblxuICBBbGwgZW5naW5lcyBtdXN0IGZvbGxvdyBjb21tb24gaW50ZXJmYWNlIGFuZCBwcm92aWRlIG1ldGhvZHM6XG4gICAgLSBzZWFyY2ggKGxhbmd1YW5nZSwgc3VjY2Vzc0hhbmRsZXIpICBjbGVhbiB0cmFuc2xhdGlvbiBtdXN0IGJlIHBhc3NlZCBpbnRvIHN1Y2Nlc3NIYW5kbGVyXG4gICAgLSBjbGlja1xuXG4gIFRyYW5zbGF0aW9uLW1vZHVsZSB0aGF0IG1ha2VzIHJlcXVlc3RzIHRvIGxhbmd1YWdlLWVuZ2luZSxcbiAgcGFyc2VzIHJlc3VsdHMgYW5kIHNlbmRzIHBsdWdpbi1nbG9iYWwgbWVzc2FnZSB3aXRoIHRyYW5zbGF0aW9uIGRhdGFcbiMjI1xuXG5DSEFSX0NPREVTID0gcmVxdWlyZSgnLi9jaGFyLWNvZGVzLmpzJyk7XG5cbmNsYXNzIFRyYW5cbiAgY29uc3RydWN0b3I6IC0+XG4gICAgQFRBQkxFX0NMQVNTID0gXCJfX19tdHRfdHJhbnNsYXRlX3RhYmxlXCJcbiAgICBAcHJvdG9jb2wgPSAnaHR0cCdcbiAgICBAaG9zdCA9ICd3d3cubXVsdGl0cmFuLnJ1J1xuICAgIEBwYXRoID0gJy9jL20uZXhlJ1xuICAgIEBxdWVyeSA9ICcmcz0nXG4gICAgQGxhbmcgPSAnP2wxPTImbDI9MScgI2Zyb20gcnVzc2lhbiB0byBlbmdsaXNoIGJ5IGRlZmF1bHRcbiAgICBAeGhyID0ge31cblxuICAjIyNcbiAgICBDb250ZXh0IG1lbnUgY2xpY2sgaGFuZGxlclxuICAjIyNcbiAgY2xpY2s6IChkYXRhKSAtPlxuICAgIGlmIHR5cGVvZiBkYXRhLnNpbGVudCA9PSB1bmRlZmluZWQgfHwgZGF0YS5zaWxlbnQgPT0gbnVsbFxuICAgICAgZGF0YS5zaWxlbnQgPSB0cnVlICMgdHJ1ZSBieSBkZWZhdWx0XG4gICAgc2VsZWN0aW9uVGV4dCA9IEByZW1vdmVIeXBoZW5hdGlvbiBkYXRhLnNlbGVjdGlvblRleHRcbiAgICBAc2VhcmNoXG4gICAgICAgIHZhbHVlOiBzZWxlY3Rpb25UZXh0XG4gICAgICAgIHN1Y2Nlc3M6IEBzdWNjZXNzdEhhbmRsZXIuYmluZCh0aGlzKVxuICAgICAgICBzaWxlbnQ6IGRhdGEuc2lsZW50ICAjIGlmIHRyYW5zbGF0aW9uIGZhaWxlZCBkbyBub3Qgc2hvdyBkaWFsb2dcblxuICAjIyNcbiAgICBEaXNjYXJkIHNvZnQgaHlwaGVuIGNoYXJhY3RlciAoVSswMEFELCAmc2h5OykgZnJvbSB0aGUgaW5wdXRcbiAgIyMjXG4gIHJlbW92ZUh5cGhlbmF0aW9uOiAodGV4dCkgLT5cbiAgICB0ZXh0LnJlcGxhY2UgL1xceGFkL2csICcnXG5cbiAgIyMjXG4gICAgSW5pdGlhdGUgdHJhbnNsYXRpb24gc2VhcmNoXG4gICMjI1xuICBzZWFyY2g6IChwYXJhbXMpIC0+XG4gICAgI3ZhbHVlLCBjYWxsYmFjaywgZXJyXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoe2xhbmd1YWdlOiAnMSd9LCAoaXRlbXMpID0+XG4gICAgICBpZiBsYW5ndWFnZSBpcyAnJ1xuICAgICAgICBsYW5ndWFnZSA9ICcxJ1xuICAgICAgQHNldExhbmd1YWdlKGl0ZW1zLmxhbmd1YWdlKVxuICAgICAgdXJsID0gQG1ha2VVcmwocGFyYW1zLnZhbHVlKTtcbiAgICAgICMgZGVjb3JhdGUgc3VjY2VzcyB0byBtYWtlIHByZWxpbWluYXJ5IHBhcnNpbmdcbiAgICAgIG9yaWdTdWNjZXNzID0gcGFyYW1zLnN1Y2Nlc3NcbiAgICAgIHBhcmFtcy5zdWNjZXNzID0gKHJlc3BvbnNlKSA9PlxuICAgICAgICB0cmFuc2xhdGVkID0gQHBhcnNlKHJlc3BvbnNlLCBwYXJhbXMuc2lsZW50KVxuICAgICAgICBvcmlnU3VjY2Vzcyh0cmFuc2xhdGVkKVxuXG4gICAgICAjIG1ha2UgcmVxdWVzdCAoR0VUIHJlcXVlc3Qgd2l0aCBxdWVyeSBwYXJhbWV0ZXJzIGluIHVybClcbiAgICAgIEByZXF1ZXN0KFxuICAgICAgICB1cmw6IHVybCxcbiAgICAgICAgc3VjY2VzczogcGFyYW1zLnN1Y2Nlc3MsXG4gICAgICAgIGVycm9yOiBwYXJhbXMuZXJyb3JcbiAgICAgIClcbiAgICApXG5cbiAgc2V0TGFuZ3VhZ2U6IChsYW5ndWFnZSkgLT5cbiAgICBAY3VycmVudExhbmd1YWdlID0gbGFuZ3VhZ2VcbiAgICBAbGFuZyA9ICc/bDE9MiZsMj0nICsgbGFuZ3VhZ2VcblxuICAjIyNcbiAgICBSZXF1ZXN0IHRyYW5zbGF0aW9uIGFuZCBydW4gY2FsbGJhY2sgZnVuY3Rpb25cbiAgICBwYXNzaW5nIHRyYW5zbGF0ZWQgcmVzdWx0IG9yIGVycm9yIHRvIGNhbGxiYWNrXG4gICMjI1xuICByZXF1ZXN0OiAob3B0cykgLT5cbiAgICB4aHIgPSBAeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KClcbiAgICB4aHIub25yZWFkeXN0YXRlY2hhbmdlID0gKGUpID0+XG4gICAgICB4aHIgPSBAeGhyXG4gICAgICBpZiB4aHIucmVhZHlTdGF0ZSA8IDRcbiAgICAgICAgcmV0dXJuXG4gICAgICBlbHNlIGlmIHhoci5zdGF0dXMgIT0gMjAwXG4gICAgICAgIEBlcnJvckhhbmRsZXIoeGhyKVxuICAgICAgICBpZiAodHlwZW9mIG9wdHMuZXJyb3IgPT0gJ2Z1bmN0aW9uJylcbiAgICAgICAgICBvcHRzLmVycm9yKClcbiAgICAgICAgcmV0dXJuXG4gICAgICBlbHNlIGlmIHhoci5yZWFkeVN0YXRlID09IDRcbiAgICAgICAgICByZXR1cm4gb3B0cy5zdWNjZXNzKGUudGFyZ2V0LnJlc3BvbnNlKVxuXG4gICAgeGhyLm9wZW4oXCJHRVRcIiwgb3B0cy51cmwsIHRydWUpO1xuICAgIHhoci5zZW5kKCk7XG5cblxuICBtYWtlVXJsOiAodmFsdWUpIC0+XG4gICAgdXJsID0gW0Bwcm90b2NvbCwgJzovLycsXG4gICAgICAgICAgICAgIEBob3N0LFxuICAgICAgICAgICAgICBAcGF0aCxcbiAgICAgICAgICAgICAgQGxhbmcsXG4gICAgICAgICAgICAgIEBxdWVyeSxcbiAgICAgICAgICAgICAgQGdldEVuY29kZWRWYWx1ZSh2YWx1ZSlcbiAgICAgICAgICBdLmpvaW4oJycpXG5cbiAgICByZXR1cm4gdXJsO1xuXG4gICMgUmVwbGFjZSBzcGVjaWFsIGxhbmd1YWdlIGNoYXJhY3RlcnMgdG8gaHRtbCBjb2Rlc1xuICBnZXRFbmNvZGVkVmFsdWU6ICh2YWx1ZSkgLT5cbiAgICAjIHRvIGZpbmQgc3BlYyBzeW1ib2xzIHdlIGZpcnN0IGVuY29kZSB0aGVtIChyYXcgc2VhcmNoIGZvciB0aGF0IHN5bWJvbCBkb2Vzbid0IHdvcilcbiAgICB2YWwgPSBlbmNvZGVVUklDb21wb25lbnQodmFsdWUpXG4gICAgZm9yIGNoYXIsIGNvZGUgb2YgQ0hBUl9DT0RFU1xuICAgICAgdmFsID0gdmFsLnJlcGxhY2UoY2hhciwgZW5jb2RlVVJJQ29tcG9uZW50KGNvZGUpKVxuICAgIHJldHVybiB2YWxcblxuICBlcnJvckhhbmRsZXI6ICh4aHIpIC0+XG4gICAgY29uc29sZS5sb2coJ2Vycm9yJywgeGhyKVxuXG4gICMjI1xuICAgUmVjZWl2aW5nIGRhdGEgZnJvbSB0cmFuc2xhdGlvbi1lbmdpbmUgYW5kIHNlbmQgcmVhZHkgbWVzc2FnZSB3aXRoIGRhdGFcbiAgIyMjXG4gIHN1Y2Nlc3N0SGFuZGxlcjogKHRyYW5zbGF0ZWQpIC0+XG4gICAgaWYgdHJhbnNsYXRlZFxuICAgICAgY2hyb21lLnRhYnMuZ2V0U2VsZWN0ZWQobnVsbCwgKHRhYikgPT5cbiAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgYWN0aW9uOiBAbWVzc2FnZVR5cGUgdHJhbnNsYXRlZFxuICAgICAgICAgIGRhdGE6IHRyYW5zbGF0ZWQub3V0ZXJIVE1MLFxuICAgICAgICAgIHN1Y2Nlc3M6ICF0cmFuc2xhdGVkLmNsYXNzTGlzdC5jb250YWlucygnZmFpbFRyYW5zbGF0ZScpXG4gICAgICAgIH0pXG4gICAgICApXG5cbiAgbWVzc2FnZVR5cGU6ICh0cmFuc2xhdGVkKSAtPlxuICAgIGlmIHRyYW5zbGF0ZWQ/LnJvd3M/Lmxlbmd0aCA9PSAxXG4gICAgICAnc2ltaWxhcl93b3JkcydcbiAgICBlbHNlXG4gICAgICAnb3Blbl90b29sdGlwJ1xuXG4gICMjI1xuICAgIFBhcnNlIHJlc3BvbnNlIGZyb20gdHJhbnNsYXRpb24gZW5naW5lXG4gICMjI1xuICBwYXJzZTogKHJlc3BvbnNlLCBzaWxlbnQsIHRyYW5zbGF0ZSA9IG51bGwpIC0+XG4gICAgICBkb2MgPSBAc3RyaXBTY3JpcHRzKHJlc3BvbnNlKVxuICAgICAgZnJhZ21lbnQgPSBAbWFrZUZyYWdtZW50KGRvYylcbiAgICAgIGlmIGZyYWdtZW50XG4gICAgICAgIHRyYW5zbGF0ZSA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3IoJyN0cmFuc2xhdGlvbiB+IHRhYmxlJylcbiAgICAgICAgaWYgdHJhbnNsYXRlXG4gICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9IEBUQUJMRV9DTEFTUztcbiAgICAgICAgICB0cmFuc2xhdGUuc2V0QXR0cmlidXRlKFwiY2VsbHBhZGRpbmdcIiwgXCI1XCIpXG4gICAgICAgICAgQGZpeEltYWdlcyh0cmFuc2xhdGUpXG4gICAgICAgICAgQGZpeExpbmtzKHRyYW5zbGF0ZSlcbiAgICAgICAgZWxzZSBpZiBub3Qgc2lsZW50XG4gICAgICAgICAgdHJhbnNsYXRlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gJ2ZhaWxUcmFuc2xhdGUnXG4gICAgICAgICAgdHJhbnNsYXRlLmlubmVyVGV4dCA9IFwiVW5mb3J0dW5hdGVseSwgY291bGQgbm90IHRyYW5zbGF0ZVwiXG5cbiAgICAgIHJldHVybiB0cmFuc2xhdGU7XG5cbiAgIyMjXG4gICAgU3RyaXAgc2NyaXB0IHRhZ3MgZnJvbSByZXNwb25zZSBodG1sXG4gICMjI1xuICBzdHJpcFNjcmlwdHM6IChzKSAtPlxuICAgIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgZGl2LmlubmVySFRNTCA9IHNcbiAgICBzY3JpcHRzID0gZGl2LmdldEVsZW1lbnRzQnlUYWdOYW1lKCdzY3JpcHQnKVxuICAgIGkgPSBzY3JpcHRzLmxlbmd0aFxuICAgIHdoaWxlIGktLVxuICAgICAgc2NyaXB0c1tpXS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHNjcmlwdHNbaV0pXG4gICAgcmV0dXJuIGRpdi5pbm5lckhUTUw7XG5cbiAgbWFrZUZyYWdtZW50OiAoZG9jLCBmcmFnbWVudCA9IG51bGwpIC0+XG4gICAgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKVxuICAgIGRpdi5pbm5lckhUTUwgPSBkb2NcbiAgICBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKVxuICAgIHdoaWxlICggZGl2LmZpcnN0Q2hpbGQgKVxuICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoIGRpdi5maXJzdENoaWxkIClcbiAgICByZXR1cm4gZnJhZ21lbnRcblxuICBmaXhJbWFnZXM6IChmcmFnbWVudD1udWxsKSAtPlxuICAgIHRoaXMuZml4VXJsKGZyYWdtZW50LCAnaW1nJywgJ3NyYycpO1xuICAgIHJldHVybiBmcmFnbWVudDtcblxuICBmaXhMaW5rczogKGZyYWdtZW50PW51bGwpIC0+XG4gICAgdGhpcy5maXhVcmwoZnJhZ21lbnQsICdhJywgJ2hyZWYnKVxuICAgIHJldHVybiBmcmFnbWVudFxuXG4gIGZpeFVybDogKGZyYWdtZW50PW51bGwsIHRhZywgYXR0cikgLT5cbiAgICBpZiBmcmFnbWVudFxuICAgICAgdGFncyA9ICBmcmFnbWVudC5xdWVyeVNlbGVjdG9yQWxsKHRhZylcbiAgICAgIHBhcnNlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKVxuICAgICAgZm9yIHRhZyBpbiB0YWdzXG4gICAgICAgIHBhcnNlci5ocmVmID0gdGFnW2F0dHJdXG4gICAgICAgIHBhcnNlci5ob3N0ID0gQGhvc3RcbiAgICAgICAgcGFyc2VyLnByb3RvY29sID0gQHByb3RvY29sXG4gICAgICAgICNmaXggcmVsYXRpdmUgbGlua3NcbiAgICAgICAgaWYgdGFnLnRhZ05hbWUgPT0gJ0EnXG4gICAgICAgICAgdGFnLmNsYXNzTGlzdC5hZGQgJ210dF9saW5rJ1xuICAgICAgICAgIGlmIHBhcnNlci5wYXRobmFtZS5pbmRleE9mKCdtLmV4ZScpIGlzbnQgLTFcbiAgICAgICAgICAgIHBhcnNlci5wYXRobmFtZSA9ICcvYycgKyBwYXJzZXIucGF0aG5hbWVcbiAgICAgICAgICAgIHRhZy5zZXRBdHRyaWJ1dGUoJ3RhcmdldCcsICdfYmxhbmsnKVxuICAgICAgICBlbHNlIGlmIHRhZy50YWdOYW1lID09ICdJTUcnXG4gICAgICAgICAgdGFnLmNsYXNzTGlzdC5hZGQgJ210dF9pbWcnXG5cbiAgICAgICAgdGFnLnNldEF0dHJpYnV0ZShhdHRyLCBwYXJzZXIuaHJlZilcblxuXG5cbm1vZHVsZS5leHBvcnRzID0gbmV3IFRyYW4iXX0=
