(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){

/*global tran, chrome */
var CHAR_CODES, tran, turkishDictionary;

CHAR_CODES = require('./char-codes.js');

tran = require('./tran.coffee');

turkishDictionary = require('./turkishdictionary.js');

chrome.contextMenus.create({
  title: 'Multitran: "%s"',
  contexts: ["page", "frame", "editable", "image", "video", "audio", "link", "selection"],
  onclick: function(data) {
    data.silent = false;
    return tran.click(data);
  }
});


/*
 Can't get chrome.storage directly from content_script
 so content_script sends request message and then background script
 responds with storage value
 */

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.method === "get_fast_option") {
    chrome.storage.sync.get({
      fast: true
    }, function(items) {
      return sendResponse({
        fast: items.fast
      });
    });
  } else if (request.method === 'request_search') {
    chrome.storage.sync.get({
      language: '1',
      fast: true
    }, function(items) {
      request.data.silent = true;
      if (parseInt(items.language, 10) === 1000) {
        turkishDictionary.translate(request.data);
      } else {
        tran.click(request.data);
      }
      return true;
    });
  }
  return true;
});


},{"./char-codes.js":3,"./tran.coffee":4,"./turkishdictionary.js":5}],2:[function(require,module,exports){
var CHAR_CODES = {
  // turkishdictionary codings
  '%C4%B1': '%FD', //ı (Lowercase i-dotless)  actually it is &#305; but turkishdictionary need it this way 
  '%C5%9F': '%FE', //ş
  '%C4%9F': '%F0', //ğ  (silent character)
  '%C3%A7': '%E7', //ç
  '%C3%B6': '%F6', //ö
  '%C3%BC': '%FC', //ü
  '%C3%A2': '%E2' // â
}

module.exports = CHAR_CODES;
},{}],3:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/var CHAR_CODES = {  '%C3%80': '&#192;', // À  '%C3%81': '&#193;', // Á  '%C3%82': '&#194;', // Â  '%C3%83': '&#195;', // Ã  '%C3%84': '&#196;', // Ä  '%C3%85': '&#197;', // Å  '%C3%86': '&#198;', // Æ  '%C3%87': '&#199;', // Ç  '%C3%88': '&#200;', // È  '%C3%89': '&#201;', // É  '%C3%8A': '&#202;', // Ê  '%C3%8B': '&#203;', // Ë  '%C3%8C': '&#204;', // Ì  '%C3%8D': '&#205;', // Í  '%C3%8E': '&#206;', // Î  '%C3%8F': '&#207;', // Ï  '%C3%91': '&#209;', // Ñ  '%C3%92': '&#210;', // Ò  '%C3%93': '&#211;', // Ó  '%C3%94': '&#212;', // Ô  '%C3%95': '&#213;', // Õ  '%C3%96': '&#214;', // Ö  '%C3%99': '&#217;', // Ù  '%C3%9A': '&#218;', // Ú  '%C3%9B': '&#219;', // Û  '%C3%9C': '&#220;', // Ü  '%C3%A0': '&#224;', // à  '%C3%A1': '&#225;', // á  '%C3%A2': '&#226;', // â  '%C3%A3': '&#227;', // ã  '%C3%A4': '&#228;', // ä  '%C3%A5': '&#229;', // å  '%C3%A6': '&#230;', // æ  '%C3%A7': '&#231;', // ç  '%C3%A8': '&#232;', // è  '%C3%A9': '&#233;', // é  '%C3%AA': '&#234;', // ê  '%C3%AB': '&#235;', // ë  '%C3%AC': '&#236;', // ì  '%C3%AD': '&#237;', // í  '%C3%AE': '&#238;', // î  '%C3%AF': '&#239;', // ï  '%C3%B0': '&#240;', // ð  '%C3%B1': '&#241;', // ñ  '%C3%B2': '&#242;', // ò  '%C3%B3': '&#243;', // ó  '%C3%B4': '&#244;', // ô  '%C3%B5': '&#245;', // õ  '%C3%B6': '&#246;', // ö  '%C3%B9': '&#249;', // ù  '%C3%BA': '&#250;', // ú  '%C3%BB': '&#251;', // û  '%C3%BC': '&#252;', // ü  '%C3%BF': '&#255;', // ÿ  '%C5%B8': '&#376;', // Ÿ  '%C3%9F': '&#223;', // ß  '%C2%BF': '&#191;', // ¿  '%C2%A1': '&#161;', // ¡};module.exports = CHAR_CODES;
},{}],4:[function(require,module,exports){

/*global chrome */

/*
  Multitran.ru translate engine
  Provides program interface for making translate queries to multitran and get clean response

  All engines must follow common interface and provide methods:
    - search (languange, successHandler)  clean translation must be passed into successHandler
    - click

  Translation-module that makes requests to language-engine,
  parses results and sends plugin-global message with translation data
 */
var CHAR_CODES, Tran;

CHAR_CODES = require('./char-codes.js');

Tran = (function() {
  function Tran() {
    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1';
    this.xhr = {};
  }


  /*
    Context menu click handler
   */

  Tran.prototype.click = function(data) {
    var selectionText;
    if (typeof data.silent === void 0 || data.silent === null) {
      data.silent = true;
    }
    selectionText = this.removeHyphenation(data.selectionText);
    return this.search({
      value: selectionText,
      success: this.successtHandler.bind(this),
      silent: data.silent
    });
  };


  /*
    Discard soft hyphen character (U+00AD, &shy;) from the input
   */

  Tran.prototype.removeHyphenation = function(text) {
    return text.replace(/\xad/g, '');
  };


  /*
    Initiate translation search
   */

  Tran.prototype.search = function(params) {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(items) {
        var language, origSuccess, url;
        if (language === '') {
          language = '1';
        }
        _this.setLanguage(items.language);
        url = _this.makeUrl(params.value);
        origSuccess = params.success;
        params.success = function(response) {
          var translated;
          translated = _this.parse(response, params.silent);
          return origSuccess(translated);
        };
        return _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      };
    })(this));
  };

  Tran.prototype.setLanguage = function(language) {
    this.currentLanguage = language;
    return this.lang = '?l1=2&l2=' + language;
  };


  /*
    Request translation and run callback function
    passing translated result or error to callback
   */

  Tran.prototype.request = function(opts) {
    var xhr;
    xhr = this.xhr = new XMLHttpRequest();
    xhr.onreadystatechange = (function(_this) {
      return function(e) {
        xhr = _this.xhr;
        if (xhr.readyState < 4) {

        } else if (xhr.status !== 200) {
          _this.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error();
          }
        } else if (xhr.readyState === 4) {
          return opts.success(e.target.response);
        }
      };
    })(this);
    xhr.open("GET", opts.url, true);
    return xhr.send();
  };

  Tran.prototype.makeUrl = function(value) {
    var url;
    url = [this.protocol, '://', this.host, this.path, this.lang, this.query, this.getEncodedValue(value)].join('');
    return url;
  };

  Tran.prototype.getEncodedValue = function(value) {
    var char, code, val;
    val = encodeURIComponent(value);
    for (char in CHAR_CODES) {
      code = CHAR_CODES[char];
      val = val.replace(char, encodeURIComponent(code));
    }
    return val;
  };

  Tran.prototype.errorHandler = function(xhr) {
    return console.log('error', xhr);
  };


  /*
   Receiving data from translation-engine and send ready message with data
   */

  Tran.prototype.successtHandler = function(translated) {
    if (translated) {
      return chrome.tabs.getSelected(null, (function(_this) {
        return function(tab) {
          return chrome.tabs.sendMessage(tab.id, {
            action: _this.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        };
      })(this));
    }
  };

  Tran.prototype.messageType = function(translated) {
    var _ref;
    if ((translated != null ? (_ref = translated.rows) != null ? _ref.length : void 0 : void 0) === 1) {
      return 'similar_words';
    } else {
      return 'open_tooltip';
    }
  };


  /*
    Parse response from translation engine
   */

  Tran.prototype.parse = function(response, silent, translate) {
    var doc, fragment;
    if (translate == null) {
      translate = null;
    }
    doc = this.stripScripts(response);
    fragment = this.makeFragment(doc);
    if (fragment) {
      translate = fragment.querySelector('#translation ~ table');
      if (translate) {
        translate.className = this.TABLE_CLASS;
        translate.setAttribute("cellpadding", "5");
        this.fixImages(translate);
        this.fixLinks(translate);
      } else if (!silent) {
        translate = document.createElement('div');
        translate.className = 'failTranslate';
        translate.innerText = "Unfortunately, could not translate";
      }
    }
    return translate;
  };


  /*
    Strip script tags from response html
   */

  Tran.prototype.stripScripts = function(s) {
    var div, i, scripts;
    div = document.createElement('div');
    div.innerHTML = s;
    scripts = div.getElementsByTagName('script');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
    return div.innerHTML;
  };

  Tran.prototype.makeFragment = function(doc, fragment) {
    var div;
    if (fragment == null) {
      fragment = null;
    }
    div = document.createElement("div");
    div.innerHTML = doc;
    fragment = document.createDocumentFragment();
    while (div.firstChild) {
      fragment.appendChild(div.firstChild);
    }
    return fragment;
  };

  Tran.prototype.fixImages = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'img', 'src');
    return fragment;
  };

  Tran.prototype.fixLinks = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'a', 'href');
    return fragment;
  };

  Tran.prototype.fixUrl = function(fragment, tag, attr) {
    var parser, tags, _i, _len, _results;
    if (fragment == null) {
      fragment = null;
    }
    if (fragment) {
      tags = fragment.querySelectorAll(tag);
      parser = document.createElement('a');
      _results = [];
      for (_i = 0, _len = tags.length; _i < _len; _i++) {
        tag = tags[_i];
        parser.href = tag[attr];
        parser.host = this.host;
        parser.protocol = this.protocol;
        if (tag.tagName === 'A') {
          tag.classList.add('mtt_link');
          if (parser.pathname.indexOf('m.exe') !== -1) {
            parser.pathname = '/c' + parser.pathname;
            tag.setAttribute('target', '_blank');
          }
        } else if (tag.tagName === 'IMG') {
          tag.classList.add('mtt_img');
        }
        _results.push(tag.setAttribute(attr, parser.href));
      }
      return _results;
    }
  };

  return Tran;

})();

module.exports = new Tran;


},{"./char-codes.js":3}],5:[function(require,module,exports){
"use strict";

var _prototypeProperties = function (child, staticProps, instanceProps) {
  if (staticProps) Object.defineProperties(child, staticProps);
  if (instanceProps) Object.defineProperties(child.prototype, instanceProps);
};

/*
  Translation engine: http://www.turkishdictionary.net
  For translating turkish-russian and vice versa
*/
var CHAR_CODES = require("./char-codes-turk.js");

var TurkishDictionary = (function () {
  function TurkishDictionary() {
    this.host = "http://www.turkishdictionary.net/?word=%FC";
    this.path = "";
    this.protocol = "http";
    this.query = "&s=";
    this.TABLE_CLASS = "___mtt_translate_table";
    this.need_publish = true;
  }

  _prototypeProperties(TurkishDictionary, null, {
    search: {
      value: function search(data) {
        data.url = this.makeUrl(data.value);
        this.need_publish = false;
        return this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    translate: {
      value: function translate(data) {
        console.log("request data:", data);
        data.url = this.makeUrl(data.selectionText);
        this.need_publish = true;
        this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeUrl: {
      value: function makeUrl(text) {
        var text = this.getEncodedValue(text);
        return ["http://www.turkishdictionary.net/?word=", text].join("");
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    getEncodedValue: {
      // Replace special language characters to html codes
      value: function getEncodedValue(value) {
        // to find spec symbols we first encode them (raw search for that symbol doesn't wor)
        var val = encodeURIComponent(value);
        for (var char in CHAR_CODES) {
          val = val.replace(char, CHAR_CODES[char]);
        }
        return val;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    request: {

      /*
        Request translation and run callback function
        passing translated result or error to callback
      */
      value: function request(opts) {
        console.log("start request");
        this.xhr = new XMLHttpRequest();
        this.xhr.onreadystatechange = this.onReadyStateChange.bind(this, opts);
        this.xhr.open("GET", opts.url, true);
        this.xhr.send();
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    onReadyStateChange: {
      value: function onReadyStateChange(opts, e) {
        var xhr = this.xhr;
        if (xhr.readyState < 4) {
          return;
        } else if (xhr.status != 200) {
          this.errorHandler(xhr);
          return opts.error && opts.error();
        } else if (xhr.readyState == 4) {
          var translation = this.successHandler(e.target.response);
          console.log("success turkish translate", translation);
          console.log("call", opts.success);
          return opts.success && opts.success(translation);
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    successHandler: {
      value: function successHandler(response) {
        var data = this.parse(response);
        if (this.need_publish) {
          chrome.tabs.getSelected(null, this.publishTranslation.bind(this, data));
        }
        return data;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    publishTranslation: {

      /* publish successfuly translated text all over extension */
      value: function publishTranslation(translation, tab) {
        console.log("publish translation");
        chrome.tabs.sendMessage(tab.id, {
          action: "open_tooltip",
          data: translation.outerHTML,
          success: !translation.classList.contains("failTranslate")
        });
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    errorHandler: {
      value: function errorHandler(response) {
        console.log("error ajax", response);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parse: {

      /* Parse response from translation engine */
      value: function parse(response, silent, translate) {
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);
        if (fragment) {
          translate = fragment.querySelector("#meaning_div > table");
          if (translate) {
            translate.className = this.TABLE_CLASS;
            translate.setAttribute("cellpadding", "5");
            // @fixImages(translate)
            // @fixLinks(translate)
          } else if (!silent) {
            translate = document.createElement("div");
            translate.className = "failTranslate";
            translate.innerText = "Unfortunately, could not translate";
          }
        }
        return translate;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    stripScripts: {

      //TODO extract to base engine class
      /* removes <script> tags from html code */
      value: function stripScripts(html) {
        var div = document.createElement("div");
        div.innerHTML = html;
        var scripts = div.getElementsByTagName("script");
        var i = scripts.length;
        while (i--) scripts[i].parentNode.removeChild(scripts[i]);
        return div.innerHTML;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeFragment: {

      //TODO extract to base engine class
      /* creates temp object to parse translation from page 
        (since it's not a friendly api) 
      */
      value: function makeFragment(html) {
        var fragment,
            div = document.createElement("div");
        div.innerHTML = html;
        fragment = document.createDocumentFragment();
        while (div.firstChild) {
          fragment.appendChild(div.firstChild);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    }
  });

  return TurkishDictionary;
})();

// Singletone
module.exports = new TurkishDictionary();
},{"./char-codes-turk.js":2}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvYmFja2dyb3VuZC5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXZlbG9wbWVudC90cmFuL2pzL2NoYXItY29kZXMtdHVyay5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvY2hhci1jb2Rlcy5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvdHJhbi5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXZlbG9wbWVudC90cmFuL2pzL3R1cmtpc2hkaWN0aW9uYXJ5LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFBQSx3QkFBQTtBQUFBLElBQUEsbUNBQUE7O0FBQUEsVUFHQSxHQUFhLE9BQUEsQ0FBUSxpQkFBUixDQUhiLENBQUE7O0FBQUEsSUFLQSxHQUFPLE9BQUEsQ0FBUSxlQUFSLENBTFAsQ0FBQTs7QUFBQSxpQkFNQSxHQUFvQixPQUFBLENBQVEsd0JBQVIsQ0FOcEIsQ0FBQTs7QUFBQSxNQVNNLENBQUMsWUFBWSxDQUFDLE1BQXBCLENBQ0U7QUFBQSxFQUFBLEtBQUEsRUFBUSxpQkFBUjtBQUFBLEVBQ0EsUUFBQSxFQUFVLENBQUMsTUFBRCxFQUFTLE9BQVQsRUFBa0IsVUFBbEIsRUFBOEIsT0FBOUIsRUFBdUMsT0FBdkMsRUFBZ0QsT0FBaEQsRUFBeUQsTUFBekQsRUFBaUUsV0FBakUsQ0FEVjtBQUFBLEVBRUEsT0FBQSxFQUFVLFNBQUMsSUFBRCxHQUFBO0FBQ1IsSUFBQSxJQUFJLENBQUMsTUFBTCxHQUFjLEtBQWQsQ0FBQTtXQUNBLElBQUksQ0FBQyxLQUFMLENBQVcsSUFBWCxFQUZRO0VBQUEsQ0FGVjtDQURGLENBVEEsQ0FBQTs7QUFpQkE7QUFBQTs7OztHQWpCQTs7QUFBQSxNQXNCTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsV0FBekIsQ0FBcUMsU0FBQyxPQUFELEVBQVUsTUFBVixFQUFrQixZQUFsQixHQUFBO0FBQ25DLEVBQUEsSUFBRyxPQUFPLENBQUMsTUFBUixLQUFrQixpQkFBckI7QUFDRSxJQUFBLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsTUFBQSxJQUFBLEVBQU0sSUFBTjtLQUF4QixFQUFvQyxTQUFDLEtBQUQsR0FBQTthQUNoQyxZQUFBLENBQWE7QUFBQSxRQUFBLElBQUEsRUFBTSxLQUFLLENBQUMsSUFBWjtPQUFiLEVBRGdDO0lBQUEsQ0FBcEMsQ0FBQSxDQURGO0dBQUEsTUFPSyxJQUFHLE9BQU8sQ0FBQyxNQUFSLEtBQWtCLGdCQUFyQjtBQUNILElBQUEsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBcEIsQ0FBd0I7QUFBQSxNQUFFLFFBQUEsRUFBVSxHQUFaO0FBQUEsTUFBaUIsSUFBQSxFQUFNLElBQXZCO0tBQXhCLEVBQXNELFNBQUMsS0FBRCxHQUFBO0FBQ3BELE1BQUEsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFiLEdBQXNCLElBQXRCLENBQUE7QUFDQSxNQUFBLElBQUcsUUFBQSxDQUFTLEtBQUssQ0FBQyxRQUFmLEVBQXdCLEVBQXhCLENBQUEsS0FBK0IsSUFBbEM7QUFDRSxRQUFBLGlCQUFpQixDQUFDLFNBQWxCLENBQTRCLE9BQU8sQ0FBQyxJQUFwQyxDQUFBLENBREY7T0FBQSxNQUFBO0FBR0UsUUFBQSxJQUFJLENBQUMsS0FBTCxDQUFXLE9BQU8sQ0FBQyxJQUFuQixDQUFBLENBSEY7T0FEQTtBQUtBLGFBQU8sSUFBUCxDQU5vRDtJQUFBLENBQXRELENBQUEsQ0FERztHQVBMO1NBZ0JBLEtBakJtQztBQUFBLENBQXJDLENBdEJBLENBQUE7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDWEE7O0FDQUE7QUFBQSxrQkFBQTtBQUNBO0FBQUE7Ozs7Ozs7Ozs7R0FEQTtBQUFBLElBQUEsZ0JBQUE7O0FBQUEsVUFhQSxHQUFhLE9BQUEsQ0FBUSxpQkFBUixDQWJiLENBQUE7O0FBQUE7QUFnQmUsRUFBQSxjQUFBLEdBQUE7QUFDWCxJQUFBLElBQUMsQ0FBQSxXQUFELEdBQWUsd0JBQWYsQ0FBQTtBQUFBLElBQ0EsSUFBQyxDQUFBLFFBQUQsR0FBWSxNQURaLENBQUE7QUFBQSxJQUVBLElBQUMsQ0FBQSxJQUFELEdBQVEsa0JBRlIsQ0FBQTtBQUFBLElBR0EsSUFBQyxDQUFBLElBQUQsR0FBUSxVQUhSLENBQUE7QUFBQSxJQUlBLElBQUMsQ0FBQSxLQUFELEdBQVMsS0FKVCxDQUFBO0FBQUEsSUFLQSxJQUFDLENBQUEsSUFBRCxHQUFRLFlBTFIsQ0FBQTtBQUFBLElBTUEsSUFBQyxDQUFBLEdBQUQsR0FBTyxFQU5QLENBRFc7RUFBQSxDQUFiOztBQVNBO0FBQUE7O0tBVEE7O0FBQUEsaUJBWUEsS0FBQSxHQUFPLFNBQUMsSUFBRCxHQUFBO0FBQ0wsUUFBQSxhQUFBO0FBQUEsSUFBQSxJQUFHLE1BQUEsQ0FBQSxJQUFXLENBQUMsTUFBWixLQUFzQixNQUF0QixJQUFtQyxJQUFJLENBQUMsTUFBTCxLQUFlLElBQXJEO0FBQ0UsTUFBQSxJQUFJLENBQUMsTUFBTCxHQUFjLElBQWQsQ0FERjtLQUFBO0FBQUEsSUFFQSxhQUFBLEdBQWdCLElBQUMsQ0FBQSxpQkFBRCxDQUFtQixJQUFJLENBQUMsYUFBeEIsQ0FGaEIsQ0FBQTtXQUdBLElBQUMsQ0FBQSxNQUFELENBQ0k7QUFBQSxNQUFBLEtBQUEsRUFBTyxhQUFQO0FBQUEsTUFDQSxPQUFBLEVBQVMsSUFBQyxDQUFBLGVBQWUsQ0FBQyxJQUFqQixDQUFzQixJQUF0QixDQURUO0FBQUEsTUFFQSxNQUFBLEVBQVEsSUFBSSxDQUFDLE1BRmI7S0FESixFQUpLO0VBQUEsQ0FaUCxDQUFBOztBQXFCQTtBQUFBOztLQXJCQTs7QUFBQSxpQkF3QkEsaUJBQUEsR0FBbUIsU0FBQyxJQUFELEdBQUE7V0FDakIsSUFBSSxDQUFDLE9BQUwsQ0FBYSxPQUFiLEVBQXNCLEVBQXRCLEVBRGlCO0VBQUEsQ0F4Qm5CLENBQUE7O0FBMkJBO0FBQUE7O0tBM0JBOztBQUFBLGlCQThCQSxNQUFBLEdBQVEsU0FBQyxNQUFELEdBQUE7V0FFTixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUMsUUFBQSxFQUFVLEdBQVg7S0FBeEIsRUFBeUMsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsS0FBRCxHQUFBO0FBQ3ZDLFlBQUEsMEJBQUE7QUFBQSxRQUFBLElBQUcsUUFBQSxLQUFZLEVBQWY7QUFDRSxVQUFBLFFBQUEsR0FBVyxHQUFYLENBREY7U0FBQTtBQUFBLFFBRUEsS0FBQyxDQUFBLFdBQUQsQ0FBYSxLQUFLLENBQUMsUUFBbkIsQ0FGQSxDQUFBO0FBQUEsUUFHQSxHQUFBLEdBQU0sS0FBQyxDQUFBLE9BQUQsQ0FBUyxNQUFNLENBQUMsS0FBaEIsQ0FITixDQUFBO0FBQUEsUUFLQSxXQUFBLEdBQWMsTUFBTSxDQUFDLE9BTHJCLENBQUE7QUFBQSxRQU1BLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLFNBQUMsUUFBRCxHQUFBO0FBQ2YsY0FBQSxVQUFBO0FBQUEsVUFBQSxVQUFBLEdBQWEsS0FBQyxDQUFBLEtBQUQsQ0FBTyxRQUFQLEVBQWlCLE1BQU0sQ0FBQyxNQUF4QixDQUFiLENBQUE7aUJBQ0EsV0FBQSxDQUFZLFVBQVosRUFGZTtRQUFBLENBTmpCLENBQUE7ZUFXQSxLQUFDLENBQUEsT0FBRCxDQUNFO0FBQUEsVUFBQSxHQUFBLEVBQUssR0FBTDtBQUFBLFVBQ0EsT0FBQSxFQUFTLE1BQU0sQ0FBQyxPQURoQjtBQUFBLFVBRUEsS0FBQSxFQUFPLE1BQU0sQ0FBQyxLQUZkO1NBREYsRUFadUM7TUFBQSxFQUFBO0lBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUF6QyxFQUZNO0VBQUEsQ0E5QlIsQ0FBQTs7QUFBQSxpQkFtREEsV0FBQSxHQUFhLFNBQUMsUUFBRCxHQUFBO0FBQ1gsSUFBQSxJQUFDLENBQUEsZUFBRCxHQUFtQixRQUFuQixDQUFBO1dBQ0EsSUFBQyxDQUFBLElBQUQsR0FBUSxXQUFBLEdBQWMsU0FGWDtFQUFBLENBbkRiLENBQUE7O0FBdURBO0FBQUE7OztLQXZEQTs7QUFBQSxpQkEyREEsT0FBQSxHQUFTLFNBQUMsSUFBRCxHQUFBO0FBQ1AsUUFBQSxHQUFBO0FBQUEsSUFBQSxHQUFBLEdBQU0sSUFBQyxDQUFBLEdBQUQsR0FBVyxJQUFBLGNBQUEsQ0FBQSxDQUFqQixDQUFBO0FBQUEsSUFDQSxHQUFHLENBQUMsa0JBQUosR0FBeUIsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsQ0FBRCxHQUFBO0FBQ3ZCLFFBQUEsR0FBQSxHQUFNLEtBQUMsQ0FBQSxHQUFQLENBQUE7QUFDQSxRQUFBLElBQUcsR0FBRyxDQUFDLFVBQUosR0FBaUIsQ0FBcEI7QUFBQTtTQUFBLE1BRUssSUFBRyxHQUFHLENBQUMsTUFBSixLQUFjLEdBQWpCO0FBQ0gsVUFBQSxLQUFDLENBQUEsWUFBRCxDQUFjLEdBQWQsQ0FBQSxDQUFBO0FBQ0EsVUFBQSxJQUFJLE1BQUEsQ0FBQSxJQUFXLENBQUMsS0FBWixLQUFxQixVQUF6QjtBQUNFLFlBQUEsSUFBSSxDQUFDLEtBQUwsQ0FBQSxDQUFBLENBREY7V0FGRztTQUFBLE1BS0EsSUFBRyxHQUFHLENBQUMsVUFBSixLQUFrQixDQUFyQjtBQUNELGlCQUFPLElBQUksQ0FBQyxPQUFMLENBQWEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUF0QixDQUFQLENBREM7U0FUa0I7TUFBQSxFQUFBO0lBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUR6QixDQUFBO0FBQUEsSUFhQSxHQUFHLENBQUMsSUFBSixDQUFTLEtBQVQsRUFBZ0IsSUFBSSxDQUFDLEdBQXJCLEVBQTBCLElBQTFCLENBYkEsQ0FBQTtXQWNBLEdBQUcsQ0FBQyxJQUFKLENBQUEsRUFmTztFQUFBLENBM0RULENBQUE7O0FBQUEsaUJBNkVBLE9BQUEsR0FBUyxTQUFDLEtBQUQsR0FBQTtBQUNQLFFBQUEsR0FBQTtBQUFBLElBQUEsR0FBQSxHQUFNLENBQUMsSUFBQyxDQUFBLFFBQUYsRUFBWSxLQUFaLEVBQ0ksSUFBQyxDQUFBLElBREwsRUFFSSxJQUFDLENBQUEsSUFGTCxFQUdJLElBQUMsQ0FBQSxJQUhMLEVBSUksSUFBQyxDQUFBLEtBSkwsRUFLSSxJQUFDLENBQUEsZUFBRCxDQUFpQixLQUFqQixDQUxKLENBTUMsQ0FBQyxJQU5GLENBTU8sRUFOUCxDQUFOLENBQUE7QUFRQSxXQUFPLEdBQVAsQ0FUTztFQUFBLENBN0VULENBQUE7O0FBQUEsaUJBeUZBLGVBQUEsR0FBaUIsU0FBQyxLQUFELEdBQUE7QUFFZixRQUFBLGVBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxrQkFBQSxDQUFtQixLQUFuQixDQUFOLENBQUE7QUFDQSxTQUFBLGtCQUFBOzhCQUFBO0FBQ0UsTUFBQSxHQUFBLEdBQU0sR0FBRyxDQUFDLE9BQUosQ0FBWSxJQUFaLEVBQWtCLGtCQUFBLENBQW1CLElBQW5CLENBQWxCLENBQU4sQ0FERjtBQUFBLEtBREE7QUFHQSxXQUFPLEdBQVAsQ0FMZTtFQUFBLENBekZqQixDQUFBOztBQUFBLGlCQWdHQSxZQUFBLEdBQWMsU0FBQyxHQUFELEdBQUE7V0FDWixPQUFPLENBQUMsR0FBUixDQUFZLE9BQVosRUFBcUIsR0FBckIsRUFEWTtFQUFBLENBaEdkLENBQUE7O0FBbUdBO0FBQUE7O0tBbkdBOztBQUFBLGlCQXNHQSxlQUFBLEdBQWlCLFNBQUMsVUFBRCxHQUFBO0FBQ2YsSUFBQSxJQUFHLFVBQUg7YUFDRSxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVosQ0FBd0IsSUFBeEIsRUFBOEIsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsR0FBRCxHQUFBO2lCQUM1QixNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVosQ0FBd0IsR0FBRyxDQUFDLEVBQTVCLEVBQWdDO0FBQUEsWUFDOUIsTUFBQSxFQUFRLEtBQUMsQ0FBQSxXQUFELENBQWEsVUFBYixDQURzQjtBQUFBLFlBRTlCLElBQUEsRUFBTSxVQUFVLENBQUMsU0FGYTtBQUFBLFlBRzlCLE9BQUEsRUFBUyxDQUFBLFVBQVcsQ0FBQyxTQUFTLENBQUMsUUFBckIsQ0FBOEIsZUFBOUIsQ0FIb0I7V0FBaEMsRUFENEI7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUE5QixFQURGO0tBRGU7RUFBQSxDQXRHakIsQ0FBQTs7QUFBQSxpQkFnSEEsV0FBQSxHQUFhLFNBQUMsVUFBRCxHQUFBO0FBQ1gsUUFBQSxJQUFBO0FBQUEsSUFBQSxpRUFBbUIsQ0FBRSx5QkFBbEIsS0FBNEIsQ0FBL0I7YUFDRSxnQkFERjtLQUFBLE1BQUE7YUFHRSxlQUhGO0tBRFc7RUFBQSxDQWhIYixDQUFBOztBQXNIQTtBQUFBOztLQXRIQTs7QUFBQSxpQkF5SEEsS0FBQSxHQUFPLFNBQUMsUUFBRCxFQUFXLE1BQVgsRUFBbUIsU0FBbkIsR0FBQTtBQUNILFFBQUEsYUFBQTs7TUFEc0IsWUFBWTtLQUNsQztBQUFBLElBQUEsR0FBQSxHQUFNLElBQUMsQ0FBQSxZQUFELENBQWMsUUFBZCxDQUFOLENBQUE7QUFBQSxJQUNBLFFBQUEsR0FBVyxJQUFDLENBQUEsWUFBRCxDQUFjLEdBQWQsQ0FEWCxDQUFBO0FBRUEsSUFBQSxJQUFHLFFBQUg7QUFDRSxNQUFBLFNBQUEsR0FBWSxRQUFRLENBQUMsYUFBVCxDQUF1QixzQkFBdkIsQ0FBWixDQUFBO0FBQ0EsTUFBQSxJQUFHLFNBQUg7QUFDRSxRQUFBLFNBQVMsQ0FBQyxTQUFWLEdBQXNCLElBQUMsQ0FBQSxXQUF2QixDQUFBO0FBQUEsUUFDQSxTQUFTLENBQUMsWUFBVixDQUF1QixhQUF2QixFQUFzQyxHQUF0QyxDQURBLENBQUE7QUFBQSxRQUVBLElBQUMsQ0FBQSxTQUFELENBQVcsU0FBWCxDQUZBLENBQUE7QUFBQSxRQUdBLElBQUMsQ0FBQSxRQUFELENBQVUsU0FBVixDQUhBLENBREY7T0FBQSxNQUtLLElBQUcsQ0FBQSxNQUFIO0FBQ0gsUUFBQSxTQUFBLEdBQVksUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBWixDQUFBO0FBQUEsUUFDQSxTQUFTLENBQUMsU0FBVixHQUFzQixlQUR0QixDQUFBO0FBQUEsUUFFQSxTQUFTLENBQUMsU0FBVixHQUFzQixvQ0FGdEIsQ0FERztPQVBQO0tBRkE7QUFjQSxXQUFPLFNBQVAsQ0FmRztFQUFBLENBekhQLENBQUE7O0FBMElBO0FBQUE7O0tBMUlBOztBQUFBLGlCQTZJQSxZQUFBLEdBQWMsU0FBQyxDQUFELEdBQUE7QUFDWixRQUFBLGVBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFOLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxTQUFKLEdBQWdCLENBRGhCLENBQUE7QUFBQSxJQUVBLE9BQUEsR0FBVSxHQUFHLENBQUMsb0JBQUosQ0FBeUIsUUFBekIsQ0FGVixDQUFBO0FBQUEsSUFHQSxDQUFBLEdBQUksT0FBTyxDQUFDLE1BSFosQ0FBQTtBQUlBLFdBQU0sQ0FBQSxFQUFOLEdBQUE7QUFDRSxNQUFBLE9BQVEsQ0FBQSxDQUFBLENBQUUsQ0FBQyxVQUFVLENBQUMsV0FBdEIsQ0FBa0MsT0FBUSxDQUFBLENBQUEsQ0FBMUMsQ0FBQSxDQURGO0lBQUEsQ0FKQTtBQU1BLFdBQU8sR0FBRyxDQUFDLFNBQVgsQ0FQWTtFQUFBLENBN0lkLENBQUE7O0FBQUEsaUJBc0pBLFlBQUEsR0FBYyxTQUFDLEdBQUQsRUFBTSxRQUFOLEdBQUE7QUFDWixRQUFBLEdBQUE7O01BRGtCLFdBQVc7S0FDN0I7QUFBQSxJQUFBLEdBQUEsR0FBTSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFOLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxTQUFKLEdBQWdCLEdBRGhCLENBQUE7QUFBQSxJQUVBLFFBQUEsR0FBVyxRQUFRLENBQUMsc0JBQVQsQ0FBQSxDQUZYLENBQUE7QUFHQSxXQUFRLEdBQUcsQ0FBQyxVQUFaLEdBQUE7QUFDRSxNQUFBLFFBQVEsQ0FBQyxXQUFULENBQXNCLEdBQUcsQ0FBQyxVQUExQixDQUFBLENBREY7SUFBQSxDQUhBO0FBS0EsV0FBTyxRQUFQLENBTlk7RUFBQSxDQXRKZCxDQUFBOztBQUFBLGlCQThKQSxTQUFBLEdBQVcsU0FBQyxRQUFELEdBQUE7O01BQUMsV0FBUztLQUNuQjtBQUFBLElBQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxRQUFaLEVBQXNCLEtBQXRCLEVBQTZCLEtBQTdCLENBQUEsQ0FBQTtBQUNBLFdBQU8sUUFBUCxDQUZTO0VBQUEsQ0E5SlgsQ0FBQTs7QUFBQSxpQkFrS0EsUUFBQSxHQUFVLFNBQUMsUUFBRCxHQUFBOztNQUFDLFdBQVM7S0FDbEI7QUFBQSxJQUFBLElBQUksQ0FBQyxNQUFMLENBQVksUUFBWixFQUFzQixHQUF0QixFQUEyQixNQUEzQixDQUFBLENBQUE7QUFDQSxXQUFPLFFBQVAsQ0FGUTtFQUFBLENBbEtWLENBQUE7O0FBQUEsaUJBc0tBLE1BQUEsR0FBUSxTQUFDLFFBQUQsRUFBZ0IsR0FBaEIsRUFBcUIsSUFBckIsR0FBQTtBQUNOLFFBQUEsZ0NBQUE7O01BRE8sV0FBUztLQUNoQjtBQUFBLElBQUEsSUFBRyxRQUFIO0FBQ0UsTUFBQSxJQUFBLEdBQVEsUUFBUSxDQUFDLGdCQUFULENBQTBCLEdBQTFCLENBQVIsQ0FBQTtBQUFBLE1BQ0EsTUFBQSxHQUFTLFFBQVEsQ0FBQyxhQUFULENBQXVCLEdBQXZCLENBRFQsQ0FBQTtBQUVBO1dBQUEsMkNBQUE7dUJBQUE7QUFDRSxRQUFBLE1BQU0sQ0FBQyxJQUFQLEdBQWMsR0FBSSxDQUFBLElBQUEsQ0FBbEIsQ0FBQTtBQUFBLFFBQ0EsTUFBTSxDQUFDLElBQVAsR0FBYyxJQUFDLENBQUEsSUFEZixDQUFBO0FBQUEsUUFFQSxNQUFNLENBQUMsUUFBUCxHQUFrQixJQUFDLENBQUEsUUFGbkIsQ0FBQTtBQUlBLFFBQUEsSUFBRyxHQUFHLENBQUMsT0FBSixLQUFlLEdBQWxCO0FBQ0UsVUFBQSxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQWQsQ0FBa0IsVUFBbEIsQ0FBQSxDQUFBO0FBQ0EsVUFBQSxJQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBaEIsQ0FBd0IsT0FBeEIsQ0FBQSxLQUFzQyxDQUFBLENBQXpDO0FBQ0UsWUFBQSxNQUFNLENBQUMsUUFBUCxHQUFrQixJQUFBLEdBQU8sTUFBTSxDQUFDLFFBQWhDLENBQUE7QUFBQSxZQUNBLEdBQUcsQ0FBQyxZQUFKLENBQWlCLFFBQWpCLEVBQTJCLFFBQTNCLENBREEsQ0FERjtXQUZGO1NBQUEsTUFLSyxJQUFHLEdBQUcsQ0FBQyxPQUFKLEtBQWUsS0FBbEI7QUFDSCxVQUFBLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBZCxDQUFrQixTQUFsQixDQUFBLENBREc7U0FUTDtBQUFBLHNCQVlBLEdBQUcsQ0FBQyxZQUFKLENBQWlCLElBQWpCLEVBQXVCLE1BQU0sQ0FBQyxJQUE5QixFQVpBLENBREY7QUFBQTtzQkFIRjtLQURNO0VBQUEsQ0F0S1IsQ0FBQTs7Y0FBQTs7SUFoQkYsQ0FBQTs7QUFBQSxNQTJNTSxDQUFDLE9BQVAsR0FBaUIsR0FBQSxDQUFBLElBM01qQixDQUFBOzs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3Rocm93IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIil9dmFyIGY9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGYuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sZixmLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIiMjI2dsb2JhbCB0cmFuLCBjaHJvbWUjIyNcblxuI2xvYWQgZW5naW5lc1xuQ0hBUl9DT0RFUyA9IHJlcXVpcmUoJy4vY2hhci1jb2Rlcy5qcycpO1xuXG50cmFuID0gcmVxdWlyZSgnLi90cmFuLmNvZmZlZScpICAgICAgICAgICAgICAgICAgICAgICAgICAgICAjIG11bHRpdHJhbi5ydVxudHVya2lzaERpY3Rpb25hcnkgPSByZXF1aXJlKCcuL3R1cmtpc2hkaWN0aW9uYXJ5LmpzJykgICAjIHR1cmtpc2hkaWN0aW9uYXJ5Lm5ldFxuXG4jZ2VuZXJhdGVzIGEgY29udGV4dCBtZW51XG5jaHJvbWUuY29udGV4dE1lbnVzLmNyZWF0ZShcbiAgdGl0bGU6ICAnTXVsdGl0cmFuOiBcIiVzXCInXG4gIGNvbnRleHRzOiBbXCJwYWdlXCIsIFwiZnJhbWVcIiwgXCJlZGl0YWJsZVwiLCBcImltYWdlXCIsIFwidmlkZW9cIiwgXCJhdWRpb1wiLCBcImxpbmtcIiwgXCJzZWxlY3Rpb25cIl1cbiAgb25jbGljazogIChkYXRhKSAtPlxuICAgIGRhdGEuc2lsZW50ID0gZmFsc2VcbiAgICB0cmFuLmNsaWNrKGRhdGEpXG4pXG5cbiMjI1xuIENhbid0IGdldCBjaHJvbWUuc3RvcmFnZSBkaXJlY3RseSBmcm9tIGNvbnRlbnRfc2NyaXB0XG4gc28gY29udGVudF9zY3JpcHQgc2VuZHMgcmVxdWVzdCBtZXNzYWdlIGFuZCB0aGVuIGJhY2tncm91bmQgc2NyaXB0XG4gcmVzcG9uZHMgd2l0aCBzdG9yYWdlIHZhbHVlXG4jIyNcbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lciAocmVxdWVzdCwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpIC0+XG4gIGlmIHJlcXVlc3QubWV0aG9kID09IFwiZ2V0X2Zhc3Rfb3B0aW9uXCJcbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldChmYXN0OiB0cnVlLCAoaXRlbXMpIC0+XG4gICAgICAgIHNlbmRSZXNwb25zZShmYXN0OiBpdGVtcy5mYXN0KVxuICAgICAgICAjcmV0dXJuIHRydWVcbiAgICApXG4gICNGYXN0IHRyYW5zbGF0aW9uIGluaXRpYXRlIHNlYXJjaCB3aXRoICdyZXF1ZXN0X3NlYXJjaCcgbWVzc2FnZSBmcm9tXG4gICNjb250ZW50X3NjcmlwdFxuICBlbHNlIGlmIHJlcXVlc3QubWV0aG9kID09ICdyZXF1ZXN0X3NlYXJjaCdcbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7IGxhbmd1YWdlOiAnMScsIGZhc3Q6IHRydWV9LCAoaXRlbXMpIC0+XG4gICAgICByZXF1ZXN0LmRhdGEuc2lsZW50ID0gdHJ1ZVxuICAgICAgaWYgcGFyc2VJbnQoaXRlbXMubGFuZ3VhZ2UsMTApID09IDEwMDBcbiAgICAgICAgdHVya2lzaERpY3Rpb25hcnkudHJhbnNsYXRlKHJlcXVlc3QuZGF0YSlcbiAgICAgIGVsc2VcbiAgICAgICAgdHJhbi5jbGljayhyZXF1ZXN0LmRhdGEpXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIClcbiAgdHJ1ZVxuXG4iLCJ2YXIgQ0hBUl9DT0RFUyA9IHtcbiAgLy8gdHVya2lzaGRpY3Rpb25hcnkgY29kaW5nc1xuICAnJUM0JUIxJzogJyVGRCcsIC8vxLEgKExvd2VyY2FzZSBpLWRvdGxlc3MpICBhY3R1YWxseSBpdCBpcyAmIzMwNTsgYnV0IHR1cmtpc2hkaWN0aW9uYXJ5IG5lZWQgaXQgdGhpcyB3YXkgXG4gICclQzUlOUYnOiAnJUZFJywgLy/Fn1xuICAnJUM0JTlGJzogJyVGMCcsIC8vxJ8gIChzaWxlbnQgY2hhcmFjdGVyKVxuICAnJUMzJUE3JzogJyVFNycsIC8vw6dcbiAgJyVDMyVCNic6ICclRjYnLCAvL8O2XG4gICclQzMlQkMnOiAnJUZDJywgLy/DvFxuICAnJUMzJUEyJzogJyVFMicgLy8gw6Jcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBDSEFSX0NPREVTOyIsIi8qXHIgIE11bHRpdHJhbiBkZXBlbmRzIG9uIGh0bWwtZXNjYXBpbmcgKG5vdCBVVEYtOCkgcnVsZXMgZm9yIHNwZWNpYWwgc3ltYm9sc1xyICDDoCwgw6gsIMOsLCDDsiwgw7kgLSDDgCwgw4gsIMOMLCDDkiwgw5lcciAgw6EsIMOpLCDDrSwgw7MsIMO6LCDDvSAtIMOBLCDDiSwgw40sIMOTLCDDmiwgw51cciAgw6IsIMOqLCDDriwgw7QsIMO7IMOCLCDDiiwgw44sIMOULCDDm1xyICDDoywgw7EsIMO1IMODLCDDkSwgw5VcciAgw6QsIMOrLCDDrywgw7YsIMO8LCDDvyDDhCwgw4ssIMOPLCDDliwgw5wsXHIgIMOlLCDDhVxyICDDpiwgw4ZcciAgw6csIMOHXHIgIMOwLCDDkFxyICDDuCwgw5hcciAgwr8gwqEgw59cciovXHJ2YXIgQ0hBUl9DT0RFUyA9IHtcciAgJyVDMyU4MCc6ICcmIzE5MjsnLCAvLyDDgFxyICAnJUMzJTgxJzogJyYjMTkzOycsIC8vIMOBXHIgICclQzMlODInOiAnJiMxOTQ7JywgLy8gw4JcciAgJyVDMyU4Myc6ICcmIzE5NTsnLCAvLyDDg1xyICAnJUMzJTg0JzogJyYjMTk2OycsIC8vIMOEXHIgICclQzMlODUnOiAnJiMxOTc7JywgLy8gw4VcciAgJyVDMyU4Nic6ICcmIzE5ODsnLCAvLyDDhlxyXHIgICclQzMlODcnOiAnJiMxOTk7JywgLy8gw4dcciAgJyVDMyU4OCc6ICcmIzIwMDsnLCAvLyDDiFxyICAnJUMzJTg5JzogJyYjMjAxOycsIC8vIMOJXHIgICclQzMlOEEnOiAnJiMyMDI7JywgLy8gw4pcciAgJyVDMyU4Qic6ICcmIzIwMzsnLCAvLyDDi1xyXHIgICclQzMlOEMnOiAnJiMyMDQ7JywgLy8gw4xcciAgJyVDMyU4RCc6ICcmIzIwNTsnLCAvLyDDjVxyICAnJUMzJThFJzogJyYjMjA2OycsIC8vIMOOXHIgICclQzMlOEYnOiAnJiMyMDc7JywgLy8gw49cclxyICAnJUMzJTkxJzogJyYjMjA5OycsIC8vIMORXHIgICclQzMlOTInOiAnJiMyMTA7JywgLy8gw5JcciAgJyVDMyU5Myc6ICcmIzIxMTsnLCAvLyDDk1xyICAnJUMzJTk0JzogJyYjMjEyOycsIC8vIMOUXHIgICclQzMlOTUnOiAnJiMyMTM7JywgLy8gw5VcciAgJyVDMyU5Nic6ICcmIzIxNDsnLCAvLyDDllxyXHIgICclQzMlOTknOiAnJiMyMTc7JywgLy8gw5lcciAgJyVDMyU5QSc6ICcmIzIxODsnLCAvLyDDmlxyICAnJUMzJTlCJzogJyYjMjE5OycsIC8vIMObXHIgICclQzMlOUMnOiAnJiMyMjA7JywgLy8gw5xcclxyXHIgICclQzMlQTAnOiAnJiMyMjQ7JywgLy8gw6BcciAgJyVDMyVBMSc6ICcmIzIyNTsnLCAvLyDDoVxyICAnJUMzJUEyJzogJyYjMjI2OycsIC8vIMOiXHIgICclQzMlQTMnOiAnJiMyMjc7JywgLy8gw6NcciAgJyVDMyVBNCc6ICcmIzIyODsnLCAvLyDDpFxyICAnJUMzJUE1JzogJyYjMjI5OycsIC8vIMOlXHIgICclQzMlQTYnOiAnJiMyMzA7JywgLy8gw6ZcciAgJyVDMyVBNyc6ICcmIzIzMTsnLCAvLyDDp1xyXHJcciAgJyVDMyVBOCc6ICcmIzIzMjsnLCAvLyDDqFxyICAnJUMzJUE5JzogJyYjMjMzOycsIC8vIMOpXHIgICclQzMlQUEnOiAnJiMyMzQ7JywgLy8gw6pcciAgJyVDMyVBQic6ICcmIzIzNTsnLCAvLyDDq1xyXHIgICclQzMlQUMnOiAnJiMyMzY7JywgLy8gw6xcciAgJyVDMyVBRCc6ICcmIzIzNzsnLCAvLyDDrVxyICAnJUMzJUFFJzogJyYjMjM4OycsIC8vIMOuXHIgICclQzMlQUYnOiAnJiMyMzk7JywgLy8gw69cclxyICAnJUMzJUIwJzogJyYjMjQwOycsIC8vIMOwXHIgICclQzMlQjEnOiAnJiMyNDE7JywgLy8gw7FcclxyICAnJUMzJUIyJzogJyYjMjQyOycsIC8vIMOyXHIgICclQzMlQjMnOiAnJiMyNDM7JywgLy8gw7NcciAgJyVDMyVCNCc6ICcmIzI0NDsnLCAvLyDDtFxyICAnJUMzJUI1JzogJyYjMjQ1OycsIC8vIMO1XHIgICclQzMlQjYnOiAnJiMyNDY7JywgLy8gw7ZcclxyICAnJUMzJUI5JzogJyYjMjQ5OycsIC8vIMO5XHIgICclQzMlQkEnOiAnJiMyNTA7JywgLy8gw7pcciAgJyVDMyVCQic6ICcmIzI1MTsnLCAvLyDDu1xyICAnJUMzJUJDJzogJyYjMjUyOycsIC8vIMO8XHIgICclQzMlQkYnOiAnJiMyNTU7JywgLy8gw79cciAgJyVDNSVCOCc6ICcmIzM3NjsnLCAvLyDFuFxyXHIgICclQzMlOUYnOiAnJiMyMjM7JywgLy8gw59cclxyICAnJUMyJUJGJzogJyYjMTkxOycsIC8vIMK/XHIgICclQzIlQTEnOiAnJiMxNjE7JywgLy8gwqFccn07XHJccm1vZHVsZS5leHBvcnRzID0gQ0hBUl9DT0RFUztcciIsIiMjI2dsb2JhbCBjaHJvbWUjIyNcbiMjI1xuICBNdWx0aXRyYW4ucnUgdHJhbnNsYXRlIGVuZ2luZVxuICBQcm92aWRlcyBwcm9ncmFtIGludGVyZmFjZSBmb3IgbWFraW5nIHRyYW5zbGF0ZSBxdWVyaWVzIHRvIG11bHRpdHJhbiBhbmQgZ2V0IGNsZWFuIHJlc3BvbnNlXG5cbiAgQWxsIGVuZ2luZXMgbXVzdCBmb2xsb3cgY29tbW9uIGludGVyZmFjZSBhbmQgcHJvdmlkZSBtZXRob2RzOlxuICAgIC0gc2VhcmNoIChsYW5ndWFuZ2UsIHN1Y2Nlc3NIYW5kbGVyKSAgY2xlYW4gdHJhbnNsYXRpb24gbXVzdCBiZSBwYXNzZWQgaW50byBzdWNjZXNzSGFuZGxlclxuICAgIC0gY2xpY2tcblxuICBUcmFuc2xhdGlvbi1tb2R1bGUgdGhhdCBtYWtlcyByZXF1ZXN0cyB0byBsYW5ndWFnZS1lbmdpbmUsXG4gIHBhcnNlcyByZXN1bHRzIGFuZCBzZW5kcyBwbHVnaW4tZ2xvYmFsIG1lc3NhZ2Ugd2l0aCB0cmFuc2xhdGlvbiBkYXRhXG4jIyNcblxuQ0hBUl9DT0RFUyA9IHJlcXVpcmUoJy4vY2hhci1jb2Rlcy5qcycpO1xuXG5jbGFzcyBUcmFuXG4gIGNvbnN0cnVjdG9yOiAtPlxuICAgIEBUQUJMRV9DTEFTUyA9IFwiX19fbXR0X3RyYW5zbGF0ZV90YWJsZVwiXG4gICAgQHByb3RvY29sID0gJ2h0dHAnXG4gICAgQGhvc3QgPSAnd3d3Lm11bHRpdHJhbi5ydSdcbiAgICBAcGF0aCA9ICcvYy9tLmV4ZSdcbiAgICBAcXVlcnkgPSAnJnM9J1xuICAgIEBsYW5nID0gJz9sMT0yJmwyPTEnICNmcm9tIHJ1c3NpYW4gdG8gZW5nbGlzaCBieSBkZWZhdWx0XG4gICAgQHhociA9IHt9XG5cbiAgIyMjXG4gICAgQ29udGV4dCBtZW51IGNsaWNrIGhhbmRsZXJcbiAgIyMjXG4gIGNsaWNrOiAoZGF0YSkgLT5cbiAgICBpZiB0eXBlb2YgZGF0YS5zaWxlbnQgPT0gdW5kZWZpbmVkIHx8IGRhdGEuc2lsZW50ID09IG51bGxcbiAgICAgIGRhdGEuc2lsZW50ID0gdHJ1ZSAjIHRydWUgYnkgZGVmYXVsdFxuICAgIHNlbGVjdGlvblRleHQgPSBAcmVtb3ZlSHlwaGVuYXRpb24gZGF0YS5zZWxlY3Rpb25UZXh0XG4gICAgQHNlYXJjaFxuICAgICAgICB2YWx1ZTogc2VsZWN0aW9uVGV4dFxuICAgICAgICBzdWNjZXNzOiBAc3VjY2Vzc3RIYW5kbGVyLmJpbmQodGhpcylcbiAgICAgICAgc2lsZW50OiBkYXRhLnNpbGVudCAgIyBpZiB0cmFuc2xhdGlvbiBmYWlsZWQgZG8gbm90IHNob3cgZGlhbG9nXG5cbiAgIyMjXG4gICAgRGlzY2FyZCBzb2Z0IGh5cGhlbiBjaGFyYWN0ZXIgKFUrMDBBRCwgJnNoeTspIGZyb20gdGhlIGlucHV0XG4gICMjI1xuICByZW1vdmVIeXBoZW5hdGlvbjogKHRleHQpIC0+XG4gICAgdGV4dC5yZXBsYWNlIC9cXHhhZC9nLCAnJ1xuXG4gICMjI1xuICAgIEluaXRpYXRlIHRyYW5zbGF0aW9uIHNlYXJjaFxuICAjIyNcbiAgc2VhcmNoOiAocGFyYW1zKSAtPlxuICAgICN2YWx1ZSwgY2FsbGJhY2ssIGVyclxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHtsYW5ndWFnZTogJzEnfSwgKGl0ZW1zKSA9PlxuICAgICAgaWYgbGFuZ3VhZ2UgaXMgJydcbiAgICAgICAgbGFuZ3VhZ2UgPSAnMSdcbiAgICAgIEBzZXRMYW5ndWFnZShpdGVtcy5sYW5ndWFnZSlcbiAgICAgIHVybCA9IEBtYWtlVXJsKHBhcmFtcy52YWx1ZSk7XG4gICAgICAjIGRlY29yYXRlIHN1Y2Nlc3MgdG8gbWFrZSBwcmVsaW1pbmFyeSBwYXJzaW5nXG4gICAgICBvcmlnU3VjY2VzcyA9IHBhcmFtcy5zdWNjZXNzXG4gICAgICBwYXJhbXMuc3VjY2VzcyA9IChyZXNwb25zZSkgPT5cbiAgICAgICAgdHJhbnNsYXRlZCA9IEBwYXJzZShyZXNwb25zZSwgcGFyYW1zLnNpbGVudClcbiAgICAgICAgb3JpZ1N1Y2Nlc3ModHJhbnNsYXRlZClcblxuICAgICAgIyBtYWtlIHJlcXVlc3QgKEdFVCByZXF1ZXN0IHdpdGggcXVlcnkgcGFyYW1ldGVycyBpbiB1cmwpXG4gICAgICBAcmVxdWVzdChcbiAgICAgICAgdXJsOiB1cmwsXG4gICAgICAgIHN1Y2Nlc3M6IHBhcmFtcy5zdWNjZXNzLFxuICAgICAgICBlcnJvcjogcGFyYW1zLmVycm9yXG4gICAgICApXG4gICAgKVxuXG4gIHNldExhbmd1YWdlOiAobGFuZ3VhZ2UpIC0+XG4gICAgQGN1cnJlbnRMYW5ndWFnZSA9IGxhbmd1YWdlXG4gICAgQGxhbmcgPSAnP2wxPTImbDI9JyArIGxhbmd1YWdlXG5cbiAgIyMjXG4gICAgUmVxdWVzdCB0cmFuc2xhdGlvbiBhbmQgcnVuIGNhbGxiYWNrIGZ1bmN0aW9uXG4gICAgcGFzc2luZyB0cmFuc2xhdGVkIHJlc3VsdCBvciBlcnJvciB0byBjYWxsYmFja1xuICAjIyNcbiAgcmVxdWVzdDogKG9wdHMpIC0+XG4gICAgeGhyID0gQHhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpXG4gICAgeGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IChlKSA9PlxuICAgICAgeGhyID0gQHhoclxuICAgICAgaWYgeGhyLnJlYWR5U3RhdGUgPCA0XG4gICAgICAgIHJldHVyblxuICAgICAgZWxzZSBpZiB4aHIuc3RhdHVzICE9IDIwMFxuICAgICAgICBAZXJyb3JIYW5kbGVyKHhocilcbiAgICAgICAgaWYgKHR5cGVvZiBvcHRzLmVycm9yID09ICdmdW5jdGlvbicpXG4gICAgICAgICAgb3B0cy5lcnJvcigpXG4gICAgICAgIHJldHVyblxuICAgICAgZWxzZSBpZiB4aHIucmVhZHlTdGF0ZSA9PSA0XG4gICAgICAgICAgcmV0dXJuIG9wdHMuc3VjY2VzcyhlLnRhcmdldC5yZXNwb25zZSlcblxuICAgIHhoci5vcGVuKFwiR0VUXCIsIG9wdHMudXJsLCB0cnVlKTtcbiAgICB4aHIuc2VuZCgpO1xuXG5cbiAgbWFrZVVybDogKHZhbHVlKSAtPlxuICAgIHVybCA9IFtAcHJvdG9jb2wsICc6Ly8nLFxuICAgICAgICAgICAgICBAaG9zdCxcbiAgICAgICAgICAgICAgQHBhdGgsXG4gICAgICAgICAgICAgIEBsYW5nLFxuICAgICAgICAgICAgICBAcXVlcnksXG4gICAgICAgICAgICAgIEBnZXRFbmNvZGVkVmFsdWUodmFsdWUpXG4gICAgICAgICAgXS5qb2luKCcnKVxuXG4gICAgcmV0dXJuIHVybDtcblxuICAjIFJlcGxhY2Ugc3BlY2lhbCBsYW5ndWFnZSBjaGFyYWN0ZXJzIHRvIGh0bWwgY29kZXNcbiAgZ2V0RW5jb2RlZFZhbHVlOiAodmFsdWUpIC0+XG4gICAgIyB0byBmaW5kIHNwZWMgc3ltYm9scyB3ZSBmaXJzdCBlbmNvZGUgdGhlbSAocmF3IHNlYXJjaCBmb3IgdGhhdCBzeW1ib2wgZG9lc24ndCB3b3IpXG4gICAgdmFsID0gZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKVxuICAgIGZvciBjaGFyLCBjb2RlIG9mIENIQVJfQ09ERVNcbiAgICAgIHZhbCA9IHZhbC5yZXBsYWNlKGNoYXIsIGVuY29kZVVSSUNvbXBvbmVudChjb2RlKSlcbiAgICByZXR1cm4gdmFsXG5cbiAgZXJyb3JIYW5kbGVyOiAoeGhyKSAtPlxuICAgIGNvbnNvbGUubG9nKCdlcnJvcicsIHhocilcblxuICAjIyNcbiAgIFJlY2VpdmluZyBkYXRhIGZyb20gdHJhbnNsYXRpb24tZW5naW5lIGFuZCBzZW5kIHJlYWR5IG1lc3NhZ2Ugd2l0aCBkYXRhXG4gICMjI1xuICBzdWNjZXNzdEhhbmRsZXI6ICh0cmFuc2xhdGVkKSAtPlxuICAgIGlmIHRyYW5zbGF0ZWRcbiAgICAgIGNocm9tZS50YWJzLmdldFNlbGVjdGVkKG51bGwsICh0YWIpID0+XG4gICAgICAgIGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhYi5pZCwge1xuICAgICAgICAgIGFjdGlvbjogQG1lc3NhZ2VUeXBlIHRyYW5zbGF0ZWRcbiAgICAgICAgICBkYXRhOiB0cmFuc2xhdGVkLm91dGVySFRNTCxcbiAgICAgICAgICBzdWNjZXNzOiAhdHJhbnNsYXRlZC5jbGFzc0xpc3QuY29udGFpbnMoJ2ZhaWxUcmFuc2xhdGUnKVxuICAgICAgICB9KVxuICAgICAgKVxuXG4gIG1lc3NhZ2VUeXBlOiAodHJhbnNsYXRlZCkgLT5cbiAgICBpZiB0cmFuc2xhdGVkPy5yb3dzPy5sZW5ndGggPT0gMVxuICAgICAgJ3NpbWlsYXJfd29yZHMnXG4gICAgZWxzZVxuICAgICAgJ29wZW5fdG9vbHRpcCdcblxuICAjIyNcbiAgICBQYXJzZSByZXNwb25zZSBmcm9tIHRyYW5zbGF0aW9uIGVuZ2luZVxuICAjIyNcbiAgcGFyc2U6IChyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUgPSBudWxsKSAtPlxuICAgICAgZG9jID0gQHN0cmlwU2NyaXB0cyhyZXNwb25zZSlcbiAgICAgIGZyYWdtZW50ID0gQG1ha2VGcmFnbWVudChkb2MpXG4gICAgICBpZiBmcmFnbWVudFxuICAgICAgICB0cmFuc2xhdGUgPSBmcmFnbWVudC5xdWVyeVNlbGVjdG9yKCcjdHJhbnNsYXRpb24gfiB0YWJsZScpXG4gICAgICAgIGlmIHRyYW5zbGF0ZVxuICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSBAVEFCTEVfQ0xBU1M7XG4gICAgICAgICAgdHJhbnNsYXRlLnNldEF0dHJpYnV0ZShcImNlbGxwYWRkaW5nXCIsIFwiNVwiKVxuICAgICAgICAgIEBmaXhJbWFnZXModHJhbnNsYXRlKVxuICAgICAgICAgIEBmaXhMaW5rcyh0cmFuc2xhdGUpXG4gICAgICAgIGVsc2UgaWYgbm90IHNpbGVudFxuICAgICAgICAgIHRyYW5zbGF0ZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9ICdmYWlsVHJhbnNsYXRlJ1xuICAgICAgICAgIHRyYW5zbGF0ZS5pbm5lclRleHQgPSBcIlVuZm9ydHVuYXRlbHksIGNvdWxkIG5vdCB0cmFuc2xhdGVcIlxuXG4gICAgICByZXR1cm4gdHJhbnNsYXRlO1xuXG4gICMjI1xuICAgIFN0cmlwIHNjcmlwdCB0YWdzIGZyb20gcmVzcG9uc2UgaHRtbFxuICAjIyNcbiAgc3RyaXBTY3JpcHRzOiAocykgLT5cbiAgICBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICAgIGRpdi5pbm5lckhUTUwgPSBzXG4gICAgc2NyaXB0cyA9IGRpdi5nZXRFbGVtZW50c0J5VGFnTmFtZSgnc2NyaXB0JylcbiAgICBpID0gc2NyaXB0cy5sZW5ndGhcbiAgICB3aGlsZSBpLS1cbiAgICAgIHNjcmlwdHNbaV0ucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChzY3JpcHRzW2ldKVxuICAgIHJldHVybiBkaXYuaW5uZXJIVE1MO1xuXG4gIG1ha2VGcmFnbWVudDogKGRvYywgZnJhZ21lbnQgPSBudWxsKSAtPlxuICAgIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIilcbiAgICBkaXYuaW5uZXJIVE1MID0gZG9jXG4gICAgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KClcbiAgICB3aGlsZSAoIGRpdi5maXJzdENoaWxkIClcbiAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKCBkaXYuZmlyc3RDaGlsZCApXG4gICAgcmV0dXJuIGZyYWdtZW50XG5cbiAgZml4SW1hZ2VzOiAoZnJhZ21lbnQ9bnVsbCkgLT5cbiAgICB0aGlzLmZpeFVybChmcmFnbWVudCwgJ2ltZycsICdzcmMnKTtcbiAgICByZXR1cm4gZnJhZ21lbnQ7XG5cbiAgZml4TGlua3M6IChmcmFnbWVudD1udWxsKSAtPlxuICAgIHRoaXMuZml4VXJsKGZyYWdtZW50LCAnYScsICdocmVmJylcbiAgICByZXR1cm4gZnJhZ21lbnRcblxuICBmaXhVcmw6IChmcmFnbWVudD1udWxsLCB0YWcsIGF0dHIpIC0+XG4gICAgaWYgZnJhZ21lbnRcbiAgICAgIHRhZ3MgPSAgZnJhZ21lbnQucXVlcnlTZWxlY3RvckFsbCh0YWcpXG4gICAgICBwYXJzZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJylcbiAgICAgIGZvciB0YWcgaW4gdGFnc1xuICAgICAgICBwYXJzZXIuaHJlZiA9IHRhZ1thdHRyXVxuICAgICAgICBwYXJzZXIuaG9zdCA9IEBob3N0XG4gICAgICAgIHBhcnNlci5wcm90b2NvbCA9IEBwcm90b2NvbFxuICAgICAgICAjZml4IHJlbGF0aXZlIGxpbmtzXG4gICAgICAgIGlmIHRhZy50YWdOYW1lID09ICdBJ1xuICAgICAgICAgIHRhZy5jbGFzc0xpc3QuYWRkICdtdHRfbGluaydcbiAgICAgICAgICBpZiBwYXJzZXIucGF0aG5hbWUuaW5kZXhPZignbS5leGUnKSBpc250IC0xXG4gICAgICAgICAgICBwYXJzZXIucGF0aG5hbWUgPSAnL2MnICsgcGFyc2VyLnBhdGhuYW1lXG4gICAgICAgICAgICB0YWcuc2V0QXR0cmlidXRlKCd0YXJnZXQnLCAnX2JsYW5rJylcbiAgICAgICAgZWxzZSBpZiB0YWcudGFnTmFtZSA9PSAnSU1HJ1xuICAgICAgICAgIHRhZy5jbGFzc0xpc3QuYWRkICdtdHRfaW1nJ1xuXG4gICAgICAgIHRhZy5zZXRBdHRyaWJ1dGUoYXR0ciwgcGFyc2VyLmhyZWYpXG5cblxuXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBUcmFuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbnZhciBfcHJvdG90eXBlUHJvcGVydGllcyA9IGZ1bmN0aW9uIChjaGlsZCwgc3RhdGljUHJvcHMsIGluc3RhbmNlUHJvcHMpIHtcbiAgaWYgKHN0YXRpY1Byb3BzKSBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhjaGlsZCwgc3RhdGljUHJvcHMpO1xuICBpZiAoaW5zdGFuY2VQcm9wcykgT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoY2hpbGQucHJvdG90eXBlLCBpbnN0YW5jZVByb3BzKTtcbn07XG5cbi8qXG4gIFRyYW5zbGF0aW9uIGVuZ2luZTogaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXRcbiAgRm9yIHRyYW5zbGF0aW5nIHR1cmtpc2gtcnVzc2lhbiBhbmQgdmljZSB2ZXJzYVxuKi9cbnZhciBDSEFSX0NPREVTID0gcmVxdWlyZShcIi4vY2hhci1jb2Rlcy10dXJrLmpzXCIpO1xuXG52YXIgVHVya2lzaERpY3Rpb25hcnkgPSAoZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBUdXJraXNoRGljdGlvbmFyeSgpIHtcbiAgICB0aGlzLmhvc3QgPSBcImh0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0Lz93b3JkPSVGQ1wiO1xuICAgIHRoaXMucGF0aCA9IFwiXCI7XG4gICAgdGhpcy5wcm90b2NvbCA9IFwiaHR0cFwiO1xuICAgIHRoaXMucXVlcnkgPSBcIiZzPVwiO1xuICAgIHRoaXMuVEFCTEVfQ0xBU1MgPSBcIl9fX210dF90cmFuc2xhdGVfdGFibGVcIjtcbiAgICB0aGlzLm5lZWRfcHVibGlzaCA9IHRydWU7XG4gIH1cblxuICBfcHJvdG90eXBlUHJvcGVydGllcyhUdXJraXNoRGljdGlvbmFyeSwgbnVsbCwge1xuICAgIHNlYXJjaDoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHNlYXJjaChkYXRhKSB7XG4gICAgICAgIGRhdGEudXJsID0gdGhpcy5tYWtlVXJsKGRhdGEudmFsdWUpO1xuICAgICAgICB0aGlzLm5lZWRfcHVibGlzaCA9IGZhbHNlO1xuICAgICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KGRhdGEpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgdHJhbnNsYXRlOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gdHJhbnNsYXRlKGRhdGEpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJyZXF1ZXN0IGRhdGE6XCIsIGRhdGEpO1xuICAgICAgICBkYXRhLnVybCA9IHRoaXMubWFrZVVybChkYXRhLnNlbGVjdGlvblRleHQpO1xuICAgICAgICB0aGlzLm5lZWRfcHVibGlzaCA9IHRydWU7XG4gICAgICAgIHRoaXMucmVxdWVzdChkYXRhKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIG1ha2VVcmw6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlVXJsKHRleHQpIHtcbiAgICAgICAgdmFyIHRleHQgPSB0aGlzLmdldEVuY29kZWRWYWx1ZSh0ZXh0KTtcbiAgICAgICAgcmV0dXJuIFtcImh0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0Lz93b3JkPVwiLCB0ZXh0XS5qb2luKFwiXCIpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgZ2V0RW5jb2RlZFZhbHVlOiB7XG4gICAgICAvLyBSZXBsYWNlIHNwZWNpYWwgbGFuZ3VhZ2UgY2hhcmFjdGVycyB0byBodG1sIGNvZGVzXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gZ2V0RW5jb2RlZFZhbHVlKHZhbHVlKSB7XG4gICAgICAgIC8vIHRvIGZpbmQgc3BlYyBzeW1ib2xzIHdlIGZpcnN0IGVuY29kZSB0aGVtIChyYXcgc2VhcmNoIGZvciB0aGF0IHN5bWJvbCBkb2Vzbid0IHdvcilcbiAgICAgICAgdmFyIHZhbCA9IGVuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSk7XG4gICAgICAgIGZvciAodmFyIGNoYXIgaW4gQ0hBUl9DT0RFUykge1xuICAgICAgICAgIHZhbCA9IHZhbC5yZXBsYWNlKGNoYXIsIENIQVJfQ09ERVNbY2hhcl0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB2YWw7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICByZXF1ZXN0OiB7XG5cbiAgICAgIC8qXG4gICAgICAgIFJlcXVlc3QgdHJhbnNsYXRpb24gYW5kIHJ1biBjYWxsYmFjayBmdW5jdGlvblxuICAgICAgICBwYXNzaW5nIHRyYW5zbGF0ZWQgcmVzdWx0IG9yIGVycm9yIHRvIGNhbGxiYWNrXG4gICAgICAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHJlcXVlc3Qob3B0cykge1xuICAgICAgICBjb25zb2xlLmxvZyhcInN0YXJ0IHJlcXVlc3RcIik7XG4gICAgICAgIHRoaXMueGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgIHRoaXMueGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IHRoaXMub25SZWFkeVN0YXRlQ2hhbmdlLmJpbmQodGhpcywgb3B0cyk7XG4gICAgICAgIHRoaXMueGhyLm9wZW4oXCJHRVRcIiwgb3B0cy51cmwsIHRydWUpO1xuICAgICAgICB0aGlzLnhoci5zZW5kKCk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBvblJlYWR5U3RhdGVDaGFuZ2U6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBvblJlYWR5U3RhdGVDaGFuZ2Uob3B0cywgZSkge1xuICAgICAgICB2YXIgeGhyID0gdGhpcy54aHI7XG4gICAgICAgIGlmICh4aHIucmVhZHlTdGF0ZSA8IDQpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH0gZWxzZSBpZiAoeGhyLnN0YXR1cyAhPSAyMDApIHtcbiAgICAgICAgICB0aGlzLmVycm9ySGFuZGxlcih4aHIpO1xuICAgICAgICAgIHJldHVybiBvcHRzLmVycm9yICYmIG9wdHMuZXJyb3IoKTtcbiAgICAgICAgfSBlbHNlIGlmICh4aHIucmVhZHlTdGF0ZSA9PSA0KSB7XG4gICAgICAgICAgdmFyIHRyYW5zbGF0aW9uID0gdGhpcy5zdWNjZXNzSGFuZGxlcihlLnRhcmdldC5yZXNwb25zZSk7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJzdWNjZXNzIHR1cmtpc2ggdHJhbnNsYXRlXCIsIHRyYW5zbGF0aW9uKTtcbiAgICAgICAgICBjb25zb2xlLmxvZyhcImNhbGxcIiwgb3B0cy5zdWNjZXNzKTtcbiAgICAgICAgICByZXR1cm4gb3B0cy5zdWNjZXNzICYmIG9wdHMuc3VjY2Vzcyh0cmFuc2xhdGlvbik7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHN1Y2Nlc3NIYW5kbGVyOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gc3VjY2Vzc0hhbmRsZXIocmVzcG9uc2UpIHtcbiAgICAgICAgdmFyIGRhdGEgPSB0aGlzLnBhcnNlKHJlc3BvbnNlKTtcbiAgICAgICAgaWYgKHRoaXMubmVlZF9wdWJsaXNoKSB7XG4gICAgICAgICAgY2hyb21lLnRhYnMuZ2V0U2VsZWN0ZWQobnVsbCwgdGhpcy5wdWJsaXNoVHJhbnNsYXRpb24uYmluZCh0aGlzLCBkYXRhKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBwdWJsaXNoVHJhbnNsYXRpb246IHtcblxuICAgICAgLyogcHVibGlzaCBzdWNjZXNzZnVseSB0cmFuc2xhdGVkIHRleHQgYWxsIG92ZXIgZXh0ZW5zaW9uICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gcHVibGlzaFRyYW5zbGF0aW9uKHRyYW5zbGF0aW9uLCB0YWIpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJwdWJsaXNoIHRyYW5zbGF0aW9uXCIpO1xuICAgICAgICBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWIuaWQsIHtcbiAgICAgICAgICBhY3Rpb246IFwib3Blbl90b29sdGlwXCIsXG4gICAgICAgICAgZGF0YTogdHJhbnNsYXRpb24ub3V0ZXJIVE1MLFxuICAgICAgICAgIHN1Y2Nlc3M6ICF0cmFuc2xhdGlvbi5jbGFzc0xpc3QuY29udGFpbnMoXCJmYWlsVHJhbnNsYXRlXCIpXG4gICAgICAgIH0pO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgZXJyb3JIYW5kbGVyOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gZXJyb3JIYW5kbGVyKHJlc3BvbnNlKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiZXJyb3IgYWpheFwiLCByZXNwb25zZSk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBwYXJzZToge1xuXG4gICAgICAvKiBQYXJzZSByZXNwb25zZSBmcm9tIHRyYW5zbGF0aW9uIGVuZ2luZSAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHBhcnNlKHJlc3BvbnNlLCBzaWxlbnQsIHRyYW5zbGF0ZSkge1xuICAgICAgICB2YXIgZG9jID0gdGhpcy5zdHJpcFNjcmlwdHMocmVzcG9uc2UpLFxuICAgICAgICAgICAgZnJhZ21lbnQgPSB0aGlzLm1ha2VGcmFnbWVudChkb2MpO1xuICAgICAgICBpZiAoZnJhZ21lbnQpIHtcbiAgICAgICAgICB0cmFuc2xhdGUgPSBmcmFnbWVudC5xdWVyeVNlbGVjdG9yKFwiI21lYW5pbmdfZGl2ID4gdGFibGVcIik7XG4gICAgICAgICAgaWYgKHRyYW5zbGF0ZSkge1xuICAgICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9IHRoaXMuVEFCTEVfQ0xBU1M7XG4gICAgICAgICAgICB0cmFuc2xhdGUuc2V0QXR0cmlidXRlKFwiY2VsbHBhZGRpbmdcIiwgXCI1XCIpO1xuICAgICAgICAgICAgLy8gQGZpeEltYWdlcyh0cmFuc2xhdGUpXG4gICAgICAgICAgICAvLyBAZml4TGlua3ModHJhbnNsYXRlKVxuICAgICAgICAgIH0gZWxzZSBpZiAoIXNpbGVudCkge1xuICAgICAgICAgICAgdHJhbnNsYXRlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSBcImZhaWxUcmFuc2xhdGVcIjtcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5pbm5lclRleHQgPSBcIlVuZm9ydHVuYXRlbHksIGNvdWxkIG5vdCB0cmFuc2xhdGVcIjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRyYW5zbGF0ZTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHN0cmlwU2NyaXB0czoge1xuXG4gICAgICAvL1RPRE8gZXh0cmFjdCB0byBiYXNlIGVuZ2luZSBjbGFzc1xuICAgICAgLyogcmVtb3ZlcyA8c2NyaXB0PiB0YWdzIGZyb20gaHRtbCBjb2RlICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gc3RyaXBTY3JpcHRzKGh0bWwpIHtcbiAgICAgICAgdmFyIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgIGRpdi5pbm5lckhUTUwgPSBodG1sO1xuICAgICAgICB2YXIgc2NyaXB0cyA9IGRpdi5nZXRFbGVtZW50c0J5VGFnTmFtZShcInNjcmlwdFwiKTtcbiAgICAgICAgdmFyIGkgPSBzY3JpcHRzLmxlbmd0aDtcbiAgICAgICAgd2hpbGUgKGktLSkgc2NyaXB0c1tpXS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHNjcmlwdHNbaV0pO1xuICAgICAgICByZXR1cm4gZGl2LmlubmVySFRNTDtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIG1ha2VGcmFnbWVudDoge1xuXG4gICAgICAvL1RPRE8gZXh0cmFjdCB0byBiYXNlIGVuZ2luZSBjbGFzc1xuICAgICAgLyogY3JlYXRlcyB0ZW1wIG9iamVjdCB0byBwYXJzZSB0cmFuc2xhdGlvbiBmcm9tIHBhZ2UgXG4gICAgICAgIChzaW5jZSBpdCdzIG5vdCBhIGZyaWVuZGx5IGFwaSkgXG4gICAgICAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIG1ha2VGcmFnbWVudChodG1sKSB7XG4gICAgICAgIHZhciBmcmFnbWVudCxcbiAgICAgICAgICAgIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgIGRpdi5pbm5lckhUTUwgPSBodG1sO1xuICAgICAgICBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKTtcbiAgICAgICAgd2hpbGUgKGRpdi5maXJzdENoaWxkKSB7XG4gICAgICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoZGl2LmZpcnN0Q2hpbGQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmcmFnbWVudDtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9XG4gIH0pO1xuXG4gIHJldHVybiBUdXJraXNoRGljdGlvbmFyeTtcbn0pKCk7XG5cbi8vIFNpbmdsZXRvbmVcbm1vZHVsZS5leHBvcnRzID0gbmV3IFR1cmtpc2hEaWN0aW9uYXJ5KCk7Il19
