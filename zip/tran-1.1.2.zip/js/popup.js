(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
var CHAR_CODES = {
  // turkishdictionary codings
  '%C4%B1': '%FD', //ı (Lowercase i-dotless)  actually it is &#305; but turkishdictionary need it this way 
  '%C5%9F': '%FE', //ş
  '%C4%9F': '%F0', //ğ  (silent character)
  '%C3%A7': '%E7', //ç
  '%C3%B6': '%F6', //ö
  '%C3%BC': '%FC', //ü
  '%C3%A2': '%E2' // â
}

module.exports = CHAR_CODES;
},{}],2:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/var CHAR_CODES = {  '%C3%80': '&#192;', // À  '%C3%81': '&#193;', // Á  '%C3%82': '&#194;', // Â  '%C3%83': '&#195;', // Ã  '%C3%84': '&#196;', // Ä  '%C3%85': '&#197;', // Å  '%C3%86': '&#198;', // Æ  '%C3%87': '&#199;', // Ç  '%C3%88': '&#200;', // È  '%C3%89': '&#201;', // É  '%C3%8A': '&#202;', // Ê  '%C3%8B': '&#203;', // Ë  '%C3%8C': '&#204;', // Ì  '%C3%8D': '&#205;', // Í  '%C3%8E': '&#206;', // Î  '%C3%8F': '&#207;', // Ï  '%C3%91': '&#209;', // Ñ  '%C3%92': '&#210;', // Ò  '%C3%93': '&#211;', // Ó  '%C3%94': '&#212;', // Ô  '%C3%95': '&#213;', // Õ  '%C3%96': '&#214;', // Ö  '%C3%99': '&#217;', // Ù  '%C3%9A': '&#218;', // Ú  '%C3%9B': '&#219;', // Û  '%C3%9C': '&#220;', // Ü  '%C3%A0': '&#224;', // à  '%C3%A1': '&#225;', // á  '%C3%A2': '&#226;', // â  '%C3%A3': '&#227;', // ã  '%C3%A4': '&#228;', // ä  '%C3%A5': '&#229;', // å  '%C3%A6': '&#230;', // æ  '%C3%A7': '&#231;', // ç  '%C3%A8': '&#232;', // è  '%C3%A9': '&#233;', // é  '%C3%AA': '&#234;', // ê  '%C3%AB': '&#235;', // ë  '%C3%AC': '&#236;', // ì  '%C3%AD': '&#237;', // í  '%C3%AE': '&#238;', // î  '%C3%AF': '&#239;', // ï  '%C3%B0': '&#240;', // ð  '%C3%B1': '&#241;', // ñ  '%C3%B2': '&#242;', // ò  '%C3%B3': '&#243;', // ó  '%C3%B4': '&#244;', // ô  '%C3%B5': '&#245;', // õ  '%C3%B6': '&#246;', // ö  '%C3%B9': '&#249;', // ù  '%C3%BA': '&#250;', // ú  '%C3%BB': '&#251;', // û  '%C3%BC': '&#252;', // ü  '%C3%BF': '&#255;', // ÿ  '%C5%B8': '&#376;', // Ÿ  '%C3%9F': '&#223;', // ß  '%C2%BF': '&#191;', // ¿  '%C2%A1': '&#161;', // ¡};module.exports = CHAR_CODES;
},{}],3:[function(require,module,exports){

/*
  Dropdown language menu
  @param opts takes element and onSelect handler
  example:
  new Dropdown({
   el: document.getElementById('#menu');
   onSelect: function () {}
  })
 */
var DICT_CODE, Dropdown, LANG_CODE;

LANG_CODE = {
  '1': 'Eng',
  '2': 'Rus',
  '3': 'Ger',
  '4': 'Fre',
  '5': 'Spa',
  '23': 'Ita',
  '24': 'Dut',
  '26': 'Est',
  '27': 'Lav',
  '31': 'Afr',
  '34': 'Epo',
  '35': 'Xal',
  '1000': 'Tur'
};

DICT_CODE = {
  '1': 'multitran',
  '1000': 'turkish'
};

Dropdown = (function() {
  function Dropdown(opts) {
    this.el = opts.el || document.createElement('div');
    this.onSelect = opts.onSelect;
    this.menu = this.el.querySelector('.dropdown-menu');
    if (this.menu) {
      this.menu.style.display = 'none';
      this.items = this.menu.getElementsByClassName('language-type');
      this.button = this.el.querySelector('.dropdown-toggle');
      this.addListeners();
      this.initLanguage();
    }
  }

  Dropdown.prototype.addListeners = function() {
    this.button.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.toggle(e);
      };
    })(this));
    document.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.hide(e);
      };
    })(this));
    return this.menu.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.choose(e);
      };
    })(this));
  };

  Dropdown.prototype.initLanguage = function() {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(store) {
        return _this.setTitle(store.language);
      };
    })(this));
  };

  Dropdown.prototype.toggle = function(e) {
    e.stopPropagation();
    this.setActiveItem();
    if (this.menu && this.menu.style.display === 'none') {
      return this.show();
    } else {
      return this.hide();
    }
  };

  Dropdown.prototype.setActiveItem = function() {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(store) {
        var item, _i, _len, _ref, _results;
        _ref = _this.items;
        _results = [];
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          item = _ref[_i];
          if (item.getAttribute('data-val') === store.language) {
            _results.push(item.classList.add('active'));
          } else {
            _results.push(item.classList.remove('active'));
          }
        }
        return _results;
      };
    })(this));
  };

  Dropdown.prototype.hide = function() {
    return this.menu.style.display = 'none';
  };

  Dropdown.prototype.show = function() {
    return this.menu.style.display = 'block';
  };

  Dropdown.prototype.choose = function(e) {
    var dictionary, language;
    e.stopPropagation();
    e.preventDefault();
    language = e.target.getAttribute('data-val');
    dictionary = this.getDictionary(language);
    chrome.storage.sync.set({
      language: language,
      dictionary: dictionary
    }, this.onSelect);
    this.setTitle(language);
    return this.hide();
  };

  Dropdown.prototype.getDictionary = function(lang) {
    var dict;
    console.log('choose dict: for', lang);
    dict = DICT_CODE[lang] || 'multitran';
    console.log('dict', dict);
    return dict;
  };

  Dropdown.prototype.setTitle = function(language) {
    var html;
    html = LANG_CODE[language] + ' <span class="caret"></span>';
    return this.button.innerHTML = html;
  };

  return Dropdown;

})();

module.exports = Dropdown;


},{}],4:[function(require,module,exports){

/*
  Extension popup window
  Shows search form and dropdown menu with languages
 */
var SearchForm;

SearchForm = require('./search_form.coffee');

document.addEventListener("DOMContentLoaded", function() {
  var form, link;
  form = new SearchForm(document.getElementById('tran-form'));
  link = document.getElementById('header-link');
  if (link) {
    return link.addEventListener('click', function(e) {
      var href;
      e.preventDefault();
      href = e.target.getAttribute('href') + form.getValue();
      return chrome.tabs.create({
        url: href
      });
    });
  }
});


},{"./search_form.coffee":5}],5:[function(require,module,exports){

/*
  Serves search input and form

  @param form DOM elemnt
  @constructor
 */
var Dropdown, SearchForm, TRANSLATE_ENGINES, tran, turkishdictionary,
  __indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

Dropdown = require('./dropdown.coffee');

tran = require('../tran.coffee');

turkishdictionary = require('../turkishdictionary.js');

TRANSLATE_ENGINES = {
  'multitran': tran,
  'turkish': turkishdictionary
};

SearchForm = (function() {
  function SearchForm(form) {
    this.form = form;
    this.input = document.getElementById('translate-txt');
    this.input.focus();
    this.result = document.getElementById('result');
    this.addListeners();
    this.dropdown = new Dropdown({
      el: document.querySelector('.dropdown-el'),
      onSelect: (function(_this) {
        return function() {
          return _this.search();
        };
      })(this)
    });
  }

  SearchForm.prototype.addListeners = function() {
    if (this.form && this.result) {
      this.form.addEventListener('submit', (function(_this) {
        return function(e) {
          return _this.search(e);
        };
      })(this));
      return this.result.addEventListener('click', (function(_this) {
        return function(e) {
          return _this.resultClickHandler(e);
        };
      })(this));
    }
  };

  SearchForm.prototype.search = function(e) {
    e && e.preventDefault && e.preventDefault();
    if (this.input.value.length > 0) {
      return chrome.storage.sync.get({
        language: '1',
        dictionary: 'multitran'
      }, (function(_this) {
        return function(items) {
          console.log('ITEMS:', items);
          return TRANSLATE_ENGINES[items.dictionary].search({
            value: _this.input.value,
            success: _this.successHandler.bind(_this)
          });
        };
      })(this));
    }
  };

  SearchForm.prototype.successHandler = function(response) {
    this.clean(this.result);
    return this.result.appendChild(response);
  };

  SearchForm.prototype.clean = function(el) {
    var _results;
    _results = [];
    while (el.lastChild) {
      _results.push(el.removeChild(el.lastChild));
    }
    return _results;
  };

  SearchForm.prototype.resultClickHandler = function(e) {
    var linkTags, _ref;
    e.preventDefault();
    linkTags = ['A', 'a'];
    if (_ref = e.target.tagName, __indexOf.call(linkTags, _ref) >= 0) {
      this.input.value = e.target.innerText;
      return this.search(e);
    }
  };

  SearchForm.prototype.getValue = function() {
    return this.input.value;
  };

  return SearchForm;

})();

module.exports = SearchForm;


},{"../tran.coffee":6,"../turkishdictionary.js":7,"./dropdown.coffee":3}],6:[function(require,module,exports){

/*global chrome */

/*
  Multitran.ru translate engine
  Provides program interface for making translate queries to multitran and get clean response

  All engines must follow common interface and provide methods:
    - search (languange, successHandler)  clean translation must be passed into successHandler
    - click

  Translation-module that makes requests to language-engine,
  parses results and sends plugin-global message with translation data
 */
var CHAR_CODES, Tran;

CHAR_CODES = require('./char-codes.js');

Tran = (function() {
  function Tran() {
    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1';
    this.xhr = {};
  }


  /*
    Context menu click handler
   */

  Tran.prototype.click = function(data) {
    var selectionText;
    if (typeof data.silent === void 0 || data.silent === null) {
      data.silent = true;
    }
    selectionText = this.removeHyphenation(data.selectionText);
    return this.search({
      value: selectionText,
      success: this.successtHandler.bind(this),
      silent: data.silent
    });
  };


  /*
    Discard soft hyphen character (U+00AD, &shy;) from the input
   */

  Tran.prototype.removeHyphenation = function(text) {
    return text.replace(/\xad/g, '');
  };


  /*
    Initiate translation search
   */

  Tran.prototype.search = function(params) {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(items) {
        var language, origSuccess, url;
        if (language === '') {
          language = '1';
        }
        _this.setLanguage(items.language);
        url = _this.makeUrl(params.value);
        origSuccess = params.success;
        params.success = function(response) {
          var translated;
          translated = _this.parse(response, params.silent);
          return origSuccess(translated);
        };
        return _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      };
    })(this));
  };

  Tran.prototype.setLanguage = function(language) {
    this.currentLanguage = language;
    return this.lang = '?l1=2&l2=' + language;
  };


  /*
    Request translation and run callback function
    passing translated result or error to callback
   */

  Tran.prototype.request = function(opts) {
    var xhr;
    xhr = this.xhr = new XMLHttpRequest();
    xhr.onreadystatechange = (function(_this) {
      return function(e) {
        xhr = _this.xhr;
        if (xhr.readyState < 4) {

        } else if (xhr.status !== 200) {
          _this.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error();
          }
        } else if (xhr.readyState === 4) {
          return opts.success(e.target.response);
        }
      };
    })(this);
    xhr.open("GET", opts.url, true);
    return xhr.send();
  };

  Tran.prototype.makeUrl = function(value) {
    var url;
    url = [this.protocol, '://', this.host, this.path, this.lang, this.query, this.getEncodedValue(value)].join('');
    return url;
  };

  Tran.prototype.getEncodedValue = function(value) {
    var char, code, val;
    val = encodeURIComponent(value);
    for (char in CHAR_CODES) {
      code = CHAR_CODES[char];
      val = val.replace(char, encodeURIComponent(code));
    }
    return val;
  };

  Tran.prototype.errorHandler = function(xhr) {
    return console.log('error', xhr);
  };


  /*
   Receiving data from translation-engine and send ready message with data
   */

  Tran.prototype.successtHandler = function(translated) {
    if (translated) {
      return chrome.tabs.getSelected(null, (function(_this) {
        return function(tab) {
          return chrome.tabs.sendMessage(tab.id, {
            action: _this.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        };
      })(this));
    }
  };

  Tran.prototype.messageType = function(translated) {
    var _ref;
    if ((translated != null ? (_ref = translated.rows) != null ? _ref.length : void 0 : void 0) === 1) {
      return 'similar_words';
    } else {
      return 'open_tooltip';
    }
  };


  /*
    Parse response from translation engine
   */

  Tran.prototype.parse = function(response, silent, translate) {
    var doc, fragment;
    if (translate == null) {
      translate = null;
    }
    doc = this.stripScripts(response);
    fragment = this.makeFragment(doc);
    if (fragment) {
      translate = fragment.querySelector('#translation ~ table');
      if (translate) {
        translate.className = this.TABLE_CLASS;
        translate.setAttribute("cellpadding", "5");
        this.fixImages(translate);
        this.fixLinks(translate);
      } else if (!silent) {
        translate = document.createElement('div');
        translate.className = 'failTranslate';
        translate.innerText = "Unfortunately, could not translate";
      }
    }
    return translate;
  };


  /*
    Strip script tags from response html
   */

  Tran.prototype.stripScripts = function(s) {
    var div, i, scripts;
    div = document.createElement('div');
    div.innerHTML = s;
    scripts = div.getElementsByTagName('script');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
    return div.innerHTML;
  };

  Tran.prototype.makeFragment = function(doc, fragment) {
    var div;
    if (fragment == null) {
      fragment = null;
    }
    div = document.createElement("div");
    div.innerHTML = doc;
    fragment = document.createDocumentFragment();
    while (div.firstChild) {
      fragment.appendChild(div.firstChild);
    }
    return fragment;
  };

  Tran.prototype.fixImages = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'img', 'src');
    return fragment;
  };

  Tran.prototype.fixLinks = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'a', 'href');
    return fragment;
  };

  Tran.prototype.fixUrl = function(fragment, tag, attr) {
    var parser, tags, _i, _len, _results;
    if (fragment == null) {
      fragment = null;
    }
    if (fragment) {
      tags = fragment.querySelectorAll(tag);
      parser = document.createElement('a');
      _results = [];
      for (_i = 0, _len = tags.length; _i < _len; _i++) {
        tag = tags[_i];
        parser.href = tag[attr];
        parser.host = this.host;
        parser.protocol = this.protocol;
        if (tag.tagName === 'A') {
          tag.classList.add('mtt_link');
          if (parser.pathname.indexOf('m.exe') !== -1) {
            parser.pathname = '/c' + parser.pathname;
            tag.setAttribute('target', '_blank');
          }
        } else if (tag.tagName === 'IMG') {
          tag.classList.add('mtt_img');
        }
        _results.push(tag.setAttribute(attr, parser.href));
      }
      return _results;
    }
  };

  return Tran;

})();

module.exports = new Tran;


},{"./char-codes.js":2}],7:[function(require,module,exports){
"use strict";

var _prototypeProperties = function (child, staticProps, instanceProps) {
  if (staticProps) Object.defineProperties(child, staticProps);
  if (instanceProps) Object.defineProperties(child.prototype, instanceProps);
};

/*
  Translation engine: http://www.turkishdictionary.net
  For translating turkish-russian and vice versa
*/
var CHAR_CODES = require("./char-codes-turk.js");

var TurkishDictionary = (function () {
  function TurkishDictionary() {
    this.host = "http://www.turkishdictionary.net/?word=%FC";
    this.path = "";
    this.protocol = "http";
    this.query = "&s=";
    this.TABLE_CLASS = "___mtt_translate_table";
    this.need_publish = true;
  }

  _prototypeProperties(TurkishDictionary, null, {
    search: {
      value: function search(data) {
        data.url = this.makeUrl(data.value);
        this.need_publish = false;
        return this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    translate: {
      value: function translate(data) {
        console.log("request data:", data);
        data.url = this.makeUrl(data.selectionText);
        this.need_publish = true;
        this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeUrl: {
      value: function makeUrl(text) {
        var text = this.getEncodedValue(text);
        return ["http://www.turkishdictionary.net/?word=", text].join("");
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    getEncodedValue: {
      // Replace special language characters to html codes
      value: function getEncodedValue(value) {
        // to find spec symbols we first encode them (raw search for that symbol doesn't wor)
        var val = encodeURIComponent(value);
        for (var char in CHAR_CODES) {
          val = val.replace(char, CHAR_CODES[char]);
        }
        return val;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    request: {

      /*
        Request translation and run callback function
        passing translated result or error to callback
      */
      value: function request(opts) {
        console.log("start request");
        this.xhr = new XMLHttpRequest();
        this.xhr.onreadystatechange = this.onReadyStateChange.bind(this, opts);
        this.xhr.open("GET", opts.url, true);
        this.xhr.send();
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    onReadyStateChange: {
      value: function onReadyStateChange(opts, e) {
        var xhr = this.xhr;
        if (xhr.readyState < 4) {
          return;
        } else if (xhr.status != 200) {
          this.errorHandler(xhr);
          return opts.error && opts.error();
        } else if (xhr.readyState == 4) {
          var translation = this.successHandler(e.target.response);
          console.log("success turkish translate", translation);
          console.log("call", opts.success);
          return opts.success && opts.success(translation);
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    successHandler: {
      value: function successHandler(response) {
        var data = this.parse(response);
        if (this.need_publish) {
          chrome.tabs.getSelected(null, this.publishTranslation.bind(this, data));
        }
        return data;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    publishTranslation: {

      /* publish successfuly translated text all over extension */
      value: function publishTranslation(translation, tab) {
        console.log("publish translation");
        chrome.tabs.sendMessage(tab.id, {
          action: "open_tooltip",
          data: translation.outerHTML,
          success: !translation.classList.contains("failTranslate")
        });
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    errorHandler: {
      value: function errorHandler(response) {
        console.log("error ajax", response);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parse: {

      /* Parse response from translation engine */
      value: function parse(response, silent, translate) {
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);
        if (fragment) {
          translate = fragment.querySelector("#meaning_div > table");
          if (translate) {
            translate.className = this.TABLE_CLASS;
            translate.setAttribute("cellpadding", "5");
            // @fixImages(translate)
            // @fixLinks(translate)
          } else if (!silent) {
            translate = document.createElement("div");
            translate.className = "failTranslate";
            translate.innerText = "Unfortunately, could not translate";
          }
        }
        return translate;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    stripScripts: {

      //TODO extract to base engine class
      /* removes <script> tags from html code */
      value: function stripScripts(html) {
        var div = document.createElement("div");
        div.innerHTML = html;
        var scripts = div.getElementsByTagName("script");
        var i = scripts.length;
        while (i--) scripts[i].parentNode.removeChild(scripts[i]);
        return div.innerHTML;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeFragment: {

      //TODO extract to base engine class
      /* creates temp object to parse translation from page 
        (since it's not a friendly api) 
      */
      value: function makeFragment(html) {
        var fragment,
            div = document.createElement("div");
        div.innerHTML = html;
        fragment = document.createDocumentFragment();
        while (div.firstChild) {
          fragment.appendChild(div.firstChild);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    }
  });

  return TurkishDictionary;
})();

// Singletone
module.exports = new TurkishDictionary();
},{"./char-codes-turk.js":1}]},{},[4])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvY2hhci1jb2Rlcy10dXJrLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy9jaGFyLWNvZGVzLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy9wb3B1cC9kcm9wZG93bi5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXZlbG9wbWVudC90cmFuL2pzL3BvcHVwL3BvcHVwLmNvZmZlZSIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvcG9wdXAvc2VhcmNoX2Zvcm0uY29mZmVlIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy90cmFuLmNvZmZlZSIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvdHVya2lzaGRpY3Rpb25hcnkuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDWEE7O0FDQUE7QUFBQTs7Ozs7Ozs7R0FBQTtBQUFBLElBQUEsOEJBQUE7O0FBQUEsU0FTQSxHQUNFO0FBQUEsRUFBQSxHQUFBLEVBQUssS0FBTDtBQUFBLEVBQ0EsR0FBQSxFQUFLLEtBREw7QUFBQSxFQUVBLEdBQUEsRUFBSyxLQUZMO0FBQUEsRUFHQSxHQUFBLEVBQUssS0FITDtBQUFBLEVBSUEsR0FBQSxFQUFLLEtBSkw7QUFBQSxFQUtBLElBQUEsRUFBTSxLQUxOO0FBQUEsRUFNQSxJQUFBLEVBQU0sS0FOTjtBQUFBLEVBT0EsSUFBQSxFQUFNLEtBUE47QUFBQSxFQVFBLElBQUEsRUFBTSxLQVJOO0FBQUEsRUFTQSxJQUFBLEVBQU0sS0FUTjtBQUFBLEVBVUEsSUFBQSxFQUFNLEtBVk47QUFBQSxFQVdBLElBQUEsRUFBTSxLQVhOO0FBQUEsRUFZQSxNQUFBLEVBQVEsS0FaUjtDQVZGLENBQUE7O0FBQUEsU0F3QkEsR0FDRTtBQUFBLEVBQUEsR0FBQSxFQUFLLFdBQUw7QUFBQSxFQUNBLE1BQUEsRUFBUSxTQURSO0NBekJGLENBQUE7O0FBQUE7QUE2QmUsRUFBQSxrQkFBQyxJQUFELEdBQUE7QUFDWCxJQUFBLElBQUMsQ0FBQSxFQUFELEdBQU0sSUFBSSxDQUFDLEVBQUwsSUFBVyxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFqQixDQUFBO0FBQUEsSUFFQSxJQUFDLENBQUEsUUFBRCxHQUFZLElBQUksQ0FBQyxRQUZqQixDQUFBO0FBQUEsSUFJQSxJQUFDLENBQUEsSUFBRCxHQUFRLElBQUMsQ0FBQSxFQUFFLENBQUMsYUFBSixDQUFrQixnQkFBbEIsQ0FKUixDQUFBO0FBS0EsSUFBQSxJQUFHLElBQUMsQ0FBQSxJQUFKO0FBQ0UsTUFBQSxJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFaLEdBQXNCLE1BQXRCLENBQUE7QUFBQSxNQUNBLElBQUMsQ0FBQSxLQUFELEdBQVMsSUFBQyxDQUFBLElBQUksQ0FBQyxzQkFBTixDQUE2QixlQUE3QixDQURULENBQUE7QUFBQSxNQUVBLElBQUMsQ0FBQSxNQUFELEdBQVUsSUFBQyxDQUFBLEVBQUUsQ0FBQyxhQUFKLENBQWtCLGtCQUFsQixDQUZWLENBQUE7QUFBQSxNQUdBLElBQUMsQ0FBQSxZQUFELENBQUEsQ0FIQSxDQUFBO0FBQUEsTUFJQSxJQUFDLENBQUEsWUFBRCxDQUFBLENBSkEsQ0FERjtLQU5XO0VBQUEsQ0FBYjs7QUFBQSxxQkFhQSxZQUFBLEdBQWMsU0FBQSxHQUFBO0FBQ1osSUFBQSxJQUFDLENBQUEsTUFBTSxDQUFDLGdCQUFSLENBQXlCLE9BQXpCLEVBQWtDLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLENBQUQsR0FBQTtlQUFPLEtBQUMsQ0FBQSxNQUFELENBQVEsQ0FBUixFQUFQO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbEMsQ0FBQSxDQUFBO0FBQUEsSUFDQSxRQUFRLENBQUMsZ0JBQVQsQ0FBMEIsT0FBMUIsRUFBbUMsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsQ0FBRCxHQUFBO2VBQU8sS0FBQyxDQUFBLElBQUQsQ0FBTSxDQUFOLEVBQVA7TUFBQSxFQUFBO0lBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFuQyxDQURBLENBQUE7V0FFQSxJQUFDLENBQUEsSUFBSSxDQUFDLGdCQUFOLENBQXVCLE9BQXZCLEVBQWdDLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLENBQUQsR0FBQTtlQUFPLEtBQUMsQ0FBQSxNQUFELENBQVEsQ0FBUixFQUFQO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBaEMsRUFIWTtFQUFBLENBYmQsQ0FBQTs7QUFBQSxxQkFtQkEsWUFBQSxHQUFjLFNBQUEsR0FBQTtXQUNaLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsTUFBRSxRQUFBLEVBQVUsR0FBWjtLQUF4QixFQUEwQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxLQUFELEdBQUE7ZUFDeEMsS0FBQyxDQUFBLFFBQUQsQ0FBVSxLQUFLLENBQUMsUUFBaEIsRUFEd0M7TUFBQSxFQUFBO0lBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUExQyxFQURZO0VBQUEsQ0FuQmQsQ0FBQTs7QUFBQSxxQkF3QkEsTUFBQSxHQUFRLFNBQUMsQ0FBRCxHQUFBO0FBQ04sSUFBQSxDQUFDLENBQUMsZUFBRixDQUFBLENBQUEsQ0FBQTtBQUFBLElBQ0EsSUFBQyxDQUFBLGFBQUQsQ0FBQSxDQURBLENBQUE7QUFFQSxJQUFBLElBQUcsSUFBQyxDQUFBLElBQUQsSUFBVSxJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFaLEtBQXVCLE1BQXBDO2FBQ0UsSUFBQyxDQUFBLElBQUQsQ0FBQSxFQURGO0tBQUEsTUFBQTthQUdFLElBQUMsQ0FBQSxJQUFELENBQUEsRUFIRjtLQUhNO0VBQUEsQ0F4QlIsQ0FBQTs7QUFBQSxxQkFpQ0EsYUFBQSxHQUFlLFNBQUEsR0FBQTtXQUNiLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsTUFBQyxRQUFBLEVBQVUsR0FBWDtLQUF4QixFQUF5QyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxLQUFELEdBQUE7QUFDdkMsWUFBQSw4QkFBQTtBQUFBO0FBQUE7YUFBQSwyQ0FBQTswQkFBQTtBQUNFLFVBQUEsSUFBRyxJQUFJLENBQUMsWUFBTCxDQUFrQixVQUFsQixDQUFBLEtBQWlDLEtBQUssQ0FBQyxRQUExQzswQkFDRSxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQWYsQ0FBbUIsUUFBbkIsR0FERjtXQUFBLE1BQUE7MEJBR0UsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFmLENBQXNCLFFBQXRCLEdBSEY7V0FERjtBQUFBO3dCQUR1QztNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpDLEVBRGE7RUFBQSxDQWpDZixDQUFBOztBQUFBLHFCQXlDQSxJQUFBLEdBQU0sU0FBQSxHQUFBO1dBQ0osSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWixHQUFzQixPQURsQjtFQUFBLENBekNOLENBQUE7O0FBQUEscUJBNENBLElBQUEsR0FBTSxTQUFBLEdBQUE7V0FDSixJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFaLEdBQXNCLFFBRGxCO0VBQUEsQ0E1Q04sQ0FBQTs7QUFBQSxxQkFpREEsTUFBQSxHQUFRLFNBQUMsQ0FBRCxHQUFBO0FBQ04sUUFBQSxvQkFBQTtBQUFBLElBQUEsQ0FBQyxDQUFDLGVBQUYsQ0FBQSxDQUFBLENBQUE7QUFBQSxJQUNBLENBQUMsQ0FBQyxjQUFGLENBQUEsQ0FEQSxDQUFBO0FBQUEsSUFFQSxRQUFBLEdBQVcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFULENBQXNCLFVBQXRCLENBRlgsQ0FBQTtBQUFBLElBR0EsVUFBQSxHQUFhLElBQUMsQ0FBQSxhQUFELENBQWUsUUFBZixDQUhiLENBQUE7QUFBQSxJQUlBLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsTUFBQyxRQUFBLEVBQVUsUUFBWDtBQUFBLE1BQXFCLFVBQUEsRUFBWSxVQUFqQztLQUF4QixFQUFzRSxJQUFDLENBQUEsUUFBdkUsQ0FKQSxDQUFBO0FBQUEsSUFLQSxJQUFDLENBQUEsUUFBRCxDQUFVLFFBQVYsQ0FMQSxDQUFBO1dBTUEsSUFBQyxDQUFBLElBQUQsQ0FBQSxFQVBNO0VBQUEsQ0FqRFIsQ0FBQTs7QUFBQSxxQkE0REEsYUFBQSxHQUFlLFNBQUMsSUFBRCxHQUFBO0FBQ2IsUUFBQSxJQUFBO0FBQUEsSUFBQSxPQUFPLENBQUMsR0FBUixDQUFZLGtCQUFaLEVBQStCLElBQS9CLENBQUEsQ0FBQTtBQUFBLElBQ0EsSUFBQSxHQUFPLFNBQVUsQ0FBQSxJQUFBLENBQVYsSUFBbUIsV0FEMUIsQ0FBQTtBQUFBLElBRUEsT0FBTyxDQUFDLEdBQVIsQ0FBWSxNQUFaLEVBQW1CLElBQW5CLENBRkEsQ0FBQTtBQUdBLFdBQU8sSUFBUCxDQUphO0VBQUEsQ0E1RGYsQ0FBQTs7QUFBQSxxQkFtRUEsUUFBQSxHQUFVLFNBQUMsUUFBRCxHQUFBO0FBQ1IsUUFBQSxJQUFBO0FBQUEsSUFBQSxJQUFBLEdBQU8sU0FBVSxDQUFBLFFBQUEsQ0FBVixHQUFzQiw4QkFBN0IsQ0FBQTtXQUNBLElBQUMsQ0FBQSxNQUFNLENBQUMsU0FBUixHQUFvQixLQUZaO0VBQUEsQ0FuRVYsQ0FBQTs7a0JBQUE7O0lBN0JGLENBQUE7O0FBQUEsTUFxR00sQ0FBQyxPQUFQLEdBQWlCLFFBckdqQixDQUFBOzs7O0FDQUE7QUFBQTs7O0dBQUE7QUFBQSxJQUFBLFVBQUE7O0FBQUEsVUFJQSxHQUFhLE9BQUEsQ0FBUSxzQkFBUixDQUpiLENBQUE7O0FBQUEsUUFNUSxDQUFDLGdCQUFULENBQTBCLGtCQUExQixFQUE4QyxTQUFBLEdBQUE7QUFDNUMsTUFBQSxVQUFBO0FBQUEsRUFBQSxJQUFBLEdBQVcsSUFBQSxVQUFBLENBQVcsUUFBUSxDQUFDLGNBQVQsQ0FBd0IsV0FBeEIsQ0FBWCxDQUFYLENBQUE7QUFBQSxFQUNBLElBQUEsR0FBTyxRQUFRLENBQUMsY0FBVCxDQUF3QixhQUF4QixDQURQLENBQUE7QUFFQSxFQUFBLElBQUcsSUFBSDtXQUNFLElBQUksQ0FBQyxnQkFBTCxDQUFzQixPQUF0QixFQUErQixTQUFDLENBQUQsR0FBQTtBQUM3QixVQUFBLElBQUE7QUFBQSxNQUFBLENBQUMsQ0FBQyxjQUFGLENBQUEsQ0FBQSxDQUFBO0FBQUEsTUFDQSxJQUFBLEdBQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFULENBQXNCLE1BQXRCLENBQUEsR0FBZ0MsSUFBSSxDQUFDLFFBQUwsQ0FBQSxDQUR2QyxDQUFBO2FBRUEsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFaLENBQW1CO0FBQUEsUUFBRSxHQUFBLEVBQUssSUFBUDtPQUFuQixFQUg2QjtJQUFBLENBQS9CLEVBREY7R0FINEM7QUFBQSxDQUE5QyxDQU5BLENBQUE7Ozs7QUNBQTtBQUFBOzs7OztHQUFBO0FBQUEsSUFBQSxnRUFBQTtFQUFBLHFKQUFBOztBQUFBLFFBTUEsR0FBVyxPQUFBLENBQVEsbUJBQVIsQ0FOWCxDQUFBOztBQUFBLElBU0EsR0FBTyxPQUFBLENBQVEsZ0JBQVIsQ0FUUCxDQUFBOztBQUFBLGlCQVVBLEdBQW9CLE9BQUEsQ0FBUSx5QkFBUixDQVZwQixDQUFBOztBQUFBLGlCQWNBLEdBQ0U7QUFBQSxFQUFBLFdBQUEsRUFBYSxJQUFiO0FBQUEsRUFDQSxTQUFBLEVBQVcsaUJBRFg7Q0FmRixDQUFBOztBQUFBO0FBbUJlLEVBQUEsb0JBQUUsSUFBRixHQUFBO0FBQ1gsSUFEWSxJQUFDLENBQUEsT0FBQSxJQUNiLENBQUE7QUFBQSxJQUFBLElBQUMsQ0FBQSxLQUFELEdBQVMsUUFBUSxDQUFDLGNBQVQsQ0FBd0IsZUFBeEIsQ0FBVCxDQUFBO0FBQUEsSUFDQSxJQUFDLENBQUEsS0FBSyxDQUFDLEtBQVAsQ0FBQSxDQURBLENBQUE7QUFBQSxJQUdBLElBQUMsQ0FBQSxNQUFELEdBQVUsUUFBUSxDQUFDLGNBQVQsQ0FBd0IsUUFBeEIsQ0FIVixDQUFBO0FBQUEsSUFJQSxJQUFDLENBQUEsWUFBRCxDQUFBLENBSkEsQ0FBQTtBQUFBLElBS0EsSUFBQyxDQUFBLFFBQUQsR0FBZ0IsSUFBQSxRQUFBLENBQVM7QUFBQSxNQUN2QixFQUFBLEVBQUksUUFBUSxDQUFDLGFBQVQsQ0FBdUIsY0FBdkIsQ0FEbUI7QUFBQSxNQUV2QixRQUFBLEVBQVUsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUEsR0FBQTtpQkFBRyxLQUFDLENBQUEsTUFBRCxDQUFBLEVBQUg7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUZhO0tBQVQsQ0FMaEIsQ0FEVztFQUFBLENBQWI7O0FBQUEsdUJBV0EsWUFBQSxHQUFjLFNBQUEsR0FBQTtBQUNaLElBQUEsSUFBRyxJQUFDLENBQUEsSUFBRCxJQUFVLElBQUMsQ0FBQSxNQUFkO0FBQ0UsTUFBQSxJQUFDLENBQUEsSUFBSSxDQUFDLGdCQUFOLENBQXVCLFFBQXZCLEVBQWlDLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLENBQUQsR0FBQTtpQkFBTyxLQUFDLENBQUEsTUFBRCxDQUFRLENBQVIsRUFBUDtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWpDLENBQUEsQ0FBQTthQUNBLElBQUMsQ0FBQSxNQUFNLENBQUMsZ0JBQVIsQ0FBeUIsT0FBekIsRUFBa0MsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsQ0FBRCxHQUFBO2lCQUFPLEtBQUMsQ0FBQSxrQkFBRCxDQUFvQixDQUFwQixFQUFQO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbEMsRUFGRjtLQURZO0VBQUEsQ0FYZCxDQUFBOztBQUFBLHVCQWdCQSxNQUFBLEdBQVEsU0FBQyxDQUFELEdBQUE7QUFDTixJQUFBLENBQUEsSUFBSyxDQUFDLENBQUMsY0FBUCxJQUF5QixDQUFDLENBQUMsY0FBRixDQUFBLENBQXpCLENBQUE7QUFDQSxJQUFBLElBQUcsSUFBQyxDQUFBLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBYixHQUFzQixDQUF6QjthQUVFLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsUUFBQyxRQUFBLEVBQVUsR0FBWDtBQUFBLFFBQWdCLFVBQUEsRUFBWSxXQUE1QjtPQUF4QixFQUFrRSxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxLQUFELEdBQUE7QUFDaEUsVUFBQSxPQUFPLENBQUMsR0FBUixDQUFZLFFBQVosRUFBc0IsS0FBdEIsQ0FBQSxDQUFBO2lCQUNBLGlCQUFrQixDQUFBLEtBQUssQ0FBQyxVQUFOLENBQWlCLENBQUMsTUFBcEMsQ0FDRTtBQUFBLFlBQUEsS0FBQSxFQUFPLEtBQUMsQ0FBQSxLQUFLLENBQUMsS0FBZDtBQUFBLFlBQ0EsT0FBQSxFQUFTLEtBQUMsQ0FBQSxjQUFjLENBQUMsSUFBaEIsQ0FBcUIsS0FBckIsQ0FEVDtXQURGLEVBRmdFO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbEUsRUFGRjtLQUZNO0VBQUEsQ0FoQlIsQ0FBQTs7QUFBQSx1QkEyQkEsY0FBQSxHQUFnQixTQUFDLFFBQUQsR0FBQTtBQUNaLElBQUEsSUFBQyxDQUFBLEtBQUQsQ0FBTyxJQUFDLENBQUEsTUFBUixDQUFBLENBQUE7V0FDQSxJQUFDLENBQUEsTUFBTSxDQUFDLFdBQVIsQ0FBb0IsUUFBcEIsRUFGWTtFQUFBLENBM0JoQixDQUFBOztBQUFBLHVCQStCQSxLQUFBLEdBQU8sU0FBQyxFQUFELEdBQUE7QUFDTCxRQUFBLFFBQUE7QUFBQTtXQUFPLEVBQUUsQ0FBQyxTQUFWLEdBQUE7QUFDRSxvQkFBQSxFQUFFLENBQUMsV0FBSCxDQUFlLEVBQUUsQ0FBQyxTQUFsQixFQUFBLENBREY7SUFBQSxDQUFBO29CQURLO0VBQUEsQ0EvQlAsQ0FBQTs7QUFBQSx1QkFtQ0Esa0JBQUEsR0FBb0IsU0FBQyxDQUFELEdBQUE7QUFDbEIsUUFBQSxjQUFBO0FBQUEsSUFBQSxDQUFDLENBQUMsY0FBRixDQUFBLENBQUEsQ0FBQTtBQUFBLElBQ0EsUUFBQSxHQUFXLENBQUMsR0FBRCxFQUFNLEdBQU4sQ0FEWCxDQUFBO0FBRUEsSUFBQSxXQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBVCxFQUFBLGVBQW9CLFFBQXBCLEVBQUEsSUFBQSxNQUFIO0FBQ0UsTUFBQSxJQUFDLENBQUEsS0FBSyxDQUFDLEtBQVAsR0FBZSxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQXhCLENBQUE7YUFDQSxJQUFDLENBQUEsTUFBRCxDQUFRLENBQVIsRUFGRjtLQUhrQjtFQUFBLENBbkNwQixDQUFBOztBQUFBLHVCQTBDQSxRQUFBLEdBQVUsU0FBQSxHQUFBO0FBQ1IsV0FBTyxJQUFDLENBQUEsS0FBSyxDQUFDLEtBQWQsQ0FEUTtFQUFBLENBMUNWLENBQUE7O29CQUFBOztJQW5CRixDQUFBOztBQUFBLE1BZ0ZNLENBQUMsT0FBUCxHQUFpQixVQWhGakIsQ0FBQTs7OztBQ0FBO0FBQUEsa0JBQUE7QUFDQTtBQUFBOzs7Ozs7Ozs7O0dBREE7QUFBQSxJQUFBLGdCQUFBOztBQUFBLFVBYUEsR0FBYSxPQUFBLENBQVEsaUJBQVIsQ0FiYixDQUFBOztBQUFBO0FBZ0JlLEVBQUEsY0FBQSxHQUFBO0FBQ1gsSUFBQSxJQUFDLENBQUEsV0FBRCxHQUFlLHdCQUFmLENBQUE7QUFBQSxJQUNBLElBQUMsQ0FBQSxRQUFELEdBQVksTUFEWixDQUFBO0FBQUEsSUFFQSxJQUFDLENBQUEsSUFBRCxHQUFRLGtCQUZSLENBQUE7QUFBQSxJQUdBLElBQUMsQ0FBQSxJQUFELEdBQVEsVUFIUixDQUFBO0FBQUEsSUFJQSxJQUFDLENBQUEsS0FBRCxHQUFTLEtBSlQsQ0FBQTtBQUFBLElBS0EsSUFBQyxDQUFBLElBQUQsR0FBUSxZQUxSLENBQUE7QUFBQSxJQU1BLElBQUMsQ0FBQSxHQUFELEdBQU8sRUFOUCxDQURXO0VBQUEsQ0FBYjs7QUFTQTtBQUFBOztLQVRBOztBQUFBLGlCQVlBLEtBQUEsR0FBTyxTQUFDLElBQUQsR0FBQTtBQUNMLFFBQUEsYUFBQTtBQUFBLElBQUEsSUFBRyxNQUFBLENBQUEsSUFBVyxDQUFDLE1BQVosS0FBc0IsTUFBdEIsSUFBbUMsSUFBSSxDQUFDLE1BQUwsS0FBZSxJQUFyRDtBQUNFLE1BQUEsSUFBSSxDQUFDLE1BQUwsR0FBYyxJQUFkLENBREY7S0FBQTtBQUFBLElBRUEsYUFBQSxHQUFnQixJQUFDLENBQUEsaUJBQUQsQ0FBbUIsSUFBSSxDQUFDLGFBQXhCLENBRmhCLENBQUE7V0FHQSxJQUFDLENBQUEsTUFBRCxDQUNJO0FBQUEsTUFBQSxLQUFBLEVBQU8sYUFBUDtBQUFBLE1BQ0EsT0FBQSxFQUFTLElBQUMsQ0FBQSxlQUFlLENBQUMsSUFBakIsQ0FBc0IsSUFBdEIsQ0FEVDtBQUFBLE1BRUEsTUFBQSxFQUFRLElBQUksQ0FBQyxNQUZiO0tBREosRUFKSztFQUFBLENBWlAsQ0FBQTs7QUFxQkE7QUFBQTs7S0FyQkE7O0FBQUEsaUJBd0JBLGlCQUFBLEdBQW1CLFNBQUMsSUFBRCxHQUFBO1dBQ2pCLElBQUksQ0FBQyxPQUFMLENBQWEsT0FBYixFQUFzQixFQUF0QixFQURpQjtFQUFBLENBeEJuQixDQUFBOztBQTJCQTtBQUFBOztLQTNCQTs7QUFBQSxpQkE4QkEsTUFBQSxHQUFRLFNBQUMsTUFBRCxHQUFBO1dBRU4sTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBcEIsQ0FBd0I7QUFBQSxNQUFDLFFBQUEsRUFBVSxHQUFYO0tBQXhCLEVBQXlDLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLEtBQUQsR0FBQTtBQUN2QyxZQUFBLDBCQUFBO0FBQUEsUUFBQSxJQUFHLFFBQUEsS0FBWSxFQUFmO0FBQ0UsVUFBQSxRQUFBLEdBQVcsR0FBWCxDQURGO1NBQUE7QUFBQSxRQUVBLEtBQUMsQ0FBQSxXQUFELENBQWEsS0FBSyxDQUFDLFFBQW5CLENBRkEsQ0FBQTtBQUFBLFFBR0EsR0FBQSxHQUFNLEtBQUMsQ0FBQSxPQUFELENBQVMsTUFBTSxDQUFDLEtBQWhCLENBSE4sQ0FBQTtBQUFBLFFBS0EsV0FBQSxHQUFjLE1BQU0sQ0FBQyxPQUxyQixDQUFBO0FBQUEsUUFNQSxNQUFNLENBQUMsT0FBUCxHQUFpQixTQUFDLFFBQUQsR0FBQTtBQUNmLGNBQUEsVUFBQTtBQUFBLFVBQUEsVUFBQSxHQUFhLEtBQUMsQ0FBQSxLQUFELENBQU8sUUFBUCxFQUFpQixNQUFNLENBQUMsTUFBeEIsQ0FBYixDQUFBO2lCQUNBLFdBQUEsQ0FBWSxVQUFaLEVBRmU7UUFBQSxDQU5qQixDQUFBO2VBV0EsS0FBQyxDQUFBLE9BQUQsQ0FDRTtBQUFBLFVBQUEsR0FBQSxFQUFLLEdBQUw7QUFBQSxVQUNBLE9BQUEsRUFBUyxNQUFNLENBQUMsT0FEaEI7QUFBQSxVQUVBLEtBQUEsRUFBTyxNQUFNLENBQUMsS0FGZDtTQURGLEVBWnVDO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBekMsRUFGTTtFQUFBLENBOUJSLENBQUE7O0FBQUEsaUJBbURBLFdBQUEsR0FBYSxTQUFDLFFBQUQsR0FBQTtBQUNYLElBQUEsSUFBQyxDQUFBLGVBQUQsR0FBbUIsUUFBbkIsQ0FBQTtXQUNBLElBQUMsQ0FBQSxJQUFELEdBQVEsV0FBQSxHQUFjLFNBRlg7RUFBQSxDQW5EYixDQUFBOztBQXVEQTtBQUFBOzs7S0F2REE7O0FBQUEsaUJBMkRBLE9BQUEsR0FBUyxTQUFDLElBQUQsR0FBQTtBQUNQLFFBQUEsR0FBQTtBQUFBLElBQUEsR0FBQSxHQUFNLElBQUMsQ0FBQSxHQUFELEdBQVcsSUFBQSxjQUFBLENBQUEsQ0FBakIsQ0FBQTtBQUFBLElBQ0EsR0FBRyxDQUFDLGtCQUFKLEdBQXlCLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLENBQUQsR0FBQTtBQUN2QixRQUFBLEdBQUEsR0FBTSxLQUFDLENBQUEsR0FBUCxDQUFBO0FBQ0EsUUFBQSxJQUFHLEdBQUcsQ0FBQyxVQUFKLEdBQWlCLENBQXBCO0FBQUE7U0FBQSxNQUVLLElBQUcsR0FBRyxDQUFDLE1BQUosS0FBYyxHQUFqQjtBQUNILFVBQUEsS0FBQyxDQUFBLFlBQUQsQ0FBYyxHQUFkLENBQUEsQ0FBQTtBQUNBLFVBQUEsSUFBSSxNQUFBLENBQUEsSUFBVyxDQUFDLEtBQVosS0FBcUIsVUFBekI7QUFDRSxZQUFBLElBQUksQ0FBQyxLQUFMLENBQUEsQ0FBQSxDQURGO1dBRkc7U0FBQSxNQUtBLElBQUcsR0FBRyxDQUFDLFVBQUosS0FBa0IsQ0FBckI7QUFDRCxpQkFBTyxJQUFJLENBQUMsT0FBTCxDQUFhLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBdEIsQ0FBUCxDQURDO1NBVGtCO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FEekIsQ0FBQTtBQUFBLElBYUEsR0FBRyxDQUFDLElBQUosQ0FBUyxLQUFULEVBQWdCLElBQUksQ0FBQyxHQUFyQixFQUEwQixJQUExQixDQWJBLENBQUE7V0FjQSxHQUFHLENBQUMsSUFBSixDQUFBLEVBZk87RUFBQSxDQTNEVCxDQUFBOztBQUFBLGlCQTZFQSxPQUFBLEdBQVMsU0FBQyxLQUFELEdBQUE7QUFDUCxRQUFBLEdBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxDQUFDLElBQUMsQ0FBQSxRQUFGLEVBQVksS0FBWixFQUNJLElBQUMsQ0FBQSxJQURMLEVBRUksSUFBQyxDQUFBLElBRkwsRUFHSSxJQUFDLENBQUEsSUFITCxFQUlJLElBQUMsQ0FBQSxLQUpMLEVBS0ksSUFBQyxDQUFBLGVBQUQsQ0FBaUIsS0FBakIsQ0FMSixDQU1DLENBQUMsSUFORixDQU1PLEVBTlAsQ0FBTixDQUFBO0FBUUEsV0FBTyxHQUFQLENBVE87RUFBQSxDQTdFVCxDQUFBOztBQUFBLGlCQXlGQSxlQUFBLEdBQWlCLFNBQUMsS0FBRCxHQUFBO0FBRWYsUUFBQSxlQUFBO0FBQUEsSUFBQSxHQUFBLEdBQU0sa0JBQUEsQ0FBbUIsS0FBbkIsQ0FBTixDQUFBO0FBQ0EsU0FBQSxrQkFBQTs4QkFBQTtBQUNFLE1BQUEsR0FBQSxHQUFNLEdBQUcsQ0FBQyxPQUFKLENBQVksSUFBWixFQUFrQixrQkFBQSxDQUFtQixJQUFuQixDQUFsQixDQUFOLENBREY7QUFBQSxLQURBO0FBR0EsV0FBTyxHQUFQLENBTGU7RUFBQSxDQXpGakIsQ0FBQTs7QUFBQSxpQkFnR0EsWUFBQSxHQUFjLFNBQUMsR0FBRCxHQUFBO1dBQ1osT0FBTyxDQUFDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCLEdBQXJCLEVBRFk7RUFBQSxDQWhHZCxDQUFBOztBQW1HQTtBQUFBOztLQW5HQTs7QUFBQSxpQkFzR0EsZUFBQSxHQUFpQixTQUFDLFVBQUQsR0FBQTtBQUNmLElBQUEsSUFBRyxVQUFIO2FBQ0UsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFaLENBQXdCLElBQXhCLEVBQThCLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLEdBQUQsR0FBQTtpQkFDNUIsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFaLENBQXdCLEdBQUcsQ0FBQyxFQUE1QixFQUFnQztBQUFBLFlBQzlCLE1BQUEsRUFBUSxLQUFDLENBQUEsV0FBRCxDQUFhLFVBQWIsQ0FEc0I7QUFBQSxZQUU5QixJQUFBLEVBQU0sVUFBVSxDQUFDLFNBRmE7QUFBQSxZQUc5QixPQUFBLEVBQVMsQ0FBQSxVQUFXLENBQUMsU0FBUyxDQUFDLFFBQXJCLENBQThCLGVBQTlCLENBSG9CO1dBQWhDLEVBRDRCO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBOUIsRUFERjtLQURlO0VBQUEsQ0F0R2pCLENBQUE7O0FBQUEsaUJBZ0hBLFdBQUEsR0FBYSxTQUFDLFVBQUQsR0FBQTtBQUNYLFFBQUEsSUFBQTtBQUFBLElBQUEsaUVBQW1CLENBQUUseUJBQWxCLEtBQTRCLENBQS9CO2FBQ0UsZ0JBREY7S0FBQSxNQUFBO2FBR0UsZUFIRjtLQURXO0VBQUEsQ0FoSGIsQ0FBQTs7QUFzSEE7QUFBQTs7S0F0SEE7O0FBQUEsaUJBeUhBLEtBQUEsR0FBTyxTQUFDLFFBQUQsRUFBVyxNQUFYLEVBQW1CLFNBQW5CLEdBQUE7QUFDSCxRQUFBLGFBQUE7O01BRHNCLFlBQVk7S0FDbEM7QUFBQSxJQUFBLEdBQUEsR0FBTSxJQUFDLENBQUEsWUFBRCxDQUFjLFFBQWQsQ0FBTixDQUFBO0FBQUEsSUFDQSxRQUFBLEdBQVcsSUFBQyxDQUFBLFlBQUQsQ0FBYyxHQUFkLENBRFgsQ0FBQTtBQUVBLElBQUEsSUFBRyxRQUFIO0FBQ0UsTUFBQSxTQUFBLEdBQVksUUFBUSxDQUFDLGFBQVQsQ0FBdUIsc0JBQXZCLENBQVosQ0FBQTtBQUNBLE1BQUEsSUFBRyxTQUFIO0FBQ0UsUUFBQSxTQUFTLENBQUMsU0FBVixHQUFzQixJQUFDLENBQUEsV0FBdkIsQ0FBQTtBQUFBLFFBQ0EsU0FBUyxDQUFDLFlBQVYsQ0FBdUIsYUFBdkIsRUFBc0MsR0FBdEMsQ0FEQSxDQUFBO0FBQUEsUUFFQSxJQUFDLENBQUEsU0FBRCxDQUFXLFNBQVgsQ0FGQSxDQUFBO0FBQUEsUUFHQSxJQUFDLENBQUEsUUFBRCxDQUFVLFNBQVYsQ0FIQSxDQURGO09BQUEsTUFLSyxJQUFHLENBQUEsTUFBSDtBQUNILFFBQUEsU0FBQSxHQUFZLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCLENBQVosQ0FBQTtBQUFBLFFBQ0EsU0FBUyxDQUFDLFNBQVYsR0FBc0IsZUFEdEIsQ0FBQTtBQUFBLFFBRUEsU0FBUyxDQUFDLFNBQVYsR0FBc0Isb0NBRnRCLENBREc7T0FQUDtLQUZBO0FBY0EsV0FBTyxTQUFQLENBZkc7RUFBQSxDQXpIUCxDQUFBOztBQTBJQTtBQUFBOztLQTFJQTs7QUFBQSxpQkE2SUEsWUFBQSxHQUFjLFNBQUMsQ0FBRCxHQUFBO0FBQ1osUUFBQSxlQUFBO0FBQUEsSUFBQSxHQUFBLEdBQU0sUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBTixDQUFBO0FBQUEsSUFDQSxHQUFHLENBQUMsU0FBSixHQUFnQixDQURoQixDQUFBO0FBQUEsSUFFQSxPQUFBLEdBQVUsR0FBRyxDQUFDLG9CQUFKLENBQXlCLFFBQXpCLENBRlYsQ0FBQTtBQUFBLElBR0EsQ0FBQSxHQUFJLE9BQU8sQ0FBQyxNQUhaLENBQUE7QUFJQSxXQUFNLENBQUEsRUFBTixHQUFBO0FBQ0UsTUFBQSxPQUFRLENBQUEsQ0FBQSxDQUFFLENBQUMsVUFBVSxDQUFDLFdBQXRCLENBQWtDLE9BQVEsQ0FBQSxDQUFBLENBQTFDLENBQUEsQ0FERjtJQUFBLENBSkE7QUFNQSxXQUFPLEdBQUcsQ0FBQyxTQUFYLENBUFk7RUFBQSxDQTdJZCxDQUFBOztBQUFBLGlCQXNKQSxZQUFBLEdBQWMsU0FBQyxHQUFELEVBQU0sUUFBTixHQUFBO0FBQ1osUUFBQSxHQUFBOztNQURrQixXQUFXO0tBQzdCO0FBQUEsSUFBQSxHQUFBLEdBQU0sUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBTixDQUFBO0FBQUEsSUFDQSxHQUFHLENBQUMsU0FBSixHQUFnQixHQURoQixDQUFBO0FBQUEsSUFFQSxRQUFBLEdBQVcsUUFBUSxDQUFDLHNCQUFULENBQUEsQ0FGWCxDQUFBO0FBR0EsV0FBUSxHQUFHLENBQUMsVUFBWixHQUFBO0FBQ0UsTUFBQSxRQUFRLENBQUMsV0FBVCxDQUFzQixHQUFHLENBQUMsVUFBMUIsQ0FBQSxDQURGO0lBQUEsQ0FIQTtBQUtBLFdBQU8sUUFBUCxDQU5ZO0VBQUEsQ0F0SmQsQ0FBQTs7QUFBQSxpQkE4SkEsU0FBQSxHQUFXLFNBQUMsUUFBRCxHQUFBOztNQUFDLFdBQVM7S0FDbkI7QUFBQSxJQUFBLElBQUksQ0FBQyxNQUFMLENBQVksUUFBWixFQUFzQixLQUF0QixFQUE2QixLQUE3QixDQUFBLENBQUE7QUFDQSxXQUFPLFFBQVAsQ0FGUztFQUFBLENBOUpYLENBQUE7O0FBQUEsaUJBa0tBLFFBQUEsR0FBVSxTQUFDLFFBQUQsR0FBQTs7TUFBQyxXQUFTO0tBQ2xCO0FBQUEsSUFBQSxJQUFJLENBQUMsTUFBTCxDQUFZLFFBQVosRUFBc0IsR0FBdEIsRUFBMkIsTUFBM0IsQ0FBQSxDQUFBO0FBQ0EsV0FBTyxRQUFQLENBRlE7RUFBQSxDQWxLVixDQUFBOztBQUFBLGlCQXNLQSxNQUFBLEdBQVEsU0FBQyxRQUFELEVBQWdCLEdBQWhCLEVBQXFCLElBQXJCLEdBQUE7QUFDTixRQUFBLGdDQUFBOztNQURPLFdBQVM7S0FDaEI7QUFBQSxJQUFBLElBQUcsUUFBSDtBQUNFLE1BQUEsSUFBQSxHQUFRLFFBQVEsQ0FBQyxnQkFBVCxDQUEwQixHQUExQixDQUFSLENBQUE7QUFBQSxNQUNBLE1BQUEsR0FBUyxRQUFRLENBQUMsYUFBVCxDQUF1QixHQUF2QixDQURULENBQUE7QUFFQTtXQUFBLDJDQUFBO3VCQUFBO0FBQ0UsUUFBQSxNQUFNLENBQUMsSUFBUCxHQUFjLEdBQUksQ0FBQSxJQUFBLENBQWxCLENBQUE7QUFBQSxRQUNBLE1BQU0sQ0FBQyxJQUFQLEdBQWMsSUFBQyxDQUFBLElBRGYsQ0FBQTtBQUFBLFFBRUEsTUFBTSxDQUFDLFFBQVAsR0FBa0IsSUFBQyxDQUFBLFFBRm5CLENBQUE7QUFJQSxRQUFBLElBQUcsR0FBRyxDQUFDLE9BQUosS0FBZSxHQUFsQjtBQUNFLFVBQUEsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFkLENBQWtCLFVBQWxCLENBQUEsQ0FBQTtBQUNBLFVBQUEsSUFBRyxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQWhCLENBQXdCLE9BQXhCLENBQUEsS0FBc0MsQ0FBQSxDQUF6QztBQUNFLFlBQUEsTUFBTSxDQUFDLFFBQVAsR0FBa0IsSUFBQSxHQUFPLE1BQU0sQ0FBQyxRQUFoQyxDQUFBO0FBQUEsWUFDQSxHQUFHLENBQUMsWUFBSixDQUFpQixRQUFqQixFQUEyQixRQUEzQixDQURBLENBREY7V0FGRjtTQUFBLE1BS0ssSUFBRyxHQUFHLENBQUMsT0FBSixLQUFlLEtBQWxCO0FBQ0gsVUFBQSxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQWQsQ0FBa0IsU0FBbEIsQ0FBQSxDQURHO1NBVEw7QUFBQSxzQkFZQSxHQUFHLENBQUMsWUFBSixDQUFpQixJQUFqQixFQUF1QixNQUFNLENBQUMsSUFBOUIsRUFaQSxDQURGO0FBQUE7c0JBSEY7S0FETTtFQUFBLENBdEtSLENBQUE7O2NBQUE7O0lBaEJGLENBQUE7O0FBQUEsTUEyTU0sQ0FBQyxPQUFQLEdBQWlCLEdBQUEsQ0FBQSxJQTNNakIsQ0FBQTs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpfXZhciBmPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChmLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGYsZi5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCJ2YXIgQ0hBUl9DT0RFUyA9IHtcbiAgLy8gdHVya2lzaGRpY3Rpb25hcnkgY29kaW5nc1xuICAnJUM0JUIxJzogJyVGRCcsIC8vxLEgKExvd2VyY2FzZSBpLWRvdGxlc3MpICBhY3R1YWxseSBpdCBpcyAmIzMwNTsgYnV0IHR1cmtpc2hkaWN0aW9uYXJ5IG5lZWQgaXQgdGhpcyB3YXkgXG4gICclQzUlOUYnOiAnJUZFJywgLy/Fn1xuICAnJUM0JTlGJzogJyVGMCcsIC8vxJ8gIChzaWxlbnQgY2hhcmFjdGVyKVxuICAnJUMzJUE3JzogJyVFNycsIC8vw6dcbiAgJyVDMyVCNic6ICclRjYnLCAvL8O2XG4gICclQzMlQkMnOiAnJUZDJywgLy/DvFxuICAnJUMzJUEyJzogJyVFMicgLy8gw6Jcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBDSEFSX0NPREVTOyIsIi8qXHIgIE11bHRpdHJhbiBkZXBlbmRzIG9uIGh0bWwtZXNjYXBpbmcgKG5vdCBVVEYtOCkgcnVsZXMgZm9yIHNwZWNpYWwgc3ltYm9sc1xyICDDoCwgw6gsIMOsLCDDsiwgw7kgLSDDgCwgw4gsIMOMLCDDkiwgw5lcciAgw6EsIMOpLCDDrSwgw7MsIMO6LCDDvSAtIMOBLCDDiSwgw40sIMOTLCDDmiwgw51cciAgw6IsIMOqLCDDriwgw7QsIMO7IMOCLCDDiiwgw44sIMOULCDDm1xyICDDoywgw7EsIMO1IMODLCDDkSwgw5VcciAgw6QsIMOrLCDDrywgw7YsIMO8LCDDvyDDhCwgw4ssIMOPLCDDliwgw5wsXHIgIMOlLCDDhVxyICDDpiwgw4ZcciAgw6csIMOHXHIgIMOwLCDDkFxyICDDuCwgw5hcciAgwr8gwqEgw59cciovXHJ2YXIgQ0hBUl9DT0RFUyA9IHtcciAgJyVDMyU4MCc6ICcmIzE5MjsnLCAvLyDDgFxyICAnJUMzJTgxJzogJyYjMTkzOycsIC8vIMOBXHIgICclQzMlODInOiAnJiMxOTQ7JywgLy8gw4JcciAgJyVDMyU4Myc6ICcmIzE5NTsnLCAvLyDDg1xyICAnJUMzJTg0JzogJyYjMTk2OycsIC8vIMOEXHIgICclQzMlODUnOiAnJiMxOTc7JywgLy8gw4VcciAgJyVDMyU4Nic6ICcmIzE5ODsnLCAvLyDDhlxyXHIgICclQzMlODcnOiAnJiMxOTk7JywgLy8gw4dcciAgJyVDMyU4OCc6ICcmIzIwMDsnLCAvLyDDiFxyICAnJUMzJTg5JzogJyYjMjAxOycsIC8vIMOJXHIgICclQzMlOEEnOiAnJiMyMDI7JywgLy8gw4pcciAgJyVDMyU4Qic6ICcmIzIwMzsnLCAvLyDDi1xyXHIgICclQzMlOEMnOiAnJiMyMDQ7JywgLy8gw4xcciAgJyVDMyU4RCc6ICcmIzIwNTsnLCAvLyDDjVxyICAnJUMzJThFJzogJyYjMjA2OycsIC8vIMOOXHIgICclQzMlOEYnOiAnJiMyMDc7JywgLy8gw49cclxyICAnJUMzJTkxJzogJyYjMjA5OycsIC8vIMORXHIgICclQzMlOTInOiAnJiMyMTA7JywgLy8gw5JcciAgJyVDMyU5Myc6ICcmIzIxMTsnLCAvLyDDk1xyICAnJUMzJTk0JzogJyYjMjEyOycsIC8vIMOUXHIgICclQzMlOTUnOiAnJiMyMTM7JywgLy8gw5VcciAgJyVDMyU5Nic6ICcmIzIxNDsnLCAvLyDDllxyXHIgICclQzMlOTknOiAnJiMyMTc7JywgLy8gw5lcciAgJyVDMyU5QSc6ICcmIzIxODsnLCAvLyDDmlxyICAnJUMzJTlCJzogJyYjMjE5OycsIC8vIMObXHIgICclQzMlOUMnOiAnJiMyMjA7JywgLy8gw5xcclxyXHIgICclQzMlQTAnOiAnJiMyMjQ7JywgLy8gw6BcciAgJyVDMyVBMSc6ICcmIzIyNTsnLCAvLyDDoVxyICAnJUMzJUEyJzogJyYjMjI2OycsIC8vIMOiXHIgICclQzMlQTMnOiAnJiMyMjc7JywgLy8gw6NcciAgJyVDMyVBNCc6ICcmIzIyODsnLCAvLyDDpFxyICAnJUMzJUE1JzogJyYjMjI5OycsIC8vIMOlXHIgICclQzMlQTYnOiAnJiMyMzA7JywgLy8gw6ZcciAgJyVDMyVBNyc6ICcmIzIzMTsnLCAvLyDDp1xyXHJcciAgJyVDMyVBOCc6ICcmIzIzMjsnLCAvLyDDqFxyICAnJUMzJUE5JzogJyYjMjMzOycsIC8vIMOpXHIgICclQzMlQUEnOiAnJiMyMzQ7JywgLy8gw6pcciAgJyVDMyVBQic6ICcmIzIzNTsnLCAvLyDDq1xyXHIgICclQzMlQUMnOiAnJiMyMzY7JywgLy8gw6xcciAgJyVDMyVBRCc6ICcmIzIzNzsnLCAvLyDDrVxyICAnJUMzJUFFJzogJyYjMjM4OycsIC8vIMOuXHIgICclQzMlQUYnOiAnJiMyMzk7JywgLy8gw69cclxyICAnJUMzJUIwJzogJyYjMjQwOycsIC8vIMOwXHIgICclQzMlQjEnOiAnJiMyNDE7JywgLy8gw7FcclxyICAnJUMzJUIyJzogJyYjMjQyOycsIC8vIMOyXHIgICclQzMlQjMnOiAnJiMyNDM7JywgLy8gw7NcciAgJyVDMyVCNCc6ICcmIzI0NDsnLCAvLyDDtFxyICAnJUMzJUI1JzogJyYjMjQ1OycsIC8vIMO1XHIgICclQzMlQjYnOiAnJiMyNDY7JywgLy8gw7ZcclxyICAnJUMzJUI5JzogJyYjMjQ5OycsIC8vIMO5XHIgICclQzMlQkEnOiAnJiMyNTA7JywgLy8gw7pcciAgJyVDMyVCQic6ICcmIzI1MTsnLCAvLyDDu1xyICAnJUMzJUJDJzogJyYjMjUyOycsIC8vIMO8XHIgICclQzMlQkYnOiAnJiMyNTU7JywgLy8gw79cciAgJyVDNSVCOCc6ICcmIzM3NjsnLCAvLyDFuFxyXHIgICclQzMlOUYnOiAnJiMyMjM7JywgLy8gw59cclxyICAnJUMyJUJGJzogJyYjMTkxOycsIC8vIMK/XHIgICclQzIlQTEnOiAnJiMxNjE7JywgLy8gwqFccn07XHJccm1vZHVsZS5leHBvcnRzID0gQ0hBUl9DT0RFUztcciIsIiMjI1xuICBEcm9wZG93biBsYW5ndWFnZSBtZW51XG4gIEBwYXJhbSBvcHRzIHRha2VzIGVsZW1lbnQgYW5kIG9uU2VsZWN0IGhhbmRsZXJcbiAgZXhhbXBsZTpcbiAgbmV3IERyb3Bkb3duKHtcbiAgIGVsOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnI21lbnUnKTtcbiAgIG9uU2VsZWN0OiBmdW5jdGlvbiAoKSB7fVxuICB9KVxuIyMjXG5MQU5HX0NPREUgPVxuICAnMSc6ICdFbmcnXG4gICcyJzogJ1J1cydcbiAgJzMnOiAnR2VyJ1xuICAnNCc6ICdGcmUnXG4gICc1JzogJ1NwYSdcbiAgJzIzJzogJ0l0YSdcbiAgJzI0JzogJ0R1dCdcbiAgJzI2JzogJ0VzdCdcbiAgJzI3JzogJ0xhdidcbiAgJzMxJzogJ0FmcidcbiAgJzM0JzogJ0VwbydcbiAgJzM1JzogJ1hhbCcsXG4gICcxMDAwJzogJ1R1cidcblxuRElDVF9DT0RFID1cbiAgJzEnOiAnbXVsdGl0cmFuJ1xuICAnMTAwMCc6ICd0dXJraXNoJ1xuXG5jbGFzcyBEcm9wZG93blxuICBjb25zdHJ1Y3RvcjogKG9wdHMpIC0+XG4gICAgQGVsID0gb3B0cy5lbCBvciBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICAgICMgb25TZWxlY3QgaGFuZGxlciBzZXQgYnkgYWdncmVnYXRlIGNsYXNzXG4gICAgQG9uU2VsZWN0ID0gb3B0cy5vblNlbGVjdFxuXG4gICAgQG1lbnUgPSBAZWwucXVlcnlTZWxlY3RvcignLmRyb3Bkb3duLW1lbnUnKVxuICAgIGlmIEBtZW51XG4gICAgICBAbWVudS5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnXG4gICAgICBAaXRlbXMgPSBAbWVudS5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCdsYW5ndWFnZS10eXBlJylcbiAgICAgIEBidXR0b24gPSBAZWwucXVlcnlTZWxlY3RvcignLmRyb3Bkb3duLXRvZ2dsZScpXG4gICAgICBAYWRkTGlzdGVuZXJzKClcbiAgICAgIEBpbml0TGFuZ3VhZ2UoKVxuXG4gIGFkZExpc3RlbmVyczogLT5cbiAgICBAYnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIgJ2NsaWNrJywgKGUpID0+IEB0b2dnbGUoZSlcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyICdjbGljaycsIChlKSA9PiBAaGlkZShlKVxuICAgIEBtZW51LmFkZEV2ZW50TGlzdGVuZXIgJ2NsaWNrJywgKGUpID0+IEBjaG9vc2UoZSlcblxuICAjIE9uIGluaXQgdHJ5aW5nIHRvIGdldCBjdXJyZW50IGxhbmd1YWdlIGZyb20gc3RvcmFnZSBvciB1c2luZyBkZWZhdWx0KCAxOmVuZ2xpc2gpXG4gIGluaXRMYW5ndWFnZTogLT5cbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7IGxhbmd1YWdlOiAnMSd9LCAoc3RvcmUpID0+XG4gICAgICBAc2V0VGl0bGUoc3RvcmUubGFuZ3VhZ2UpO1xuICAgIClcblxuICB0b2dnbGU6IChlKSAtPlxuICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcbiAgICBAc2V0QWN0aXZlSXRlbSgpXG4gICAgaWYgQG1lbnUgYW5kIEBtZW51LnN0eWxlLmRpc3BsYXkgaXMgJ25vbmUnXG4gICAgICBAc2hvdygpXG4gICAgZWxzZVxuICAgICAgQGhpZGUoKVxuXG4gICMgUmVhZCBjdXJyZW50IGxhbmd1YWdlIGZyb20gQ2hyb21lIFN0b3JhZ2UgYW5kIGNvbG9yIGFjdGl2ZSBsaW5lXG4gIHNldEFjdGl2ZUl0ZW06IC0+XG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQge2xhbmd1YWdlOiAnMSd9LCAoc3RvcmUpID0+XG4gICAgICBmb3IgaXRlbSBpbiBAaXRlbXNcbiAgICAgICAgaWYgaXRlbS5nZXRBdHRyaWJ1dGUoJ2RhdGEtdmFsJykgPT0gc3RvcmUubGFuZ3VhZ2VcbiAgICAgICAgICBpdGVtLmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpXG4gICAgICAgIGVsc2VcbiAgICAgICAgICBpdGVtLmNsYXNzTGlzdC5yZW1vdmUoJ2FjdGl2ZScpXG5cbiAgaGlkZTogLT5cbiAgICBAbWVudS5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnXG5cbiAgc2hvdzogLT5cbiAgICBAbWVudS5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJ1xuXG4gICMgU2F2ZXMgY2hvc2VuIGxhbmd1YWdlIHRvIGNocm9tZS5zdG9yYWdlIGFuZCBkZWNpZGUgd2hpY2ggZGljdGlvbmFyeSB0byB1c2VcbiAgIyBUaGVuIGNhbGxlZCBvblNlbGVjdCBoYW5kbGVyIG9mIHRoZSBjb250YWluZXIgY2xhc3NcbiAgY2hvb3NlOiAoZSkgLT5cbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgbGFuZ3VhZ2UgPSBlLnRhcmdldC5nZXRBdHRyaWJ1dGUoJ2RhdGEtdmFsJylcbiAgICBkaWN0aW9uYXJ5ID0gQGdldERpY3Rpb25hcnkobGFuZ3VhZ2UpXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5zZXQoe2xhbmd1YWdlOiBsYW5ndWFnZSwgZGljdGlvbmFyeTogZGljdGlvbmFyeX0sIEBvblNlbGVjdClcbiAgICBAc2V0VGl0bGUobGFuZ3VhZ2UpXG4gICAgQGhpZGUoKVxuXG4gICMgU29tZSBsYW5ndWFnZXMgYXJlIG5vdCBwcmVzZW50IGluIG11bHRpdHJhbiAoZS5nLiB0dXJraXNoKVxuICAjIHNvIHdlIGNob29zZSBhbm90aGVyIHNlcnZpY2VcbiAgZ2V0RGljdGlvbmFyeTogKGxhbmcpIC0+XG4gICAgY29uc29sZS5sb2coJ2Nob29zZSBkaWN0OiBmb3InLGxhbmcpO1xuICAgIGRpY3QgPSBESUNUX0NPREVbbGFuZ10gfHwgJ211bHRpdHJhbidcbiAgICBjb25zb2xlLmxvZygnZGljdCcsZGljdClcbiAgICByZXR1cm4gZGljdFxuXG4gICNTZXQgY3VycmVudCBsYW5ndWFnZSBsYWJlbFxuICBzZXRUaXRsZTogKGxhbmd1YWdlKSAtPlxuICAgIGh0bWwgPSBMQU5HX0NPREVbbGFuZ3VhZ2VdICsgJyA8c3BhbiBjbGFzcz1cImNhcmV0XCI+PC9zcGFuPidcbiAgICBAYnV0dG9uLmlubmVySFRNTCA9IGh0bWxcblxuXG5tb2R1bGUuZXhwb3J0cyA9IERyb3Bkb3duIiwiIyMjXG4gIEV4dGVuc2lvbiBwb3B1cCB3aW5kb3dcbiAgU2hvd3Mgc2VhcmNoIGZvcm0gYW5kIGRyb3Bkb3duIG1lbnUgd2l0aCBsYW5ndWFnZXNcbiMjI1xuU2VhcmNoRm9ybSA9IHJlcXVpcmUoJy4vc2VhcmNoX2Zvcm0uY29mZmVlJylcblxuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lciBcIkRPTUNvbnRlbnRMb2FkZWRcIiwgLT5cbiAgZm9ybSA9IG5ldyBTZWFyY2hGb3JtIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0cmFuLWZvcm0nKVxuICBsaW5rID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2hlYWRlci1saW5rJylcbiAgaWYgbGlua1xuICAgIGxpbmsuYWRkRXZlbnRMaXN0ZW5lciAnY2xpY2snLCAoZSkgLT5cbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGhyZWYgPSBlLnRhcmdldC5nZXRBdHRyaWJ1dGUoJ2hyZWYnKSArIGZvcm0uZ2V0VmFsdWUoKVxuICAgICAgY2hyb21lLnRhYnMuY3JlYXRlKHsgdXJsOiBocmVmIH0pXG4iLCIjIyNcbiAgU2VydmVzIHNlYXJjaCBpbnB1dCBhbmQgZm9ybVxuXG4gIEBwYXJhbSBmb3JtIERPTSBlbGVtbnRcbiAgQGNvbnN0cnVjdG9yXG4jIyNcbkRyb3Bkb3duID0gcmVxdWlyZSgnLi9kcm9wZG93bi5jb2ZmZWUnKVxuXG4jdHJhbnNsYXRlIGVuZ2luZXNcbnRyYW4gPSByZXF1aXJlKCcuLi90cmFuLmNvZmZlZScpXG50dXJraXNoZGljdGlvbmFyeSA9IHJlcXVpcmUoJy4uL3R1cmtpc2hkaWN0aW9uYXJ5LmpzJylcblxuXG4jVHJhbnNsYXRlIGVuZ2luZXNcblRSQU5TTEFURV9FTkdJTkVTID1cbiAgJ211bHRpdHJhbic6IHRyYW5cbiAgJ3R1cmtpc2gnOiB0dXJraXNoZGljdGlvbmFyeVxuXG5jbGFzcyBTZWFyY2hGb3JtXG4gIGNvbnN0cnVjdG9yOiAoQGZvcm0pIC0+XG4gICAgQGlucHV0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RyYW5zbGF0ZS10eHQnKVxuICAgIEBpbnB1dC5mb2N1cygpXG5cbiAgICBAcmVzdWx0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jlc3VsdCcpXG4gICAgQGFkZExpc3RlbmVycygpO1xuICAgIEBkcm9wZG93biA9IG5ldyBEcm9wZG93bih7XG4gICAgICBlbDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmRyb3Bkb3duLWVsJyksXG4gICAgICBvblNlbGVjdDogPT4gQHNlYXJjaCgpXG4gICAgfSk7XG5cbiAgYWRkTGlzdGVuZXJzOiAtPlxuICAgIGlmIEBmb3JtIGFuZCBAcmVzdWx0XG4gICAgICBAZm9ybS5hZGRFdmVudExpc3RlbmVyICdzdWJtaXQnLCAoZSkgPT4gQHNlYXJjaChlKVxuICAgICAgQHJlc3VsdC5hZGRFdmVudExpc3RlbmVyICdjbGljaycsIChlKSA9PiBAcmVzdWx0Q2xpY2tIYW5kbGVyKGUpXG5cbiAgc2VhcmNoOiAoZSkgLT5cbiAgICBlICYmIGUucHJldmVudERlZmF1bHQgJiYgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgaWYgQGlucHV0LnZhbHVlLmxlbmd0aCA+IDBcbiAgICAgICNjaG9vc2UgZW5naW5lIGFuZCBzZWFyY2ggZm9yIHRyYW5zbGF0aW9uIChieSBkZWZhdWx0IGVuZ2xpc2gtbXVsdGl0cmFuKVxuICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoe2xhbmd1YWdlOiAnMScsIGRpY3Rpb25hcnk6ICdtdWx0aXRyYW4nfSwgKGl0ZW1zKSA9PlxuICAgICAgICBjb25zb2xlLmxvZygnSVRFTVM6JywgaXRlbXMpO1xuICAgICAgICBUUkFOU0xBVEVfRU5HSU5FU1tpdGVtcy5kaWN0aW9uYXJ5XS5zZWFyY2hcbiAgICAgICAgICB2YWx1ZTogQGlucHV0LnZhbHVlXG4gICAgICAgICAgc3VjY2VzczogQHN1Y2Nlc3NIYW5kbGVyLmJpbmQoQClcbiAgICAgIClcblxuICBzdWNjZXNzSGFuZGxlcjogKHJlc3BvbnNlKSAtPlxuICAgICAgQGNsZWFuKEByZXN1bHQpXG4gICAgICBAcmVzdWx0LmFwcGVuZENoaWxkKHJlc3BvbnNlKVxuXG4gIGNsZWFuOiAoZWwpIC0+XG4gICAgd2hpbGUgKGVsLmxhc3RDaGlsZClcbiAgICAgIGVsLnJlbW92ZUNoaWxkKGVsLmxhc3RDaGlsZClcblxuICByZXN1bHRDbGlja0hhbmRsZXI6IChlKSAtPlxuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBsaW5rVGFncyA9IFsnQScsICdhJ11cbiAgICBpZiBlLnRhcmdldC50YWdOYW1lIGluIGxpbmtUYWdzXG4gICAgICBAaW5wdXQudmFsdWUgPSBlLnRhcmdldC5pbm5lclRleHQ7XG4gICAgICBAc2VhcmNoKGUpXG5cbiAgZ2V0VmFsdWU6IC0+XG4gICAgcmV0dXJuIEBpbnB1dC52YWx1ZVxuXG4gICMgaW5wdXRIYW5kbGVyOiAoZSkgLT5cbiAgIyAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHtsYW5ndWFnZTogJzEnLCBkaWN0aW9uYXJ5OiAnbXVsdGl0cmFuJ30sIChpdGVtcykgPT5cbiAgIyAgICAgVFJBTlNMQVRFX0VOR0lORVNbaXRlbXMuZGljdGlvbmFyeV0ucmVxdWVzdFxuICAjICAgICAgIHZhbHVlOiBAaW5wdXQudmFsdWVcbiAgIyAgICAgICBzdWNjZXNzOiBAc3VjY2Vzc0hhbmRsZXIuYmluZChAKVxuICAjICAgICAgIGVycm9yOiBwYXJhbXMuZXJyb3JcbiAgIyAgIClcbiAgICAjIHZhbHVlID0gQGlucHV0LnZhbHVlXG4gICAgIyB0cmFuLnJlcXVlc3QoXG4gICAgIyAgIHVybDogdXJsLFxuICAgICMgICBzdWNjZXNzOiBwYXJhbXMuc3VjY2VzcyxcbiAgICAjICAgZXJyb3I6IHBhcmFtcy5lcnJvclxuICAgICMgKVxuXG5cblxubW9kdWxlLmV4cG9ydHMgPSBTZWFyY2hGb3JtXG4iLCIjIyNnbG9iYWwgY2hyb21lIyMjXG4jIyNcbiAgTXVsdGl0cmFuLnJ1IHRyYW5zbGF0ZSBlbmdpbmVcbiAgUHJvdmlkZXMgcHJvZ3JhbSBpbnRlcmZhY2UgZm9yIG1ha2luZyB0cmFuc2xhdGUgcXVlcmllcyB0byBtdWx0aXRyYW4gYW5kIGdldCBjbGVhbiByZXNwb25zZVxuXG4gIEFsbCBlbmdpbmVzIG11c3QgZm9sbG93IGNvbW1vbiBpbnRlcmZhY2UgYW5kIHByb3ZpZGUgbWV0aG9kczpcbiAgICAtIHNlYXJjaCAobGFuZ3VhbmdlLCBzdWNjZXNzSGFuZGxlcikgIGNsZWFuIHRyYW5zbGF0aW9uIG11c3QgYmUgcGFzc2VkIGludG8gc3VjY2Vzc0hhbmRsZXJcbiAgICAtIGNsaWNrXG5cbiAgVHJhbnNsYXRpb24tbW9kdWxlIHRoYXQgbWFrZXMgcmVxdWVzdHMgdG8gbGFuZ3VhZ2UtZW5naW5lLFxuICBwYXJzZXMgcmVzdWx0cyBhbmQgc2VuZHMgcGx1Z2luLWdsb2JhbCBtZXNzYWdlIHdpdGggdHJhbnNsYXRpb24gZGF0YVxuIyMjXG5cbkNIQVJfQ09ERVMgPSByZXF1aXJlKCcuL2NoYXItY29kZXMuanMnKTtcblxuY2xhc3MgVHJhblxuICBjb25zdHJ1Y3RvcjogLT5cbiAgICBAVEFCTEVfQ0xBU1MgPSBcIl9fX210dF90cmFuc2xhdGVfdGFibGVcIlxuICAgIEBwcm90b2NvbCA9ICdodHRwJ1xuICAgIEBob3N0ID0gJ3d3dy5tdWx0aXRyYW4ucnUnXG4gICAgQHBhdGggPSAnL2MvbS5leGUnXG4gICAgQHF1ZXJ5ID0gJyZzPSdcbiAgICBAbGFuZyA9ICc/bDE9MiZsMj0xJyAjZnJvbSBydXNzaWFuIHRvIGVuZ2xpc2ggYnkgZGVmYXVsdFxuICAgIEB4aHIgPSB7fVxuXG4gICMjI1xuICAgIENvbnRleHQgbWVudSBjbGljayBoYW5kbGVyXG4gICMjI1xuICBjbGljazogKGRhdGEpIC0+XG4gICAgaWYgdHlwZW9mIGRhdGEuc2lsZW50ID09IHVuZGVmaW5lZCB8fCBkYXRhLnNpbGVudCA9PSBudWxsXG4gICAgICBkYXRhLnNpbGVudCA9IHRydWUgIyB0cnVlIGJ5IGRlZmF1bHRcbiAgICBzZWxlY3Rpb25UZXh0ID0gQHJlbW92ZUh5cGhlbmF0aW9uIGRhdGEuc2VsZWN0aW9uVGV4dFxuICAgIEBzZWFyY2hcbiAgICAgICAgdmFsdWU6IHNlbGVjdGlvblRleHRcbiAgICAgICAgc3VjY2VzczogQHN1Y2Nlc3N0SGFuZGxlci5iaW5kKHRoaXMpXG4gICAgICAgIHNpbGVudDogZGF0YS5zaWxlbnQgICMgaWYgdHJhbnNsYXRpb24gZmFpbGVkIGRvIG5vdCBzaG93IGRpYWxvZ1xuXG4gICMjI1xuICAgIERpc2NhcmQgc29mdCBoeXBoZW4gY2hhcmFjdGVyIChVKzAwQUQsICZzaHk7KSBmcm9tIHRoZSBpbnB1dFxuICAjIyNcbiAgcmVtb3ZlSHlwaGVuYXRpb246ICh0ZXh0KSAtPlxuICAgIHRleHQucmVwbGFjZSAvXFx4YWQvZywgJydcblxuICAjIyNcbiAgICBJbml0aWF0ZSB0cmFuc2xhdGlvbiBzZWFyY2hcbiAgIyMjXG4gIHNlYXJjaDogKHBhcmFtcykgLT5cbiAgICAjdmFsdWUsIGNhbGxiYWNrLCBlcnJcbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7bGFuZ3VhZ2U6ICcxJ30sIChpdGVtcykgPT5cbiAgICAgIGlmIGxhbmd1YWdlIGlzICcnXG4gICAgICAgIGxhbmd1YWdlID0gJzEnXG4gICAgICBAc2V0TGFuZ3VhZ2UoaXRlbXMubGFuZ3VhZ2UpXG4gICAgICB1cmwgPSBAbWFrZVVybChwYXJhbXMudmFsdWUpO1xuICAgICAgIyBkZWNvcmF0ZSBzdWNjZXNzIHRvIG1ha2UgcHJlbGltaW5hcnkgcGFyc2luZ1xuICAgICAgb3JpZ1N1Y2Nlc3MgPSBwYXJhbXMuc3VjY2Vzc1xuICAgICAgcGFyYW1zLnN1Y2Nlc3MgPSAocmVzcG9uc2UpID0+XG4gICAgICAgIHRyYW5zbGF0ZWQgPSBAcGFyc2UocmVzcG9uc2UsIHBhcmFtcy5zaWxlbnQpXG4gICAgICAgIG9yaWdTdWNjZXNzKHRyYW5zbGF0ZWQpXG5cbiAgICAgICMgbWFrZSByZXF1ZXN0IChHRVQgcmVxdWVzdCB3aXRoIHF1ZXJ5IHBhcmFtZXRlcnMgaW4gdXJsKVxuICAgICAgQHJlcXVlc3QoXG4gICAgICAgIHVybDogdXJsLFxuICAgICAgICBzdWNjZXNzOiBwYXJhbXMuc3VjY2VzcyxcbiAgICAgICAgZXJyb3I6IHBhcmFtcy5lcnJvclxuICAgICAgKVxuICAgIClcblxuICBzZXRMYW5ndWFnZTogKGxhbmd1YWdlKSAtPlxuICAgIEBjdXJyZW50TGFuZ3VhZ2UgPSBsYW5ndWFnZVxuICAgIEBsYW5nID0gJz9sMT0yJmwyPScgKyBsYW5ndWFnZVxuXG4gICMjI1xuICAgIFJlcXVlc3QgdHJhbnNsYXRpb24gYW5kIHJ1biBjYWxsYmFjayBmdW5jdGlvblxuICAgIHBhc3NpbmcgdHJhbnNsYXRlZCByZXN1bHQgb3IgZXJyb3IgdG8gY2FsbGJhY2tcbiAgIyMjXG4gIHJlcXVlc3Q6IChvcHRzKSAtPlxuICAgIHhociA9IEB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKVxuICAgIHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSAoZSkgPT5cbiAgICAgIHhociA9IEB4aHJcbiAgICAgIGlmIHhoci5yZWFkeVN0YXRlIDwgNFxuICAgICAgICByZXR1cm5cbiAgICAgIGVsc2UgaWYgeGhyLnN0YXR1cyAhPSAyMDBcbiAgICAgICAgQGVycm9ySGFuZGxlcih4aHIpXG4gICAgICAgIGlmICh0eXBlb2Ygb3B0cy5lcnJvciA9PSAnZnVuY3Rpb24nKVxuICAgICAgICAgIG9wdHMuZXJyb3IoKVxuICAgICAgICByZXR1cm5cbiAgICAgIGVsc2UgaWYgeGhyLnJlYWR5U3RhdGUgPT0gNFxuICAgICAgICAgIHJldHVybiBvcHRzLnN1Y2Nlc3MoZS50YXJnZXQucmVzcG9uc2UpXG5cbiAgICB4aHIub3BlbihcIkdFVFwiLCBvcHRzLnVybCwgdHJ1ZSk7XG4gICAgeGhyLnNlbmQoKTtcblxuXG4gIG1ha2VVcmw6ICh2YWx1ZSkgLT5cbiAgICB1cmwgPSBbQHByb3RvY29sLCAnOi8vJyxcbiAgICAgICAgICAgICAgQGhvc3QsXG4gICAgICAgICAgICAgIEBwYXRoLFxuICAgICAgICAgICAgICBAbGFuZyxcbiAgICAgICAgICAgICAgQHF1ZXJ5LFxuICAgICAgICAgICAgICBAZ2V0RW5jb2RlZFZhbHVlKHZhbHVlKVxuICAgICAgICAgIF0uam9pbignJylcblxuICAgIHJldHVybiB1cmw7XG5cbiAgIyBSZXBsYWNlIHNwZWNpYWwgbGFuZ3VhZ2UgY2hhcmFjdGVycyB0byBodG1sIGNvZGVzXG4gIGdldEVuY29kZWRWYWx1ZTogKHZhbHVlKSAtPlxuICAgICMgdG8gZmluZCBzcGVjIHN5bWJvbHMgd2UgZmlyc3QgZW5jb2RlIHRoZW0gKHJhdyBzZWFyY2ggZm9yIHRoYXQgc3ltYm9sIGRvZXNuJ3Qgd29yKVxuICAgIHZhbCA9IGVuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSlcbiAgICBmb3IgY2hhciwgY29kZSBvZiBDSEFSX0NPREVTXG4gICAgICB2YWwgPSB2YWwucmVwbGFjZShjaGFyLCBlbmNvZGVVUklDb21wb25lbnQoY29kZSkpXG4gICAgcmV0dXJuIHZhbFxuXG4gIGVycm9ySGFuZGxlcjogKHhocikgLT5cbiAgICBjb25zb2xlLmxvZygnZXJyb3InLCB4aHIpXG5cbiAgIyMjXG4gICBSZWNlaXZpbmcgZGF0YSBmcm9tIHRyYW5zbGF0aW9uLWVuZ2luZSBhbmQgc2VuZCByZWFkeSBtZXNzYWdlIHdpdGggZGF0YVxuICAjIyNcbiAgc3VjY2Vzc3RIYW5kbGVyOiAodHJhbnNsYXRlZCkgLT5cbiAgICBpZiB0cmFuc2xhdGVkXG4gICAgICBjaHJvbWUudGFicy5nZXRTZWxlY3RlZChudWxsLCAodGFiKSA9PlxuICAgICAgICBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWIuaWQsIHtcbiAgICAgICAgICBhY3Rpb246IEBtZXNzYWdlVHlwZSB0cmFuc2xhdGVkXG4gICAgICAgICAgZGF0YTogdHJhbnNsYXRlZC5vdXRlckhUTUwsXG4gICAgICAgICAgc3VjY2VzczogIXRyYW5zbGF0ZWQuY2xhc3NMaXN0LmNvbnRhaW5zKCdmYWlsVHJhbnNsYXRlJylcbiAgICAgICAgfSlcbiAgICAgIClcblxuICBtZXNzYWdlVHlwZTogKHRyYW5zbGF0ZWQpIC0+XG4gICAgaWYgdHJhbnNsYXRlZD8ucm93cz8ubGVuZ3RoID09IDFcbiAgICAgICdzaW1pbGFyX3dvcmRzJ1xuICAgIGVsc2VcbiAgICAgICdvcGVuX3Rvb2x0aXAnXG5cbiAgIyMjXG4gICAgUGFyc2UgcmVzcG9uc2UgZnJvbSB0cmFuc2xhdGlvbiBlbmdpbmVcbiAgIyMjXG4gIHBhcnNlOiAocmVzcG9uc2UsIHNpbGVudCwgdHJhbnNsYXRlID0gbnVsbCkgLT5cbiAgICAgIGRvYyA9IEBzdHJpcFNjcmlwdHMocmVzcG9uc2UpXG4gICAgICBmcmFnbWVudCA9IEBtYWtlRnJhZ21lbnQoZG9jKVxuICAgICAgaWYgZnJhZ21lbnRcbiAgICAgICAgdHJhbnNsYXRlID0gZnJhZ21lbnQucXVlcnlTZWxlY3RvcignI3RyYW5zbGF0aW9uIH4gdGFibGUnKVxuICAgICAgICBpZiB0cmFuc2xhdGVcbiAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gQFRBQkxFX0NMQVNTO1xuICAgICAgICAgIHRyYW5zbGF0ZS5zZXRBdHRyaWJ1dGUoXCJjZWxscGFkZGluZ1wiLCBcIjVcIilcbiAgICAgICAgICBAZml4SW1hZ2VzKHRyYW5zbGF0ZSlcbiAgICAgICAgICBAZml4TGlua3ModHJhbnNsYXRlKVxuICAgICAgICBlbHNlIGlmIG5vdCBzaWxlbnRcbiAgICAgICAgICB0cmFuc2xhdGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSAnZmFpbFRyYW5zbGF0ZSdcbiAgICAgICAgICB0cmFuc2xhdGUuaW5uZXJUZXh0ID0gXCJVbmZvcnR1bmF0ZWx5LCBjb3VsZCBub3QgdHJhbnNsYXRlXCJcblxuICAgICAgcmV0dXJuIHRyYW5zbGF0ZTtcblxuICAjIyNcbiAgICBTdHJpcCBzY3JpcHQgdGFncyBmcm9tIHJlc3BvbnNlIGh0bWxcbiAgIyMjXG4gIHN0cmlwU2NyaXB0czogKHMpIC0+XG4gICAgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgICBkaXYuaW5uZXJIVE1MID0gc1xuICAgIHNjcmlwdHMgPSBkaXYuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ3NjcmlwdCcpXG4gICAgaSA9IHNjcmlwdHMubGVuZ3RoXG4gICAgd2hpbGUgaS0tXG4gICAgICBzY3JpcHRzW2ldLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc2NyaXB0c1tpXSlcbiAgICByZXR1cm4gZGl2LmlubmVySFRNTDtcblxuICBtYWtlRnJhZ21lbnQ6IChkb2MsIGZyYWdtZW50ID0gbnVsbCkgLT5cbiAgICBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpXG4gICAgZGl2LmlubmVySFRNTCA9IGRvY1xuICAgIGZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpXG4gICAgd2hpbGUgKCBkaXYuZmlyc3RDaGlsZCApXG4gICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZCggZGl2LmZpcnN0Q2hpbGQgKVxuICAgIHJldHVybiBmcmFnbWVudFxuXG4gIGZpeEltYWdlczogKGZyYWdtZW50PW51bGwpIC0+XG4gICAgdGhpcy5maXhVcmwoZnJhZ21lbnQsICdpbWcnLCAnc3JjJyk7XG4gICAgcmV0dXJuIGZyYWdtZW50O1xuXG4gIGZpeExpbmtzOiAoZnJhZ21lbnQ9bnVsbCkgLT5cbiAgICB0aGlzLmZpeFVybChmcmFnbWVudCwgJ2EnLCAnaHJlZicpXG4gICAgcmV0dXJuIGZyYWdtZW50XG5cbiAgZml4VXJsOiAoZnJhZ21lbnQ9bnVsbCwgdGFnLCBhdHRyKSAtPlxuICAgIGlmIGZyYWdtZW50XG4gICAgICB0YWdzID0gIGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3JBbGwodGFnKVxuICAgICAgcGFyc2VyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpXG4gICAgICBmb3IgdGFnIGluIHRhZ3NcbiAgICAgICAgcGFyc2VyLmhyZWYgPSB0YWdbYXR0cl1cbiAgICAgICAgcGFyc2VyLmhvc3QgPSBAaG9zdFxuICAgICAgICBwYXJzZXIucHJvdG9jb2wgPSBAcHJvdG9jb2xcbiAgICAgICAgI2ZpeCByZWxhdGl2ZSBsaW5rc1xuICAgICAgICBpZiB0YWcudGFnTmFtZSA9PSAnQSdcbiAgICAgICAgICB0YWcuY2xhc3NMaXN0LmFkZCAnbXR0X2xpbmsnXG4gICAgICAgICAgaWYgcGFyc2VyLnBhdGhuYW1lLmluZGV4T2YoJ20uZXhlJykgaXNudCAtMVxuICAgICAgICAgICAgcGFyc2VyLnBhdGhuYW1lID0gJy9jJyArIHBhcnNlci5wYXRobmFtZVxuICAgICAgICAgICAgdGFnLnNldEF0dHJpYnV0ZSgndGFyZ2V0JywgJ19ibGFuaycpXG4gICAgICAgIGVsc2UgaWYgdGFnLnRhZ05hbWUgPT0gJ0lNRydcbiAgICAgICAgICB0YWcuY2xhc3NMaXN0LmFkZCAnbXR0X2ltZydcblxuICAgICAgICB0YWcuc2V0QXR0cmlidXRlKGF0dHIsIHBhcnNlci5ocmVmKVxuXG5cblxubW9kdWxlLmV4cG9ydHMgPSBuZXcgVHJhbiIsIlwidXNlIHN0cmljdFwiO1xuXG52YXIgX3Byb3RvdHlwZVByb3BlcnRpZXMgPSBmdW5jdGlvbiAoY2hpbGQsIHN0YXRpY1Byb3BzLCBpbnN0YW5jZVByb3BzKSB7XG4gIGlmIChzdGF0aWNQcm9wcykgT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoY2hpbGQsIHN0YXRpY1Byb3BzKTtcbiAgaWYgKGluc3RhbmNlUHJvcHMpIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGNoaWxkLnByb3RvdHlwZSwgaW5zdGFuY2VQcm9wcyk7XG59O1xuXG4vKlxuICBUcmFuc2xhdGlvbiBlbmdpbmU6IGh0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0XG4gIEZvciB0cmFuc2xhdGluZyB0dXJraXNoLXJ1c3NpYW4gYW5kIHZpY2UgdmVyc2FcbiovXG52YXIgQ0hBUl9DT0RFUyA9IHJlcXVpcmUoXCIuL2NoYXItY29kZXMtdHVyay5qc1wiKTtcblxudmFyIFR1cmtpc2hEaWN0aW9uYXJ5ID0gKGZ1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gVHVya2lzaERpY3Rpb25hcnkoKSB7XG4gICAgdGhpcy5ob3N0ID0gXCJodHRwOi8vd3d3LnR1cmtpc2hkaWN0aW9uYXJ5Lm5ldC8/d29yZD0lRkNcIjtcbiAgICB0aGlzLnBhdGggPSBcIlwiO1xuICAgIHRoaXMucHJvdG9jb2wgPSBcImh0dHBcIjtcbiAgICB0aGlzLnF1ZXJ5ID0gXCImcz1cIjtcbiAgICB0aGlzLlRBQkxFX0NMQVNTID0gXCJfX19tdHRfdHJhbnNsYXRlX3RhYmxlXCI7XG4gICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSB0cnVlO1xuICB9XG5cbiAgX3Byb3RvdHlwZVByb3BlcnRpZXMoVHVya2lzaERpY3Rpb25hcnksIG51bGwsIHtcbiAgICBzZWFyY2g6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBzZWFyY2goZGF0YSkge1xuICAgICAgICBkYXRhLnVybCA9IHRoaXMubWFrZVVybChkYXRhLnZhbHVlKTtcbiAgICAgICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSBmYWxzZTtcbiAgICAgICAgcmV0dXJuIHRoaXMucmVxdWVzdChkYXRhKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHRyYW5zbGF0ZToge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHRyYW5zbGF0ZShkYXRhKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwicmVxdWVzdCBkYXRhOlwiLCBkYXRhKTtcbiAgICAgICAgZGF0YS51cmwgPSB0aGlzLm1ha2VVcmwoZGF0YS5zZWxlY3Rpb25UZXh0KTtcbiAgICAgICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSB0cnVlO1xuICAgICAgICB0aGlzLnJlcXVlc3QoZGF0YSk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBtYWtlVXJsOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZVVybCh0ZXh0KSB7XG4gICAgICAgIHZhciB0ZXh0ID0gdGhpcy5nZXRFbmNvZGVkVmFsdWUodGV4dCk7XG4gICAgICAgIHJldHVybiBbXCJodHRwOi8vd3d3LnR1cmtpc2hkaWN0aW9uYXJ5Lm5ldC8/d29yZD1cIiwgdGV4dF0uam9pbihcIlwiKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIGdldEVuY29kZWRWYWx1ZToge1xuICAgICAgLy8gUmVwbGFjZSBzcGVjaWFsIGxhbmd1YWdlIGNoYXJhY3RlcnMgdG8gaHRtbCBjb2Rlc1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIGdldEVuY29kZWRWYWx1ZSh2YWx1ZSkge1xuICAgICAgICAvLyB0byBmaW5kIHNwZWMgc3ltYm9scyB3ZSBmaXJzdCBlbmNvZGUgdGhlbSAocmF3IHNlYXJjaCBmb3IgdGhhdCBzeW1ib2wgZG9lc24ndCB3b3IpXG4gICAgICAgIHZhciB2YWwgPSBlbmNvZGVVUklDb21wb25lbnQodmFsdWUpO1xuICAgICAgICBmb3IgKHZhciBjaGFyIGluIENIQVJfQ09ERVMpIHtcbiAgICAgICAgICB2YWwgPSB2YWwucmVwbGFjZShjaGFyLCBDSEFSX0NPREVTW2NoYXJdKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdmFsO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcmVxdWVzdDoge1xuXG4gICAgICAvKlxuICAgICAgICBSZXF1ZXN0IHRyYW5zbGF0aW9uIGFuZCBydW4gY2FsbGJhY2sgZnVuY3Rpb25cbiAgICAgICAgcGFzc2luZyB0cmFuc2xhdGVkIHJlc3VsdCBvciBlcnJvciB0byBjYWxsYmFja1xuICAgICAgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiByZXF1ZXN0KG9wdHMpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJzdGFydCByZXF1ZXN0XCIpO1xuICAgICAgICB0aGlzLnhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgICB0aGlzLnhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSB0aGlzLm9uUmVhZHlTdGF0ZUNoYW5nZS5iaW5kKHRoaXMsIG9wdHMpO1xuICAgICAgICB0aGlzLnhoci5vcGVuKFwiR0VUXCIsIG9wdHMudXJsLCB0cnVlKTtcbiAgICAgICAgdGhpcy54aHIuc2VuZCgpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgb25SZWFkeVN0YXRlQ2hhbmdlOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gb25SZWFkeVN0YXRlQ2hhbmdlKG9wdHMsIGUpIHtcbiAgICAgICAgdmFyIHhociA9IHRoaXMueGhyO1xuICAgICAgICBpZiAoeGhyLnJlYWR5U3RhdGUgPCA0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9IGVsc2UgaWYgKHhoci5zdGF0dXMgIT0gMjAwKSB7XG4gICAgICAgICAgdGhpcy5lcnJvckhhbmRsZXIoeGhyKTtcbiAgICAgICAgICByZXR1cm4gb3B0cy5lcnJvciAmJiBvcHRzLmVycm9yKCk7XG4gICAgICAgIH0gZWxzZSBpZiAoeGhyLnJlYWR5U3RhdGUgPT0gNCkge1xuICAgICAgICAgIHZhciB0cmFuc2xhdGlvbiA9IHRoaXMuc3VjY2Vzc0hhbmRsZXIoZS50YXJnZXQucmVzcG9uc2UpO1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwic3VjY2VzcyB0dXJraXNoIHRyYW5zbGF0ZVwiLCB0cmFuc2xhdGlvbik7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJjYWxsXCIsIG9wdHMuc3VjY2Vzcyk7XG4gICAgICAgICAgcmV0dXJuIG9wdHMuc3VjY2VzcyAmJiBvcHRzLnN1Y2Nlc3ModHJhbnNsYXRpb24pO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBzdWNjZXNzSGFuZGxlcjoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHN1Y2Nlc3NIYW5kbGVyKHJlc3BvbnNlKSB7XG4gICAgICAgIHZhciBkYXRhID0gdGhpcy5wYXJzZShyZXNwb25zZSk7XG4gICAgICAgIGlmICh0aGlzLm5lZWRfcHVibGlzaCkge1xuICAgICAgICAgIGNocm9tZS50YWJzLmdldFNlbGVjdGVkKG51bGwsIHRoaXMucHVibGlzaFRyYW5zbGF0aW9uLmJpbmQodGhpcywgZGF0YSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcHVibGlzaFRyYW5zbGF0aW9uOiB7XG5cbiAgICAgIC8qIHB1Ymxpc2ggc3VjY2Vzc2Z1bHkgdHJhbnNsYXRlZCB0ZXh0IGFsbCBvdmVyIGV4dGVuc2lvbiAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHB1Ymxpc2hUcmFuc2xhdGlvbih0cmFuc2xhdGlvbiwgdGFiKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwicHVibGlzaCB0cmFuc2xhdGlvblwiKTtcbiAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgYWN0aW9uOiBcIm9wZW5fdG9vbHRpcFwiLFxuICAgICAgICAgIGRhdGE6IHRyYW5zbGF0aW9uLm91dGVySFRNTCxcbiAgICAgICAgICBzdWNjZXNzOiAhdHJhbnNsYXRpb24uY2xhc3NMaXN0LmNvbnRhaW5zKFwiZmFpbFRyYW5zbGF0ZVwiKVxuICAgICAgICB9KTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIGVycm9ySGFuZGxlcjoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIGVycm9ySGFuZGxlcihyZXNwb25zZSkge1xuICAgICAgICBjb25zb2xlLmxvZyhcImVycm9yIGFqYXhcIiwgcmVzcG9uc2UpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcGFyc2U6IHtcblxuICAgICAgLyogUGFyc2UgcmVzcG9uc2UgZnJvbSB0cmFuc2xhdGlvbiBlbmdpbmUgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBwYXJzZShyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUpIHtcbiAgICAgICAgdmFyIGRvYyA9IHRoaXMuc3RyaXBTY3JpcHRzKHJlc3BvbnNlKSxcbiAgICAgICAgICAgIGZyYWdtZW50ID0gdGhpcy5tYWtlRnJhZ21lbnQoZG9jKTtcbiAgICAgICAgaWYgKGZyYWdtZW50KSB7XG4gICAgICAgICAgdHJhbnNsYXRlID0gZnJhZ21lbnQucXVlcnlTZWxlY3RvcihcIiNtZWFuaW5nX2RpdiA+IHRhYmxlXCIpO1xuICAgICAgICAgIGlmICh0cmFuc2xhdGUpIHtcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSB0aGlzLlRBQkxFX0NMQVNTO1xuICAgICAgICAgICAgdHJhbnNsYXRlLnNldEF0dHJpYnV0ZShcImNlbGxwYWRkaW5nXCIsIFwiNVwiKTtcbiAgICAgICAgICAgIC8vIEBmaXhJbWFnZXModHJhbnNsYXRlKVxuICAgICAgICAgICAgLy8gQGZpeExpbmtzKHRyYW5zbGF0ZSlcbiAgICAgICAgICB9IGVsc2UgaWYgKCFzaWxlbnQpIHtcbiAgICAgICAgICAgIHRyYW5zbGF0ZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gXCJmYWlsVHJhbnNsYXRlXCI7XG4gICAgICAgICAgICB0cmFuc2xhdGUuaW5uZXJUZXh0ID0gXCJVbmZvcnR1bmF0ZWx5LCBjb3VsZCBub3QgdHJhbnNsYXRlXCI7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cmFuc2xhdGU7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBzdHJpcFNjcmlwdHM6IHtcblxuICAgICAgLy9UT0RPIGV4dHJhY3QgdG8gYmFzZSBlbmdpbmUgY2xhc3NcbiAgICAgIC8qIHJlbW92ZXMgPHNjcmlwdD4gdGFncyBmcm9tIGh0bWwgY29kZSAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHN0cmlwU2NyaXB0cyhodG1sKSB7XG4gICAgICAgIHZhciBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcbiAgICAgICAgdmFyIHNjcmlwdHMgPSBkaXYuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJzY3JpcHRcIik7XG4gICAgICAgIHZhciBpID0gc2NyaXB0cy5sZW5ndGg7XG4gICAgICAgIHdoaWxlIChpLS0pIHNjcmlwdHNbaV0ucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChzY3JpcHRzW2ldKTtcbiAgICAgICAgcmV0dXJuIGRpdi5pbm5lckhUTUw7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBtYWtlRnJhZ21lbnQ6IHtcblxuICAgICAgLy9UT0RPIGV4dHJhY3QgdG8gYmFzZSBlbmdpbmUgY2xhc3NcbiAgICAgIC8qIGNyZWF0ZXMgdGVtcCBvYmplY3QgdG8gcGFyc2UgdHJhbnNsYXRpb24gZnJvbSBwYWdlIFxuICAgICAgICAoc2luY2UgaXQncyBub3QgYSBmcmllbmRseSBhcGkpIFxuICAgICAgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlRnJhZ21lbnQoaHRtbCkge1xuICAgICAgICB2YXIgZnJhZ21lbnQsXG4gICAgICAgICAgICBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcbiAgICAgICAgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG4gICAgICAgIHdoaWxlIChkaXYuZmlyc3RDaGlsZCkge1xuICAgICAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKGRpdi5maXJzdENoaWxkKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfVxuICB9KTtcblxuICByZXR1cm4gVHVya2lzaERpY3Rpb25hcnk7XG59KSgpO1xuXG4vLyBTaW5nbGV0b25lXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBUdXJraXNoRGljdGlvbmFyeSgpOyJdfQ==
