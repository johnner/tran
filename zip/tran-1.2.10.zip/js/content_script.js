(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
/* global chrome */
/*
 Script embedded on each user page
 Listens messages from translation module and renders popup
 with translated text
*/
"use strict";

require("../polyfills/Array.from.js");

var View = require('./view.js');
var content = new View();
//# sourceMappingURL=content.js.map

},{"../polyfills/Array.from.js":4,"./view.js":3}],2:[function(require,module,exports){
// TODO вынести настройки подключения в settings.js
//var HOST = 'http://tran-service.com'
'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var HOST = 'http://localhost:5000';

var TOOLTIP_CLASS_PREFIX = '__mtt_translate_dialog__';
var ctrlDown = false;
var ctrlKey = 17;
var cmdKey = 91;
var cKey = 67;
var add_title = 'Добавить в персональный словарь';

var _ = require('../utils.js');

var Tooltip = (function () {
  function Tooltip(coordinates) {
    _classCallCheck(this, Tooltip);

    this.setListeners();
    this.clickTarget = null;
  }

  _createClass(Tooltip, [{
    key: 'createEl',
    value: function createEl(storage) {
      this.el = document.createElement('div');
      this.memorizeButton = this.createMemoBtn();
      this.elContainer = this.createContainer();
      this.el.appendChild(this.memorizeButton);
      this.el.appendChild(this.elContainer);
      this.el.classList.add(TOOLTIP_CLASS_PREFIX);
      this.addListeners();
    }
  }, {
    key: 'addListeners',
    value: function addListeners() {
      this.el.addEventListener('mousedown', function (e) {
        return e.stopPropagation();
      });
      this.el.addEventListener('keydown', this.onKeyDown);
      this.memorizeButton.addEventListener('click', this.memoClick);
    }
  }, {
    key: 'createMemoBtn',
    value: function createMemoBtn() {
      var t = document.createElement('template');
      var tmpl = '<a title="' + add_title + '"\n                   class="btn-floating waves-effect waves-light blue word-add">\n                  <i class="material-icons">+</i>\n                </a>';
      t.innerHTML = tmpl;
      return t.content;
    }
  }, {
    key: 'memoClick',
    value: function memoClick(e) {
      e.stopPropagation();
      e.preventDefault();
      _.post(HOST + '/api/plugin/add_word/', { data: 'blabla' });
    }
  }, {
    key: 'createContainer',
    value: function createContainer() {
      var docFragment = document.createDocumentFragment();
      var container = document.createElement('div');
      container.classList.add(TOOLTIP_CLASS_PREFIX + 'container');
      return container;
    }
  }, {
    key: 'onKeyDown',
    value: function onKeyDown(e) {
      if (ctrlDown && (e.keyCode == vKey || e.keyCode == cKey)) {
        e.stopPropagation();
        return true;
      }
    }
  }, {
    key: 'setListeners',
    value: function setListeners() {
      var _this = this;

      window.addEventListener('mousedown', function (e) {
        return _this.destroy(e);
      });
      document.addEventListener('mousedown', function (e) {
        return _this.destroy(e);
      });
      window.addEventListener('blur', function (e) {
        return _this.destroy(e);
      });
      document.addEventListener('keydown', function (e) {
        return _this.keydown(e);
      });
      document.addEventListener('keyup', function (e) {
        return _this.keyup(e);
      });
    }
  }, {
    key: 'render',
    value: function render(data) {
      var transform = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];

      if (!this.el) {
        this.createEl();
      }
      this.checkMemorize();
      this.elContainer.innerHTML = data;
      if (transform) {
        transform(this.el);
      }
      this.el.style.left = this.coordinates.mouseX + 'px';
      this.el.style.top = this.coordinates.mouseY + 'px';
      document.body.appendChild(this.el);
      if (this.coordinates.mouseX + this.el.offsetWidth > window.innerWidth) {
        this.el.style.left = this.coordinates.mouseX - this.el.offsetWidth + 'px';
      }
    }
  }, {
    key: 'checkMemorize',
    value: function checkMemorize() {
      var self = this;
      chrome.storage.sync.get({ memorize: false, auth_token: null }, function (storage) {
        if (storage.memorize && storage.auth_token) {
          self.el.classList.add('memorize');
        } else {
          self.el.classList.remove('memorize');
        }
      });
    }
  }, {
    key: 'keydown',
    value: function keydown(e) {
      if (e.keyCode == ctrlKey || e.keyCode == cmdKey) {
        ctrlDown = true;
      }
      if (ctrlDown && (e.keyCode == ctrlKey || e.keyCode == cKey || e.keyCode == cmdKey)) {
        return true;
      } else {
        this.destroy(e);
      }
    }
  }, {
    key: 'keyup',
    value: function keyup(e) {
      if (e.keyCode == ctrlKey) {
        ctrlDown = false;
      }
    }
  }, {
    key: 'destroy',
    value: function destroy(e) {
      if (this.el && this.el.parentNode == document.body) {
        document.body.removeChild(this.el);
        this.el = null;
        this.clickTarget = null; // reset click target
      }
    }
  }, {
    key: 'setCoordinates',
    value: function setCoordinates(coordinates) {
      this.coordinates = coordinates;
    }
  }]);

  return Tooltip;
})();

module.exports = Tooltip;
//# sourceMappingURL=tooltip.js.map

},{"../utils.js":5}],3:[function(require,module,exports){
'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var Tooltip = require('./tooltip.js');
var TEXTBOX_TAGS = ['input', 'textarea'];

var Main = (function () {
  function Main() {
    _classCallCheck(this, Main);

    this.addEventListeners();
    this.coordinates = { mouseX: 0, mouseY: 0 };
    this.tooltip = new Tooltip(this.coordinates);
    chrome.runtime.onMessage.addListener(this.renderResult.bind(this));
  }

  _createClass(Main, [{
    key: 'addEventListeners',
    value: function addEventListeners() {
      var _this = this;

      window.addEventListener('mousedown', function (e) {
        return _this.mouseDownEvent(e);
      });
      document.addEventListener('mousedown', function (e) {
        return _this.mouseDownEvent(e);
      });
      window.addEventListener('mouseup', function (e) {
        return _this.mouseUpEvent(e);
      });
      document.addEventListener('contextmenu', function (e) {
        return _this.saveMousePosition(e);
      });
    }
  }, {
    key: 'renderResult',
    value: function renderResult(msg) {
      if (msg.action == 'open_tooltip' || msg.action == 'similar_words') {
        //don't show annoying tooltip when typing
        if (!msg.success && this.tooltip.clickTarget == 'textbox') {
          return;
        } else if (msg.action == 'similar_words') {
          this.tooltip.render(msg.data, this.attachSimilarWordsHandlers.bind(this));
        } else {
          this.tooltip.render(msg.data);
        }
      }
    }
  }, {
    key: 'requestSearch',
    value: function requestSearch(selection) {
      chrome.runtime.sendMessage({
        method: "request_search",
        data: {
          selectionText: selection
        }
      });
    }
  }, {
    key: 'saveMousePosition',
    value: function saveMousePosition(e) {
      this.coordinates.mouseX = e.pageX + 5;
      this.coordinates.mouseY = e.pageY + 10;
      this.tooltip.setCoordinates(this.coordinates);
    }
  }, {
    key: 'mouseDownEvent',
    value: function mouseDownEvent(e) {
      var tag = e.target.tagName.toLowerCase();
      if (TEXTBOX_TAGS.indexOf(tag) != -1) {
        this.tooltip.clickTarget = 'textbox';
      }
    }
  }, {
    key: 'mouseUpEvent',
    value: function mouseUpEvent(e) {
      // fix for accidental tooltip appearance when clicked on text
      setTimeout(this.clickHandler.bind(this, e), 10);
      return true;
    }
  }, {
    key: 'clickHandler',
    value: function clickHandler(e) {
      this.saveMousePosition(e);
      var selection = this.getSelection();
      var self = this;
      if (selection.length > 0) {
        chrome.storage.sync.get({ fast: true }, function (items) {
          if (items.fast) {
            self.requestSearch(selection);
          }
        });
      }
    }
  }, {
    key: 'getSelection',
    value: function getSelection(e) {
      var txt = window.getSelection().toString();
      var span = document.createElement('SPAN');
      span.innerHTML = txt;
      var selection = span.textContent.trim();
      return selection;
    }
  }, {
    key: 'attachSimilarWordsHandlers',
    value: function attachSimilarWordsHandlers(fragment) {
      var _this2 = this;

      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        var _loop = function () {
          var link = _step.value;

          // sanitize
          link.removeAttribute('onclick');
          link.onclick = null;
          var clone = link.cloneNode(true);
          link.parentNode.replaceChild(clone, link);
          var word = clone.textContent;
          // Prevent link from being followed.
          clone.addEventListener('click', function (e) {
            e.stopPropagation();e.preventDefault();
          });
          // Don't let @mouseUpEvent fire again with the wrong word.
          self = _this2;

          clone.addEventListener('mouseup', function (e) {
            e.stopPropagation();
            self.requestSearch(word);
          });
        };

        for (var _iterator = Array.from(fragment.querySelectorAll('a'))[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var self;

          _loop();
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator['return']) {
            _iterator['return']();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return true;
    }
  }]);

  return Main;
})();

module.exports = Main;
//# sourceMappingURL=view.js.map

},{"./tooltip.js":2}],4:[function(require,module,exports){
"use strict";

Array.from || !(function () {
  "use strict";var r = (function () {
    try {
      var r = {},
          e = Object.defineProperty,
          t = e(r, r, r) && e;
    } catch (n) {}return t || function (r, e, t) {
      r[e] = t.value;
    };
  })(),
      e = Object.prototype.toString,
      t = function t(r) {
    return "function" == typeof r || "[object Function]" == e.call(r);
  },
      n = function n(r) {
    var e = Number(r);return isNaN(e) ? 0 : 0 != e && isFinite(e) ? (e > 0 ? 1 : -1) * Math.floor(Math.abs(e)) : e;
  },
      a = Math.pow(2, 53) - 1,
      o = function o(r) {
    var e = n(r);return Math.min(Math.max(e, 0), a);
  },
      u = function u(e) {
    var n = this;if (null == e) throw new TypeError("`Array.from` requires an array-like object, not `null` or `undefined`");{
      var a,
          u,
          i = Object(e);arguments.length > 1;
    }if (arguments.length > 1) {
      if ((a = arguments[1], !t(a))) throw new TypeError("When provided, the second argument to `Array.from` must be a function");arguments.length > 2 && (u = arguments[2]);
    }for (var f, c, l = o(i.length), h = t(n) ? Object(new n(l)) : new Array(l), m = 0; l > m;) f = i[m], c = a ? "undefined" == typeof u ? a(f, m) : a.call(u, f, m) : f, r(h, m, { value: c, configurable: !0, enumerable: !0, writable: !0 }), ++m;return (h.length = l, h);
  };r(Array, "from", { value: u, configurable: !0, writable: !0 });
})();
//# sourceMappingURL=Array.from.js.map

},{}],5:[function(require,module,exports){
"use strict";

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Utils = (function () {
  function Utils() {
    _classCallCheck(this, Utils);
  }

  _createClass(Utils, [{
    key: "request",
    value: function request(type, url, opts) {
      // Return a new promise.
      return new Promise(function (resolve, reject) {
        // Do the usual XHR stuff
        var req = new XMLHttpRequest();
        req.withCredentials = true;
        req.open(type, url);
        if (type == 'POST') {
          req.setRequestHeader("Content-Type", "application/json");
        }
        req.onload = function () {
          // This is called even on 404 etc
          // so check the status
          if (req.status == 200) {
            // Resolve the promise with the response text
            resolve(req.response);
          } else {
            // Otherwise reject with the status text
            // which will hopefully be a meaningful error
            reject(Error(req.statusText));
          }
        };

        // Handle network errors
        req.onerror = function () {
          reject(Error("Network Error"));
        };

        // Set headers
        if (opts.headers) {
          var _iteratorNormalCompletion = true;
          var _didIteratorError = false;
          var _iteratorError = undefined;

          try {
            for (var _iterator = Object.keys(opts.headers)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              var key = _step.value;

              req.setRequestHeader(key, opts.headers[key]);
            }
          } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion && _iterator["return"]) {
                _iterator["return"]();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
          }
        }
        // Make the request
        req.send(JSON.stringify(opts.data));
      });
    }
  }, {
    key: "get",
    value: function get(url) {
      var opts = arguments.length <= 1 || arguments[1] === undefined ? { data: '' } : arguments[1];

      return this.request('GET', url, opts);
    }
  }, {
    key: "post",
    value: function post(url) {
      var opts = arguments.length <= 1 || arguments[1] === undefined ? { data: '' } : arguments[1];

      return this.request('POST', url, opts);
    }
  }]);

  return Utils;
})();

module.exports = new Utils();
//# sourceMappingURL=utils.js.map

},{}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvZXM1L2NvbnRlbnRfc2NyaXB0L2NvbnRlbnQuanMiLCIvVXNlcnMvYW50aG9ueS9EZXZlbG9wbWVudC90cmFuL2pzL2VzNS9jb250ZW50X3NjcmlwdC90b29sdGlwLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy9lczUvY29udGVudF9zY3JpcHQvdmlldy5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvZXM1L3BvbHlmaWxscy9BcnJheS5mcm9tLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy9lczUvdXRpbHMuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzNLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdktBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3Rocm93IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIil9dmFyIGY9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGYuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sZixmLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIi8qIGdsb2JhbCBjaHJvbWUgKi9cbi8qXG4gU2NyaXB0IGVtYmVkZGVkIG9uIGVhY2ggdXNlciBwYWdlXG4gTGlzdGVucyBtZXNzYWdlcyBmcm9tIHRyYW5zbGF0aW9uIG1vZHVsZSBhbmQgcmVuZGVycyBwb3B1cFxuIHdpdGggdHJhbnNsYXRlZCB0ZXh0XG4qL1xuXCJ1c2Ugc3RyaWN0XCI7XG5cbnJlcXVpcmUoXCIuLi9wb2x5ZmlsbHMvQXJyYXkuZnJvbS5qc1wiKTtcblxudmFyIFZpZXcgPSByZXF1aXJlKCcuL3ZpZXcuanMnKTtcbnZhciBjb250ZW50ID0gbmV3IFZpZXcoKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNvbnRlbnQuanMubWFwXG4iLCIvLyBUT0RPINCy0YvQvdC10YHRgtC4INC90LDRgdGC0YDQvtC50LrQuCDQv9C+0LTQutC70Y7Rh9C10L3QuNGPINCyIHNldHRpbmdzLmpzXG4vL3ZhciBIT1NUID0gJ2h0dHA6Ly90cmFuLXNlcnZpY2UuY29tJ1xuJ3VzZSBzdHJpY3QnO1xuXG52YXIgX2NyZWF0ZUNsYXNzID0gKGZ1bmN0aW9uICgpIHsgZnVuY3Rpb24gZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIHByb3BzKSB7IGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpKyspIHsgdmFyIGRlc2NyaXB0b3IgPSBwcm9wc1tpXTsgZGVzY3JpcHRvci5lbnVtZXJhYmxlID0gZGVzY3JpcHRvci5lbnVtZXJhYmxlIHx8IGZhbHNlOyBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSA9IHRydWU7IGlmICgndmFsdWUnIGluIGRlc2NyaXB0b3IpIGRlc2NyaXB0b3Iud3JpdGFibGUgPSB0cnVlOyBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBkZXNjcmlwdG9yLmtleSwgZGVzY3JpcHRvcik7IH0gfSByZXR1cm4gZnVuY3Rpb24gKENvbnN0cnVjdG9yLCBwcm90b1Byb3BzLCBzdGF0aWNQcm9wcykgeyBpZiAocHJvdG9Qcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvci5wcm90b3R5cGUsIHByb3RvUHJvcHMpOyBpZiAoc3RhdGljUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IsIHN0YXRpY1Byb3BzKTsgcmV0dXJuIENvbnN0cnVjdG9yOyB9OyB9KSgpO1xuXG5mdW5jdGlvbiBfY2xhc3NDYWxsQ2hlY2soaW5zdGFuY2UsIENvbnN0cnVjdG9yKSB7IGlmICghKGluc3RhbmNlIGluc3RhbmNlb2YgQ29uc3RydWN0b3IpKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoJ0Nhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvbicpOyB9IH1cblxudmFyIEhPU1QgPSAnaHR0cDovL2xvY2FsaG9zdDo1MDAwJztcblxudmFyIFRPT0xUSVBfQ0xBU1NfUFJFRklYID0gJ19fbXR0X3RyYW5zbGF0ZV9kaWFsb2dfXyc7XG52YXIgY3RybERvd24gPSBmYWxzZTtcbnZhciBjdHJsS2V5ID0gMTc7XG52YXIgY21kS2V5ID0gOTE7XG52YXIgY0tleSA9IDY3O1xudmFyIGFkZF90aXRsZSA9ICfQlNC+0LHQsNCy0LjRgtGMINCyINC/0LXRgNGB0L7QvdCw0LvRjNC90YvQuSDRgdC70L7QstCw0YDRjCc7XG5cbnZhciBfID0gcmVxdWlyZSgnLi4vdXRpbHMuanMnKTtcblxudmFyIFRvb2x0aXAgPSAoZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBUb29sdGlwKGNvb3JkaW5hdGVzKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIFRvb2x0aXApO1xuXG4gICAgdGhpcy5zZXRMaXN0ZW5lcnMoKTtcbiAgICB0aGlzLmNsaWNrVGFyZ2V0ID0gbnVsbDtcbiAgfVxuXG4gIF9jcmVhdGVDbGFzcyhUb29sdGlwLCBbe1xuICAgIGtleTogJ2NyZWF0ZUVsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gY3JlYXRlRWwoc3RvcmFnZSkge1xuICAgICAgdGhpcy5lbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgdGhpcy5tZW1vcml6ZUJ1dHRvbiA9IHRoaXMuY3JlYXRlTWVtb0J0bigpO1xuICAgICAgdGhpcy5lbENvbnRhaW5lciA9IHRoaXMuY3JlYXRlQ29udGFpbmVyKCk7XG4gICAgICB0aGlzLmVsLmFwcGVuZENoaWxkKHRoaXMubWVtb3JpemVCdXR0b24pO1xuICAgICAgdGhpcy5lbC5hcHBlbmRDaGlsZCh0aGlzLmVsQ29udGFpbmVyKTtcbiAgICAgIHRoaXMuZWwuY2xhc3NMaXN0LmFkZChUT09MVElQX0NMQVNTX1BSRUZJWCk7XG4gICAgICB0aGlzLmFkZExpc3RlbmVycygpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2FkZExpc3RlbmVycycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGFkZExpc3RlbmVycygpIHtcbiAgICAgIHRoaXMuZWwuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgcmV0dXJuIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICB9KTtcbiAgICAgIHRoaXMuZWwuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIHRoaXMub25LZXlEb3duKTtcbiAgICAgIHRoaXMubWVtb3JpemVCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLm1lbW9DbGljayk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnY3JlYXRlTWVtb0J0bicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNyZWF0ZU1lbW9CdG4oKSB7XG4gICAgICB2YXIgdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3RlbXBsYXRlJyk7XG4gICAgICB2YXIgdG1wbCA9ICc8YSB0aXRsZT1cIicgKyBhZGRfdGl0bGUgKyAnXCJcXG4gICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidG4tZmxvYXRpbmcgd2F2ZXMtZWZmZWN0IHdhdmVzLWxpZ2h0IGJsdWUgd29yZC1hZGRcIj5cXG4gICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cIm1hdGVyaWFsLWljb25zXCI+KzwvaT5cXG4gICAgICAgICAgICAgICAgPC9hPic7XG4gICAgICB0LmlubmVySFRNTCA9IHRtcGw7XG4gICAgICByZXR1cm4gdC5jb250ZW50O1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ21lbW9DbGljaycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG1lbW9DbGljayhlKSB7XG4gICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgXy5wb3N0KEhPU1QgKyAnL2FwaS9wbHVnaW4vYWRkX3dvcmQvJywgeyBkYXRhOiAnYmxhYmxhJyB9KTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdjcmVhdGVDb250YWluZXInLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjcmVhdGVDb250YWluZXIoKSB7XG4gICAgICB2YXIgZG9jRnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG4gICAgICB2YXIgY29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICBjb250YWluZXIuY2xhc3NMaXN0LmFkZChUT09MVElQX0NMQVNTX1BSRUZJWCArICdjb250YWluZXInKTtcbiAgICAgIHJldHVybiBjb250YWluZXI7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnb25LZXlEb3duJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gb25LZXlEb3duKGUpIHtcbiAgICAgIGlmIChjdHJsRG93biAmJiAoZS5rZXlDb2RlID09IHZLZXkgfHwgZS5rZXlDb2RlID09IGNLZXkpKSB7XG4gICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3NldExpc3RlbmVycycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHNldExpc3RlbmVycygpIHtcbiAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gX3RoaXMuZGVzdHJveShlKTtcbiAgICAgIH0pO1xuICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzLmRlc3Ryb3koZSk7XG4gICAgICB9KTtcbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdibHVyJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzLmRlc3Ryb3koZSk7XG4gICAgICB9KTtcbiAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gX3RoaXMua2V5ZG93bihlKTtcbiAgICAgIH0pO1xuICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigna2V5dXAnLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gX3RoaXMua2V5dXAoZSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdyZW5kZXInLFxuICAgIHZhbHVlOiBmdW5jdGlvbiByZW5kZXIoZGF0YSkge1xuICAgICAgdmFyIHRyYW5zZm9ybSA9IGFyZ3VtZW50cy5sZW5ndGggPD0gMSB8fCBhcmd1bWVudHNbMV0gPT09IHVuZGVmaW5lZCA/IG51bGwgOiBhcmd1bWVudHNbMV07XG5cbiAgICAgIGlmICghdGhpcy5lbCkge1xuICAgICAgICB0aGlzLmNyZWF0ZUVsKCk7XG4gICAgICB9XG4gICAgICB0aGlzLmNoZWNrTWVtb3JpemUoKTtcbiAgICAgIHRoaXMuZWxDb250YWluZXIuaW5uZXJIVE1MID0gZGF0YTtcbiAgICAgIGlmICh0cmFuc2Zvcm0pIHtcbiAgICAgICAgdHJhbnNmb3JtKHRoaXMuZWwpO1xuICAgICAgfVxuICAgICAgdGhpcy5lbC5zdHlsZS5sZWZ0ID0gdGhpcy5jb29yZGluYXRlcy5tb3VzZVggKyAncHgnO1xuICAgICAgdGhpcy5lbC5zdHlsZS50b3AgPSB0aGlzLmNvb3JkaW5hdGVzLm1vdXNlWSArICdweCc7XG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHRoaXMuZWwpO1xuICAgICAgaWYgKHRoaXMuY29vcmRpbmF0ZXMubW91c2VYICsgdGhpcy5lbC5vZmZzZXRXaWR0aCA+IHdpbmRvdy5pbm5lcldpZHRoKSB7XG4gICAgICAgIHRoaXMuZWwuc3R5bGUubGVmdCA9IHRoaXMuY29vcmRpbmF0ZXMubW91c2VYIC0gdGhpcy5lbC5vZmZzZXRXaWR0aCArICdweCc7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnY2hlY2tNZW1vcml6ZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNoZWNrTWVtb3JpemUoKSB7XG4gICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7IG1lbW9yaXplOiBmYWxzZSwgYXV0aF90b2tlbjogbnVsbCB9LCBmdW5jdGlvbiAoc3RvcmFnZSkge1xuICAgICAgICBpZiAoc3RvcmFnZS5tZW1vcml6ZSAmJiBzdG9yYWdlLmF1dGhfdG9rZW4pIHtcbiAgICAgICAgICBzZWxmLmVsLmNsYXNzTGlzdC5hZGQoJ21lbW9yaXplJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2VsZi5lbC5jbGFzc0xpc3QucmVtb3ZlKCdtZW1vcml6ZScpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdrZXlkb3duJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24ga2V5ZG93bihlKSB7XG4gICAgICBpZiAoZS5rZXlDb2RlID09IGN0cmxLZXkgfHwgZS5rZXlDb2RlID09IGNtZEtleSkge1xuICAgICAgICBjdHJsRG93biA9IHRydWU7XG4gICAgICB9XG4gICAgICBpZiAoY3RybERvd24gJiYgKGUua2V5Q29kZSA9PSBjdHJsS2V5IHx8IGUua2V5Q29kZSA9PSBjS2V5IHx8IGUua2V5Q29kZSA9PSBjbWRLZXkpKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5kZXN0cm95KGUpO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2tleXVwJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24ga2V5dXAoZSkge1xuICAgICAgaWYgKGUua2V5Q29kZSA9PSBjdHJsS2V5KSB7XG4gICAgICAgIGN0cmxEb3duID0gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnZGVzdHJveScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGRlc3Ryb3koZSkge1xuICAgICAgaWYgKHRoaXMuZWwgJiYgdGhpcy5lbC5wYXJlbnROb2RlID09IGRvY3VtZW50LmJvZHkpIHtcbiAgICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZCh0aGlzLmVsKTtcbiAgICAgICAgdGhpcy5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMuY2xpY2tUYXJnZXQgPSBudWxsOyAvLyByZXNldCBjbGljayB0YXJnZXRcbiAgICAgIH1cbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdzZXRDb29yZGluYXRlcycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHNldENvb3JkaW5hdGVzKGNvb3JkaW5hdGVzKSB7XG4gICAgICB0aGlzLmNvb3JkaW5hdGVzID0gY29vcmRpbmF0ZXM7XG4gICAgfVxuICB9XSk7XG5cbiAgcmV0dXJuIFRvb2x0aXA7XG59KSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IFRvb2x0aXA7XG4vLyMgc291cmNlTWFwcGluZ1VSTD10b29sdGlwLmpzLm1hcFxuIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgX2NyZWF0ZUNsYXNzID0gKGZ1bmN0aW9uICgpIHsgZnVuY3Rpb24gZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIHByb3BzKSB7IGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpKyspIHsgdmFyIGRlc2NyaXB0b3IgPSBwcm9wc1tpXTsgZGVzY3JpcHRvci5lbnVtZXJhYmxlID0gZGVzY3JpcHRvci5lbnVtZXJhYmxlIHx8IGZhbHNlOyBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSA9IHRydWU7IGlmICgndmFsdWUnIGluIGRlc2NyaXB0b3IpIGRlc2NyaXB0b3Iud3JpdGFibGUgPSB0cnVlOyBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBkZXNjcmlwdG9yLmtleSwgZGVzY3JpcHRvcik7IH0gfSByZXR1cm4gZnVuY3Rpb24gKENvbnN0cnVjdG9yLCBwcm90b1Byb3BzLCBzdGF0aWNQcm9wcykgeyBpZiAocHJvdG9Qcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvci5wcm90b3R5cGUsIHByb3RvUHJvcHMpOyBpZiAoc3RhdGljUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IsIHN0YXRpY1Byb3BzKTsgcmV0dXJuIENvbnN0cnVjdG9yOyB9OyB9KSgpO1xuXG5mdW5jdGlvbiBfY2xhc3NDYWxsQ2hlY2soaW5zdGFuY2UsIENvbnN0cnVjdG9yKSB7IGlmICghKGluc3RhbmNlIGluc3RhbmNlb2YgQ29uc3RydWN0b3IpKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoJ0Nhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvbicpOyB9IH1cblxudmFyIFRvb2x0aXAgPSByZXF1aXJlKCcuL3Rvb2x0aXAuanMnKTtcbnZhciBURVhUQk9YX1RBR1MgPSBbJ2lucHV0JywgJ3RleHRhcmVhJ107XG5cbnZhciBNYWluID0gKGZ1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gTWFpbigpIHtcbiAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgTWFpbik7XG5cbiAgICB0aGlzLmFkZEV2ZW50TGlzdGVuZXJzKCk7XG4gICAgdGhpcy5jb29yZGluYXRlcyA9IHsgbW91c2VYOiAwLCBtb3VzZVk6IDAgfTtcbiAgICB0aGlzLnRvb2x0aXAgPSBuZXcgVG9vbHRpcCh0aGlzLmNvb3JkaW5hdGVzKTtcbiAgICBjaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIodGhpcy5yZW5kZXJSZXN1bHQuYmluZCh0aGlzKSk7XG4gIH1cblxuICBfY3JlYXRlQ2xhc3MoTWFpbiwgW3tcbiAgICBrZXk6ICdhZGRFdmVudExpc3RlbmVycycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGFkZEV2ZW50TGlzdGVuZXJzKCkge1xuICAgICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlZG93bicsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHJldHVybiBfdGhpcy5tb3VzZURvd25FdmVudChlKTtcbiAgICAgIH0pO1xuICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzLm1vdXNlRG93bkV2ZW50KGUpO1xuICAgICAgfSk7XG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbW91c2V1cCcsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHJldHVybiBfdGhpcy5tb3VzZVVwRXZlbnQoZSk7XG4gICAgICB9KTtcbiAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NvbnRleHRtZW51JywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzLnNhdmVNb3VzZVBvc2l0aW9uKGUpO1xuICAgICAgfSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAncmVuZGVyUmVzdWx0JyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gcmVuZGVyUmVzdWx0KG1zZykge1xuICAgICAgaWYgKG1zZy5hY3Rpb24gPT0gJ29wZW5fdG9vbHRpcCcgfHwgbXNnLmFjdGlvbiA9PSAnc2ltaWxhcl93b3JkcycpIHtcbiAgICAgICAgLy9kb24ndCBzaG93IGFubm95aW5nIHRvb2x0aXAgd2hlbiB0eXBpbmdcbiAgICAgICAgaWYgKCFtc2cuc3VjY2VzcyAmJiB0aGlzLnRvb2x0aXAuY2xpY2tUYXJnZXQgPT0gJ3RleHRib3gnKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9IGVsc2UgaWYgKG1zZy5hY3Rpb24gPT0gJ3NpbWlsYXJfd29yZHMnKSB7XG4gICAgICAgICAgdGhpcy50b29sdGlwLnJlbmRlcihtc2cuZGF0YSwgdGhpcy5hdHRhY2hTaW1pbGFyV29yZHNIYW5kbGVycy5iaW5kKHRoaXMpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzLnRvb2x0aXAucmVuZGVyKG1zZy5kYXRhKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3JlcXVlc3RTZWFyY2gnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiByZXF1ZXN0U2VhcmNoKHNlbGVjdGlvbikge1xuICAgICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2Uoe1xuICAgICAgICBtZXRob2Q6IFwicmVxdWVzdF9zZWFyY2hcIixcbiAgICAgICAgZGF0YToge1xuICAgICAgICAgIHNlbGVjdGlvblRleHQ6IHNlbGVjdGlvblxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdzYXZlTW91c2VQb3NpdGlvbicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHNhdmVNb3VzZVBvc2l0aW9uKGUpIHtcbiAgICAgIHRoaXMuY29vcmRpbmF0ZXMubW91c2VYID0gZS5wYWdlWCArIDU7XG4gICAgICB0aGlzLmNvb3JkaW5hdGVzLm1vdXNlWSA9IGUucGFnZVkgKyAxMDtcbiAgICAgIHRoaXMudG9vbHRpcC5zZXRDb29yZGluYXRlcyh0aGlzLmNvb3JkaW5hdGVzKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdtb3VzZURvd25FdmVudCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG1vdXNlRG93bkV2ZW50KGUpIHtcbiAgICAgIHZhciB0YWcgPSBlLnRhcmdldC50YWdOYW1lLnRvTG93ZXJDYXNlKCk7XG4gICAgICBpZiAoVEVYVEJPWF9UQUdTLmluZGV4T2YodGFnKSAhPSAtMSkge1xuICAgICAgICB0aGlzLnRvb2x0aXAuY2xpY2tUYXJnZXQgPSAndGV4dGJveCc7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnbW91c2VVcEV2ZW50JyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gbW91c2VVcEV2ZW50KGUpIHtcbiAgICAgIC8vIGZpeCBmb3IgYWNjaWRlbnRhbCB0b29sdGlwIGFwcGVhcmFuY2Ugd2hlbiBjbGlja2VkIG9uIHRleHRcbiAgICAgIHNldFRpbWVvdXQodGhpcy5jbGlja0hhbmRsZXIuYmluZCh0aGlzLCBlKSwgMTApO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnY2xpY2tIYW5kbGVyJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gY2xpY2tIYW5kbGVyKGUpIHtcbiAgICAgIHRoaXMuc2F2ZU1vdXNlUG9zaXRpb24oZSk7XG4gICAgICB2YXIgc2VsZWN0aW9uID0gdGhpcy5nZXRTZWxlY3Rpb24oKTtcbiAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgIGlmIChzZWxlY3Rpb24ubGVuZ3RoID4gMCkge1xuICAgICAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7IGZhc3Q6IHRydWUgfSwgZnVuY3Rpb24gKGl0ZW1zKSB7XG4gICAgICAgICAgaWYgKGl0ZW1zLmZhc3QpIHtcbiAgICAgICAgICAgIHNlbGYucmVxdWVzdFNlYXJjaChzZWxlY3Rpb24pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnZ2V0U2VsZWN0aW9uJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZ2V0U2VsZWN0aW9uKGUpIHtcbiAgICAgIHZhciB0eHQgPSB3aW5kb3cuZ2V0U2VsZWN0aW9uKCkudG9TdHJpbmcoKTtcbiAgICAgIHZhciBzcGFuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnU1BBTicpO1xuICAgICAgc3Bhbi5pbm5lckhUTUwgPSB0eHQ7XG4gICAgICB2YXIgc2VsZWN0aW9uID0gc3Bhbi50ZXh0Q29udGVudC50cmltKCk7XG4gICAgICByZXR1cm4gc2VsZWN0aW9uO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2F0dGFjaFNpbWlsYXJXb3Jkc0hhbmRsZXJzJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gYXR0YWNoU2ltaWxhcldvcmRzSGFuZGxlcnMoZnJhZ21lbnQpIHtcbiAgICAgIHZhciBfdGhpczIgPSB0aGlzO1xuXG4gICAgICB2YXIgX2l0ZXJhdG9yTm9ybWFsQ29tcGxldGlvbiA9IHRydWU7XG4gICAgICB2YXIgX2RpZEl0ZXJhdG9yRXJyb3IgPSBmYWxzZTtcbiAgICAgIHZhciBfaXRlcmF0b3JFcnJvciA9IHVuZGVmaW5lZDtcblxuICAgICAgdHJ5IHtcbiAgICAgICAgdmFyIF9sb29wID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHZhciBsaW5rID0gX3N0ZXAudmFsdWU7XG5cbiAgICAgICAgICAvLyBzYW5pdGl6ZVxuICAgICAgICAgIGxpbmsucmVtb3ZlQXR0cmlidXRlKCdvbmNsaWNrJyk7XG4gICAgICAgICAgbGluay5vbmNsaWNrID0gbnVsbDtcbiAgICAgICAgICB2YXIgY2xvbmUgPSBsaW5rLmNsb25lTm9kZSh0cnVlKTtcbiAgICAgICAgICBsaW5rLnBhcmVudE5vZGUucmVwbGFjZUNoaWxkKGNsb25lLCBsaW5rKTtcbiAgICAgICAgICB2YXIgd29yZCA9IGNsb25lLnRleHRDb250ZW50O1xuICAgICAgICAgIC8vIFByZXZlbnQgbGluayBmcm9tIGJlaW5nIGZvbGxvd2VkLlxuICAgICAgICAgIGNsb25lLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7ZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIC8vIERvbid0IGxldCBAbW91c2VVcEV2ZW50IGZpcmUgYWdhaW4gd2l0aCB0aGUgd3Jvbmcgd29yZC5cbiAgICAgICAgICBzZWxmID0gX3RoaXMyO1xuXG4gICAgICAgICAgY2xvbmUuYWRkRXZlbnRMaXN0ZW5lcignbW91c2V1cCcsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgc2VsZi5yZXF1ZXN0U2VhcmNoKHdvcmQpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9O1xuXG4gICAgICAgIGZvciAodmFyIF9pdGVyYXRvciA9IEFycmF5LmZyb20oZnJhZ21lbnQucXVlcnlTZWxlY3RvckFsbCgnYScpKVtTeW1ib2wuaXRlcmF0b3JdKCksIF9zdGVwOyAhKF9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gPSAoX3N0ZXAgPSBfaXRlcmF0b3IubmV4dCgpKS5kb25lKTsgX2l0ZXJhdG9yTm9ybWFsQ29tcGxldGlvbiA9IHRydWUpIHtcbiAgICAgICAgICB2YXIgc2VsZjtcblxuICAgICAgICAgIF9sb29wKCk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBfZGlkSXRlcmF0b3JFcnJvciA9IHRydWU7XG4gICAgICAgIF9pdGVyYXRvckVycm9yID0gZXJyO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBpZiAoIV9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gJiYgX2l0ZXJhdG9yWydyZXR1cm4nXSkge1xuICAgICAgICAgICAgX2l0ZXJhdG9yWydyZXR1cm4nXSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICBpZiAoX2RpZEl0ZXJhdG9yRXJyb3IpIHtcbiAgICAgICAgICAgIHRocm93IF9pdGVyYXRvckVycm9yO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH1dKTtcblxuICByZXR1cm4gTWFpbjtcbn0pKCk7XG5cbm1vZHVsZS5leHBvcnRzID0gTWFpbjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXZpZXcuanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcblxuQXJyYXkuZnJvbSB8fCAhKGZ1bmN0aW9uICgpIHtcbiAgXCJ1c2Ugc3RyaWN0XCI7dmFyIHIgPSAoZnVuY3Rpb24gKCkge1xuICAgIHRyeSB7XG4gICAgICB2YXIgciA9IHt9LFxuICAgICAgICAgIGUgPSBPYmplY3QuZGVmaW5lUHJvcGVydHksXG4gICAgICAgICAgdCA9IGUociwgciwgcikgJiYgZTtcbiAgICB9IGNhdGNoIChuKSB7fXJldHVybiB0IHx8IGZ1bmN0aW9uIChyLCBlLCB0KSB7XG4gICAgICByW2VdID0gdC52YWx1ZTtcbiAgICB9O1xuICB9KSgpLFxuICAgICAgZSA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcsXG4gICAgICB0ID0gZnVuY3Rpb24gdChyKSB7XG4gICAgcmV0dXJuIFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgciB8fCBcIltvYmplY3QgRnVuY3Rpb25dXCIgPT0gZS5jYWxsKHIpO1xuICB9LFxuICAgICAgbiA9IGZ1bmN0aW9uIG4ocikge1xuICAgIHZhciBlID0gTnVtYmVyKHIpO3JldHVybiBpc05hTihlKSA/IDAgOiAwICE9IGUgJiYgaXNGaW5pdGUoZSkgPyAoZSA+IDAgPyAxIDogLTEpICogTWF0aC5mbG9vcihNYXRoLmFicyhlKSkgOiBlO1xuICB9LFxuICAgICAgYSA9IE1hdGgucG93KDIsIDUzKSAtIDEsXG4gICAgICBvID0gZnVuY3Rpb24gbyhyKSB7XG4gICAgdmFyIGUgPSBuKHIpO3JldHVybiBNYXRoLm1pbihNYXRoLm1heChlLCAwKSwgYSk7XG4gIH0sXG4gICAgICB1ID0gZnVuY3Rpb24gdShlKSB7XG4gICAgdmFyIG4gPSB0aGlzO2lmIChudWxsID09IGUpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJgQXJyYXkuZnJvbWAgcmVxdWlyZXMgYW4gYXJyYXktbGlrZSBvYmplY3QsIG5vdCBgbnVsbGAgb3IgYHVuZGVmaW5lZGBcIik7e1xuICAgICAgdmFyIGEsXG4gICAgICAgICAgdSxcbiAgICAgICAgICBpID0gT2JqZWN0KGUpO2FyZ3VtZW50cy5sZW5ndGggPiAxO1xuICAgIH1pZiAoYXJndW1lbnRzLmxlbmd0aCA+IDEpIHtcbiAgICAgIGlmICgoYSA9IGFyZ3VtZW50c1sxXSwgIXQoYSkpKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiV2hlbiBwcm92aWRlZCwgdGhlIHNlY29uZCBhcmd1bWVudCB0byBgQXJyYXkuZnJvbWAgbXVzdCBiZSBhIGZ1bmN0aW9uXCIpO2FyZ3VtZW50cy5sZW5ndGggPiAyICYmICh1ID0gYXJndW1lbnRzWzJdKTtcbiAgICB9Zm9yICh2YXIgZiwgYywgbCA9IG8oaS5sZW5ndGgpLCBoID0gdChuKSA/IE9iamVjdChuZXcgbihsKSkgOiBuZXcgQXJyYXkobCksIG0gPSAwOyBsID4gbTspIGYgPSBpW21dLCBjID0gYSA/IFwidW5kZWZpbmVkXCIgPT0gdHlwZW9mIHUgPyBhKGYsIG0pIDogYS5jYWxsKHUsIGYsIG0pIDogZiwgcihoLCBtLCB7IHZhbHVlOiBjLCBjb25maWd1cmFibGU6ICEwLCBlbnVtZXJhYmxlOiAhMCwgd3JpdGFibGU6ICEwIH0pLCArK207cmV0dXJuIChoLmxlbmd0aCA9IGwsIGgpO1xuICB9O3IoQXJyYXksIFwiZnJvbVwiLCB7IHZhbHVlOiB1LCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSk7XG59KSgpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9QXJyYXkuZnJvbS5qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuXG52YXIgX2NyZWF0ZUNsYXNzID0gKGZ1bmN0aW9uICgpIHsgZnVuY3Rpb24gZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIHByb3BzKSB7IGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpKyspIHsgdmFyIGRlc2NyaXB0b3IgPSBwcm9wc1tpXTsgZGVzY3JpcHRvci5lbnVtZXJhYmxlID0gZGVzY3JpcHRvci5lbnVtZXJhYmxlIHx8IGZhbHNlOyBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSA9IHRydWU7IGlmIChcInZhbHVlXCIgaW4gZGVzY3JpcHRvcikgZGVzY3JpcHRvci53cml0YWJsZSA9IHRydWU7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGRlc2NyaXB0b3Iua2V5LCBkZXNjcmlwdG9yKTsgfSB9IHJldHVybiBmdW5jdGlvbiAoQ29uc3RydWN0b3IsIHByb3RvUHJvcHMsIHN0YXRpY1Byb3BzKSB7IGlmIChwcm90b1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLnByb3RvdHlwZSwgcHJvdG9Qcm9wcyk7IGlmIChzdGF0aWNQcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvciwgc3RhdGljUHJvcHMpOyByZXR1cm4gQ29uc3RydWN0b3I7IH07IH0pKCk7XG5cbmZ1bmN0aW9uIF9jbGFzc0NhbGxDaGVjayhpbnN0YW5jZSwgQ29uc3RydWN0b3IpIHsgaWYgKCEoaW5zdGFuY2UgaW5zdGFuY2VvZiBDb25zdHJ1Y3RvcikpIHsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvblwiKTsgfSB9XG5cbnZhciBVdGlscyA9IChmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIFV0aWxzKCkge1xuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBVdGlscyk7XG4gIH1cblxuICBfY3JlYXRlQ2xhc3MoVXRpbHMsIFt7XG4gICAga2V5OiBcInJlcXVlc3RcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gcmVxdWVzdCh0eXBlLCB1cmwsIG9wdHMpIHtcbiAgICAgIC8vIFJldHVybiBhIG5ldyBwcm9taXNlLlxuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgLy8gRG8gdGhlIHVzdWFsIFhIUiBzdHVmZlxuICAgICAgICB2YXIgcmVxID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgIHJlcS53aXRoQ3JlZGVudGlhbHMgPSB0cnVlO1xuICAgICAgICByZXEub3Blbih0eXBlLCB1cmwpO1xuICAgICAgICBpZiAodHlwZSA9PSAnUE9TVCcpIHtcbiAgICAgICAgICByZXEuc2V0UmVxdWVzdEhlYWRlcihcIkNvbnRlbnQtVHlwZVwiLCBcImFwcGxpY2F0aW9uL2pzb25cIik7XG4gICAgICAgIH1cbiAgICAgICAgcmVxLm9ubG9hZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAvLyBUaGlzIGlzIGNhbGxlZCBldmVuIG9uIDQwNCBldGNcbiAgICAgICAgICAvLyBzbyBjaGVjayB0aGUgc3RhdHVzXG4gICAgICAgICAgaWYgKHJlcS5zdGF0dXMgPT0gMjAwKSB7XG4gICAgICAgICAgICAvLyBSZXNvbHZlIHRoZSBwcm9taXNlIHdpdGggdGhlIHJlc3BvbnNlIHRleHRcbiAgICAgICAgICAgIHJlc29sdmUocmVxLnJlc3BvbnNlKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gT3RoZXJ3aXNlIHJlamVjdCB3aXRoIHRoZSBzdGF0dXMgdGV4dFxuICAgICAgICAgICAgLy8gd2hpY2ggd2lsbCBob3BlZnVsbHkgYmUgYSBtZWFuaW5nZnVsIGVycm9yXG4gICAgICAgICAgICByZWplY3QoRXJyb3IocmVxLnN0YXR1c1RleHQpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gSGFuZGxlIG5ldHdvcmsgZXJyb3JzXG4gICAgICAgIHJlcS5vbmVycm9yID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHJlamVjdChFcnJvcihcIk5ldHdvcmsgRXJyb3JcIikpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8vIFNldCBoZWFkZXJzXG4gICAgICAgIGlmIChvcHRzLmhlYWRlcnMpIHtcbiAgICAgICAgICB2YXIgX2l0ZXJhdG9yTm9ybWFsQ29tcGxldGlvbiA9IHRydWU7XG4gICAgICAgICAgdmFyIF9kaWRJdGVyYXRvckVycm9yID0gZmFsc2U7XG4gICAgICAgICAgdmFyIF9pdGVyYXRvckVycm9yID0gdW5kZWZpbmVkO1xuXG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGZvciAodmFyIF9pdGVyYXRvciA9IE9iamVjdC5rZXlzKG9wdHMuaGVhZGVycylbU3ltYm9sLml0ZXJhdG9yXSgpLCBfc3RlcDsgIShfaXRlcmF0b3JOb3JtYWxDb21wbGV0aW9uID0gKF9zdGVwID0gX2l0ZXJhdG9yLm5leHQoKSkuZG9uZSk7IF9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gPSB0cnVlKSB7XG4gICAgICAgICAgICAgIHZhciBrZXkgPSBfc3RlcC52YWx1ZTtcblxuICAgICAgICAgICAgICByZXEuc2V0UmVxdWVzdEhlYWRlcihrZXksIG9wdHMuaGVhZGVyc1trZXldKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIF9kaWRJdGVyYXRvckVycm9yID0gdHJ1ZTtcbiAgICAgICAgICAgIF9pdGVyYXRvckVycm9yID0gZXJyO1xuICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICBpZiAoIV9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gJiYgX2l0ZXJhdG9yW1wicmV0dXJuXCJdKSB7XG4gICAgICAgICAgICAgICAgX2l0ZXJhdG9yW1wicmV0dXJuXCJdKCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgIGlmIChfZGlkSXRlcmF0b3JFcnJvcikge1xuICAgICAgICAgICAgICAgIHRocm93IF9pdGVyYXRvckVycm9yO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIE1ha2UgdGhlIHJlcXVlc3RcbiAgICAgICAgcmVxLnNlbmQoSlNPTi5zdHJpbmdpZnkob3B0cy5kYXRhKSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6IFwiZ2V0XCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGdldCh1cmwpIHtcbiAgICAgIHZhciBvcHRzID0gYXJndW1lbnRzLmxlbmd0aCA8PSAxIHx8IGFyZ3VtZW50c1sxXSA9PT0gdW5kZWZpbmVkID8geyBkYXRhOiAnJyB9IDogYXJndW1lbnRzWzFdO1xuXG4gICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KCdHRVQnLCB1cmwsIG9wdHMpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogXCJwb3N0XCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHBvc3QodXJsKSB7XG4gICAgICB2YXIgb3B0cyA9IGFyZ3VtZW50cy5sZW5ndGggPD0gMSB8fCBhcmd1bWVudHNbMV0gPT09IHVuZGVmaW5lZCA/IHsgZGF0YTogJycgfSA6IGFyZ3VtZW50c1sxXTtcblxuICAgICAgcmV0dXJuIHRoaXMucmVxdWVzdCgnUE9TVCcsIHVybCwgb3B0cyk7XG4gICAgfVxuICB9XSk7XG5cbiAgcmV0dXJuIFV0aWxzO1xufSkoKTtcblxubW9kdWxlLmV4cG9ydHMgPSBuZXcgVXRpbHMoKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXV0aWxzLmpzLm1hcFxuIl19
