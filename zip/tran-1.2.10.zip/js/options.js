(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _ = require('../utils.js');
var SERVICE_URL = 'http://tran-service.com/api/user/';

var Options = (function () {
  function Options() {
    _classCallCheck(this, Options);

    this.signed = document.getElementById('signed');
    this.needSign = document.getElementById('need-sign');
  }

  /** Restores select box and checkbox state using
   * the preferences stored in chrome.storage.*/

  _createClass(Options, [{
    key: 'restore',
    value: function restore() {
      // Use default value language is 'english' and fast translate is true
      var defaults = {
        language: '1',
        fast: true,
        memorize: false
      };
      this.storage('get', defaults, this.onRestore);
    }

    /** Saves options to chrome.storage */
  }, {
    key: 'save',
    value: function save() {
      var params = arguments.length <= 0 || arguments[0] === undefined ? { restored: false } : arguments[0];

      // save options if only it is not restored onload
      if (!params.restored) {
        this.storage('set', this.options, this.onSave);
      } else {
        this.memorize();
      }
    }
  }, {
    key: 'onSave',
    value: function onSave() {
      // let user know that options are saved.
      var status = document.getElementById('status');
      status.textContent = 'Options saved.';
      var hideStatus = function hideStatus() {
        status.textContent = '';
      };
      this.memorize();
      setTimeout(hideStatus, 750);
    }

    /** Handler of success options restore */
  }, {
    key: 'onRestore',
    value: function onRestore(items) {
      // set checkboxes
      this.options = items;
      this.save({ restored: true });
    }

    /** chrome storage wrapper */
  }, {
    key: 'storage',
    value: function storage(op, data, cb) {
      cb = cb.bind(this);
      if (op == 'set') {
        chrome.storage.sync.set(data, function (evt) {
          return cb(evt);
        });
      } else if (op == 'get') {
        chrome.storage.sync.get(data, function (evt) {
          return cb(evt);
        });
      }
    }

    /** toggle memorize option */
  }, {
    key: 'memorize',
    value: function memorize() {
      var _this = this;

      if (this.options.memorize) {
        this.check_auth().then(function (res) {
          return _this.authorized = true;
        }, function (res) {
          return _this.authorized = false;
        });
      } else {
        this.revoke();
        this.signed.classList.add('hidden');
        this.needSign.classList.add('hidden');
      }
    }
  }, {
    key: 'check_login',
    value: function check_login() {
      var _this2 = this;

      _.get(SERVICE_URL).then(function (res) {
        return _this2.memok(res);
      }, function (res) {
        return _this2.memfail(res);
      });
    }

    /** memorization is activated */
  }, {
    key: 'memok',
    value: function memok(response) {
      this.authorized = true;
    }

    /** memorization failed */
  }, {
    key: 'memfail',
    value: function memfail(response) {
      this.authorized = false;
    }
  }, {
    key: 'check_auth',
    value: function check_auth() {
      return new Promise((function (resolve, reject) {
        this.storage('get', 'auth_token', (function (data) {
          if (!data.auth_token) {
            reject();
          } else {
            _.get(SERVICE_URL, { headers: { 'X-AUTH-TOKEN': data.auth_token } }).then(function (res) {
              return resolve(res);
            }, function (res) {
              return reject(res);
            });
          }
        }).bind(this));
      }).bind(this));
    }
  }, {
    key: 'signin',
    value: function signin() {
      var _this3 = this;

      var cred = {
        login: document.getElementById('login').value,
        password: document.getElementById('password').value
      };

      _.post(SERVICE_URL, { data: cred }).then(function (res) {
        return _this3.authSuccess(res);
      }, function (res) {
        return _this3.authFail(res);
      });
    }
  }, {
    key: 'authSuccess',
    value: function authSuccess(data) {
      var _this4 = this;

      this.storage('set', { 'auth_token': data }, function (data) {
        return _this4.save();
      });
      this.authorized = true;
    }
  }, {
    key: 'authFail',
    value: function authFail(data) {
      console.log('fail auth', data);
      var status = document.querySelector('.error-login');
      status.textContent = 'Bad login or password.';
      var hideStatus = function hideStatus() {
        status.textContent = '';
      };
      setTimeout(hideStatus, 2750);
    }
  }, {
    key: 'revoke',
    value: function revoke(event) {
      event && event.preventDefault();
      this.storage('set', { 'auth_token': null }, (function (data) {
        this.authorized = false;
      }).bind(this));
    }
  }, {
    key: 'options',
    get: function get() {
      return {
        language: document.getElementById('language').value,
        fast: document.getElementById('fast').checked,
        memorize: document.getElementById('memorize').checked
      };
    },
    set: function set(values) {
      document.getElementById('language').value = values.language;
      document.getElementById('fast').checked = values.fast;
      document.getElementById('memorize').checked = values.memorize;
    }
  }, {
    key: 'authorized',
    set: function set(state) {
      if (this.options.memorize) {
        if (state) {
          this.signed.classList.remove('hidden');
          this.needSign.classList.add('hidden');
        } else {
          this.needSign.classList.remove('hidden');
          this.signed.classList.add('hidden');
        }
      }
    }
  }]);

  return Options;
})();

document.addEventListener('DOMContentLoaded', function (event) {
  var options = new Options();
  options.restore();
  document.getElementById('save').addEventListener('click', function (evt) {
    return options.save();
  });
  document.getElementById('memorize').addEventListener('click', function (evt) {
    return options.memorize();
  });
  document.getElementById('signinBtn').addEventListener('click', function (evt) {
    return options.signin();
  });
  document.querySelector('#revoke').addEventListener('click', function (evt) {
    return options.revoke(evt);
  });
});
//# sourceMappingURL=options.js.map

},{"../utils.js":2}],2:[function(require,module,exports){
"use strict";

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Utils = (function () {
  function Utils() {
    _classCallCheck(this, Utils);
  }

  _createClass(Utils, [{
    key: "request",
    value: function request(type, url, opts) {
      // Return a new promise.
      return new Promise(function (resolve, reject) {
        // Do the usual XHR stuff
        var req = new XMLHttpRequest();
        req.withCredentials = true;
        req.open(type, url);
        if (type == 'POST') {
          req.setRequestHeader("Content-Type", "application/json");
        }
        req.onload = function () {
          // This is called even on 404 etc
          // so check the status
          if (req.status == 200) {
            // Resolve the promise with the response text
            resolve(req.response);
          } else {
            // Otherwise reject with the status text
            // which will hopefully be a meaningful error
            reject(Error(req.statusText));
          }
        };

        // Handle network errors
        req.onerror = function () {
          reject(Error("Network Error"));
        };

        // Set headers
        if (opts.headers) {
          var _iteratorNormalCompletion = true;
          var _didIteratorError = false;
          var _iteratorError = undefined;

          try {
            for (var _iterator = Object.keys(opts.headers)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              var key = _step.value;

              req.setRequestHeader(key, opts.headers[key]);
            }
          } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion && _iterator["return"]) {
                _iterator["return"]();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
          }
        }
        // Make the request
        req.send(JSON.stringify(opts.data));
      });
    }
  }, {
    key: "get",
    value: function get(url) {
      var opts = arguments.length <= 1 || arguments[1] === undefined ? { data: '' } : arguments[1];

      return this.request('GET', url, opts);
    }
  }, {
    key: "post",
    value: function post(url) {
      var opts = arguments.length <= 1 || arguments[1] === undefined ? { data: '' } : arguments[1];

      return this.request('POST', url, opts);
    }
  }]);

  return Utils;
})();

module.exports = new Utils();
//# sourceMappingURL=utils.js.map

},{}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvZXM1L29wdGlvbnMvb3B0aW9ucy5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvZXM1L3V0aWxzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDN09BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3Rocm93IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIil9dmFyIGY9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGYuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sZixmLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIid1c2Ugc3RyaWN0JztcblxudmFyIF9jcmVhdGVDbGFzcyA9IChmdW5jdGlvbiAoKSB7IGZ1bmN0aW9uIGRlZmluZVByb3BlcnRpZXModGFyZ2V0LCBwcm9wcykgeyBmb3IgKHZhciBpID0gMDsgaSA8IHByb3BzLmxlbmd0aDsgaSsrKSB7IHZhciBkZXNjcmlwdG9yID0gcHJvcHNbaV07IGRlc2NyaXB0b3IuZW51bWVyYWJsZSA9IGRlc2NyaXB0b3IuZW51bWVyYWJsZSB8fCBmYWxzZTsgZGVzY3JpcHRvci5jb25maWd1cmFibGUgPSB0cnVlOyBpZiAoJ3ZhbHVlJyBpbiBkZXNjcmlwdG9yKSBkZXNjcmlwdG9yLndyaXRhYmxlID0gdHJ1ZTsgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgZGVzY3JpcHRvci5rZXksIGRlc2NyaXB0b3IpOyB9IH0gcmV0dXJuIGZ1bmN0aW9uIChDb25zdHJ1Y3RvciwgcHJvdG9Qcm9wcywgc3RhdGljUHJvcHMpIHsgaWYgKHByb3RvUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IucHJvdG90eXBlLCBwcm90b1Byb3BzKTsgaWYgKHN0YXRpY1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLCBzdGF0aWNQcm9wcyk7IHJldHVybiBDb25zdHJ1Y3RvcjsgfTsgfSkoKTtcblxuZnVuY3Rpb24gX2NsYXNzQ2FsbENoZWNrKGluc3RhbmNlLCBDb25zdHJ1Y3RvcikgeyBpZiAoIShpbnN0YW5jZSBpbnN0YW5jZW9mIENvbnN0cnVjdG9yKSkgeyB0aHJvdyBuZXcgVHlwZUVycm9yKCdDYW5ub3QgY2FsbCBhIGNsYXNzIGFzIGEgZnVuY3Rpb24nKTsgfSB9XG5cbnZhciBfID0gcmVxdWlyZSgnLi4vdXRpbHMuanMnKTtcbnZhciBTRVJWSUNFX1VSTCA9ICdodHRwOi8vdHJhbi1zZXJ2aWNlLmNvbS9hcGkvdXNlci8nO1xuXG52YXIgT3B0aW9ucyA9IChmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIE9wdGlvbnMoKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIE9wdGlvbnMpO1xuXG4gICAgdGhpcy5zaWduZWQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc2lnbmVkJyk7XG4gICAgdGhpcy5uZWVkU2lnbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCduZWVkLXNpZ24nKTtcbiAgfVxuXG4gIC8qKiBSZXN0b3JlcyBzZWxlY3QgYm94IGFuZCBjaGVja2JveCBzdGF0ZSB1c2luZ1xuICAgKiB0aGUgcHJlZmVyZW5jZXMgc3RvcmVkIGluIGNocm9tZS5zdG9yYWdlLiovXG5cbiAgX2NyZWF0ZUNsYXNzKE9wdGlvbnMsIFt7XG4gICAga2V5OiAncmVzdG9yZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJlc3RvcmUoKSB7XG4gICAgICAvLyBVc2UgZGVmYXVsdCB2YWx1ZSBsYW5ndWFnZSBpcyAnZW5nbGlzaCcgYW5kIGZhc3QgdHJhbnNsYXRlIGlzIHRydWVcbiAgICAgIHZhciBkZWZhdWx0cyA9IHtcbiAgICAgICAgbGFuZ3VhZ2U6ICcxJyxcbiAgICAgICAgZmFzdDogdHJ1ZSxcbiAgICAgICAgbWVtb3JpemU6IGZhbHNlXG4gICAgICB9O1xuICAgICAgdGhpcy5zdG9yYWdlKCdnZXQnLCBkZWZhdWx0cywgdGhpcy5vblJlc3RvcmUpO1xuICAgIH1cblxuICAgIC8qKiBTYXZlcyBvcHRpb25zIHRvIGNocm9tZS5zdG9yYWdlICovXG4gIH0sIHtcbiAgICBrZXk6ICdzYXZlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc2F2ZSgpIHtcbiAgICAgIHZhciBwYXJhbXMgPSBhcmd1bWVudHMubGVuZ3RoIDw9IDAgfHwgYXJndW1lbnRzWzBdID09PSB1bmRlZmluZWQgPyB7IHJlc3RvcmVkOiBmYWxzZSB9IDogYXJndW1lbnRzWzBdO1xuXG4gICAgICAvLyBzYXZlIG9wdGlvbnMgaWYgb25seSBpdCBpcyBub3QgcmVzdG9yZWQgb25sb2FkXG4gICAgICBpZiAoIXBhcmFtcy5yZXN0b3JlZCkge1xuICAgICAgICB0aGlzLnN0b3JhZ2UoJ3NldCcsIHRoaXMub3B0aW9ucywgdGhpcy5vblNhdmUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5tZW1vcml6ZSgpO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ29uU2F2ZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG9uU2F2ZSgpIHtcbiAgICAgIC8vIGxldCB1c2VyIGtub3cgdGhhdCBvcHRpb25zIGFyZSBzYXZlZC5cbiAgICAgIHZhciBzdGF0dXMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc3RhdHVzJyk7XG4gICAgICBzdGF0dXMudGV4dENvbnRlbnQgPSAnT3B0aW9ucyBzYXZlZC4nO1xuICAgICAgdmFyIGhpZGVTdGF0dXMgPSBmdW5jdGlvbiBoaWRlU3RhdHVzKCkge1xuICAgICAgICBzdGF0dXMudGV4dENvbnRlbnQgPSAnJztcbiAgICAgIH07XG4gICAgICB0aGlzLm1lbW9yaXplKCk7XG4gICAgICBzZXRUaW1lb3V0KGhpZGVTdGF0dXMsIDc1MCk7XG4gICAgfVxuXG4gICAgLyoqIEhhbmRsZXIgb2Ygc3VjY2VzcyBvcHRpb25zIHJlc3RvcmUgKi9cbiAgfSwge1xuICAgIGtleTogJ29uUmVzdG9yZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG9uUmVzdG9yZShpdGVtcykge1xuICAgICAgLy8gc2V0IGNoZWNrYm94ZXNcbiAgICAgIHRoaXMub3B0aW9ucyA9IGl0ZW1zO1xuICAgICAgdGhpcy5zYXZlKHsgcmVzdG9yZWQ6IHRydWUgfSk7XG4gICAgfVxuXG4gICAgLyoqIGNocm9tZSBzdG9yYWdlIHdyYXBwZXIgKi9cbiAgfSwge1xuICAgIGtleTogJ3N0b3JhZ2UnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzdG9yYWdlKG9wLCBkYXRhLCBjYikge1xuICAgICAgY2IgPSBjYi5iaW5kKHRoaXMpO1xuICAgICAgaWYgKG9wID09ICdzZXQnKSB7XG4gICAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuc2V0KGRhdGEsIGZ1bmN0aW9uIChldnQpIHtcbiAgICAgICAgICByZXR1cm4gY2IoZXZ0KTtcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2UgaWYgKG9wID09ICdnZXQnKSB7XG4gICAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KGRhdGEsIGZ1bmN0aW9uIChldnQpIHtcbiAgICAgICAgICByZXR1cm4gY2IoZXZ0KTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLyoqIHRvZ2dsZSBtZW1vcml6ZSBvcHRpb24gKi9cbiAgfSwge1xuICAgIGtleTogJ21lbW9yaXplJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gbWVtb3JpemUoKSB7XG4gICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgICBpZiAodGhpcy5vcHRpb25zLm1lbW9yaXplKSB7XG4gICAgICAgIHRoaXMuY2hlY2tfYXV0aCgpLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgIHJldHVybiBfdGhpcy5hdXRob3JpemVkID0gdHJ1ZTtcbiAgICAgICAgfSwgZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgIHJldHVybiBfdGhpcy5hdXRob3JpemVkID0gZmFsc2U7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5yZXZva2UoKTtcbiAgICAgICAgdGhpcy5zaWduZWQuY2xhc3NMaXN0LmFkZCgnaGlkZGVuJyk7XG4gICAgICAgIHRoaXMubmVlZFNpZ24uY2xhc3NMaXN0LmFkZCgnaGlkZGVuJyk7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnY2hlY2tfbG9naW4nLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjaGVja19sb2dpbigpIHtcbiAgICAgIHZhciBfdGhpczIgPSB0aGlzO1xuXG4gICAgICBfLmdldChTRVJWSUNFX1VSTCkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgIHJldHVybiBfdGhpczIubWVtb2socmVzKTtcbiAgICAgIH0sIGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzMi5tZW1mYWlsKHJlcyk7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvKiogbWVtb3JpemF0aW9uIGlzIGFjdGl2YXRlZCAqL1xuICB9LCB7XG4gICAga2V5OiAnbWVtb2snLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtZW1vayhyZXNwb25zZSkge1xuICAgICAgdGhpcy5hdXRob3JpemVkID0gdHJ1ZTtcbiAgICB9XG5cbiAgICAvKiogbWVtb3JpemF0aW9uIGZhaWxlZCAqL1xuICB9LCB7XG4gICAga2V5OiAnbWVtZmFpbCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG1lbWZhaWwocmVzcG9uc2UpIHtcbiAgICAgIHRoaXMuYXV0aG9yaXplZCA9IGZhbHNlO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2NoZWNrX2F1dGgnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjaGVja19hdXRoKCkge1xuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIHRoaXMuc3RvcmFnZSgnZ2V0JywgJ2F1dGhfdG9rZW4nLCAoZnVuY3Rpb24gKGRhdGEpIHtcbiAgICAgICAgICBpZiAoIWRhdGEuYXV0aF90b2tlbikge1xuICAgICAgICAgICAgcmVqZWN0KCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIF8uZ2V0KFNFUlZJQ0VfVVJMLCB7IGhlYWRlcnM6IHsgJ1gtQVVUSC1UT0tFTic6IGRhdGEuYXV0aF90b2tlbiB9IH0pLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgICAgICByZXR1cm4gcmVzb2x2ZShyZXMpO1xuICAgICAgICAgICAgfSwgZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgICAgICByZXR1cm4gcmVqZWN0KHJlcyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pLmJpbmQodGhpcykpO1xuICAgICAgfSkuYmluZCh0aGlzKSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnc2lnbmluJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc2lnbmluKCkge1xuICAgICAgdmFyIF90aGlzMyA9IHRoaXM7XG5cbiAgICAgIHZhciBjcmVkID0ge1xuICAgICAgICBsb2dpbjogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2xvZ2luJykudmFsdWUsXG4gICAgICAgIHBhc3N3b3JkOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncGFzc3dvcmQnKS52YWx1ZVxuICAgICAgfTtcblxuICAgICAgXy5wb3N0KFNFUlZJQ0VfVVJMLCB7IGRhdGE6IGNyZWQgfSkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgIHJldHVybiBfdGhpczMuYXV0aFN1Y2Nlc3MocmVzKTtcbiAgICAgIH0sIGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzMy5hdXRoRmFpbChyZXMpO1xuICAgICAgfSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnYXV0aFN1Y2Nlc3MnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBhdXRoU3VjY2VzcyhkYXRhKSB7XG4gICAgICB2YXIgX3RoaXM0ID0gdGhpcztcblxuICAgICAgdGhpcy5zdG9yYWdlKCdzZXQnLCB7ICdhdXRoX3Rva2VuJzogZGF0YSB9LCBmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICByZXR1cm4gX3RoaXM0LnNhdmUoKTtcbiAgICAgIH0pO1xuICAgICAgdGhpcy5hdXRob3JpemVkID0gdHJ1ZTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdhdXRoRmFpbCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGF1dGhGYWlsKGRhdGEpIHtcbiAgICAgIGNvbnNvbGUubG9nKCdmYWlsIGF1dGgnLCBkYXRhKTtcbiAgICAgIHZhciBzdGF0dXMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuZXJyb3ItbG9naW4nKTtcbiAgICAgIHN0YXR1cy50ZXh0Q29udGVudCA9ICdCYWQgbG9naW4gb3IgcGFzc3dvcmQuJztcbiAgICAgIHZhciBoaWRlU3RhdHVzID0gZnVuY3Rpb24gaGlkZVN0YXR1cygpIHtcbiAgICAgICAgc3RhdHVzLnRleHRDb250ZW50ID0gJyc7XG4gICAgICB9O1xuICAgICAgc2V0VGltZW91dChoaWRlU3RhdHVzLCAyNzUwKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdyZXZva2UnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiByZXZva2UoZXZlbnQpIHtcbiAgICAgIGV2ZW50ICYmIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICB0aGlzLnN0b3JhZ2UoJ3NldCcsIHsgJ2F1dGhfdG9rZW4nOiBudWxsIH0sIChmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICB0aGlzLmF1dGhvcml6ZWQgPSBmYWxzZTtcbiAgICAgIH0pLmJpbmQodGhpcykpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ29wdGlvbnMnLFxuICAgIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGFuZ3VhZ2U6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdsYW5ndWFnZScpLnZhbHVlLFxuICAgICAgICBmYXN0OiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZmFzdCcpLmNoZWNrZWQsXG4gICAgICAgIG1lbW9yaXplOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbWVtb3JpemUnKS5jaGVja2VkXG4gICAgICB9O1xuICAgIH0sXG4gICAgc2V0OiBmdW5jdGlvbiBzZXQodmFsdWVzKSB7XG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbGFuZ3VhZ2UnKS52YWx1ZSA9IHZhbHVlcy5sYW5ndWFnZTtcbiAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdmYXN0JykuY2hlY2tlZCA9IHZhbHVlcy5mYXN0O1xuICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ21lbW9yaXplJykuY2hlY2tlZCA9IHZhbHVlcy5tZW1vcml6ZTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdhdXRob3JpemVkJyxcbiAgICBzZXQ6IGZ1bmN0aW9uIHNldChzdGF0ZSkge1xuICAgICAgaWYgKHRoaXMub3B0aW9ucy5tZW1vcml6ZSkge1xuICAgICAgICBpZiAoc3RhdGUpIHtcbiAgICAgICAgICB0aGlzLnNpZ25lZC5jbGFzc0xpc3QucmVtb3ZlKCdoaWRkZW4nKTtcbiAgICAgICAgICB0aGlzLm5lZWRTaWduLmNsYXNzTGlzdC5hZGQoJ2hpZGRlbicpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMubmVlZFNpZ24uY2xhc3NMaXN0LnJlbW92ZSgnaGlkZGVuJyk7XG4gICAgICAgICAgdGhpcy5zaWduZWQuY2xhc3NMaXN0LmFkZCgnaGlkZGVuJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1dKTtcblxuICByZXR1cm4gT3B0aW9ucztcbn0pKCk7XG5cbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ0RPTUNvbnRlbnRMb2FkZWQnLCBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgdmFyIG9wdGlvbnMgPSBuZXcgT3B0aW9ucygpO1xuICBvcHRpb25zLnJlc3RvcmUoKTtcbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3NhdmUnKS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGZ1bmN0aW9uIChldnQpIHtcbiAgICByZXR1cm4gb3B0aW9ucy5zYXZlKCk7XG4gIH0pO1xuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbWVtb3JpemUnKS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGZ1bmN0aW9uIChldnQpIHtcbiAgICByZXR1cm4gb3B0aW9ucy5tZW1vcml6ZSgpO1xuICB9KTtcbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3NpZ25pbkJ0bicpLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgZnVuY3Rpb24gKGV2dCkge1xuICAgIHJldHVybiBvcHRpb25zLnNpZ25pbigpO1xuICB9KTtcbiAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI3Jldm9rZScpLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgZnVuY3Rpb24gKGV2dCkge1xuICAgIHJldHVybiBvcHRpb25zLnJldm9rZShldnQpO1xuICB9KTtcbn0pO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9b3B0aW9ucy5qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuXG52YXIgX2NyZWF0ZUNsYXNzID0gKGZ1bmN0aW9uICgpIHsgZnVuY3Rpb24gZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIHByb3BzKSB7IGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpKyspIHsgdmFyIGRlc2NyaXB0b3IgPSBwcm9wc1tpXTsgZGVzY3JpcHRvci5lbnVtZXJhYmxlID0gZGVzY3JpcHRvci5lbnVtZXJhYmxlIHx8IGZhbHNlOyBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSA9IHRydWU7IGlmIChcInZhbHVlXCIgaW4gZGVzY3JpcHRvcikgZGVzY3JpcHRvci53cml0YWJsZSA9IHRydWU7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGRlc2NyaXB0b3Iua2V5LCBkZXNjcmlwdG9yKTsgfSB9IHJldHVybiBmdW5jdGlvbiAoQ29uc3RydWN0b3IsIHByb3RvUHJvcHMsIHN0YXRpY1Byb3BzKSB7IGlmIChwcm90b1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLnByb3RvdHlwZSwgcHJvdG9Qcm9wcyk7IGlmIChzdGF0aWNQcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvciwgc3RhdGljUHJvcHMpOyByZXR1cm4gQ29uc3RydWN0b3I7IH07IH0pKCk7XG5cbmZ1bmN0aW9uIF9jbGFzc0NhbGxDaGVjayhpbnN0YW5jZSwgQ29uc3RydWN0b3IpIHsgaWYgKCEoaW5zdGFuY2UgaW5zdGFuY2VvZiBDb25zdHJ1Y3RvcikpIHsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvblwiKTsgfSB9XG5cbnZhciBVdGlscyA9IChmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIFV0aWxzKCkge1xuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBVdGlscyk7XG4gIH1cblxuICBfY3JlYXRlQ2xhc3MoVXRpbHMsIFt7XG4gICAga2V5OiBcInJlcXVlc3RcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gcmVxdWVzdCh0eXBlLCB1cmwsIG9wdHMpIHtcbiAgICAgIC8vIFJldHVybiBhIG5ldyBwcm9taXNlLlxuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgLy8gRG8gdGhlIHVzdWFsIFhIUiBzdHVmZlxuICAgICAgICB2YXIgcmVxID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgIHJlcS53aXRoQ3JlZGVudGlhbHMgPSB0cnVlO1xuICAgICAgICByZXEub3Blbih0eXBlLCB1cmwpO1xuICAgICAgICBpZiAodHlwZSA9PSAnUE9TVCcpIHtcbiAgICAgICAgICByZXEuc2V0UmVxdWVzdEhlYWRlcihcIkNvbnRlbnQtVHlwZVwiLCBcImFwcGxpY2F0aW9uL2pzb25cIik7XG4gICAgICAgIH1cbiAgICAgICAgcmVxLm9ubG9hZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAvLyBUaGlzIGlzIGNhbGxlZCBldmVuIG9uIDQwNCBldGNcbiAgICAgICAgICAvLyBzbyBjaGVjayB0aGUgc3RhdHVzXG4gICAgICAgICAgaWYgKHJlcS5zdGF0dXMgPT0gMjAwKSB7XG4gICAgICAgICAgICAvLyBSZXNvbHZlIHRoZSBwcm9taXNlIHdpdGggdGhlIHJlc3BvbnNlIHRleHRcbiAgICAgICAgICAgIHJlc29sdmUocmVxLnJlc3BvbnNlKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gT3RoZXJ3aXNlIHJlamVjdCB3aXRoIHRoZSBzdGF0dXMgdGV4dFxuICAgICAgICAgICAgLy8gd2hpY2ggd2lsbCBob3BlZnVsbHkgYmUgYSBtZWFuaW5nZnVsIGVycm9yXG4gICAgICAgICAgICByZWplY3QoRXJyb3IocmVxLnN0YXR1c1RleHQpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gSGFuZGxlIG5ldHdvcmsgZXJyb3JzXG4gICAgICAgIHJlcS5vbmVycm9yID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHJlamVjdChFcnJvcihcIk5ldHdvcmsgRXJyb3JcIikpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8vIFNldCBoZWFkZXJzXG4gICAgICAgIGlmIChvcHRzLmhlYWRlcnMpIHtcbiAgICAgICAgICB2YXIgX2l0ZXJhdG9yTm9ybWFsQ29tcGxldGlvbiA9IHRydWU7XG4gICAgICAgICAgdmFyIF9kaWRJdGVyYXRvckVycm9yID0gZmFsc2U7XG4gICAgICAgICAgdmFyIF9pdGVyYXRvckVycm9yID0gdW5kZWZpbmVkO1xuXG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGZvciAodmFyIF9pdGVyYXRvciA9IE9iamVjdC5rZXlzKG9wdHMuaGVhZGVycylbU3ltYm9sLml0ZXJhdG9yXSgpLCBfc3RlcDsgIShfaXRlcmF0b3JOb3JtYWxDb21wbGV0aW9uID0gKF9zdGVwID0gX2l0ZXJhdG9yLm5leHQoKSkuZG9uZSk7IF9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gPSB0cnVlKSB7XG4gICAgICAgICAgICAgIHZhciBrZXkgPSBfc3RlcC52YWx1ZTtcblxuICAgICAgICAgICAgICByZXEuc2V0UmVxdWVzdEhlYWRlcihrZXksIG9wdHMuaGVhZGVyc1trZXldKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIF9kaWRJdGVyYXRvckVycm9yID0gdHJ1ZTtcbiAgICAgICAgICAgIF9pdGVyYXRvckVycm9yID0gZXJyO1xuICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICBpZiAoIV9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gJiYgX2l0ZXJhdG9yW1wicmV0dXJuXCJdKSB7XG4gICAgICAgICAgICAgICAgX2l0ZXJhdG9yW1wicmV0dXJuXCJdKCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgIGlmIChfZGlkSXRlcmF0b3JFcnJvcikge1xuICAgICAgICAgICAgICAgIHRocm93IF9pdGVyYXRvckVycm9yO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIE1ha2UgdGhlIHJlcXVlc3RcbiAgICAgICAgcmVxLnNlbmQoSlNPTi5zdHJpbmdpZnkob3B0cy5kYXRhKSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6IFwiZ2V0XCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGdldCh1cmwpIHtcbiAgICAgIHZhciBvcHRzID0gYXJndW1lbnRzLmxlbmd0aCA8PSAxIHx8IGFyZ3VtZW50c1sxXSA9PT0gdW5kZWZpbmVkID8geyBkYXRhOiAnJyB9IDogYXJndW1lbnRzWzFdO1xuXG4gICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KCdHRVQnLCB1cmwsIG9wdHMpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogXCJwb3N0XCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHBvc3QodXJsKSB7XG4gICAgICB2YXIgb3B0cyA9IGFyZ3VtZW50cy5sZW5ndGggPD0gMSB8fCBhcmd1bWVudHNbMV0gPT09IHVuZGVmaW5lZCA/IHsgZGF0YTogJycgfSA6IGFyZ3VtZW50c1sxXTtcblxuICAgICAgcmV0dXJuIHRoaXMucmVxdWVzdCgnUE9TVCcsIHVybCwgb3B0cyk7XG4gICAgfVxuICB9XSk7XG5cbiAgcmV0dXJuIFV0aWxzO1xufSkoKTtcblxubW9kdWxlLmV4cG9ydHMgPSBuZXcgVXRpbHMoKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXV0aWxzLmpzLm1hcFxuIl19
