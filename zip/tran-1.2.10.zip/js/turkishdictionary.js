(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
// turkishdictionary codings
'use strict';

var DICT = {
    350: '%DE', //Ş
    286: '%D0', //Ğ
    287: '%F0', //ğ
    351: '%FE', //ş
    305: '%FD', //ı
    304: '%DD', //İ
    252: '%FC', //ü
    220: '%DC', //Ü
    231: '%E7', //ç
    199: '%C7', //Ç
    246: '%F6', //ö
    244: '%F4', //ô
    214: '%D6', //Ö
    212: '%D4', //Ô
    251: '%FB', //û
    219: '%DB', //Û
    194: '%C2', //Â
    226: '%E2', //â
    39: '' };

//'
module.exports = DICT;
//# sourceMappingURL=char-codes-turk.js.map

},{}],2:[function(require,module,exports){
/*
  Translation engine: http://www.turkishdictionary.net
  For translating turkish-russian and vice versa
*/
'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var CHAR_CODES = require('./char-codes-turk.js');

var TurkishDictionary = (function () {
  function TurkishDictionary() {
    _classCallCheck(this, TurkishDictionary);

    this.host = 'http://www.turkishdictionary.net/?word=%FC';
    this.path = '';
    this.protocol = 'http';
    this.query = '&s=';
    this.TABLE_CLASS = '___mtt_translate_table';
    // this flag indicates that if translation was successful then publish it all over extension
    this.need_publish = true;
  }

  // Singletone

  _createClass(TurkishDictionary, [{
    key: 'search',
    value: function search(data) {
      data.url = this.makeUrl(data.value);
      this.need_publish = false;
      return this.request(data);
    }
  }, {
    key: 'translate',
    value: function translate(data) {
      data.url = this.makeUrl(data.selectionText);
      this.need_publish = true;
      this.request(data);
    }
  }, {
    key: 'makeUrl',
    value: function makeUrl(text) {
      var text = this.getEncodedValue(text);
      return ['http://www.turkishdictionary.net/?word=', text].join('');
    }

    // Replace special language characters to html codes
  }, {
    key: 'getEncodedValue',
    value: function getEncodedValue(value) {
      // to find spec symbols we first encode them (raw search for that symbol doesn't wor)
      return encodeURIComponent(value);
      //return this.makeStringTransferable(value);
    }

    /** converting script from the turkishdict */
  }, {
    key: 'makeStringTransferable',
    value: function makeStringTransferable(inputText) {
      var text = "";
      if (inputText.length > 0) {
        text = inputText;
        for (var i = 0; i < text.length; i++) {
          if (CHAR_CODES[text.charCodeAt(i)]) {
            text = text.substring(0, i) + CHAR_CODES[text.charCodeAt(i)] + text.substring(i + 1, text.length);
          } else if (text.charAt(i) == ' ') {
            // replace spaces
            text = text.substring(0, i) + '___' + text.substring(i + 1, text.length);
          }
        }
      }
      return text;
    }

    /*
      Request translation and run callback function
      passing translated result or error to callback
    */
  }, {
    key: 'request',
    value: function request(opts) {
      console.log('start request');
      this.xhr = new XMLHttpRequest();
      this.xhr.onreadystatechange = this.onReadyStateChange.bind(this, opts);
      this.xhr.open("GET", opts.url, true);
      this.xhr.send();
    }
  }, {
    key: 'onReadyStateChange',
    value: function onReadyStateChange(opts, e) {
      var xhr = this.xhr;
      if (xhr.readyState < 4) {
        return;
      } else if (xhr.status != 200) {
        this.errorHandler(xhr);
        return opts.error && opts.error();
      } else if (xhr.readyState == 4) {
        var translation = this.successHandler(e.target.response);
        console.log('success turkish translate', translation);
        console.log('call', opts.success);
        return opts.success && opts.success(translation);
      }
    }
  }, {
    key: 'successHandler',
    value: function successHandler(response) {
      var data = this.parse(response);
      if (this.need_publish) {
        chrome.tabs.getSelected(null, this.publishTranslation.bind(this, data));
      }
      return data;
    }

    /* publish successfuly translated text all over extension */
  }, {
    key: 'publishTranslation',
    value: function publishTranslation(translation, tab) {
      console.log('publish translation');
      chrome.tabs.sendMessage(tab.id, {
        action: this.tooltipAction(translation),
        data: translation.outerHTML,
        success: !translation.classList.contains('failTranslate')
      });
    }
  }, {
    key: 'tooltipAction',
    value: function tooltipAction(translation) {
      if (translation.textContent.trim().indexOf('was not found in our dictionary') != -1) {
        console.log('similar words');
        return 'similar_words';
      } else {
        console.log('open tooltip');
        return 'open_tooltip';
      }
    }
  }, {
    key: 'errorHandler',
    value: function errorHandler(response) {
      console.log('error ajax', response);
    }

    /* Parse response from translation engine */
  }, {
    key: 'parse',
    value: function parse(response, silent, translate) {
      var doc = this.stripScripts(response),
          fragment = this.makeFragment(doc);
      if (fragment) {
        translate = fragment.querySelector('#meaning_div > table');
        if (translate) {
          translate.className = this.TABLE_CLASS;
          translate.setAttribute("cellpadding", "5");
          // @fixImages(translate)
          // @fixLinks(translate)
        } else if (!silent) {
            translate = document.createElement('div');
            translate.className = 'failTranslate';
            translate.innerText = "Unfortunately, could not translate";
          }
      }
      return translate;
    }

    /** parsing of terrible html markup */
  }, {
    key: 'parseText',
    value: function parseText(response, silent, translate) {
      var _this = this;

      var doc = this.stripScripts(response),
          fragment = this.makeFragment(doc);

      if (fragment) {
        var i;

        var _ret = (function () {
          var stopIndex = null;
          var tr = fragment.querySelectorAll('#meaning_div>table>tbody>tr');
          tr = Array.prototype.slice.call(tr);

          var trans = tr.filter(function (tr, index) {
            if (!isNaN(parseInt(stopIndex, 10)) && index >= stopIndex) {
              return;
            } else {
              tr = $(tr);
              // take every row before next section (which is English->English)
              if (tr.attr('bgcolor') == "e0e6ff") {
                stopIndex = index;return;
              } else {
                return $.trim(tr.find('td').text()).length;
              }
            }
          });
          trans = trans.slice(1, trans.length - 1);
          trans = trans.filter(function (el, indx) {
            return indx % 2;
          });
          var frag = _this.fragmentFromList(trans);
          var fonts = frag.querySelectorAll('font');
          var text = '';
          for (i = 0; i < fonts.length; i++) {
            text += ' ' + fonts[i].textContent.trim();
          }
          return {
            v: text
          };
        })();

        if (typeof _ret === 'object') return _ret.v;
      } else {
        throw "HTML fragment could not be parsed";
      }
    }

    //TODO extract to base engine class
    /* removes <script> tags from html code */
  }, {
    key: 'stripScripts',
    value: function stripScripts(html) {
      var div = document.createElement('div');
      div.innerHTML = html;
      var scripts = div.getElementsByTagName('script');
      var i = scripts.length;
      while (i--) scripts[i].parentNode.removeChild(scripts[i]);
      return div.innerHTML;
    }

    //TODO extract to base engine class
    /* creates temp object to parse translation from page 
      (since it's not a friendly api) 
    */
  }, {
    key: 'makeFragment',
    value: function makeFragment(html) {
      var fragment = document.createDocumentFragment(),
          div = document.createElement("div");
      div.innerHTML = html;
      while (div.firstChild) {
        fragment.appendChild(div.firstChild);
      }
      return fragment;
    }

    /** create fragment from list of DOM elements */
  }, {
    key: 'fragmentFromList',
    value: function fragmentFromList(list) {
      var fragment = document.createDocumentFragment(),
          len = list.length;
      while (len--) {
        fragment.appendChild(list[len]);
      }
      return fragment;
    }
  }]);

  return TurkishDictionary;
})();

module.exports = new TurkishDictionary();
//# sourceMappingURL=turkishdictionary.js.map

},{"./char-codes-turk.js":1}]},{},[2])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvZXM1L2NoYXItY29kZXMtdHVyay5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvZXM1L3R1cmtpc2hkaWN0aW9uYXJ5LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDM0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpfXZhciBmPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChmLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGYsZi5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCIvLyB0dXJraXNoZGljdGlvbmFyeSBjb2RpbmdzXG4ndXNlIHN0cmljdCc7XG5cbnZhciBESUNUID0ge1xuICAgIDM1MDogJyVERScsIC8vxZ5cbiAgICAyODY6ICclRDAnLCAvL8SeXG4gICAgMjg3OiAnJUYwJywgLy/En1xuICAgIDM1MTogJyVGRScsIC8vxZ9cbiAgICAzMDU6ICclRkQnLCAvL8SxXG4gICAgMzA0OiAnJUREJywgLy/EsFxuICAgIDI1MjogJyVGQycsIC8vw7xcbiAgICAyMjA6ICclREMnLCAvL8OcXG4gICAgMjMxOiAnJUU3JywgLy/Dp1xuICAgIDE5OTogJyVDNycsIC8vw4dcbiAgICAyNDY6ICclRjYnLCAvL8O2XG4gICAgMjQ0OiAnJUY0JywgLy/DtFxuICAgIDIxNDogJyVENicsIC8vw5ZcbiAgICAyMTI6ICclRDQnLCAvL8OUXG4gICAgMjUxOiAnJUZCJywgLy/Du1xuICAgIDIxOTogJyVEQicsIC8vw5tcbiAgICAxOTQ6ICclQzInLCAvL8OCXG4gICAgMjI2OiAnJUUyJywgLy/DolxuICAgIDM5OiAnJyB9O1xuXG4vLydcbm1vZHVsZS5leHBvcnRzID0gRElDVDtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNoYXItY29kZXMtdHVyay5qcy5tYXBcbiIsIi8qXG4gIFRyYW5zbGF0aW9uIGVuZ2luZTogaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXRcbiAgRm9yIHRyYW5zbGF0aW5nIHR1cmtpc2gtcnVzc2lhbiBhbmQgdmljZSB2ZXJzYVxuKi9cbid1c2Ugc3RyaWN0JztcblxudmFyIF9jcmVhdGVDbGFzcyA9IChmdW5jdGlvbiAoKSB7IGZ1bmN0aW9uIGRlZmluZVByb3BlcnRpZXModGFyZ2V0LCBwcm9wcykgeyBmb3IgKHZhciBpID0gMDsgaSA8IHByb3BzLmxlbmd0aDsgaSsrKSB7IHZhciBkZXNjcmlwdG9yID0gcHJvcHNbaV07IGRlc2NyaXB0b3IuZW51bWVyYWJsZSA9IGRlc2NyaXB0b3IuZW51bWVyYWJsZSB8fCBmYWxzZTsgZGVzY3JpcHRvci5jb25maWd1cmFibGUgPSB0cnVlOyBpZiAoJ3ZhbHVlJyBpbiBkZXNjcmlwdG9yKSBkZXNjcmlwdG9yLndyaXRhYmxlID0gdHJ1ZTsgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgZGVzY3JpcHRvci5rZXksIGRlc2NyaXB0b3IpOyB9IH0gcmV0dXJuIGZ1bmN0aW9uIChDb25zdHJ1Y3RvciwgcHJvdG9Qcm9wcywgc3RhdGljUHJvcHMpIHsgaWYgKHByb3RvUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IucHJvdG90eXBlLCBwcm90b1Byb3BzKTsgaWYgKHN0YXRpY1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLCBzdGF0aWNQcm9wcyk7IHJldHVybiBDb25zdHJ1Y3RvcjsgfTsgfSkoKTtcblxuZnVuY3Rpb24gX2NsYXNzQ2FsbENoZWNrKGluc3RhbmNlLCBDb25zdHJ1Y3RvcikgeyBpZiAoIShpbnN0YW5jZSBpbnN0YW5jZW9mIENvbnN0cnVjdG9yKSkgeyB0aHJvdyBuZXcgVHlwZUVycm9yKCdDYW5ub3QgY2FsbCBhIGNsYXNzIGFzIGEgZnVuY3Rpb24nKTsgfSB9XG5cbnZhciBDSEFSX0NPREVTID0gcmVxdWlyZSgnLi9jaGFyLWNvZGVzLXR1cmsuanMnKTtcblxudmFyIFR1cmtpc2hEaWN0aW9uYXJ5ID0gKGZ1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gVHVya2lzaERpY3Rpb25hcnkoKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIFR1cmtpc2hEaWN0aW9uYXJ5KTtcblxuICAgIHRoaXMuaG9zdCA9ICdodHRwOi8vd3d3LnR1cmtpc2hkaWN0aW9uYXJ5Lm5ldC8/d29yZD0lRkMnO1xuICAgIHRoaXMucGF0aCA9ICcnO1xuICAgIHRoaXMucHJvdG9jb2wgPSAnaHR0cCc7XG4gICAgdGhpcy5xdWVyeSA9ICcmcz0nO1xuICAgIHRoaXMuVEFCTEVfQ0xBU1MgPSAnX19fbXR0X3RyYW5zbGF0ZV90YWJsZSc7XG4gICAgLy8gdGhpcyBmbGFnIGluZGljYXRlcyB0aGF0IGlmIHRyYW5zbGF0aW9uIHdhcyBzdWNjZXNzZnVsIHRoZW4gcHVibGlzaCBpdCBhbGwgb3ZlciBleHRlbnNpb25cbiAgICB0aGlzLm5lZWRfcHVibGlzaCA9IHRydWU7XG4gIH1cblxuICAvLyBTaW5nbGV0b25lXG5cbiAgX2NyZWF0ZUNsYXNzKFR1cmtpc2hEaWN0aW9uYXJ5LCBbe1xuICAgIGtleTogJ3NlYXJjaCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHNlYXJjaChkYXRhKSB7XG4gICAgICBkYXRhLnVybCA9IHRoaXMubWFrZVVybChkYXRhLnZhbHVlKTtcbiAgICAgIHRoaXMubmVlZF9wdWJsaXNoID0gZmFsc2U7XG4gICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KGRhdGEpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3RyYW5zbGF0ZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHRyYW5zbGF0ZShkYXRhKSB7XG4gICAgICBkYXRhLnVybCA9IHRoaXMubWFrZVVybChkYXRhLnNlbGVjdGlvblRleHQpO1xuICAgICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSB0cnVlO1xuICAgICAgdGhpcy5yZXF1ZXN0KGRhdGEpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ21ha2VVcmwnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlVXJsKHRleHQpIHtcbiAgICAgIHZhciB0ZXh0ID0gdGhpcy5nZXRFbmNvZGVkVmFsdWUodGV4dCk7XG4gICAgICByZXR1cm4gWydodHRwOi8vd3d3LnR1cmtpc2hkaWN0aW9uYXJ5Lm5ldC8/d29yZD0nLCB0ZXh0XS5qb2luKCcnKTtcbiAgICB9XG5cbiAgICAvLyBSZXBsYWNlIHNwZWNpYWwgbGFuZ3VhZ2UgY2hhcmFjdGVycyB0byBodG1sIGNvZGVzXG4gIH0sIHtcbiAgICBrZXk6ICdnZXRFbmNvZGVkVmFsdWUnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBnZXRFbmNvZGVkVmFsdWUodmFsdWUpIHtcbiAgICAgIC8vIHRvIGZpbmQgc3BlYyBzeW1ib2xzIHdlIGZpcnN0IGVuY29kZSB0aGVtIChyYXcgc2VhcmNoIGZvciB0aGF0IHN5bWJvbCBkb2Vzbid0IHdvcilcbiAgICAgIHJldHVybiBlbmNvZGVVUklDb21wb25lbnQodmFsdWUpO1xuICAgICAgLy9yZXR1cm4gdGhpcy5tYWtlU3RyaW5nVHJhbnNmZXJhYmxlKHZhbHVlKTtcbiAgICB9XG5cbiAgICAvKiogY29udmVydGluZyBzY3JpcHQgZnJvbSB0aGUgdHVya2lzaGRpY3QgKi9cbiAgfSwge1xuICAgIGtleTogJ21ha2VTdHJpbmdUcmFuc2ZlcmFibGUnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlU3RyaW5nVHJhbnNmZXJhYmxlKGlucHV0VGV4dCkge1xuICAgICAgdmFyIHRleHQgPSBcIlwiO1xuICAgICAgaWYgKGlucHV0VGV4dC5sZW5ndGggPiAwKSB7XG4gICAgICAgIHRleHQgPSBpbnB1dFRleHQ7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGV4dC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGlmIChDSEFSX0NPREVTW3RleHQuY2hhckNvZGVBdChpKV0pIHtcbiAgICAgICAgICAgIHRleHQgPSB0ZXh0LnN1YnN0cmluZygwLCBpKSArIENIQVJfQ09ERVNbdGV4dC5jaGFyQ29kZUF0KGkpXSArIHRleHQuc3Vic3RyaW5nKGkgKyAxLCB0ZXh0Lmxlbmd0aCk7XG4gICAgICAgICAgfSBlbHNlIGlmICh0ZXh0LmNoYXJBdChpKSA9PSAnICcpIHtcbiAgICAgICAgICAgIC8vIHJlcGxhY2Ugc3BhY2VzXG4gICAgICAgICAgICB0ZXh0ID0gdGV4dC5zdWJzdHJpbmcoMCwgaSkgKyAnX19fJyArIHRleHQuc3Vic3RyaW5nKGkgKyAxLCB0ZXh0Lmxlbmd0aCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdGV4dDtcbiAgICB9XG5cbiAgICAvKlxuICAgICAgUmVxdWVzdCB0cmFuc2xhdGlvbiBhbmQgcnVuIGNhbGxiYWNrIGZ1bmN0aW9uXG4gICAgICBwYXNzaW5nIHRyYW5zbGF0ZWQgcmVzdWx0IG9yIGVycm9yIHRvIGNhbGxiYWNrXG4gICAgKi9cbiAgfSwge1xuICAgIGtleTogJ3JlcXVlc3QnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiByZXF1ZXN0KG9wdHMpIHtcbiAgICAgIGNvbnNvbGUubG9nKCdzdGFydCByZXF1ZXN0Jyk7XG4gICAgICB0aGlzLnhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgdGhpcy54aHIub25yZWFkeXN0YXRlY2hhbmdlID0gdGhpcy5vblJlYWR5U3RhdGVDaGFuZ2UuYmluZCh0aGlzLCBvcHRzKTtcbiAgICAgIHRoaXMueGhyLm9wZW4oXCJHRVRcIiwgb3B0cy51cmwsIHRydWUpO1xuICAgICAgdGhpcy54aHIuc2VuZCgpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ29uUmVhZHlTdGF0ZUNoYW5nZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG9uUmVhZHlTdGF0ZUNoYW5nZShvcHRzLCBlKSB7XG4gICAgICB2YXIgeGhyID0gdGhpcy54aHI7XG4gICAgICBpZiAoeGhyLnJlYWR5U3RhdGUgPCA0KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH0gZWxzZSBpZiAoeGhyLnN0YXR1cyAhPSAyMDApIHtcbiAgICAgICAgdGhpcy5lcnJvckhhbmRsZXIoeGhyKTtcbiAgICAgICAgcmV0dXJuIG9wdHMuZXJyb3IgJiYgb3B0cy5lcnJvcigpO1xuICAgICAgfSBlbHNlIGlmICh4aHIucmVhZHlTdGF0ZSA9PSA0KSB7XG4gICAgICAgIHZhciB0cmFuc2xhdGlvbiA9IHRoaXMuc3VjY2Vzc0hhbmRsZXIoZS50YXJnZXQucmVzcG9uc2UpO1xuICAgICAgICBjb25zb2xlLmxvZygnc3VjY2VzcyB0dXJraXNoIHRyYW5zbGF0ZScsIHRyYW5zbGF0aW9uKTtcbiAgICAgICAgY29uc29sZS5sb2coJ2NhbGwnLCBvcHRzLnN1Y2Nlc3MpO1xuICAgICAgICByZXR1cm4gb3B0cy5zdWNjZXNzICYmIG9wdHMuc3VjY2Vzcyh0cmFuc2xhdGlvbik7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnc3VjY2Vzc0hhbmRsZXInLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzdWNjZXNzSGFuZGxlcihyZXNwb25zZSkge1xuICAgICAgdmFyIGRhdGEgPSB0aGlzLnBhcnNlKHJlc3BvbnNlKTtcbiAgICAgIGlmICh0aGlzLm5lZWRfcHVibGlzaCkge1xuICAgICAgICBjaHJvbWUudGFicy5nZXRTZWxlY3RlZChudWxsLCB0aGlzLnB1Ymxpc2hUcmFuc2xhdGlvbi5iaW5kKHRoaXMsIGRhdGEpKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBkYXRhO1xuICAgIH1cblxuICAgIC8qIHB1Ymxpc2ggc3VjY2Vzc2Z1bHkgdHJhbnNsYXRlZCB0ZXh0IGFsbCBvdmVyIGV4dGVuc2lvbiAqL1xuICB9LCB7XG4gICAga2V5OiAncHVibGlzaFRyYW5zbGF0aW9uJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gcHVibGlzaFRyYW5zbGF0aW9uKHRyYW5zbGF0aW9uLCB0YWIpIHtcbiAgICAgIGNvbnNvbGUubG9nKCdwdWJsaXNoIHRyYW5zbGF0aW9uJyk7XG4gICAgICBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWIuaWQsIHtcbiAgICAgICAgYWN0aW9uOiB0aGlzLnRvb2x0aXBBY3Rpb24odHJhbnNsYXRpb24pLFxuICAgICAgICBkYXRhOiB0cmFuc2xhdGlvbi5vdXRlckhUTUwsXG4gICAgICAgIHN1Y2Nlc3M6ICF0cmFuc2xhdGlvbi5jbGFzc0xpc3QuY29udGFpbnMoJ2ZhaWxUcmFuc2xhdGUnKVxuICAgICAgfSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAndG9vbHRpcEFjdGlvbicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHRvb2x0aXBBY3Rpb24odHJhbnNsYXRpb24pIHtcbiAgICAgIGlmICh0cmFuc2xhdGlvbi50ZXh0Q29udGVudC50cmltKCkuaW5kZXhPZignd2FzIG5vdCBmb3VuZCBpbiBvdXIgZGljdGlvbmFyeScpICE9IC0xKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdzaW1pbGFyIHdvcmRzJyk7XG4gICAgICAgIHJldHVybiAnc2ltaWxhcl93b3Jkcyc7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZygnb3BlbiB0b29sdGlwJyk7XG4gICAgICAgIHJldHVybiAnb3Blbl90b29sdGlwJztcbiAgICAgIH1cbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdlcnJvckhhbmRsZXInLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBlcnJvckhhbmRsZXIocmVzcG9uc2UpIHtcbiAgICAgIGNvbnNvbGUubG9nKCdlcnJvciBhamF4JywgcmVzcG9uc2UpO1xuICAgIH1cblxuICAgIC8qIFBhcnNlIHJlc3BvbnNlIGZyb20gdHJhbnNsYXRpb24gZW5naW5lICovXG4gIH0sIHtcbiAgICBrZXk6ICdwYXJzZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHBhcnNlKHJlc3BvbnNlLCBzaWxlbnQsIHRyYW5zbGF0ZSkge1xuICAgICAgdmFyIGRvYyA9IHRoaXMuc3RyaXBTY3JpcHRzKHJlc3BvbnNlKSxcbiAgICAgICAgICBmcmFnbWVudCA9IHRoaXMubWFrZUZyYWdtZW50KGRvYyk7XG4gICAgICBpZiAoZnJhZ21lbnQpIHtcbiAgICAgICAgdHJhbnNsYXRlID0gZnJhZ21lbnQucXVlcnlTZWxlY3RvcignI21lYW5pbmdfZGl2ID4gdGFibGUnKTtcbiAgICAgICAgaWYgKHRyYW5zbGF0ZSkge1xuICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSB0aGlzLlRBQkxFX0NMQVNTO1xuICAgICAgICAgIHRyYW5zbGF0ZS5zZXRBdHRyaWJ1dGUoXCJjZWxscGFkZGluZ1wiLCBcIjVcIik7XG4gICAgICAgICAgLy8gQGZpeEltYWdlcyh0cmFuc2xhdGUpXG4gICAgICAgICAgLy8gQGZpeExpbmtzKHRyYW5zbGF0ZSlcbiAgICAgICAgfSBlbHNlIGlmICghc2lsZW50KSB7XG4gICAgICAgICAgICB0cmFuc2xhdGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSAnZmFpbFRyYW5zbGF0ZSc7XG4gICAgICAgICAgICB0cmFuc2xhdGUuaW5uZXJUZXh0ID0gXCJVbmZvcnR1bmF0ZWx5LCBjb3VsZCBub3QgdHJhbnNsYXRlXCI7XG4gICAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRyYW5zbGF0ZTtcbiAgICB9XG5cbiAgICAvKiogcGFyc2luZyBvZiB0ZXJyaWJsZSBodG1sIG1hcmt1cCAqL1xuICB9LCB7XG4gICAga2V5OiAncGFyc2VUZXh0JyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gcGFyc2VUZXh0KHJlc3BvbnNlLCBzaWxlbnQsIHRyYW5zbGF0ZSkge1xuICAgICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgICAgdmFyIGRvYyA9IHRoaXMuc3RyaXBTY3JpcHRzKHJlc3BvbnNlKSxcbiAgICAgICAgICBmcmFnbWVudCA9IHRoaXMubWFrZUZyYWdtZW50KGRvYyk7XG5cbiAgICAgIGlmIChmcmFnbWVudCkge1xuICAgICAgICB2YXIgaTtcblxuICAgICAgICB2YXIgX3JldCA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdmFyIHN0b3BJbmRleCA9IG51bGw7XG4gICAgICAgICAgdmFyIHRyID0gZnJhZ21lbnQucXVlcnlTZWxlY3RvckFsbCgnI21lYW5pbmdfZGl2PnRhYmxlPnRib2R5PnRyJyk7XG4gICAgICAgICAgdHIgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbCh0cik7XG5cbiAgICAgICAgICB2YXIgdHJhbnMgPSB0ci5maWx0ZXIoZnVuY3Rpb24gKHRyLCBpbmRleCkge1xuICAgICAgICAgICAgaWYgKCFpc05hTihwYXJzZUludChzdG9wSW5kZXgsIDEwKSkgJiYgaW5kZXggPj0gc3RvcEluZGV4KSB7XG4gICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHRyID0gJCh0cik7XG4gICAgICAgICAgICAgIC8vIHRha2UgZXZlcnkgcm93IGJlZm9yZSBuZXh0IHNlY3Rpb24gKHdoaWNoIGlzIEVuZ2xpc2gtPkVuZ2xpc2gpXG4gICAgICAgICAgICAgIGlmICh0ci5hdHRyKCdiZ2NvbG9yJykgPT0gXCJlMGU2ZmZcIikge1xuICAgICAgICAgICAgICAgIHN0b3BJbmRleCA9IGluZGV4O3JldHVybjtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJC50cmltKHRyLmZpbmQoJ3RkJykudGV4dCgpKS5sZW5ndGg7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgICB0cmFucyA9IHRyYW5zLnNsaWNlKDEsIHRyYW5zLmxlbmd0aCAtIDEpO1xuICAgICAgICAgIHRyYW5zID0gdHJhbnMuZmlsdGVyKGZ1bmN0aW9uIChlbCwgaW5keCkge1xuICAgICAgICAgICAgcmV0dXJuIGluZHggJSAyO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIHZhciBmcmFnID0gX3RoaXMuZnJhZ21lbnRGcm9tTGlzdCh0cmFucyk7XG4gICAgICAgICAgdmFyIGZvbnRzID0gZnJhZy5xdWVyeVNlbGVjdG9yQWxsKCdmb250Jyk7XG4gICAgICAgICAgdmFyIHRleHQgPSAnJztcbiAgICAgICAgICBmb3IgKGkgPSAwOyBpIDwgZm9udHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHRleHQgKz0gJyAnICsgZm9udHNbaV0udGV4dENvbnRlbnQudHJpbSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdjogdGV4dFxuICAgICAgICAgIH07XG4gICAgICAgIH0pKCk7XG5cbiAgICAgICAgaWYgKHR5cGVvZiBfcmV0ID09PSAnb2JqZWN0JykgcmV0dXJuIF9yZXQudjtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IFwiSFRNTCBmcmFnbWVudCBjb3VsZCBub3QgYmUgcGFyc2VkXCI7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy9UT0RPIGV4dHJhY3QgdG8gYmFzZSBlbmdpbmUgY2xhc3NcbiAgICAvKiByZW1vdmVzIDxzY3JpcHQ+IHRhZ3MgZnJvbSBodG1sIGNvZGUgKi9cbiAgfSwge1xuICAgIGtleTogJ3N0cmlwU2NyaXB0cycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHN0cmlwU2NyaXB0cyhodG1sKSB7XG4gICAgICB2YXIgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcbiAgICAgIHZhciBzY3JpcHRzID0gZGl2LmdldEVsZW1lbnRzQnlUYWdOYW1lKCdzY3JpcHQnKTtcbiAgICAgIHZhciBpID0gc2NyaXB0cy5sZW5ndGg7XG4gICAgICB3aGlsZSAoaS0tKSBzY3JpcHRzW2ldLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc2NyaXB0c1tpXSk7XG4gICAgICByZXR1cm4gZGl2LmlubmVySFRNTDtcbiAgICB9XG5cbiAgICAvL1RPRE8gZXh0cmFjdCB0byBiYXNlIGVuZ2luZSBjbGFzc1xuICAgIC8qIGNyZWF0ZXMgdGVtcCBvYmplY3QgdG8gcGFyc2UgdHJhbnNsYXRpb24gZnJvbSBwYWdlIFxuICAgICAgKHNpbmNlIGl0J3Mgbm90IGEgZnJpZW5kbHkgYXBpKSBcbiAgICAqL1xuICB9LCB7XG4gICAga2V5OiAnbWFrZUZyYWdtZW50JyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZUZyYWdtZW50KGh0bWwpIHtcbiAgICAgIHZhciBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKSxcbiAgICAgICAgICBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgZGl2LmlubmVySFRNTCA9IGh0bWw7XG4gICAgICB3aGlsZSAoZGl2LmZpcnN0Q2hpbGQpIHtcbiAgICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoZGl2LmZpcnN0Q2hpbGQpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZyYWdtZW50O1xuICAgIH1cblxuICAgIC8qKiBjcmVhdGUgZnJhZ21lbnQgZnJvbSBsaXN0IG9mIERPTSBlbGVtZW50cyAqL1xuICB9LCB7XG4gICAga2V5OiAnZnJhZ21lbnRGcm9tTGlzdCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGZyYWdtZW50RnJvbUxpc3QobGlzdCkge1xuICAgICAgdmFyIGZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpLFxuICAgICAgICAgIGxlbiA9IGxpc3QubGVuZ3RoO1xuICAgICAgd2hpbGUgKGxlbi0tKSB7XG4gICAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKGxpc3RbbGVuXSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgfVxuICB9XSk7XG5cbiAgcmV0dXJuIFR1cmtpc2hEaWN0aW9uYXJ5O1xufSkoKTtcblxubW9kdWxlLmV4cG9ydHMgPSBuZXcgVHVya2lzaERpY3Rpb25hcnkoKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXR1cmtpc2hkaWN0aW9uYXJ5LmpzLm1hcFxuIl19
