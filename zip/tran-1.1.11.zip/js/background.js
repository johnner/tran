(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){

/*global tran, chrome */
var CHAR_CODES, tran, turkishDictionary;

CHAR_CODES = require('./char-codes.js');

tran = require('./tran.coffee');

turkishDictionary = require('./turkishdictionary.js');

chrome.contextMenus.create({
  title: 'Multitran: "%s"',
  contexts: ["page", "frame", "editable", "image", "video", "audio", "link", "selection"],
  onclick: function(data) {
    data.silent = false;
    return tran.click(data);
  }
});


/*
 Can't get chrome.storage directly from content_script
 so content_script sends request message and then background script
 responds with storage value
 */

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.method === "get_fast_option") {
    chrome.storage.sync.get({
      fast: true
    }, function(items) {
      return sendResponse({
        fast: items.fast
      });
    });
  } else if (request.method === 'request_search') {
    chrome.storage.sync.get({
      language: '1',
      fast: true
    }, function(items) {
      request.data.silent = true;
      if (parseInt(items.language, 10) === 1000) {
        turkishDictionary.translate(request.data);
      } else {
        tran.click(request.data);
      }
      return true;
    });
  }
  return true;
});


},{"./char-codes.js":3,"./tran.coffee":4,"./turkishdictionary.js":5}],2:[function(require,module,exports){
var CHAR_CODES = {
  // turkishdictionary codings
  '%C4%B1': '%FD', //ı (Lowercase i-dotless)  actually it is &#305; but turkishdictionary need it this way 
  '%C5%9F': '%FE', //ş
  '%C4%9F': '%F0', //ğ  (silent character)
  '%C3%A7': '%E7', //ç
  '%C3%B6': '%F6', //ö
  '%C3%BC': '%FC' //ü
}

module.exports = CHAR_CODES;
},{}],3:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/var CHAR_CODES = {  '%C3%80': '&#192;', // À  '%C3%81': '&#193;', // Á  '%C3%82': '&#194;', // Â  '%C3%83': '&#195;', // Ã  '%C3%84': '&#196;', // Ä  '%C3%85': '&#197;', // Å  '%C3%86': '&#198;', // Æ  '%C3%87': '&#199;', // Ç  '%C3%88': '&#200;', // È  '%C3%89': '&#201;', // É  '%C3%8A': '&#202;', // Ê  '%C3%8B': '&#203;', // Ë  '%C3%8C': '&#204;', // Ì  '%C3%8D': '&#205;', // Í  '%C3%8E': '&#206;', // Î  '%C3%8F': '&#207;', // Ï  '%C3%91': '&#209;', // Ñ  '%C3%92': '&#210;', // Ò  '%C3%93': '&#211;', // Ó  '%C3%94': '&#212;', // Ô  '%C3%95': '&#213;', // Õ  '%C3%96': '&#214;', // Ö  '%C3%99': '&#217;', // Ù  '%C3%9A': '&#218;', // Ú  '%C3%9B': '&#219;', // Û  '%C3%9C': '&#220;', // Ü  '%C3%A0': '&#224;', // à  '%C3%A1': '&#225;', // á  '%C3%A2': '&#226;', // â  '%C3%A3': '&#227;', // ã  '%C3%A4': '&#228;', // ä  '%C3%A5': '&#229;', // å  '%C3%A6': '&#230;', // æ  '%C3%A7': '&#231;', // ç  '%C3%A8': '&#232;', // è  '%C3%A9': '&#233;', // é  '%C3%AA': '&#234;', // ê  '%C3%AB': '&#235;', // ë  '%C3%AC': '&#236;', // ì  '%C3%AD': '&#237;', // í  '%C3%AE': '&#238;', // î  '%C3%AF': '&#239;', // ï  '%C3%B0': '&#240;', // ð  '%C3%B1': '&#241;', // ñ  '%C3%B2': '&#242;', // ò  '%C3%B3': '&#243;', // ó  '%C3%B4': '&#244;', // ô  '%C3%B5': '&#245;', // õ  '%C3%B6': '&#246;', // ö  '%C3%B9': '&#249;', // ù  '%C3%BA': '&#250;', // ú  '%C3%BB': '&#251;', // û  '%C3%BC': '&#252;', // ü  '%C3%BF': '&#255;', // ÿ  '%C5%B8': '&#376;', // Ÿ  '%C3%9F': '&#223;', // ß  '%C2%BF': '&#191;', // ¿  '%C2%A1': '&#161;', // ¡};module.exports = CHAR_CODES;
},{}],4:[function(require,module,exports){

/*global chrome */

/*
  Multitran.ru translate engine
  Provides program interface for making translate queries to multitran and get clean response

  All engines must follow common interface and provide methods:
    - search (languange, successHandler)  clean translation must be passed into successHandler
    - click

  Translation-module that makes requests to language-engine,
  parses results and sends plugin-global message with translation data
 */
var CHAR_CODES, Tran;

CHAR_CODES = require('./char-codes.js');

Tran = (function() {
  function Tran() {
    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1';
    this.xhr = {};
  }


  /*
    Context menu click handler
   */

  Tran.prototype.click = function(data) {
    var selectionText;
    if (typeof data.silent === void 0 || data.silent === null) {
      data.silent = true;
    }
    selectionText = this.removeHyphenation(data.selectionText);
    return this.search({
      value: selectionText,
      success: this.successtHandler.bind(this),
      silent: data.silent
    });
  };


  /*
    Discard soft hyphen character (U+00AD, &shy;) from the input
   */

  Tran.prototype.removeHyphenation = function(text) {
    return text.replace(/\xad/g, '');
  };


  /*
    Initiate translation search
   */

  Tran.prototype.search = function(params) {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(items) {
        var language, origSuccess, url;
        if (language === '') {
          language = '1';
        }
        _this.setLanguage(items.language);
        url = _this.makeUrl(params.value);
        origSuccess = params.success;
        params.success = function(response) {
          var translated;
          translated = _this.parse(response, params.silent);
          return origSuccess(translated);
        };
        return _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      };
    })(this));
  };

  Tran.prototype.setLanguage = function(language) {
    this.currentLanguage = language;
    return this.lang = '?l1=2&l2=' + language;
  };


  /*
    Request translation and run callback function
    passing translated result or error to callback
   */

  Tran.prototype.request = function(opts) {
    var xhr;
    xhr = this.xhr = new XMLHttpRequest();
    xhr.onreadystatechange = (function(_this) {
      return function(e) {
        xhr = _this.xhr;
        if (xhr.readyState < 4) {

        } else if (xhr.status !== 200) {
          _this.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error();
          }
        } else if (xhr.readyState === 4) {
          return opts.success(e.target.response);
        }
      };
    })(this);
    xhr.open("GET", opts.url, true);
    return xhr.send();
  };

  Tran.prototype.makeUrl = function(value) {
    var url;
    url = [this.protocol, '://', this.host, this.path, this.lang, this.query, this.getEncodedValue(value)].join('');
    return url;
  };

  Tran.prototype.getEncodedValue = function(value) {
    var char, code, val;
    val = encodeURIComponent(value);
    for (char in CHAR_CODES) {
      code = CHAR_CODES[char];
      val = val.replace(char, encodeURIComponent(code));
    }
    return val;
  };

  Tran.prototype.errorHandler = function(xhr) {
    return console.log('error', xhr);
  };


  /*
   Receiving data from translation-engine and send ready message with data
   */

  Tran.prototype.successtHandler = function(translated) {
    if (translated) {
      return chrome.tabs.getSelected(null, (function(_this) {
        return function(tab) {
          return chrome.tabs.sendMessage(tab.id, {
            action: _this.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        };
      })(this));
    }
  };

  Tran.prototype.messageType = function(translated) {
    var _ref;
    if ((translated != null ? (_ref = translated.rows) != null ? _ref.length : void 0 : void 0) === 1) {
      return 'similar_words';
    } else {
      return 'open_tooltip';
    }
  };


  /*
    Parse response from translation engine
   */

  Tran.prototype.parse = function(response, silent, translate) {
    var doc, fragment;
    if (translate == null) {
      translate = null;
    }
    doc = this.stripScripts(response);
    fragment = this.makeFragment(doc);
    if (fragment) {
      translate = fragment.querySelector('#translation ~ table');
      if (translate) {
        translate.className = this.TABLE_CLASS;
        translate.setAttribute("cellpadding", "5");
        this.fixImages(translate);
        this.fixLinks(translate);
      } else if (!silent) {
        translate = document.createElement('div');
        translate.className = 'failTranslate';
        translate.innerText = "Unfortunately, could not translate";
      }
    }
    return translate;
  };


  /*
    Strip script tags from response html
   */

  Tran.prototype.stripScripts = function(s) {
    var div, i, scripts;
    div = document.createElement('div');
    div.innerHTML = s;
    scripts = div.getElementsByTagName('script');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
    return div.innerHTML;
  };

  Tran.prototype.makeFragment = function(doc, fragment) {
    var div;
    if (fragment == null) {
      fragment = null;
    }
    div = document.createElement("div");
    div.innerHTML = doc;
    fragment = document.createDocumentFragment();
    while (div.firstChild) {
      fragment.appendChild(div.firstChild);
    }
    return fragment;
  };

  Tran.prototype.fixImages = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'img', 'src');
    return fragment;
  };

  Tran.prototype.fixLinks = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'a', 'href');
    return fragment;
  };

  Tran.prototype.fixUrl = function(fragment, tag, attr) {
    var parser, tags, _i, _len, _results;
    if (fragment == null) {
      fragment = null;
    }
    if (fragment) {
      tags = fragment.querySelectorAll(tag);
      parser = document.createElement('a');
      _results = [];
      for (_i = 0, _len = tags.length; _i < _len; _i++) {
        tag = tags[_i];
        parser.href = tag[attr];
        parser.host = this.host;
        parser.protocol = this.protocol;
        if (tag.tagName === 'A') {
          tag.classList.add('mtt_link');
          if (parser.pathname.indexOf('m.exe') !== -1) {
            parser.pathname = '/c' + parser.pathname;
            tag.setAttribute('target', '_blank');
          }
        } else if (tag.tagName === 'IMG') {
          tag.classList.add('mtt_img');
        }
        _results.push(tag.setAttribute(attr, parser.href));
      }
      return _results;
    }
  };

  return Tran;

})();

module.exports = new Tran;


},{"./char-codes.js":3}],5:[function(require,module,exports){
"use strict";

var _prototypeProperties = function (child, staticProps, instanceProps) {
  if (staticProps) Object.defineProperties(child, staticProps);
  if (instanceProps) Object.defineProperties(child.prototype, instanceProps);
};

/*
  Translation engine: http://www.turkishdictionary.net
  For translating turkish-russian and vice versa
*/
var CHAR_CODES = require("./char-codes-turk.js");

var TurkishDictionary = (function () {
  function TurkishDictionary() {
    this.host = "http://www.turkishdictionary.net/?word=%FC";
    this.path = "";
    this.protocol = "http";
    this.query = "&s=";
    this.TABLE_CLASS = "___mtt_translate_table";
    this.need_publish = true;
  }

  _prototypeProperties(TurkishDictionary, null, {
    search: {
      value: function search(data) {
        data.url = this.makeUrl(data.value);
        this.need_publish = false;
        return this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    translate: {
      value: function translate(data) {
        console.log("request data:", data);
        data.url = this.makeUrl(data.selectionText);
        this.need_publish = true;
        this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeUrl: {
      value: function makeUrl(text) {
        var text = this.getEncodedValue(text);
        return ["http://www.turkishdictionary.net/?word=", text].join("");
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    getEncodedValue: {
      // Replace special language characters to html codes
      value: function getEncodedValue(value) {
        // to find spec symbols we first encode them (raw search for that symbol doesn't wor)
        var val = encodeURIComponent(value);
        for (var char in CHAR_CODES) {
          val = val.replace(char, CHAR_CODES[char]);
        }
        return val;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    request: {

      /*
        Request translation and run callback function
        passing translated result or error to callback
      */
      value: function request(opts) {
        console.log("start request");
        this.xhr = new XMLHttpRequest();
        this.xhr.onreadystatechange = this.onReadyStateChange.bind(this, opts);
        this.xhr.open("GET", opts.url, true);
        this.xhr.send();
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    onReadyStateChange: {
      value: function onReadyStateChange(opts, e) {
        var xhr = this.xhr;
        if (xhr.readyState < 4) {
          return;
        } else if (xhr.status != 200) {
          this.errorHandler(xhr);
          return opts.error && opts.error();
        } else if (xhr.readyState == 4) {
          var translation = this.successHandler(e.target.response);
          console.log("success turkish translate", translation);
          console.log("call", opts.success);
          return opts.success && opts.success(translation);
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    successHandler: {
      value: function successHandler(response) {
        var data = this.parse(response);
        if (this.need_publish) {
          chrome.tabs.getSelected(null, this.publishTranslation.bind(this, data));
        }
        return data;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    publishTranslation: {

      /* publish successfuly translated text all over extension */
      value: function publishTranslation(translation, tab) {
        console.log("publish translation");
        chrome.tabs.sendMessage(tab.id, {
          action: "open_tooltip",
          data: translation.outerHTML,
          success: !translation.classList.contains("failTranslate")
        });
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    errorHandler: {
      value: function errorHandler(response) {
        console.log("error ajax", response);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parse: {

      /* Parse response from translation engine */
      value: function parse(response, silent, translate) {
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);
        if (fragment) {
          translate = fragment.querySelector("#meaning_div > table");
          if (translate) {
            translate.className = this.TABLE_CLASS;
            translate.setAttribute("cellpadding", "5");
            // @fixImages(translate)
            // @fixLinks(translate)
          } else if (!silent) {
            translate = document.createElement("div");
            translate.className = "failTranslate";
            translate.innerText = "Unfortunately, could not translate";
          }
        }
        return translate;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    stripScripts: {

      //TODO extract to base engine class
      /* removes <script> tags from html code */
      value: function stripScripts(html) {
        var div = document.createElement("div");
        div.innerHTML = html;
        var scripts = div.getElementsByTagName("script");
        var i = scripts.length;
        while (i--) scripts[i].parentNode.removeChild(scripts[i]);
        return div.innerHTML;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeFragment: {

      //TODO extract to base engine class
      /* creates temp object to parse translation from page 
        (since it's not a friendly api) 
      */
      value: function makeFragment(html) {
        var fragment,
            div = document.createElement("div");
        div.innerHTML = html;
        fragment = document.createDocumentFragment();
        while (div.firstChild) {
          fragment.appendChild(div.firstChild);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    }
  });

  return TurkishDictionary;
})();

// Singletone
module.exports = new TurkishDictionary();
},{"./char-codes-turk.js":2}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvYmFja2dyb3VuZC5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXZlbG9wbWVudC90cmFuL2pzL2NoYXItY29kZXMtdHVyay5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvY2hhci1jb2Rlcy5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvdHJhbi5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXZlbG9wbWVudC90cmFuL2pzL3R1cmtpc2hkaWN0aW9uYXJ5LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFBQSx3QkFBQTtBQUFBLElBQUEsbUNBQUE7O0FBQUEsVUFHQSxHQUFhLE9BQUEsQ0FBUSxpQkFBUixDQUhiLENBQUE7O0FBQUEsSUFLQSxHQUFPLE9BQUEsQ0FBUSxlQUFSLENBTFAsQ0FBQTs7QUFBQSxpQkFNQSxHQUFvQixPQUFBLENBQVEsd0JBQVIsQ0FOcEIsQ0FBQTs7QUFBQSxNQVNNLENBQUMsWUFBWSxDQUFDLE1BQXBCLENBQ0U7QUFBQSxFQUFBLEtBQUEsRUFBUSxpQkFBUjtBQUFBLEVBQ0EsUUFBQSxFQUFVLENBQUMsTUFBRCxFQUFTLE9BQVQsRUFBa0IsVUFBbEIsRUFBOEIsT0FBOUIsRUFBdUMsT0FBdkMsRUFBZ0QsT0FBaEQsRUFBeUQsTUFBekQsRUFBaUUsV0FBakUsQ0FEVjtBQUFBLEVBRUEsT0FBQSxFQUFVLFNBQUMsSUFBRCxHQUFBO0FBQ1IsSUFBQSxJQUFJLENBQUMsTUFBTCxHQUFjLEtBQWQsQ0FBQTtXQUNBLElBQUksQ0FBQyxLQUFMLENBQVcsSUFBWCxFQUZRO0VBQUEsQ0FGVjtDQURGLENBVEEsQ0FBQTs7QUFpQkE7QUFBQTs7OztHQWpCQTs7QUFBQSxNQXNCTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsV0FBekIsQ0FBcUMsU0FBQyxPQUFELEVBQVUsTUFBVixFQUFrQixZQUFsQixHQUFBO0FBQ25DLEVBQUEsSUFBRyxPQUFPLENBQUMsTUFBUixLQUFrQixpQkFBckI7QUFDRSxJQUFBLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsTUFBQSxJQUFBLEVBQU0sSUFBTjtLQUF4QixFQUFvQyxTQUFDLEtBQUQsR0FBQTthQUNoQyxZQUFBLENBQWE7QUFBQSxRQUFBLElBQUEsRUFBTSxLQUFLLENBQUMsSUFBWjtPQUFiLEVBRGdDO0lBQUEsQ0FBcEMsQ0FBQSxDQURGO0dBQUEsTUFPSyxJQUFHLE9BQU8sQ0FBQyxNQUFSLEtBQWtCLGdCQUFyQjtBQUNILElBQUEsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBcEIsQ0FBd0I7QUFBQSxNQUFFLFFBQUEsRUFBVSxHQUFaO0FBQUEsTUFBaUIsSUFBQSxFQUFNLElBQXZCO0tBQXhCLEVBQXNELFNBQUMsS0FBRCxHQUFBO0FBQ3BELE1BQUEsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFiLEdBQXNCLElBQXRCLENBQUE7QUFDQSxNQUFBLElBQUcsUUFBQSxDQUFTLEtBQUssQ0FBQyxRQUFmLEVBQXdCLEVBQXhCLENBQUEsS0FBK0IsSUFBbEM7QUFDRSxRQUFBLGlCQUFpQixDQUFDLFNBQWxCLENBQTRCLE9BQU8sQ0FBQyxJQUFwQyxDQUFBLENBREY7T0FBQSxNQUFBO0FBR0UsUUFBQSxJQUFJLENBQUMsS0FBTCxDQUFXLE9BQU8sQ0FBQyxJQUFuQixDQUFBLENBSEY7T0FEQTtBQUtBLGFBQU8sSUFBUCxDQU5vRDtJQUFBLENBQXRELENBQUEsQ0FERztHQVBMO1NBZ0JBLEtBakJtQztBQUFBLENBQXJDLENBdEJBLENBQUE7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1ZBOztBQ0FBO0FBQUEsa0JBQUE7QUFDQTtBQUFBOzs7Ozs7Ozs7O0dBREE7QUFBQSxJQUFBLGdCQUFBOztBQUFBLFVBYUEsR0FBYSxPQUFBLENBQVEsaUJBQVIsQ0FiYixDQUFBOztBQUFBO0FBZ0JlLEVBQUEsY0FBQSxHQUFBO0FBQ1gsSUFBQSxJQUFDLENBQUEsV0FBRCxHQUFlLHdCQUFmLENBQUE7QUFBQSxJQUNBLElBQUMsQ0FBQSxRQUFELEdBQVksTUFEWixDQUFBO0FBQUEsSUFFQSxJQUFDLENBQUEsSUFBRCxHQUFRLGtCQUZSLENBQUE7QUFBQSxJQUdBLElBQUMsQ0FBQSxJQUFELEdBQVEsVUFIUixDQUFBO0FBQUEsSUFJQSxJQUFDLENBQUEsS0FBRCxHQUFTLEtBSlQsQ0FBQTtBQUFBLElBS0EsSUFBQyxDQUFBLElBQUQsR0FBUSxZQUxSLENBQUE7QUFBQSxJQU1BLElBQUMsQ0FBQSxHQUFELEdBQU8sRUFOUCxDQURXO0VBQUEsQ0FBYjs7QUFTQTtBQUFBOztLQVRBOztBQUFBLGlCQVlBLEtBQUEsR0FBTyxTQUFDLElBQUQsR0FBQTtBQUNMLFFBQUEsYUFBQTtBQUFBLElBQUEsSUFBRyxNQUFBLENBQUEsSUFBVyxDQUFDLE1BQVosS0FBc0IsTUFBdEIsSUFBbUMsSUFBSSxDQUFDLE1BQUwsS0FBZSxJQUFyRDtBQUNFLE1BQUEsSUFBSSxDQUFDLE1BQUwsR0FBYyxJQUFkLENBREY7S0FBQTtBQUFBLElBRUEsYUFBQSxHQUFnQixJQUFDLENBQUEsaUJBQUQsQ0FBbUIsSUFBSSxDQUFDLGFBQXhCLENBRmhCLENBQUE7V0FHQSxJQUFDLENBQUEsTUFBRCxDQUNJO0FBQUEsTUFBQSxLQUFBLEVBQU8sYUFBUDtBQUFBLE1BQ0EsT0FBQSxFQUFTLElBQUMsQ0FBQSxlQUFlLENBQUMsSUFBakIsQ0FBc0IsSUFBdEIsQ0FEVDtBQUFBLE1BRUEsTUFBQSxFQUFRLElBQUksQ0FBQyxNQUZiO0tBREosRUFKSztFQUFBLENBWlAsQ0FBQTs7QUFxQkE7QUFBQTs7S0FyQkE7O0FBQUEsaUJBd0JBLGlCQUFBLEdBQW1CLFNBQUMsSUFBRCxHQUFBO1dBQ2pCLElBQUksQ0FBQyxPQUFMLENBQWEsT0FBYixFQUFzQixFQUF0QixFQURpQjtFQUFBLENBeEJuQixDQUFBOztBQTJCQTtBQUFBOztLQTNCQTs7QUFBQSxpQkE4QkEsTUFBQSxHQUFRLFNBQUMsTUFBRCxHQUFBO1dBRU4sTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBcEIsQ0FBd0I7QUFBQSxNQUFDLFFBQUEsRUFBVSxHQUFYO0tBQXhCLEVBQXlDLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLEtBQUQsR0FBQTtBQUN2QyxZQUFBLDBCQUFBO0FBQUEsUUFBQSxJQUFHLFFBQUEsS0FBWSxFQUFmO0FBQ0UsVUFBQSxRQUFBLEdBQVcsR0FBWCxDQURGO1NBQUE7QUFBQSxRQUVBLEtBQUMsQ0FBQSxXQUFELENBQWEsS0FBSyxDQUFDLFFBQW5CLENBRkEsQ0FBQTtBQUFBLFFBR0EsR0FBQSxHQUFNLEtBQUMsQ0FBQSxPQUFELENBQVMsTUFBTSxDQUFDLEtBQWhCLENBSE4sQ0FBQTtBQUFBLFFBS0EsV0FBQSxHQUFjLE1BQU0sQ0FBQyxPQUxyQixDQUFBO0FBQUEsUUFNQSxNQUFNLENBQUMsT0FBUCxHQUFpQixTQUFDLFFBQUQsR0FBQTtBQUNmLGNBQUEsVUFBQTtBQUFBLFVBQUEsVUFBQSxHQUFhLEtBQUMsQ0FBQSxLQUFELENBQU8sUUFBUCxFQUFpQixNQUFNLENBQUMsTUFBeEIsQ0FBYixDQUFBO2lCQUNBLFdBQUEsQ0FBWSxVQUFaLEVBRmU7UUFBQSxDQU5qQixDQUFBO2VBV0EsS0FBQyxDQUFBLE9BQUQsQ0FDRTtBQUFBLFVBQUEsR0FBQSxFQUFLLEdBQUw7QUFBQSxVQUNBLE9BQUEsRUFBUyxNQUFNLENBQUMsT0FEaEI7QUFBQSxVQUVBLEtBQUEsRUFBTyxNQUFNLENBQUMsS0FGZDtTQURGLEVBWnVDO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBekMsRUFGTTtFQUFBLENBOUJSLENBQUE7O0FBQUEsaUJBbURBLFdBQUEsR0FBYSxTQUFDLFFBQUQsR0FBQTtBQUNYLElBQUEsSUFBQyxDQUFBLGVBQUQsR0FBbUIsUUFBbkIsQ0FBQTtXQUNBLElBQUMsQ0FBQSxJQUFELEdBQVEsV0FBQSxHQUFjLFNBRlg7RUFBQSxDQW5EYixDQUFBOztBQXVEQTtBQUFBOzs7S0F2REE7O0FBQUEsaUJBMkRBLE9BQUEsR0FBUyxTQUFDLElBQUQsR0FBQTtBQUNQLFFBQUEsR0FBQTtBQUFBLElBQUEsR0FBQSxHQUFNLElBQUMsQ0FBQSxHQUFELEdBQVcsSUFBQSxjQUFBLENBQUEsQ0FBakIsQ0FBQTtBQUFBLElBQ0EsR0FBRyxDQUFDLGtCQUFKLEdBQXlCLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLENBQUQsR0FBQTtBQUN2QixRQUFBLEdBQUEsR0FBTSxLQUFDLENBQUEsR0FBUCxDQUFBO0FBQ0EsUUFBQSxJQUFHLEdBQUcsQ0FBQyxVQUFKLEdBQWlCLENBQXBCO0FBQUE7U0FBQSxNQUVLLElBQUcsR0FBRyxDQUFDLE1BQUosS0FBYyxHQUFqQjtBQUNILFVBQUEsS0FBQyxDQUFBLFlBQUQsQ0FBYyxHQUFkLENBQUEsQ0FBQTtBQUNBLFVBQUEsSUFBSSxNQUFBLENBQUEsSUFBVyxDQUFDLEtBQVosS0FBcUIsVUFBekI7QUFDRSxZQUFBLElBQUksQ0FBQyxLQUFMLENBQUEsQ0FBQSxDQURGO1dBRkc7U0FBQSxNQUtBLElBQUcsR0FBRyxDQUFDLFVBQUosS0FBa0IsQ0FBckI7QUFDRCxpQkFBTyxJQUFJLENBQUMsT0FBTCxDQUFhLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBdEIsQ0FBUCxDQURDO1NBVGtCO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FEekIsQ0FBQTtBQUFBLElBYUEsR0FBRyxDQUFDLElBQUosQ0FBUyxLQUFULEVBQWdCLElBQUksQ0FBQyxHQUFyQixFQUEwQixJQUExQixDQWJBLENBQUE7V0FjQSxHQUFHLENBQUMsSUFBSixDQUFBLEVBZk87RUFBQSxDQTNEVCxDQUFBOztBQUFBLGlCQTZFQSxPQUFBLEdBQVMsU0FBQyxLQUFELEdBQUE7QUFDUCxRQUFBLEdBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxDQUFDLElBQUMsQ0FBQSxRQUFGLEVBQVksS0FBWixFQUNJLElBQUMsQ0FBQSxJQURMLEVBRUksSUFBQyxDQUFBLElBRkwsRUFHSSxJQUFDLENBQUEsSUFITCxFQUlJLElBQUMsQ0FBQSxLQUpMLEVBS0ksSUFBQyxDQUFBLGVBQUQsQ0FBaUIsS0FBakIsQ0FMSixDQU1DLENBQUMsSUFORixDQU1PLEVBTlAsQ0FBTixDQUFBO0FBUUEsV0FBTyxHQUFQLENBVE87RUFBQSxDQTdFVCxDQUFBOztBQUFBLGlCQXlGQSxlQUFBLEdBQWlCLFNBQUMsS0FBRCxHQUFBO0FBRWYsUUFBQSxlQUFBO0FBQUEsSUFBQSxHQUFBLEdBQU0sa0JBQUEsQ0FBbUIsS0FBbkIsQ0FBTixDQUFBO0FBQ0EsU0FBQSxrQkFBQTs4QkFBQTtBQUNFLE1BQUEsR0FBQSxHQUFNLEdBQUcsQ0FBQyxPQUFKLENBQVksSUFBWixFQUFrQixrQkFBQSxDQUFtQixJQUFuQixDQUFsQixDQUFOLENBREY7QUFBQSxLQURBO0FBR0EsV0FBTyxHQUFQLENBTGU7RUFBQSxDQXpGakIsQ0FBQTs7QUFBQSxpQkFnR0EsWUFBQSxHQUFjLFNBQUMsR0FBRCxHQUFBO1dBQ1osT0FBTyxDQUFDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCLEdBQXJCLEVBRFk7RUFBQSxDQWhHZCxDQUFBOztBQW1HQTtBQUFBOztLQW5HQTs7QUFBQSxpQkFzR0EsZUFBQSxHQUFpQixTQUFDLFVBQUQsR0FBQTtBQUNmLElBQUEsSUFBRyxVQUFIO2FBQ0UsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFaLENBQXdCLElBQXhCLEVBQThCLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLEdBQUQsR0FBQTtpQkFDNUIsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFaLENBQXdCLEdBQUcsQ0FBQyxFQUE1QixFQUFnQztBQUFBLFlBQzlCLE1BQUEsRUFBUSxLQUFDLENBQUEsV0FBRCxDQUFhLFVBQWIsQ0FEc0I7QUFBQSxZQUU5QixJQUFBLEVBQU0sVUFBVSxDQUFDLFNBRmE7QUFBQSxZQUc5QixPQUFBLEVBQVMsQ0FBQSxVQUFXLENBQUMsU0FBUyxDQUFDLFFBQXJCLENBQThCLGVBQTlCLENBSG9CO1dBQWhDLEVBRDRCO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBOUIsRUFERjtLQURlO0VBQUEsQ0F0R2pCLENBQUE7O0FBQUEsaUJBZ0hBLFdBQUEsR0FBYSxTQUFDLFVBQUQsR0FBQTtBQUNYLFFBQUEsSUFBQTtBQUFBLElBQUEsaUVBQW1CLENBQUUseUJBQWxCLEtBQTRCLENBQS9CO2FBQ0UsZ0JBREY7S0FBQSxNQUFBO2FBR0UsZUFIRjtLQURXO0VBQUEsQ0FoSGIsQ0FBQTs7QUFzSEE7QUFBQTs7S0F0SEE7O0FBQUEsaUJBeUhBLEtBQUEsR0FBTyxTQUFDLFFBQUQsRUFBVyxNQUFYLEVBQW1CLFNBQW5CLEdBQUE7QUFDSCxRQUFBLGFBQUE7O01BRHNCLFlBQVk7S0FDbEM7QUFBQSxJQUFBLEdBQUEsR0FBTSxJQUFDLENBQUEsWUFBRCxDQUFjLFFBQWQsQ0FBTixDQUFBO0FBQUEsSUFDQSxRQUFBLEdBQVcsSUFBQyxDQUFBLFlBQUQsQ0FBYyxHQUFkLENBRFgsQ0FBQTtBQUVBLElBQUEsSUFBRyxRQUFIO0FBQ0UsTUFBQSxTQUFBLEdBQVksUUFBUSxDQUFDLGFBQVQsQ0FBdUIsc0JBQXZCLENBQVosQ0FBQTtBQUNBLE1BQUEsSUFBRyxTQUFIO0FBQ0UsUUFBQSxTQUFTLENBQUMsU0FBVixHQUFzQixJQUFDLENBQUEsV0FBdkIsQ0FBQTtBQUFBLFFBQ0EsU0FBUyxDQUFDLFlBQVYsQ0FBdUIsYUFBdkIsRUFBc0MsR0FBdEMsQ0FEQSxDQUFBO0FBQUEsUUFFQSxJQUFDLENBQUEsU0FBRCxDQUFXLFNBQVgsQ0FGQSxDQUFBO0FBQUEsUUFHQSxJQUFDLENBQUEsUUFBRCxDQUFVLFNBQVYsQ0FIQSxDQURGO09BQUEsTUFLSyxJQUFHLENBQUEsTUFBSDtBQUNILFFBQUEsU0FBQSxHQUFZLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCLENBQVosQ0FBQTtBQUFBLFFBQ0EsU0FBUyxDQUFDLFNBQVYsR0FBc0IsZUFEdEIsQ0FBQTtBQUFBLFFBRUEsU0FBUyxDQUFDLFNBQVYsR0FBc0Isb0NBRnRCLENBREc7T0FQUDtLQUZBO0FBY0EsV0FBTyxTQUFQLENBZkc7RUFBQSxDQXpIUCxDQUFBOztBQTBJQTtBQUFBOztLQTFJQTs7QUFBQSxpQkE2SUEsWUFBQSxHQUFjLFNBQUMsQ0FBRCxHQUFBO0FBQ1osUUFBQSxlQUFBO0FBQUEsSUFBQSxHQUFBLEdBQU0sUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBTixDQUFBO0FBQUEsSUFDQSxHQUFHLENBQUMsU0FBSixHQUFnQixDQURoQixDQUFBO0FBQUEsSUFFQSxPQUFBLEdBQVUsR0FBRyxDQUFDLG9CQUFKLENBQXlCLFFBQXpCLENBRlYsQ0FBQTtBQUFBLElBR0EsQ0FBQSxHQUFJLE9BQU8sQ0FBQyxNQUhaLENBQUE7QUFJQSxXQUFNLENBQUEsRUFBTixHQUFBO0FBQ0UsTUFBQSxPQUFRLENBQUEsQ0FBQSxDQUFFLENBQUMsVUFBVSxDQUFDLFdBQXRCLENBQWtDLE9BQVEsQ0FBQSxDQUFBLENBQTFDLENBQUEsQ0FERjtJQUFBLENBSkE7QUFNQSxXQUFPLEdBQUcsQ0FBQyxTQUFYLENBUFk7RUFBQSxDQTdJZCxDQUFBOztBQUFBLGlCQXNKQSxZQUFBLEdBQWMsU0FBQyxHQUFELEVBQU0sUUFBTixHQUFBO0FBQ1osUUFBQSxHQUFBOztNQURrQixXQUFXO0tBQzdCO0FBQUEsSUFBQSxHQUFBLEdBQU0sUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBTixDQUFBO0FBQUEsSUFDQSxHQUFHLENBQUMsU0FBSixHQUFnQixHQURoQixDQUFBO0FBQUEsSUFFQSxRQUFBLEdBQVcsUUFBUSxDQUFDLHNCQUFULENBQUEsQ0FGWCxDQUFBO0FBR0EsV0FBUSxHQUFHLENBQUMsVUFBWixHQUFBO0FBQ0UsTUFBQSxRQUFRLENBQUMsV0FBVCxDQUFzQixHQUFHLENBQUMsVUFBMUIsQ0FBQSxDQURGO0lBQUEsQ0FIQTtBQUtBLFdBQU8sUUFBUCxDQU5ZO0VBQUEsQ0F0SmQsQ0FBQTs7QUFBQSxpQkE4SkEsU0FBQSxHQUFXLFNBQUMsUUFBRCxHQUFBOztNQUFDLFdBQVM7S0FDbkI7QUFBQSxJQUFBLElBQUksQ0FBQyxNQUFMLENBQVksUUFBWixFQUFzQixLQUF0QixFQUE2QixLQUE3QixDQUFBLENBQUE7QUFDQSxXQUFPLFFBQVAsQ0FGUztFQUFBLENBOUpYLENBQUE7O0FBQUEsaUJBa0tBLFFBQUEsR0FBVSxTQUFDLFFBQUQsR0FBQTs7TUFBQyxXQUFTO0tBQ2xCO0FBQUEsSUFBQSxJQUFJLENBQUMsTUFBTCxDQUFZLFFBQVosRUFBc0IsR0FBdEIsRUFBMkIsTUFBM0IsQ0FBQSxDQUFBO0FBQ0EsV0FBTyxRQUFQLENBRlE7RUFBQSxDQWxLVixDQUFBOztBQUFBLGlCQXNLQSxNQUFBLEdBQVEsU0FBQyxRQUFELEVBQWdCLEdBQWhCLEVBQXFCLElBQXJCLEdBQUE7QUFDTixRQUFBLGdDQUFBOztNQURPLFdBQVM7S0FDaEI7QUFBQSxJQUFBLElBQUcsUUFBSDtBQUNFLE1BQUEsSUFBQSxHQUFRLFFBQVEsQ0FBQyxnQkFBVCxDQUEwQixHQUExQixDQUFSLENBQUE7QUFBQSxNQUNBLE1BQUEsR0FBUyxRQUFRLENBQUMsYUFBVCxDQUF1QixHQUF2QixDQURULENBQUE7QUFFQTtXQUFBLDJDQUFBO3VCQUFBO0FBQ0UsUUFBQSxNQUFNLENBQUMsSUFBUCxHQUFjLEdBQUksQ0FBQSxJQUFBLENBQWxCLENBQUE7QUFBQSxRQUNBLE1BQU0sQ0FBQyxJQUFQLEdBQWMsSUFBQyxDQUFBLElBRGYsQ0FBQTtBQUFBLFFBRUEsTUFBTSxDQUFDLFFBQVAsR0FBa0IsSUFBQyxDQUFBLFFBRm5CLENBQUE7QUFJQSxRQUFBLElBQUcsR0FBRyxDQUFDLE9BQUosS0FBZSxHQUFsQjtBQUNFLFVBQUEsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFkLENBQWtCLFVBQWxCLENBQUEsQ0FBQTtBQUNBLFVBQUEsSUFBRyxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQWhCLENBQXdCLE9BQXhCLENBQUEsS0FBc0MsQ0FBQSxDQUF6QztBQUNFLFlBQUEsTUFBTSxDQUFDLFFBQVAsR0FBa0IsSUFBQSxHQUFPLE1BQU0sQ0FBQyxRQUFoQyxDQUFBO0FBQUEsWUFDQSxHQUFHLENBQUMsWUFBSixDQUFpQixRQUFqQixFQUEyQixRQUEzQixDQURBLENBREY7V0FGRjtTQUFBLE1BS0ssSUFBRyxHQUFHLENBQUMsT0FBSixLQUFlLEtBQWxCO0FBQ0gsVUFBQSxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQWQsQ0FBa0IsU0FBbEIsQ0FBQSxDQURHO1NBVEw7QUFBQSxzQkFZQSxHQUFHLENBQUMsWUFBSixDQUFpQixJQUFqQixFQUF1QixNQUFNLENBQUMsSUFBOUIsRUFaQSxDQURGO0FBQUE7c0JBSEY7S0FETTtFQUFBLENBdEtSLENBQUE7O2NBQUE7O0lBaEJGLENBQUE7O0FBQUEsTUEyTU0sQ0FBQyxPQUFQLEdBQWlCLEdBQUEsQ0FBQSxJQTNNakIsQ0FBQTs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpfXZhciBmPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChmLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGYsZi5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCIjIyNnbG9iYWwgdHJhbiwgY2hyb21lIyMjXG5cbiNsb2FkIGVuZ2luZXNcbkNIQVJfQ09ERVMgPSByZXF1aXJlKCcuL2NoYXItY29kZXMuanMnKTtcblxudHJhbiA9IHJlcXVpcmUoJy4vdHJhbi5jb2ZmZWUnKSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIyBtdWx0aXRyYW4ucnVcbnR1cmtpc2hEaWN0aW9uYXJ5ID0gcmVxdWlyZSgnLi90dXJraXNoZGljdGlvbmFyeS5qcycpICAgIyB0dXJraXNoZGljdGlvbmFyeS5uZXRcblxuI2dlbmVyYXRlcyBhIGNvbnRleHQgbWVudVxuY2hyb21lLmNvbnRleHRNZW51cy5jcmVhdGUoXG4gIHRpdGxlOiAgJ011bHRpdHJhbjogXCIlc1wiJ1xuICBjb250ZXh0czogW1wicGFnZVwiLCBcImZyYW1lXCIsIFwiZWRpdGFibGVcIiwgXCJpbWFnZVwiLCBcInZpZGVvXCIsIFwiYXVkaW9cIiwgXCJsaW5rXCIsIFwic2VsZWN0aW9uXCJdXG4gIG9uY2xpY2s6ICAoZGF0YSkgLT5cbiAgICBkYXRhLnNpbGVudCA9IGZhbHNlXG4gICAgdHJhbi5jbGljayhkYXRhKVxuKVxuXG4jIyNcbiBDYW4ndCBnZXQgY2hyb21lLnN0b3JhZ2UgZGlyZWN0bHkgZnJvbSBjb250ZW50X3NjcmlwdFxuIHNvIGNvbnRlbnRfc2NyaXB0IHNlbmRzIHJlcXVlc3QgbWVzc2FnZSBhbmQgdGhlbiBiYWNrZ3JvdW5kIHNjcmlwdFxuIHJlc3BvbmRzIHdpdGggc3RvcmFnZSB2YWx1ZVxuIyMjXG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIgKHJlcXVlc3QsIHNlbmRlciwgc2VuZFJlc3BvbnNlKSAtPlxuICBpZiByZXF1ZXN0Lm1ldGhvZCA9PSBcImdldF9mYXN0X29wdGlvblwiXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoZmFzdDogdHJ1ZSwgKGl0ZW1zKSAtPlxuICAgICAgICBzZW5kUmVzcG9uc2UoZmFzdDogaXRlbXMuZmFzdClcbiAgICAgICAgI3JldHVybiB0cnVlXG4gICAgKVxuICAjRmFzdCB0cmFuc2xhdGlvbiBpbml0aWF0ZSBzZWFyY2ggd2l0aCAncmVxdWVzdF9zZWFyY2gnIG1lc3NhZ2UgZnJvbVxuICAjY29udGVudF9zY3JpcHRcbiAgZWxzZSBpZiByZXF1ZXN0Lm1ldGhvZCA9PSAncmVxdWVzdF9zZWFyY2gnXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoeyBsYW5ndWFnZTogJzEnLCBmYXN0OiB0cnVlfSwgKGl0ZW1zKSAtPlxuICAgICAgcmVxdWVzdC5kYXRhLnNpbGVudCA9IHRydWVcbiAgICAgIGlmIHBhcnNlSW50KGl0ZW1zLmxhbmd1YWdlLDEwKSA9PSAxMDAwXG4gICAgICAgIHR1cmtpc2hEaWN0aW9uYXJ5LnRyYW5zbGF0ZShyZXF1ZXN0LmRhdGEpXG4gICAgICBlbHNlXG4gICAgICAgIHRyYW4uY2xpY2socmVxdWVzdC5kYXRhKVxuICAgICAgcmV0dXJuIHRydWVcbiAgICApXG4gIHRydWVcblxuIiwidmFyIENIQVJfQ09ERVMgPSB7XG4gIC8vIHR1cmtpc2hkaWN0aW9uYXJ5IGNvZGluZ3NcbiAgJyVDNCVCMSc6ICclRkQnLCAvL8SxIChMb3dlcmNhc2UgaS1kb3RsZXNzKSAgYWN0dWFsbHkgaXQgaXMgJiMzMDU7IGJ1dCB0dXJraXNoZGljdGlvbmFyeSBuZWVkIGl0IHRoaXMgd2F5IFxuICAnJUM1JTlGJzogJyVGRScsIC8vxZ9cbiAgJyVDNCU5Ric6ICclRjAnLCAvL8SfICAoc2lsZW50IGNoYXJhY3RlcilcbiAgJyVDMyVBNyc6ICclRTcnLCAvL8OnXG4gICclQzMlQjYnOiAnJUY2JywgLy/DtlxuICAnJUMzJUJDJzogJyVGQycgLy/DvFxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IENIQVJfQ09ERVM7IiwiLypcciAgTXVsdGl0cmFuIGRlcGVuZHMgb24gaHRtbC1lc2NhcGluZyAobm90IFVURi04KSBydWxlcyBmb3Igc3BlY2lhbCBzeW1ib2xzXHIgIMOgLCDDqCwgw6wsIMOyLCDDuSAtIMOALCDDiCwgw4wsIMOSLCDDmVxyICDDoSwgw6ksIMOtLCDDsywgw7osIMO9IC0gw4EsIMOJLCDDjSwgw5MsIMOaLCDDnVxyICDDoiwgw6osIMOuLCDDtCwgw7sgw4IsIMOKLCDDjiwgw5QsIMObXHIgIMOjLCDDsSwgw7Ugw4MsIMORLCDDlVxyICDDpCwgw6ssIMOvLCDDtiwgw7wsIMO/IMOELCDDiywgw48sIMOWLCDDnCxcciAgw6UsIMOFXHIgIMOmLCDDhlxyICDDpywgw4dcciAgw7AsIMOQXHIgIMO4LCDDmFxyICDCvyDCoSDDn1xyKi9ccnZhciBDSEFSX0NPREVTID0ge1xyICAnJUMzJTgwJzogJyYjMTkyOycsIC8vIMOAXHIgICclQzMlODEnOiAnJiMxOTM7JywgLy8gw4FcciAgJyVDMyU4Mic6ICcmIzE5NDsnLCAvLyDDglxyICAnJUMzJTgzJzogJyYjMTk1OycsIC8vIMODXHIgICclQzMlODQnOiAnJiMxOTY7JywgLy8gw4RcciAgJyVDMyU4NSc6ICcmIzE5NzsnLCAvLyDDhVxyICAnJUMzJTg2JzogJyYjMTk4OycsIC8vIMOGXHJcciAgJyVDMyU4Nyc6ICcmIzE5OTsnLCAvLyDDh1xyICAnJUMzJTg4JzogJyYjMjAwOycsIC8vIMOIXHIgICclQzMlODknOiAnJiMyMDE7JywgLy8gw4lcciAgJyVDMyU4QSc6ICcmIzIwMjsnLCAvLyDDilxyICAnJUMzJThCJzogJyYjMjAzOycsIC8vIMOLXHJcciAgJyVDMyU4Qyc6ICcmIzIwNDsnLCAvLyDDjFxyICAnJUMzJThEJzogJyYjMjA1OycsIC8vIMONXHIgICclQzMlOEUnOiAnJiMyMDY7JywgLy8gw45cciAgJyVDMyU4Ric6ICcmIzIwNzsnLCAvLyDDj1xyXHIgICclQzMlOTEnOiAnJiMyMDk7JywgLy8gw5FcciAgJyVDMyU5Mic6ICcmIzIxMDsnLCAvLyDDklxyICAnJUMzJTkzJzogJyYjMjExOycsIC8vIMOTXHIgICclQzMlOTQnOiAnJiMyMTI7JywgLy8gw5RcciAgJyVDMyU5NSc6ICcmIzIxMzsnLCAvLyDDlVxyICAnJUMzJTk2JzogJyYjMjE0OycsIC8vIMOWXHJcciAgJyVDMyU5OSc6ICcmIzIxNzsnLCAvLyDDmVxyICAnJUMzJTlBJzogJyYjMjE4OycsIC8vIMOaXHIgICclQzMlOUInOiAnJiMyMTk7JywgLy8gw5tcciAgJyVDMyU5Qyc6ICcmIzIyMDsnLCAvLyDDnFxyXHJcciAgJyVDMyVBMCc6ICcmIzIyNDsnLCAvLyDDoFxyICAnJUMzJUExJzogJyYjMjI1OycsIC8vIMOhXHIgICclQzMlQTInOiAnJiMyMjY7JywgLy8gw6JcciAgJyVDMyVBMyc6ICcmIzIyNzsnLCAvLyDDo1xyICAnJUMzJUE0JzogJyYjMjI4OycsIC8vIMOkXHIgICclQzMlQTUnOiAnJiMyMjk7JywgLy8gw6VcciAgJyVDMyVBNic6ICcmIzIzMDsnLCAvLyDDplxyICAnJUMzJUE3JzogJyYjMjMxOycsIC8vIMOnXHJcclxyICAnJUMzJUE4JzogJyYjMjMyOycsIC8vIMOoXHIgICclQzMlQTknOiAnJiMyMzM7JywgLy8gw6lcciAgJyVDMyVBQSc6ICcmIzIzNDsnLCAvLyDDqlxyICAnJUMzJUFCJzogJyYjMjM1OycsIC8vIMOrXHJcciAgJyVDMyVBQyc6ICcmIzIzNjsnLCAvLyDDrFxyICAnJUMzJUFEJzogJyYjMjM3OycsIC8vIMOtXHIgICclQzMlQUUnOiAnJiMyMzg7JywgLy8gw65cciAgJyVDMyVBRic6ICcmIzIzOTsnLCAvLyDDr1xyXHIgICclQzMlQjAnOiAnJiMyNDA7JywgLy8gw7BcciAgJyVDMyVCMSc6ICcmIzI0MTsnLCAvLyDDsVxyXHIgICclQzMlQjInOiAnJiMyNDI7JywgLy8gw7JcciAgJyVDMyVCMyc6ICcmIzI0MzsnLCAvLyDDs1xyICAnJUMzJUI0JzogJyYjMjQ0OycsIC8vIMO0XHIgICclQzMlQjUnOiAnJiMyNDU7JywgLy8gw7VcciAgJyVDMyVCNic6ICcmIzI0NjsnLCAvLyDDtlxyXHIgICclQzMlQjknOiAnJiMyNDk7JywgLy8gw7lcciAgJyVDMyVCQSc6ICcmIzI1MDsnLCAvLyDDulxyICAnJUMzJUJCJzogJyYjMjUxOycsIC8vIMO7XHIgICclQzMlQkMnOiAnJiMyNTI7JywgLy8gw7xcciAgJyVDMyVCRic6ICcmIzI1NTsnLCAvLyDDv1xyICAnJUM1JUI4JzogJyYjMzc2OycsIC8vIMW4XHJcciAgJyVDMyU5Ric6ICcmIzIyMzsnLCAvLyDDn1xyXHIgICclQzIlQkYnOiAnJiMxOTE7JywgLy8gwr9cciAgJyVDMiVBMSc6ICcmIzE2MTsnLCAvLyDCoVxyfTtcclxybW9kdWxlLmV4cG9ydHMgPSBDSEFSX0NPREVTO1xyIiwiIyMjZ2xvYmFsIGNocm9tZSMjI1xuIyMjXG4gIE11bHRpdHJhbi5ydSB0cmFuc2xhdGUgZW5naW5lXG4gIFByb3ZpZGVzIHByb2dyYW0gaW50ZXJmYWNlIGZvciBtYWtpbmcgdHJhbnNsYXRlIHF1ZXJpZXMgdG8gbXVsdGl0cmFuIGFuZCBnZXQgY2xlYW4gcmVzcG9uc2VcblxuICBBbGwgZW5naW5lcyBtdXN0IGZvbGxvdyBjb21tb24gaW50ZXJmYWNlIGFuZCBwcm92aWRlIG1ldGhvZHM6XG4gICAgLSBzZWFyY2ggKGxhbmd1YW5nZSwgc3VjY2Vzc0hhbmRsZXIpICBjbGVhbiB0cmFuc2xhdGlvbiBtdXN0IGJlIHBhc3NlZCBpbnRvIHN1Y2Nlc3NIYW5kbGVyXG4gICAgLSBjbGlja1xuXG4gIFRyYW5zbGF0aW9uLW1vZHVsZSB0aGF0IG1ha2VzIHJlcXVlc3RzIHRvIGxhbmd1YWdlLWVuZ2luZSxcbiAgcGFyc2VzIHJlc3VsdHMgYW5kIHNlbmRzIHBsdWdpbi1nbG9iYWwgbWVzc2FnZSB3aXRoIHRyYW5zbGF0aW9uIGRhdGFcbiMjI1xuXG5DSEFSX0NPREVTID0gcmVxdWlyZSgnLi9jaGFyLWNvZGVzLmpzJyk7XG5cbmNsYXNzIFRyYW5cbiAgY29uc3RydWN0b3I6IC0+XG4gICAgQFRBQkxFX0NMQVNTID0gXCJfX19tdHRfdHJhbnNsYXRlX3RhYmxlXCJcbiAgICBAcHJvdG9jb2wgPSAnaHR0cCdcbiAgICBAaG9zdCA9ICd3d3cubXVsdGl0cmFuLnJ1J1xuICAgIEBwYXRoID0gJy9jL20uZXhlJ1xuICAgIEBxdWVyeSA9ICcmcz0nXG4gICAgQGxhbmcgPSAnP2wxPTImbDI9MScgI2Zyb20gcnVzc2lhbiB0byBlbmdsaXNoIGJ5IGRlZmF1bHRcbiAgICBAeGhyID0ge31cblxuICAjIyNcbiAgICBDb250ZXh0IG1lbnUgY2xpY2sgaGFuZGxlclxuICAjIyNcbiAgY2xpY2s6IChkYXRhKSAtPlxuICAgIGlmIHR5cGVvZiBkYXRhLnNpbGVudCA9PSB1bmRlZmluZWQgfHwgZGF0YS5zaWxlbnQgPT0gbnVsbFxuICAgICAgZGF0YS5zaWxlbnQgPSB0cnVlICMgdHJ1ZSBieSBkZWZhdWx0XG4gICAgc2VsZWN0aW9uVGV4dCA9IEByZW1vdmVIeXBoZW5hdGlvbiBkYXRhLnNlbGVjdGlvblRleHRcbiAgICBAc2VhcmNoXG4gICAgICAgIHZhbHVlOiBzZWxlY3Rpb25UZXh0XG4gICAgICAgIHN1Y2Nlc3M6IEBzdWNjZXNzdEhhbmRsZXIuYmluZCh0aGlzKVxuICAgICAgICBzaWxlbnQ6IGRhdGEuc2lsZW50ICAjIGlmIHRyYW5zbGF0aW9uIGZhaWxlZCBkbyBub3Qgc2hvdyBkaWFsb2dcblxuICAjIyNcbiAgICBEaXNjYXJkIHNvZnQgaHlwaGVuIGNoYXJhY3RlciAoVSswMEFELCAmc2h5OykgZnJvbSB0aGUgaW5wdXRcbiAgIyMjXG4gIHJlbW92ZUh5cGhlbmF0aW9uOiAodGV4dCkgLT5cbiAgICB0ZXh0LnJlcGxhY2UgL1xceGFkL2csICcnXG5cbiAgIyMjXG4gICAgSW5pdGlhdGUgdHJhbnNsYXRpb24gc2VhcmNoXG4gICMjI1xuICBzZWFyY2g6IChwYXJhbXMpIC0+XG4gICAgI3ZhbHVlLCBjYWxsYmFjaywgZXJyXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoe2xhbmd1YWdlOiAnMSd9LCAoaXRlbXMpID0+XG4gICAgICBpZiBsYW5ndWFnZSBpcyAnJ1xuICAgICAgICBsYW5ndWFnZSA9ICcxJ1xuICAgICAgQHNldExhbmd1YWdlKGl0ZW1zLmxhbmd1YWdlKVxuICAgICAgdXJsID0gQG1ha2VVcmwocGFyYW1zLnZhbHVlKTtcbiAgICAgICMgZGVjb3JhdGUgc3VjY2VzcyB0byBtYWtlIHByZWxpbWluYXJ5IHBhcnNpbmdcbiAgICAgIG9yaWdTdWNjZXNzID0gcGFyYW1zLnN1Y2Nlc3NcbiAgICAgIHBhcmFtcy5zdWNjZXNzID0gKHJlc3BvbnNlKSA9PlxuICAgICAgICB0cmFuc2xhdGVkID0gQHBhcnNlKHJlc3BvbnNlLCBwYXJhbXMuc2lsZW50KVxuICAgICAgICBvcmlnU3VjY2Vzcyh0cmFuc2xhdGVkKVxuXG4gICAgICAjIG1ha2UgcmVxdWVzdCAoR0VUIHJlcXVlc3Qgd2l0aCBxdWVyeSBwYXJhbWV0ZXJzIGluIHVybClcbiAgICAgIEByZXF1ZXN0KFxuICAgICAgICB1cmw6IHVybCxcbiAgICAgICAgc3VjY2VzczogcGFyYW1zLnN1Y2Nlc3MsXG4gICAgICAgIGVycm9yOiBwYXJhbXMuZXJyb3JcbiAgICAgIClcbiAgICApXG5cbiAgc2V0TGFuZ3VhZ2U6IChsYW5ndWFnZSkgLT5cbiAgICBAY3VycmVudExhbmd1YWdlID0gbGFuZ3VhZ2VcbiAgICBAbGFuZyA9ICc/bDE9MiZsMj0nICsgbGFuZ3VhZ2VcblxuICAjIyNcbiAgICBSZXF1ZXN0IHRyYW5zbGF0aW9uIGFuZCBydW4gY2FsbGJhY2sgZnVuY3Rpb25cbiAgICBwYXNzaW5nIHRyYW5zbGF0ZWQgcmVzdWx0IG9yIGVycm9yIHRvIGNhbGxiYWNrXG4gICMjI1xuICByZXF1ZXN0OiAob3B0cykgLT5cbiAgICB4aHIgPSBAeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KClcbiAgICB4aHIub25yZWFkeXN0YXRlY2hhbmdlID0gKGUpID0+XG4gICAgICB4aHIgPSBAeGhyXG4gICAgICBpZiB4aHIucmVhZHlTdGF0ZSA8IDRcbiAgICAgICAgcmV0dXJuXG4gICAgICBlbHNlIGlmIHhoci5zdGF0dXMgIT0gMjAwXG4gICAgICAgIEBlcnJvckhhbmRsZXIoeGhyKVxuICAgICAgICBpZiAodHlwZW9mIG9wdHMuZXJyb3IgPT0gJ2Z1bmN0aW9uJylcbiAgICAgICAgICBvcHRzLmVycm9yKClcbiAgICAgICAgcmV0dXJuXG4gICAgICBlbHNlIGlmIHhoci5yZWFkeVN0YXRlID09IDRcbiAgICAgICAgICByZXR1cm4gb3B0cy5zdWNjZXNzKGUudGFyZ2V0LnJlc3BvbnNlKVxuXG4gICAgeGhyLm9wZW4oXCJHRVRcIiwgb3B0cy51cmwsIHRydWUpO1xuICAgIHhoci5zZW5kKCk7XG5cblxuICBtYWtlVXJsOiAodmFsdWUpIC0+XG4gICAgdXJsID0gW0Bwcm90b2NvbCwgJzovLycsXG4gICAgICAgICAgICAgIEBob3N0LFxuICAgICAgICAgICAgICBAcGF0aCxcbiAgICAgICAgICAgICAgQGxhbmcsXG4gICAgICAgICAgICAgIEBxdWVyeSxcbiAgICAgICAgICAgICAgQGdldEVuY29kZWRWYWx1ZSh2YWx1ZSlcbiAgICAgICAgICBdLmpvaW4oJycpXG5cbiAgICByZXR1cm4gdXJsO1xuXG4gICMgUmVwbGFjZSBzcGVjaWFsIGxhbmd1YWdlIGNoYXJhY3RlcnMgdG8gaHRtbCBjb2Rlc1xuICBnZXRFbmNvZGVkVmFsdWU6ICh2YWx1ZSkgLT5cbiAgICAjIHRvIGZpbmQgc3BlYyBzeW1ib2xzIHdlIGZpcnN0IGVuY29kZSB0aGVtIChyYXcgc2VhcmNoIGZvciB0aGF0IHN5bWJvbCBkb2Vzbid0IHdvcilcbiAgICB2YWwgPSBlbmNvZGVVUklDb21wb25lbnQodmFsdWUpXG4gICAgZm9yIGNoYXIsIGNvZGUgb2YgQ0hBUl9DT0RFU1xuICAgICAgdmFsID0gdmFsLnJlcGxhY2UoY2hhciwgZW5jb2RlVVJJQ29tcG9uZW50KGNvZGUpKVxuICAgIHJldHVybiB2YWxcblxuICBlcnJvckhhbmRsZXI6ICh4aHIpIC0+XG4gICAgY29uc29sZS5sb2coJ2Vycm9yJywgeGhyKVxuXG4gICMjI1xuICAgUmVjZWl2aW5nIGRhdGEgZnJvbSB0cmFuc2xhdGlvbi1lbmdpbmUgYW5kIHNlbmQgcmVhZHkgbWVzc2FnZSB3aXRoIGRhdGFcbiAgIyMjXG4gIHN1Y2Nlc3N0SGFuZGxlcjogKHRyYW5zbGF0ZWQpIC0+XG4gICAgaWYgdHJhbnNsYXRlZFxuICAgICAgY2hyb21lLnRhYnMuZ2V0U2VsZWN0ZWQobnVsbCwgKHRhYikgPT5cbiAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgYWN0aW9uOiBAbWVzc2FnZVR5cGUgdHJhbnNsYXRlZFxuICAgICAgICAgIGRhdGE6IHRyYW5zbGF0ZWQub3V0ZXJIVE1MLFxuICAgICAgICAgIHN1Y2Nlc3M6ICF0cmFuc2xhdGVkLmNsYXNzTGlzdC5jb250YWlucygnZmFpbFRyYW5zbGF0ZScpXG4gICAgICAgIH0pXG4gICAgICApXG5cbiAgbWVzc2FnZVR5cGU6ICh0cmFuc2xhdGVkKSAtPlxuICAgIGlmIHRyYW5zbGF0ZWQ/LnJvd3M/Lmxlbmd0aCA9PSAxXG4gICAgICAnc2ltaWxhcl93b3JkcydcbiAgICBlbHNlXG4gICAgICAnb3Blbl90b29sdGlwJ1xuXG4gICMjI1xuICAgIFBhcnNlIHJlc3BvbnNlIGZyb20gdHJhbnNsYXRpb24gZW5naW5lXG4gICMjI1xuICBwYXJzZTogKHJlc3BvbnNlLCBzaWxlbnQsIHRyYW5zbGF0ZSA9IG51bGwpIC0+XG4gICAgICBkb2MgPSBAc3RyaXBTY3JpcHRzKHJlc3BvbnNlKVxuICAgICAgZnJhZ21lbnQgPSBAbWFrZUZyYWdtZW50KGRvYylcbiAgICAgIGlmIGZyYWdtZW50XG4gICAgICAgIHRyYW5zbGF0ZSA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3IoJyN0cmFuc2xhdGlvbiB+IHRhYmxlJylcbiAgICAgICAgaWYgdHJhbnNsYXRlXG4gICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9IEBUQUJMRV9DTEFTUztcbiAgICAgICAgICB0cmFuc2xhdGUuc2V0QXR0cmlidXRlKFwiY2VsbHBhZGRpbmdcIiwgXCI1XCIpXG4gICAgICAgICAgQGZpeEltYWdlcyh0cmFuc2xhdGUpXG4gICAgICAgICAgQGZpeExpbmtzKHRyYW5zbGF0ZSlcbiAgICAgICAgZWxzZSBpZiBub3Qgc2lsZW50XG4gICAgICAgICAgdHJhbnNsYXRlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gJ2ZhaWxUcmFuc2xhdGUnXG4gICAgICAgICAgdHJhbnNsYXRlLmlubmVyVGV4dCA9IFwiVW5mb3J0dW5hdGVseSwgY291bGQgbm90IHRyYW5zbGF0ZVwiXG5cbiAgICAgIHJldHVybiB0cmFuc2xhdGU7XG5cbiAgIyMjXG4gICAgU3RyaXAgc2NyaXB0IHRhZ3MgZnJvbSByZXNwb25zZSBodG1sXG4gICMjI1xuICBzdHJpcFNjcmlwdHM6IChzKSAtPlxuICAgIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgZGl2LmlubmVySFRNTCA9IHNcbiAgICBzY3JpcHRzID0gZGl2LmdldEVsZW1lbnRzQnlUYWdOYW1lKCdzY3JpcHQnKVxuICAgIGkgPSBzY3JpcHRzLmxlbmd0aFxuICAgIHdoaWxlIGktLVxuICAgICAgc2NyaXB0c1tpXS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHNjcmlwdHNbaV0pXG4gICAgcmV0dXJuIGRpdi5pbm5lckhUTUw7XG5cbiAgbWFrZUZyYWdtZW50OiAoZG9jLCBmcmFnbWVudCA9IG51bGwpIC0+XG4gICAgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKVxuICAgIGRpdi5pbm5lckhUTUwgPSBkb2NcbiAgICBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKVxuICAgIHdoaWxlICggZGl2LmZpcnN0Q2hpbGQgKVxuICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoIGRpdi5maXJzdENoaWxkIClcbiAgICByZXR1cm4gZnJhZ21lbnRcblxuICBmaXhJbWFnZXM6IChmcmFnbWVudD1udWxsKSAtPlxuICAgIHRoaXMuZml4VXJsKGZyYWdtZW50LCAnaW1nJywgJ3NyYycpO1xuICAgIHJldHVybiBmcmFnbWVudDtcblxuICBmaXhMaW5rczogKGZyYWdtZW50PW51bGwpIC0+XG4gICAgdGhpcy5maXhVcmwoZnJhZ21lbnQsICdhJywgJ2hyZWYnKVxuICAgIHJldHVybiBmcmFnbWVudFxuXG4gIGZpeFVybDogKGZyYWdtZW50PW51bGwsIHRhZywgYXR0cikgLT5cbiAgICBpZiBmcmFnbWVudFxuICAgICAgdGFncyA9ICBmcmFnbWVudC5xdWVyeVNlbGVjdG9yQWxsKHRhZylcbiAgICAgIHBhcnNlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKVxuICAgICAgZm9yIHRhZyBpbiB0YWdzXG4gICAgICAgIHBhcnNlci5ocmVmID0gdGFnW2F0dHJdXG4gICAgICAgIHBhcnNlci5ob3N0ID0gQGhvc3RcbiAgICAgICAgcGFyc2VyLnByb3RvY29sID0gQHByb3RvY29sXG4gICAgICAgICNmaXggcmVsYXRpdmUgbGlua3NcbiAgICAgICAgaWYgdGFnLnRhZ05hbWUgPT0gJ0EnXG4gICAgICAgICAgdGFnLmNsYXNzTGlzdC5hZGQgJ210dF9saW5rJ1xuICAgICAgICAgIGlmIHBhcnNlci5wYXRobmFtZS5pbmRleE9mKCdtLmV4ZScpIGlzbnQgLTFcbiAgICAgICAgICAgIHBhcnNlci5wYXRobmFtZSA9ICcvYycgKyBwYXJzZXIucGF0aG5hbWVcbiAgICAgICAgICAgIHRhZy5zZXRBdHRyaWJ1dGUoJ3RhcmdldCcsICdfYmxhbmsnKVxuICAgICAgICBlbHNlIGlmIHRhZy50YWdOYW1lID09ICdJTUcnXG4gICAgICAgICAgdGFnLmNsYXNzTGlzdC5hZGQgJ210dF9pbWcnXG5cbiAgICAgICAgdGFnLnNldEF0dHJpYnV0ZShhdHRyLCBwYXJzZXIuaHJlZilcblxuXG5cbm1vZHVsZS5leHBvcnRzID0gbmV3IFRyYW4iLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIF9wcm90b3R5cGVQcm9wZXJ0aWVzID0gZnVuY3Rpb24gKGNoaWxkLCBzdGF0aWNQcm9wcywgaW5zdGFuY2VQcm9wcykge1xuICBpZiAoc3RhdGljUHJvcHMpIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGNoaWxkLCBzdGF0aWNQcm9wcyk7XG4gIGlmIChpbnN0YW5jZVByb3BzKSBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhjaGlsZC5wcm90b3R5cGUsIGluc3RhbmNlUHJvcHMpO1xufTtcblxuLypcbiAgVHJhbnNsYXRpb24gZW5naW5lOiBodHRwOi8vd3d3LnR1cmtpc2hkaWN0aW9uYXJ5Lm5ldFxuICBGb3IgdHJhbnNsYXRpbmcgdHVya2lzaC1ydXNzaWFuIGFuZCB2aWNlIHZlcnNhXG4qL1xudmFyIENIQVJfQ09ERVMgPSByZXF1aXJlKFwiLi9jaGFyLWNvZGVzLXR1cmsuanNcIik7XG5cbnZhciBUdXJraXNoRGljdGlvbmFyeSA9IChmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIFR1cmtpc2hEaWN0aW9uYXJ5KCkge1xuICAgIHRoaXMuaG9zdCA9IFwiaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXQvP3dvcmQ9JUZDXCI7XG4gICAgdGhpcy5wYXRoID0gXCJcIjtcbiAgICB0aGlzLnByb3RvY29sID0gXCJodHRwXCI7XG4gICAgdGhpcy5xdWVyeSA9IFwiJnM9XCI7XG4gICAgdGhpcy5UQUJMRV9DTEFTUyA9IFwiX19fbXR0X3RyYW5zbGF0ZV90YWJsZVwiO1xuICAgIHRoaXMubmVlZF9wdWJsaXNoID0gdHJ1ZTtcbiAgfVxuXG4gIF9wcm90b3R5cGVQcm9wZXJ0aWVzKFR1cmtpc2hEaWN0aW9uYXJ5LCBudWxsLCB7XG4gICAgc2VhcmNoOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gc2VhcmNoKGRhdGEpIHtcbiAgICAgICAgZGF0YS51cmwgPSB0aGlzLm1ha2VVcmwoZGF0YS52YWx1ZSk7XG4gICAgICAgIHRoaXMubmVlZF9wdWJsaXNoID0gZmFsc2U7XG4gICAgICAgIHJldHVybiB0aGlzLnJlcXVlc3QoZGF0YSk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICB0cmFuc2xhdGU6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiB0cmFuc2xhdGUoZGF0YSkge1xuICAgICAgICBjb25zb2xlLmxvZyhcInJlcXVlc3QgZGF0YTpcIiwgZGF0YSk7XG4gICAgICAgIGRhdGEudXJsID0gdGhpcy5tYWtlVXJsKGRhdGEuc2VsZWN0aW9uVGV4dCk7XG4gICAgICAgIHRoaXMubmVlZF9wdWJsaXNoID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5yZXF1ZXN0KGRhdGEpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgbWFrZVVybDoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIG1ha2VVcmwodGV4dCkge1xuICAgICAgICB2YXIgdGV4dCA9IHRoaXMuZ2V0RW5jb2RlZFZhbHVlKHRleHQpO1xuICAgICAgICByZXR1cm4gW1wiaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXQvP3dvcmQ9XCIsIHRleHRdLmpvaW4oXCJcIik7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBnZXRFbmNvZGVkVmFsdWU6IHtcbiAgICAgIC8vIFJlcGxhY2Ugc3BlY2lhbCBsYW5ndWFnZSBjaGFyYWN0ZXJzIHRvIGh0bWwgY29kZXNcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBnZXRFbmNvZGVkVmFsdWUodmFsdWUpIHtcbiAgICAgICAgLy8gdG8gZmluZCBzcGVjIHN5bWJvbHMgd2UgZmlyc3QgZW5jb2RlIHRoZW0gKHJhdyBzZWFyY2ggZm9yIHRoYXQgc3ltYm9sIGRvZXNuJ3Qgd29yKVxuICAgICAgICB2YXIgdmFsID0gZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcbiAgICAgICAgZm9yICh2YXIgY2hhciBpbiBDSEFSX0NPREVTKSB7XG4gICAgICAgICAgdmFsID0gdmFsLnJlcGxhY2UoY2hhciwgQ0hBUl9DT0RFU1tjaGFyXSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHZhbDtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHJlcXVlc3Q6IHtcblxuICAgICAgLypcbiAgICAgICAgUmVxdWVzdCB0cmFuc2xhdGlvbiBhbmQgcnVuIGNhbGxiYWNrIGZ1bmN0aW9uXG4gICAgICAgIHBhc3NpbmcgdHJhbnNsYXRlZCByZXN1bHQgb3IgZXJyb3IgdG8gY2FsbGJhY2tcbiAgICAgICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gcmVxdWVzdChvcHRzKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwic3RhcnQgcmVxdWVzdFwiKTtcbiAgICAgICAgdGhpcy54aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgICAgdGhpcy54aHIub25yZWFkeXN0YXRlY2hhbmdlID0gdGhpcy5vblJlYWR5U3RhdGVDaGFuZ2UuYmluZCh0aGlzLCBvcHRzKTtcbiAgICAgICAgdGhpcy54aHIub3BlbihcIkdFVFwiLCBvcHRzLnVybCwgdHJ1ZSk7XG4gICAgICAgIHRoaXMueGhyLnNlbmQoKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIG9uUmVhZHlTdGF0ZUNoYW5nZToge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIG9uUmVhZHlTdGF0ZUNoYW5nZShvcHRzLCBlKSB7XG4gICAgICAgIHZhciB4aHIgPSB0aGlzLnhocjtcbiAgICAgICAgaWYgKHhoci5yZWFkeVN0YXRlIDwgNCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSBlbHNlIGlmICh4aHIuc3RhdHVzICE9IDIwMCkge1xuICAgICAgICAgIHRoaXMuZXJyb3JIYW5kbGVyKHhocik7XG4gICAgICAgICAgcmV0dXJuIG9wdHMuZXJyb3IgJiYgb3B0cy5lcnJvcigpO1xuICAgICAgICB9IGVsc2UgaWYgKHhoci5yZWFkeVN0YXRlID09IDQpIHtcbiAgICAgICAgICB2YXIgdHJhbnNsYXRpb24gPSB0aGlzLnN1Y2Nlc3NIYW5kbGVyKGUudGFyZ2V0LnJlc3BvbnNlKTtcbiAgICAgICAgICBjb25zb2xlLmxvZyhcInN1Y2Nlc3MgdHVya2lzaCB0cmFuc2xhdGVcIiwgdHJhbnNsYXRpb24pO1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwiY2FsbFwiLCBvcHRzLnN1Y2Nlc3MpO1xuICAgICAgICAgIHJldHVybiBvcHRzLnN1Y2Nlc3MgJiYgb3B0cy5zdWNjZXNzKHRyYW5zbGF0aW9uKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgc3VjY2Vzc0hhbmRsZXI6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBzdWNjZXNzSGFuZGxlcihyZXNwb25zZSkge1xuICAgICAgICB2YXIgZGF0YSA9IHRoaXMucGFyc2UocmVzcG9uc2UpO1xuICAgICAgICBpZiAodGhpcy5uZWVkX3B1Ymxpc2gpIHtcbiAgICAgICAgICBjaHJvbWUudGFicy5nZXRTZWxlY3RlZChudWxsLCB0aGlzLnB1Ymxpc2hUcmFuc2xhdGlvbi5iaW5kKHRoaXMsIGRhdGEpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZGF0YTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHB1Ymxpc2hUcmFuc2xhdGlvbjoge1xuXG4gICAgICAvKiBwdWJsaXNoIHN1Y2Nlc3NmdWx5IHRyYW5zbGF0ZWQgdGV4dCBhbGwgb3ZlciBleHRlbnNpb24gKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBwdWJsaXNoVHJhbnNsYXRpb24odHJhbnNsYXRpb24sIHRhYikge1xuICAgICAgICBjb25zb2xlLmxvZyhcInB1Ymxpc2ggdHJhbnNsYXRpb25cIik7XG4gICAgICAgIGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhYi5pZCwge1xuICAgICAgICAgIGFjdGlvbjogXCJvcGVuX3Rvb2x0aXBcIixcbiAgICAgICAgICBkYXRhOiB0cmFuc2xhdGlvbi5vdXRlckhUTUwsXG4gICAgICAgICAgc3VjY2VzczogIXRyYW5zbGF0aW9uLmNsYXNzTGlzdC5jb250YWlucyhcImZhaWxUcmFuc2xhdGVcIilcbiAgICAgICAgfSk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBlcnJvckhhbmRsZXI6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBlcnJvckhhbmRsZXIocmVzcG9uc2UpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJlcnJvciBhamF4XCIsIHJlc3BvbnNlKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHBhcnNlOiB7XG5cbiAgICAgIC8qIFBhcnNlIHJlc3BvbnNlIGZyb20gdHJhbnNsYXRpb24gZW5naW5lICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gcGFyc2UocmVzcG9uc2UsIHNpbGVudCwgdHJhbnNsYXRlKSB7XG4gICAgICAgIHZhciBkb2MgPSB0aGlzLnN0cmlwU2NyaXB0cyhyZXNwb25zZSksXG4gICAgICAgICAgICBmcmFnbWVudCA9IHRoaXMubWFrZUZyYWdtZW50KGRvYyk7XG4gICAgICAgIGlmIChmcmFnbWVudCkge1xuICAgICAgICAgIHRyYW5zbGF0ZSA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjbWVhbmluZ19kaXYgPiB0YWJsZVwiKTtcbiAgICAgICAgICBpZiAodHJhbnNsYXRlKSB7XG4gICAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gdGhpcy5UQUJMRV9DTEFTUztcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5zZXRBdHRyaWJ1dGUoXCJjZWxscGFkZGluZ1wiLCBcIjVcIik7XG4gICAgICAgICAgICAvLyBAZml4SW1hZ2VzKHRyYW5zbGF0ZSlcbiAgICAgICAgICAgIC8vIEBmaXhMaW5rcyh0cmFuc2xhdGUpXG4gICAgICAgICAgfSBlbHNlIGlmICghc2lsZW50KSB7XG4gICAgICAgICAgICB0cmFuc2xhdGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9IFwiZmFpbFRyYW5zbGF0ZVwiO1xuICAgICAgICAgICAgdHJhbnNsYXRlLmlubmVyVGV4dCA9IFwiVW5mb3J0dW5hdGVseSwgY291bGQgbm90IHRyYW5zbGF0ZVwiO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJhbnNsYXRlO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgc3RyaXBTY3JpcHRzOiB7XG5cbiAgICAgIC8vVE9ETyBleHRyYWN0IHRvIGJhc2UgZW5naW5lIGNsYXNzXG4gICAgICAvKiByZW1vdmVzIDxzY3JpcHQ+IHRhZ3MgZnJvbSBodG1sIGNvZGUgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBzdHJpcFNjcmlwdHMoaHRtbCkge1xuICAgICAgICB2YXIgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgZGl2LmlubmVySFRNTCA9IGh0bWw7XG4gICAgICAgIHZhciBzY3JpcHRzID0gZGl2LmdldEVsZW1lbnRzQnlUYWdOYW1lKFwic2NyaXB0XCIpO1xuICAgICAgICB2YXIgaSA9IHNjcmlwdHMubGVuZ3RoO1xuICAgICAgICB3aGlsZSAoaS0tKSBzY3JpcHRzW2ldLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc2NyaXB0c1tpXSk7XG4gICAgICAgIHJldHVybiBkaXYuaW5uZXJIVE1MO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgbWFrZUZyYWdtZW50OiB7XG5cbiAgICAgIC8vVE9ETyBleHRyYWN0IHRvIGJhc2UgZW5naW5lIGNsYXNzXG4gICAgICAvKiBjcmVhdGVzIHRlbXAgb2JqZWN0IHRvIHBhcnNlIHRyYW5zbGF0aW9uIGZyb20gcGFnZSBcbiAgICAgICAgKHNpbmNlIGl0J3Mgbm90IGEgZnJpZW5kbHkgYXBpKSBcbiAgICAgICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZUZyYWdtZW50KGh0bWwpIHtcbiAgICAgICAgdmFyIGZyYWdtZW50LFxuICAgICAgICAgICAgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgZGl2LmlubmVySFRNTCA9IGh0bWw7XG4gICAgICAgIGZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpO1xuICAgICAgICB3aGlsZSAoZGl2LmZpcnN0Q2hpbGQpIHtcbiAgICAgICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZChkaXYuZmlyc3RDaGlsZCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZyYWdtZW50O1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH1cbiAgfSk7XG5cbiAgcmV0dXJuIFR1cmtpc2hEaWN0aW9uYXJ5O1xufSkoKTtcblxuLy8gU2luZ2xldG9uZVxubW9kdWxlLmV4cG9ydHMgPSBuZXcgVHVya2lzaERpY3Rpb25hcnkoKTsiXX0=
