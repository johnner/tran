(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _ = require('../utils.js');
var SERVICE_URL = 'http://tran-service.com/api/user/';

var Options = (function () {
  function Options() {
    _classCallCheck(this, Options);

    this.signed = document.getElementById('signed');
    this.needSign = document.getElementById('need-sign');
  }

  /** Restores select box and checkbox state using
   * the preferences stored in chrome.storage.*/

  _createClass(Options, [{
    key: 'restore',
    value: function restore() {
      // Use default value language is 'english' and fast translate is true
      var defaults = {
        language: '1',
        fast: true,
        memorize: false
      };
      this.storage('get', defaults, this.onRestore);
    }

    /** Saves options to chrome.storage */
  }, {
    key: 'save',
    value: function save() {
      var params = arguments.length <= 0 || arguments[0] === undefined ? { restored: false } : arguments[0];

      // save options if only it is not restored onload
      if (!params.restored) {
        this.storage('set', this.options, this.onSave);
      } else {
        this.memorize();
      }
    }
  }, {
    key: 'onSave',
    value: function onSave() {
      // let user know that options are saved.
      var status = document.getElementById('status');
      status.textContent = 'Options saved.';
      var hideStatus = function hideStatus() {
        status.textContent = '';
      };
      this.memorize();
      setTimeout(hideStatus, 750);
    }

    /** Handler of success options restore */
  }, {
    key: 'onRestore',
    value: function onRestore(items) {
      // set checkboxes
      this.options = items;
      this.save({ restored: true });
    }

    /** chrome storage wrapper */
  }, {
    key: 'storage',
    value: function storage(op, data, cb) {
      cb = cb.bind(this);
      if (op == 'set') {
        chrome.storage.sync.set(data, function (evt) {
          return cb(evt);
        });
      } else if (op == 'get') {
        chrome.storage.sync.get(data, function (evt) {
          return cb(evt);
        });
      }
    }

    /** toggle memorize option */
  }, {
    key: 'memorize',
    value: function memorize() {
      var _this = this;

      if (this.options.memorize) {
        this.check_auth().then(function (res) {
          return _this.authorized = true;
        }, function (res) {
          return _this.authorized = false;
        });
      } else {
        this.revoke();
        this.signed.classList.add('hidden');
        this.needSign.classList.add('hidden');
      }
    }
  }, {
    key: 'check_login',
    value: function check_login() {
      var _this2 = this;

      _.get(SERVICE_URL).then(function (res) {
        return _this2.memok(res);
      }, function (res) {
        return _this2.memfail(res);
      });
    }

    /** memorization is activated */
  }, {
    key: 'memok',
    value: function memok(response) {
      this.authorized = true;
    }

    /** memorization failed */
  }, {
    key: 'memfail',
    value: function memfail(response) {
      this.authorized = false;
    }
  }, {
    key: 'check_auth',
    value: function check_auth() {
      return new Promise((function (resolve, reject) {
        this.storage('get', 'auth_token', (function (data) {
          if (!data.auth_token) {
            reject();
          } else {
            _.get(SERVICE_URL, { headers: { 'X-AUTH-TOKEN': data.auth_token } }).then(function (res) {
              return resolve(res);
            }, function (res) {
              return reject(res);
            });
          }
        }).bind(this));
      }).bind(this));
    }
  }, {
    key: 'signin',
    value: function signin() {
      var _this3 = this;

      var cred = {
        login: document.getElementById('login').value,
        password: document.getElementById('password').value
      };

      _.post(SERVICE_URL, { data: cred }).then(function (res) {
        return _this3.authSuccess(res);
      }, function (res) {
        return _this3.authFail(res);
      });
    }
  }, {
    key: 'authSuccess',
    value: function authSuccess(data) {
      var _this4 = this;

      this.storage('set', { 'auth_token': data }, function (data) {
        return _this4.save();
      });
      this.authorized = true;
    }
  }, {
    key: 'authFail',
    value: function authFail(data) {
      console.log('fail auth', data);
      var status = document.querySelector('.error-login');
      status.textContent = 'Bad login or password.';
      var hideStatus = function hideStatus() {
        status.textContent = '';
      };
      setTimeout(hideStatus, 2750);
    }
  }, {
    key: 'revoke',
    value: function revoke(event) {
      event && event.preventDefault();
      this.storage('set', { 'auth_token': null }, (function (data) {
        this.authorized = false;
      }).bind(this));
    }
  }, {
    key: 'options',
    get: function get() {
      return {
        language: document.getElementById('language').value,
        fast: document.getElementById('fast').checked,
        memorize: document.getElementById('memorize').checked
      };
    },
    set: function set(values) {
      document.getElementById('language').value = values.language;
      document.getElementById('fast').checked = values.fast;
      document.getElementById('memorize').checked = values.memorize;
    }
  }, {
    key: 'authorized',
    set: function set(state) {
      if (this.options.memorize) {
        if (state) {
          this.signed.classList.remove('hidden');
          this.needSign.classList.add('hidden');
        } else {
          this.needSign.classList.remove('hidden');
          this.signed.classList.add('hidden');
        }
      }
    }
  }]);

  return Options;
})();

document.addEventListener('DOMContentLoaded', function (event) {
  var options = new Options();
  options.restore();
  document.getElementById('save').addEventListener('click', function (evt) {
    return options.save();
  });
  document.getElementById('memorize').addEventListener('click', function (evt) {
    return options.memorize();
  });
  document.getElementById('signinBtn').addEventListener('click', function (evt) {
    return options.signin();
  });
  document.querySelector('#revoke').addEventListener('click', function (evt) {
    return options.revoke(evt);
  });
});
//# sourceMappingURL=options.js.map

},{"../utils.js":2}],2:[function(require,module,exports){
"use strict";

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Utils = (function () {
  function Utils() {
    _classCallCheck(this, Utils);
  }

  _createClass(Utils, [{
    key: "request",
    value: function request(type, url, opts) {
      // Return a new promise.
      return new Promise(function (resolve, reject) {
        // Do the usual XHR stuff
        var req = new XMLHttpRequest();
        req.withCredentials = true;
        req.open(type, url);
        if (type == 'POST') {
          req.setRequestHeader("Content-Type", "application/json");
        }
        req.onload = function () {
          // This is called even on 404 etc
          // so check the status
          if (req.status == 200) {
            // Resolve the promise with the response text
            resolve(req.response);
          } else {
            // Otherwise reject with the status text
            // which will hopefully be a meaningful error
            reject(Error(req.statusText));
          }
        };

        // Handle network errors
        req.onerror = function () {
          reject(Error("Network Error"));
        };

        // Set headers
        if (opts.headers) {
          var _iteratorNormalCompletion = true;
          var _didIteratorError = false;
          var _iteratorError = undefined;

          try {
            for (var _iterator = Object.keys(opts.headers)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              var key = _step.value;

              req.setRequestHeader(key, opts.headers[key]);
            }
          } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion && _iterator["return"]) {
                _iterator["return"]();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
          }
        }
        // Make the request
        req.send(JSON.stringify(opts.data));
      });
    }
  }, {
    key: "get",
    value: function get(url) {
      var opts = arguments.length <= 1 || arguments[1] === undefined ? { data: '' } : arguments[1];

      return this.request('GET', url, opts);
    }
  }, {
    key: "post",
    value: function post(url) {
      var opts = arguments.length <= 1 || arguments[1] === undefined ? { data: '' } : arguments[1];

      return this.request('POST', url, opts);
    }
  }]);

  return Utils;
})();

module.exports = new Utils();
//# sourceMappingURL=utils.js.map

},{}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxkZXZcXHRyYW5cXG5vZGVfbW9kdWxlc1xcYnJvd3Nlci1wYWNrXFxfcHJlbHVkZS5qcyIsIkM6L2Rldi90cmFuL2pzL2VzNS9vcHRpb25zL29wdGlvbnMuanMiLCJDOi9kZXYvdHJhbi9qcy9lczUvdXRpbHMuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM3T0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKX12YXIgZj1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwoZi5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxmLGYuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgX2NyZWF0ZUNsYXNzID0gKGZ1bmN0aW9uICgpIHsgZnVuY3Rpb24gZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIHByb3BzKSB7IGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpKyspIHsgdmFyIGRlc2NyaXB0b3IgPSBwcm9wc1tpXTsgZGVzY3JpcHRvci5lbnVtZXJhYmxlID0gZGVzY3JpcHRvci5lbnVtZXJhYmxlIHx8IGZhbHNlOyBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSA9IHRydWU7IGlmICgndmFsdWUnIGluIGRlc2NyaXB0b3IpIGRlc2NyaXB0b3Iud3JpdGFibGUgPSB0cnVlOyBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBkZXNjcmlwdG9yLmtleSwgZGVzY3JpcHRvcik7IH0gfSByZXR1cm4gZnVuY3Rpb24gKENvbnN0cnVjdG9yLCBwcm90b1Byb3BzLCBzdGF0aWNQcm9wcykgeyBpZiAocHJvdG9Qcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvci5wcm90b3R5cGUsIHByb3RvUHJvcHMpOyBpZiAoc3RhdGljUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IsIHN0YXRpY1Byb3BzKTsgcmV0dXJuIENvbnN0cnVjdG9yOyB9OyB9KSgpO1xuXG5mdW5jdGlvbiBfY2xhc3NDYWxsQ2hlY2soaW5zdGFuY2UsIENvbnN0cnVjdG9yKSB7IGlmICghKGluc3RhbmNlIGluc3RhbmNlb2YgQ29uc3RydWN0b3IpKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoJ0Nhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvbicpOyB9IH1cblxudmFyIF8gPSByZXF1aXJlKCcuLi91dGlscy5qcycpO1xudmFyIFNFUlZJQ0VfVVJMID0gJ2h0dHA6Ly90cmFuLXNlcnZpY2UuY29tL2FwaS91c2VyLyc7XG5cbnZhciBPcHRpb25zID0gKGZ1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gT3B0aW9ucygpIHtcbiAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgT3B0aW9ucyk7XG5cbiAgICB0aGlzLnNpZ25lZCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzaWduZWQnKTtcbiAgICB0aGlzLm5lZWRTaWduID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ25lZWQtc2lnbicpO1xuICB9XG5cbiAgLyoqIFJlc3RvcmVzIHNlbGVjdCBib3ggYW5kIGNoZWNrYm94IHN0YXRlIHVzaW5nXG4gICAqIHRoZSBwcmVmZXJlbmNlcyBzdG9yZWQgaW4gY2hyb21lLnN0b3JhZ2UuKi9cblxuICBfY3JlYXRlQ2xhc3MoT3B0aW9ucywgW3tcbiAgICBrZXk6ICdyZXN0b3JlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gcmVzdG9yZSgpIHtcbiAgICAgIC8vIFVzZSBkZWZhdWx0IHZhbHVlIGxhbmd1YWdlIGlzICdlbmdsaXNoJyBhbmQgZmFzdCB0cmFuc2xhdGUgaXMgdHJ1ZVxuICAgICAgdmFyIGRlZmF1bHRzID0ge1xuICAgICAgICBsYW5ndWFnZTogJzEnLFxuICAgICAgICBmYXN0OiB0cnVlLFxuICAgICAgICBtZW1vcml6ZTogZmFsc2VcbiAgICAgIH07XG4gICAgICB0aGlzLnN0b3JhZ2UoJ2dldCcsIGRlZmF1bHRzLCB0aGlzLm9uUmVzdG9yZSk7XG4gICAgfVxuXG4gICAgLyoqIFNhdmVzIG9wdGlvbnMgdG8gY2hyb21lLnN0b3JhZ2UgKi9cbiAgfSwge1xuICAgIGtleTogJ3NhdmUnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzYXZlKCkge1xuICAgICAgdmFyIHBhcmFtcyA9IGFyZ3VtZW50cy5sZW5ndGggPD0gMCB8fCBhcmd1bWVudHNbMF0gPT09IHVuZGVmaW5lZCA/IHsgcmVzdG9yZWQ6IGZhbHNlIH0gOiBhcmd1bWVudHNbMF07XG5cbiAgICAgIC8vIHNhdmUgb3B0aW9ucyBpZiBvbmx5IGl0IGlzIG5vdCByZXN0b3JlZCBvbmxvYWRcbiAgICAgIGlmICghcGFyYW1zLnJlc3RvcmVkKSB7XG4gICAgICAgIHRoaXMuc3RvcmFnZSgnc2V0JywgdGhpcy5vcHRpb25zLCB0aGlzLm9uU2F2ZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLm1lbW9yaXplKCk7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnb25TYXZlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gb25TYXZlKCkge1xuICAgICAgLy8gbGV0IHVzZXIga25vdyB0aGF0IG9wdGlvbnMgYXJlIHNhdmVkLlxuICAgICAgdmFyIHN0YXR1cyA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzdGF0dXMnKTtcbiAgICAgIHN0YXR1cy50ZXh0Q29udGVudCA9ICdPcHRpb25zIHNhdmVkLic7XG4gICAgICB2YXIgaGlkZVN0YXR1cyA9IGZ1bmN0aW9uIGhpZGVTdGF0dXMoKSB7XG4gICAgICAgIHN0YXR1cy50ZXh0Q29udGVudCA9ICcnO1xuICAgICAgfTtcbiAgICAgIHRoaXMubWVtb3JpemUoKTtcbiAgICAgIHNldFRpbWVvdXQoaGlkZVN0YXR1cywgNzUwKTtcbiAgICB9XG5cbiAgICAvKiogSGFuZGxlciBvZiBzdWNjZXNzIG9wdGlvbnMgcmVzdG9yZSAqL1xuICB9LCB7XG4gICAga2V5OiAnb25SZXN0b3JlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gb25SZXN0b3JlKGl0ZW1zKSB7XG4gICAgICAvLyBzZXQgY2hlY2tib3hlc1xuICAgICAgdGhpcy5vcHRpb25zID0gaXRlbXM7XG4gICAgICB0aGlzLnNhdmUoeyByZXN0b3JlZDogdHJ1ZSB9KTtcbiAgICB9XG5cbiAgICAvKiogY2hyb21lIHN0b3JhZ2Ugd3JhcHBlciAqL1xuICB9LCB7XG4gICAga2V5OiAnc3RvcmFnZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHN0b3JhZ2Uob3AsIGRhdGEsIGNiKSB7XG4gICAgICBjYiA9IGNiLmJpbmQodGhpcyk7XG4gICAgICBpZiAob3AgPT0gJ3NldCcpIHtcbiAgICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5zZXQoZGF0YSwgZnVuY3Rpb24gKGV2dCkge1xuICAgICAgICAgIHJldHVybiBjYihldnQpO1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSBpZiAob3AgPT0gJ2dldCcpIHtcbiAgICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoZGF0YSwgZnVuY3Rpb24gKGV2dCkge1xuICAgICAgICAgIHJldHVybiBjYihldnQpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKiogdG9nZ2xlIG1lbW9yaXplIG9wdGlvbiAqL1xuICB9LCB7XG4gICAga2V5OiAnbWVtb3JpemUnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtZW1vcml6ZSgpIHtcbiAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAgIGlmICh0aGlzLm9wdGlvbnMubWVtb3JpemUpIHtcbiAgICAgICAgdGhpcy5jaGVja19hdXRoKCkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgICAgcmV0dXJuIF90aGlzLmF1dGhvcml6ZWQgPSB0cnVlO1xuICAgICAgICB9LCBmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgICAgcmV0dXJuIF90aGlzLmF1dGhvcml6ZWQgPSBmYWxzZTtcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLnJldm9rZSgpO1xuICAgICAgICB0aGlzLnNpZ25lZC5jbGFzc0xpc3QuYWRkKCdoaWRkZW4nKTtcbiAgICAgICAgdGhpcy5uZWVkU2lnbi5jbGFzc0xpc3QuYWRkKCdoaWRkZW4nKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdjaGVja19sb2dpbicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNoZWNrX2xvZ2luKCkge1xuICAgICAgdmFyIF90aGlzMiA9IHRoaXM7XG5cbiAgICAgIF8uZ2V0KFNFUlZJQ0VfVVJMKS50aGVuKGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzMi5tZW1vayhyZXMpO1xuICAgICAgfSwgZnVuY3Rpb24gKHJlcykge1xuICAgICAgICByZXR1cm4gX3RoaXMyLm1lbWZhaWwocmVzKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKiBtZW1vcml6YXRpb24gaXMgYWN0aXZhdGVkICovXG4gIH0sIHtcbiAgICBrZXk6ICdtZW1vaycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG1lbW9rKHJlc3BvbnNlKSB7XG4gICAgICB0aGlzLmF1dGhvcml6ZWQgPSB0cnVlO1xuICAgIH1cblxuICAgIC8qKiBtZW1vcml6YXRpb24gZmFpbGVkICovXG4gIH0sIHtcbiAgICBrZXk6ICdtZW1mYWlsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gbWVtZmFpbChyZXNwb25zZSkge1xuICAgICAgdGhpcy5hdXRob3JpemVkID0gZmFsc2U7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnY2hlY2tfYXV0aCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNoZWNrX2F1dGgoKSB7XG4gICAgICByZXR1cm4gbmV3IFByb21pc2UoKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgdGhpcy5zdG9yYWdlKCdnZXQnLCAnYXV0aF90b2tlbicsIChmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgIGlmICghZGF0YS5hdXRoX3Rva2VuKSB7XG4gICAgICAgICAgICByZWplY3QoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgXy5nZXQoU0VSVklDRV9VUkwsIHsgaGVhZGVyczogeyAnWC1BVVRILVRPS0VOJzogZGF0YS5hdXRoX3Rva2VuIH0gfSkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgICAgICAgIHJldHVybiByZXNvbHZlKHJlcyk7XG4gICAgICAgICAgICB9LCBmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgICAgICAgIHJldHVybiByZWplY3QocmVzKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSkuYmluZCh0aGlzKSk7XG4gICAgICB9KS5iaW5kKHRoaXMpKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdzaWduaW4nLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzaWduaW4oKSB7XG4gICAgICB2YXIgX3RoaXMzID0gdGhpcztcblxuICAgICAgdmFyIGNyZWQgPSB7XG4gICAgICAgIGxvZ2luOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbG9naW4nKS52YWx1ZSxcbiAgICAgICAgcGFzc3dvcmQ6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdwYXNzd29yZCcpLnZhbHVlXG4gICAgICB9O1xuXG4gICAgICBfLnBvc3QoU0VSVklDRV9VUkwsIHsgZGF0YTogY3JlZCB9KS50aGVuKGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzMy5hdXRoU3VjY2VzcyhyZXMpO1xuICAgICAgfSwgZnVuY3Rpb24gKHJlcykge1xuICAgICAgICByZXR1cm4gX3RoaXMzLmF1dGhGYWlsKHJlcyk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdhdXRoU3VjY2VzcycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGF1dGhTdWNjZXNzKGRhdGEpIHtcbiAgICAgIHZhciBfdGhpczQgPSB0aGlzO1xuXG4gICAgICB0aGlzLnN0b3JhZ2UoJ3NldCcsIHsgJ2F1dGhfdG9rZW4nOiBkYXRhIH0sIGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgIHJldHVybiBfdGhpczQuc2F2ZSgpO1xuICAgICAgfSk7XG4gICAgICB0aGlzLmF1dGhvcml6ZWQgPSB0cnVlO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2F1dGhGYWlsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gYXV0aEZhaWwoZGF0YSkge1xuICAgICAgY29uc29sZS5sb2coJ2ZhaWwgYXV0aCcsIGRhdGEpO1xuICAgICAgdmFyIHN0YXR1cyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5lcnJvci1sb2dpbicpO1xuICAgICAgc3RhdHVzLnRleHRDb250ZW50ID0gJ0JhZCBsb2dpbiBvciBwYXNzd29yZC4nO1xuICAgICAgdmFyIGhpZGVTdGF0dXMgPSBmdW5jdGlvbiBoaWRlU3RhdHVzKCkge1xuICAgICAgICBzdGF0dXMudGV4dENvbnRlbnQgPSAnJztcbiAgICAgIH07XG4gICAgICBzZXRUaW1lb3V0KGhpZGVTdGF0dXMsIDI3NTApO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3Jldm9rZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJldm9rZShldmVudCkge1xuICAgICAgZXZlbnQgJiYgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgIHRoaXMuc3RvcmFnZSgnc2V0JywgeyAnYXV0aF90b2tlbic6IG51bGwgfSwgKGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgIHRoaXMuYXV0aG9yaXplZCA9IGZhbHNlO1xuICAgICAgfSkuYmluZCh0aGlzKSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnb3B0aW9ucycsXG4gICAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBsYW5ndWFnZTogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2xhbmd1YWdlJykudmFsdWUsXG4gICAgICAgIGZhc3Q6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdmYXN0JykuY2hlY2tlZCxcbiAgICAgICAgbWVtb3JpemU6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdtZW1vcml6ZScpLmNoZWNrZWRcbiAgICAgIH07XG4gICAgfSxcbiAgICBzZXQ6IGZ1bmN0aW9uIHNldCh2YWx1ZXMpIHtcbiAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdsYW5ndWFnZScpLnZhbHVlID0gdmFsdWVzLmxhbmd1YWdlO1xuICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2Zhc3QnKS5jaGVja2VkID0gdmFsdWVzLmZhc3Q7XG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbWVtb3JpemUnKS5jaGVja2VkID0gdmFsdWVzLm1lbW9yaXplO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2F1dGhvcml6ZWQnLFxuICAgIHNldDogZnVuY3Rpb24gc2V0KHN0YXRlKSB7XG4gICAgICBpZiAodGhpcy5vcHRpb25zLm1lbW9yaXplKSB7XG4gICAgICAgIGlmIChzdGF0ZSkge1xuICAgICAgICAgIHRoaXMuc2lnbmVkLmNsYXNzTGlzdC5yZW1vdmUoJ2hpZGRlbicpO1xuICAgICAgICAgIHRoaXMubmVlZFNpZ24uY2xhc3NMaXN0LmFkZCgnaGlkZGVuJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy5uZWVkU2lnbi5jbGFzc0xpc3QucmVtb3ZlKCdoaWRkZW4nKTtcbiAgICAgICAgICB0aGlzLnNpZ25lZC5jbGFzc0xpc3QuYWRkKCdoaWRkZW4nKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfV0pO1xuXG4gIHJldHVybiBPcHRpb25zO1xufSkoKTtcblxuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignRE9NQ29udGVudExvYWRlZCcsIGZ1bmN0aW9uIChldmVudCkge1xuICB2YXIgb3B0aW9ucyA9IG5ldyBPcHRpb25zKCk7XG4gIG9wdGlvbnMucmVzdG9yZSgpO1xuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc2F2ZScpLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgZnVuY3Rpb24gKGV2dCkge1xuICAgIHJldHVybiBvcHRpb25zLnNhdmUoKTtcbiAgfSk7XG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdtZW1vcml6ZScpLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgZnVuY3Rpb24gKGV2dCkge1xuICAgIHJldHVybiBvcHRpb25zLm1lbW9yaXplKCk7XG4gIH0pO1xuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc2lnbmluQnRuJykuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBmdW5jdGlvbiAoZXZ0KSB7XG4gICAgcmV0dXJuIG9wdGlvbnMuc2lnbmluKCk7XG4gIH0pO1xuICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjcmV2b2tlJykuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBmdW5jdGlvbiAoZXZ0KSB7XG4gICAgcmV0dXJuIG9wdGlvbnMucmV2b2tlKGV2dCk7XG4gIH0pO1xufSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1vcHRpb25zLmpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbnZhciBfY3JlYXRlQ2xhc3MgPSAoZnVuY3Rpb24gKCkgeyBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0aWVzKHRhcmdldCwgcHJvcHMpIHsgZm9yICh2YXIgaSA9IDA7IGkgPCBwcm9wcy5sZW5ndGg7IGkrKykgeyB2YXIgZGVzY3JpcHRvciA9IHByb3BzW2ldOyBkZXNjcmlwdG9yLmVudW1lcmFibGUgPSBkZXNjcmlwdG9yLmVudW1lcmFibGUgfHwgZmFsc2U7IGRlc2NyaXB0b3IuY29uZmlndXJhYmxlID0gdHJ1ZTsgaWYgKFwidmFsdWVcIiBpbiBkZXNjcmlwdG9yKSBkZXNjcmlwdG9yLndyaXRhYmxlID0gdHJ1ZTsgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgZGVzY3JpcHRvci5rZXksIGRlc2NyaXB0b3IpOyB9IH0gcmV0dXJuIGZ1bmN0aW9uIChDb25zdHJ1Y3RvciwgcHJvdG9Qcm9wcywgc3RhdGljUHJvcHMpIHsgaWYgKHByb3RvUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IucHJvdG90eXBlLCBwcm90b1Byb3BzKTsgaWYgKHN0YXRpY1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLCBzdGF0aWNQcm9wcyk7IHJldHVybiBDb25zdHJ1Y3RvcjsgfTsgfSkoKTtcblxuZnVuY3Rpb24gX2NsYXNzQ2FsbENoZWNrKGluc3RhbmNlLCBDb25zdHJ1Y3RvcikgeyBpZiAoIShpbnN0YW5jZSBpbnN0YW5jZW9mIENvbnN0cnVjdG9yKSkgeyB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IGNhbGwgYSBjbGFzcyBhcyBhIGZ1bmN0aW9uXCIpOyB9IH1cblxudmFyIFV0aWxzID0gKGZ1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gVXRpbHMoKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIFV0aWxzKTtcbiAgfVxuXG4gIF9jcmVhdGVDbGFzcyhVdGlscywgW3tcbiAgICBrZXk6IFwicmVxdWVzdFwiLFxuICAgIHZhbHVlOiBmdW5jdGlvbiByZXF1ZXN0KHR5cGUsIHVybCwgb3B0cykge1xuICAgICAgLy8gUmV0dXJuIGEgbmV3IHByb21pc2UuXG4gICAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAvLyBEbyB0aGUgdXN1YWwgWEhSIHN0dWZmXG4gICAgICAgIHZhciByZXEgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgICAgcmVxLndpdGhDcmVkZW50aWFscyA9IHRydWU7XG4gICAgICAgIHJlcS5vcGVuKHR5cGUsIHVybCk7XG4gICAgICAgIGlmICh0eXBlID09ICdQT1NUJykge1xuICAgICAgICAgIHJlcS5zZXRSZXF1ZXN0SGVhZGVyKFwiQ29udGVudC1UeXBlXCIsIFwiYXBwbGljYXRpb24vanNvblwiKTtcbiAgICAgICAgfVxuICAgICAgICByZXEub25sb2FkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIC8vIFRoaXMgaXMgY2FsbGVkIGV2ZW4gb24gNDA0IGV0Y1xuICAgICAgICAgIC8vIHNvIGNoZWNrIHRoZSBzdGF0dXNcbiAgICAgICAgICBpZiAocmVxLnN0YXR1cyA9PSAyMDApIHtcbiAgICAgICAgICAgIC8vIFJlc29sdmUgdGhlIHByb21pc2Ugd2l0aCB0aGUgcmVzcG9uc2UgdGV4dFxuICAgICAgICAgICAgcmVzb2x2ZShyZXEucmVzcG9uc2UpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBPdGhlcndpc2UgcmVqZWN0IHdpdGggdGhlIHN0YXR1cyB0ZXh0XG4gICAgICAgICAgICAvLyB3aGljaCB3aWxsIGhvcGVmdWxseSBiZSBhIG1lYW5pbmdmdWwgZXJyb3JcbiAgICAgICAgICAgIHJlamVjdChFcnJvcihyZXEuc3RhdHVzVGV4dCkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICAvLyBIYW5kbGUgbmV0d29yayBlcnJvcnNcbiAgICAgICAgcmVxLm9uZXJyb3IgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmVqZWN0KEVycm9yKFwiTmV0d29yayBFcnJvclwiKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gU2V0IGhlYWRlcnNcbiAgICAgICAgaWYgKG9wdHMuaGVhZGVycykge1xuICAgICAgICAgIHZhciBfaXRlcmF0b3JOb3JtYWxDb21wbGV0aW9uID0gdHJ1ZTtcbiAgICAgICAgICB2YXIgX2RpZEl0ZXJhdG9yRXJyb3IgPSBmYWxzZTtcbiAgICAgICAgICB2YXIgX2l0ZXJhdG9yRXJyb3IgPSB1bmRlZmluZWQ7XG5cbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgZm9yICh2YXIgX2l0ZXJhdG9yID0gT2JqZWN0LmtleXMob3B0cy5oZWFkZXJzKVtTeW1ib2wuaXRlcmF0b3JdKCksIF9zdGVwOyAhKF9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gPSAoX3N0ZXAgPSBfaXRlcmF0b3IubmV4dCgpKS5kb25lKTsgX2l0ZXJhdG9yTm9ybWFsQ29tcGxldGlvbiA9IHRydWUpIHtcbiAgICAgICAgICAgICAgdmFyIGtleSA9IF9zdGVwLnZhbHVlO1xuXG4gICAgICAgICAgICAgIHJlcS5zZXRSZXF1ZXN0SGVhZGVyKGtleSwgb3B0cy5oZWFkZXJzW2tleV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgX2RpZEl0ZXJhdG9yRXJyb3IgPSB0cnVlO1xuICAgICAgICAgICAgX2l0ZXJhdG9yRXJyb3IgPSBlcnI7XG4gICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIGlmICghX2l0ZXJhdG9yTm9ybWFsQ29tcGxldGlvbiAmJiBfaXRlcmF0b3JbXCJyZXR1cm5cIl0pIHtcbiAgICAgICAgICAgICAgICBfaXRlcmF0b3JbXCJyZXR1cm5cIl0oKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgaWYgKF9kaWRJdGVyYXRvckVycm9yKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgX2l0ZXJhdG9yRXJyb3I7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gTWFrZSB0aGUgcmVxdWVzdFxuICAgICAgICByZXEuc2VuZChKU09OLnN0cmluZ2lmeShvcHRzLmRhdGEpKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogXCJnZXRcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gZ2V0KHVybCkge1xuICAgICAgdmFyIG9wdHMgPSBhcmd1bWVudHMubGVuZ3RoIDw9IDEgfHwgYXJndW1lbnRzWzFdID09PSB1bmRlZmluZWQgPyB7IGRhdGE6ICcnIH0gOiBhcmd1bWVudHNbMV07XG5cbiAgICAgIHJldHVybiB0aGlzLnJlcXVlc3QoJ0dFVCcsIHVybCwgb3B0cyk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiBcInBvc3RcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gcG9zdCh1cmwpIHtcbiAgICAgIHZhciBvcHRzID0gYXJndW1lbnRzLmxlbmd0aCA8PSAxIHx8IGFyZ3VtZW50c1sxXSA9PT0gdW5kZWZpbmVkID8geyBkYXRhOiAnJyB9IDogYXJndW1lbnRzWzFdO1xuXG4gICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KCdQT1NUJywgdXJsLCBvcHRzKTtcbiAgICB9XG4gIH1dKTtcblxuICByZXR1cm4gVXRpbHM7XG59KSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBVdGlscygpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXRpbHMuanMubWFwXG4iXX0=
