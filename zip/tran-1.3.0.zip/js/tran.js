(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/
'use strict';

var CHAR_CODES = {
  //russian
  '%D1%8A': { val: '%FA', lang: 'ru' }, // ъ
  '%D0%AA': { val: '%DA', lang: 'ru' }, // Ъ

  '%C3%80': '&#192;', // À
  '%C3%81': '&#193;', // Á
  '%C3%82': '&#194;', // Â
  '%C3%83': '&#195;', // Ã
  '%C3%84': '&#196;', // Ä
  '%C3%85': '&#197;', // Å
  '%C3%86': '&#198;', // Æ

  '%C3%87': '&#199;', // Ç
  '%C3%88': '&#200;', // È
  '%C3%89': '&#201;', // É
  '%C3%8A': '&#202;', // Ê
  '%C3%8B': '&#203;', // Ë

  '%C3%8C': '&#204;', // Ì
  '%C3%8D': '&#205;', // Í
  '%C3%8E': '&#206;', // Î
  '%C3%8F': '&#207;', // Ï

  '%C3%91': '&#209;', // Ñ
  '%C3%92': '&#210;', // Ò
  '%C3%93': '&#211;', // Ó
  '%C3%94': '&#212;', // Ô
  '%C3%95': '&#213;', // Õ
  '%C3%96': '&#214;', // Ö

  '%C3%99': '&#217;', // Ù
  '%C3%9A': '&#218;', // Ú
  '%C3%9B': '&#219;', // Û
  '%C3%9C': '&#220;', // Ü

  '%C3%A0': '&#224;', // à
  '%C3%A1': '&#225;', // á
  '%C3%A2': '&#226;', // â
  '%C3%A3': '&#227;', // ã
  '%C3%A4': '&#228;', // ä
  '%C3%A5': '&#229;', // å
  '%C3%A6': '&#230;', // æ
  '%C3%A7': '&#231;', // ç

  '%C3%A8': '&#232;', // è
  '%C3%A9': '&#233;', // é
  '%C3%AA': '&#234;', // ê
  '%C3%AB': '&#235;', // ë

  '%C3%AC': '&#236;', // ì
  '%C3%AD': '&#237;', // í
  '%C3%AE': '&#238;', // î
  '%C3%AF': '&#239;', // ï

  '%C3%B0': '&#240;', // ð
  '%C3%B1': '&#241;', // ñ

  '%C3%B2': '&#242;', // ò
  '%C3%B3': '&#243;', // ó
  '%C3%B4': '&#244;', // ô
  '%C3%B5': '&#245;', // õ
  '%C3%B6': '&#246;', // ö

  '%C3%B9': '&#249;', // ù
  '%C3%BA': '&#250;', // ú
  '%C3%BB': '&#251;', // û
  '%C3%BC': '&#252;', // ü
  '%C3%BF': '&#255;', // ÿ
  '%C5%B8': '&#376;', // Ÿ

  '%C3%9F': '&#223;', // ß

  '%C2%BF': '&#191;', // ¿
  '%C2%A1': '&#161;' };

// ¡
module.exports = CHAR_CODES;
//# sourceMappingURL=char-codes.js.map

},{}],2:[function(require,module,exports){
/**
 Multitran translate engine
 Provides program interface for making translate queries to multitran and get clean response

 All engines must follow common interface and provide methods:
 - search (languange, successHandler)  clean translation must be passed into successHandler
 - click

 Translation-module that makes requests to language-engine,
 parses results and sends plugin-global message with translation data
 **/

'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var CHAR_CODES = require('./char-codes.js');

var Tran = (function () {
  function Tran() {
    _classCallCheck(this, Tran);

    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1'; // from russian to english by default
    this.xhr = {};
  }

  /**
   * Context menu click handler
   */

  _createClass(Tran, [{
    key: 'click',
    value: function click(data) {
      if (typeof data.silent === "undefined" || data.silent === null) {
        data.silent = true; // true by default
      }
      var selectionText = this.removeHyphenation(data.selectionText);
      this.search({
        value: selectionText,
        success: this.successtHandler.bind(this),
        silent: data.silent // if translation failed do not show dialog
      });
    }

    /**
     * Discard soft hyphen character (U+00AD, &shy;) from the input
     */
  }, {
    key: 'removeHyphenation',
    value: function removeHyphenation(text) {
      return text.replace(/\xad/g, '');
    }

    /**
     * Initiate translation search
     */
  }, {
    key: 'search',
    value: function search(params) {
      var _this = this;

      //value, callback, err
      chrome.storage.sync.get({ language: '1' }, function (items) {
        if (items.language === '') {
          items.language = '1';
        }
        _this.setLanguage(items.language);
        var url = _this.makeUrl(params.value);
        // decorate success to make preliminary parsing
        var origSuccess = params.success;
        params.success = function (response) {
          var translated = _this.parse(response, params.silent);
          origSuccess.call(_this, translated);
        };
        console.log('params.success=', params.success);
        _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      });
    }
  }, {
    key: 'setLanguage',
    value: function setLanguage(language) {
      this.currentLanguage = language;
      this.lang = '?l1=2&l2=' + language;
    }

    /**
     * Request translation and run callback function
     * passing translated result or error to callback
     * @param opts
     */
  }, {
    key: 'request',
    value: function request(opts) {
      var _this2 = this;

      var xhr = this.xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function (e) {
        xhr = _this2.xhr;
        if (xhr.readyState < 4) {
          return;
        } else if (xhr.status !== 200) {
          _this2.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error.call(_this2);
          }
          return;
        } else if (xhr.readyState == 4) {
          return opts.success(e.target.response);
        }
        return xhr;
      };

      xhr.open("GET", opts.url, true);
      xhr.send();
    }
  }, {
    key: 'makeUrl',
    value: function makeUrl(value) {
      return this.protocol + '://' + this.host + this.path + this.lang + this.query + this.getEncodedValue(value);
    }

    // Replace special language characters to html codes
  }, {
    key: 'getEncodedValue',
    value: function getEncodedValue(value) {
      //to find spec symbols we first encode them (raw search for that symbol doesn't work)
      var val = encodeURIComponent(value);
      var code = undefined,
          cc = undefined;
      for (var char in CHAR_CODES) {
        if (CHAR_CODES.hasOwnProperty(char)) {
          code = CHAR_CODES[char];
          if (typeof code === 'object') {
            // russian has special codes
            cc = code.val;
          } else {
            //for all langs except russian encode html-codes needed
            cc = encodeURIComponent(code);
          }
          val = val.replace(char, cc);
        }
      }
      return val;
    }
  }, {
    key: 'errorHandler',
    value: function errorHandler(xhr) {
      console.log('xhr error:', xhr);
    }

    //Receiving data from translation-engine and send ready message with data
  }, {
    key: 'successtHandler',
    value: function successtHandler(translated) {
      var _this3 = this;

      if (translated) {
        chrome.tabs.getSelected(null, function (tab) {
          chrome.tabs.sendMessage(tab.id, {
            action: _this3.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        });
      }
    }
  }, {
    key: 'messageType',
    value: function messageType(translated) {
      if (translated && translated.rows && translated.rows.length === 1) {
        return 'similar_words';
      } else {
        return 'open_tooltip';
      }
    }

    //Parse response from translation engine
  }, {
    key: 'parse',
    value: function parse(response, silent, translate) {
      translate = translate || null;
      var doc = this.stripScripts(response);
      var fragment = this.makeFragment(doc);
      if (fragment) {
        translate = fragment.querySelector('#translation ~ table');
        if (translate) {
          translate.className = this.TABLE_CLASS;
          translate.setAttribute("cellpadding", "5");
          this.fixImages(translate);
          this.fixLinks(translate);
        } else if (!silent) {
          translate = document.createElement('div');
          translate.className = 'failTranslate';
          translate.innerText = "Unfortunately, could not translate";
        }
      }
      return translate;
    }

    //  Strip script tags from response html
  }, {
    key: 'stripScripts',
    value: function stripScripts(res) {
      var div = document.createElement('div');
      div.innerHTML = res;
      var scripts = div.getElementsByTagName('script');
      var i = scripts.length;
      while (i--) {
        scripts[i].parentNode.removeChild(scripts[i]);
      }
      return div.innerHTML;
    }
  }, {
    key: 'makeFragment',
    value: function makeFragment(doc, fragment) {
      fragment = fragment || null;
      var div = document.createElement("div");
      div.innerHTML = doc;
      fragment = document.createDocumentFragment();
      while (div.firstChild) {
        fragment.appendChild(div.firstChild);
      }
      return fragment;
    }
  }, {
    key: 'fixImages',
    value: function fixImages(fragment) {
      fragment = fragment || null;
      this.fixUrl(fragment, 'img', 'src');
      return fragment;
    }
  }, {
    key: 'fixLinks',
    value: function fixLinks() {
      var fragment = arguments.length <= 0 || arguments[0] === undefined ? null : arguments[0];

      this.fixUrl(fragment, 'a', 'href');
      return fragment;
    }
  }, {
    key: 'fixUrl',
    value: function fixUrl(fragment, tag, attr) {
      if (fragment === undefined) fragment = null;

      var tags = {};
      if (fragment) {
        tags = fragment.querySelectorAll(tag);
      }
      var parser = document.createElement('a');
      for (var _tag in tags) {
        if (tags.hasOwnProperty(_tag)) {
          parser.href = _tag[attr];
          parser.host = this.host;
          parser.protocol = this.protocol;
          // fix relative links
          if (_tag.tagMessage === 'A') {
            _tag.classList.add('mtt_link');
            if (parser.pathname.indexOf('m.exe') !== -1) {
              parser.pathname = '/c' + parser.pathname;
              _tag.setAttribute('target', '_blank');
              _tag.setAttribute(attr, parser.href);
            }
          } else if (_tag.tagName === 'IMG') {
            _tag.classList.add('mtt_img');
          }
        }
      }
    }
  }]);

  return Tran;
})();

module.exports = new Tran();
//# sourceMappingURL=tran.js.map

},{"./char-codes.js":1}]},{},[2])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxkZXZcXHRyYW5cXG5vZGVfbW9kdWxlc1xcYnJvd3Nlci1wYWNrXFxfcHJlbHVkZS5qcyIsIkM6L2Rldi90cmFuL2pzL2VzNS9jaGFyLWNvZGVzLmpzIiwiQzovZGV2L3RyYW4vanMvZXM1L3RyYW4uanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2xGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3Rocm93IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIil9dmFyIGY9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGYuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sZixmLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIi8qXHIgIE11bHRpdHJhbiBkZXBlbmRzIG9uIGh0bWwtZXNjYXBpbmcgKG5vdCBVVEYtOCkgcnVsZXMgZm9yIHNwZWNpYWwgc3ltYm9sc1xyICDDoCwgw6gsIMOsLCDDsiwgw7kgLSDDgCwgw4gsIMOMLCDDkiwgw5lcciAgw6EsIMOpLCDDrSwgw7MsIMO6LCDDvSAtIMOBLCDDiSwgw40sIMOTLCDDmiwgw51cciAgw6IsIMOqLCDDriwgw7QsIMO7IMOCLCDDiiwgw44sIMOULCDDm1xyICDDoywgw7EsIMO1IMODLCDDkSwgw5VcciAgw6QsIMOrLCDDrywgw7YsIMO8LCDDvyDDhCwgw4ssIMOPLCDDliwgw5wsXHIgIMOlLCDDhVxyICDDpiwgw4ZcciAgw6csIMOHXHIgIMOwLCDDkFxyICDDuCwgw5hcciAgwr8gwqEgw59cciovXG4ndXNlIHN0cmljdCc7XG5cbnZhciBDSEFSX0NPREVTID0ge1xuICAvL3J1c3NpYW5cbiAgJyVEMSU4QSc6IHsgdmFsOiAnJUZBJywgbGFuZzogJ3J1JyB9LCAvLyDRilxuICAnJUQwJUFBJzogeyB2YWw6ICclREEnLCBsYW5nOiAncnUnIH0sIC8vINCqXG5cbiAgJyVDMyU4MCc6ICcmIzE5MjsnLCAvLyDDgFxuICAnJUMzJTgxJzogJyYjMTkzOycsIC8vIMOBXG4gICclQzMlODInOiAnJiMxOTQ7JywgLy8gw4JcbiAgJyVDMyU4Myc6ICcmIzE5NTsnLCAvLyDDg1xuICAnJUMzJTg0JzogJyYjMTk2OycsIC8vIMOEXG4gICclQzMlODUnOiAnJiMxOTc7JywgLy8gw4VcbiAgJyVDMyU4Nic6ICcmIzE5ODsnLCAvLyDDhlxuXG4gICclQzMlODcnOiAnJiMxOTk7JywgLy8gw4dcbiAgJyVDMyU4OCc6ICcmIzIwMDsnLCAvLyDDiFxuICAnJUMzJTg5JzogJyYjMjAxOycsIC8vIMOJXG4gICclQzMlOEEnOiAnJiMyMDI7JywgLy8gw4pcbiAgJyVDMyU4Qic6ICcmIzIwMzsnLCAvLyDDi1xuXG4gICclQzMlOEMnOiAnJiMyMDQ7JywgLy8gw4xcbiAgJyVDMyU4RCc6ICcmIzIwNTsnLCAvLyDDjVxuICAnJUMzJThFJzogJyYjMjA2OycsIC8vIMOOXG4gICclQzMlOEYnOiAnJiMyMDc7JywgLy8gw49cblxuICAnJUMzJTkxJzogJyYjMjA5OycsIC8vIMORXG4gICclQzMlOTInOiAnJiMyMTA7JywgLy8gw5JcbiAgJyVDMyU5Myc6ICcmIzIxMTsnLCAvLyDDk1xuICAnJUMzJTk0JzogJyYjMjEyOycsIC8vIMOUXG4gICclQzMlOTUnOiAnJiMyMTM7JywgLy8gw5VcbiAgJyVDMyU5Nic6ICcmIzIxNDsnLCAvLyDDllxuXG4gICclQzMlOTknOiAnJiMyMTc7JywgLy8gw5lcbiAgJyVDMyU5QSc6ICcmIzIxODsnLCAvLyDDmlxuICAnJUMzJTlCJzogJyYjMjE5OycsIC8vIMObXG4gICclQzMlOUMnOiAnJiMyMjA7JywgLy8gw5xcblxuICAnJUMzJUEwJzogJyYjMjI0OycsIC8vIMOgXG4gICclQzMlQTEnOiAnJiMyMjU7JywgLy8gw6FcbiAgJyVDMyVBMic6ICcmIzIyNjsnLCAvLyDDolxuICAnJUMzJUEzJzogJyYjMjI3OycsIC8vIMOjXG4gICclQzMlQTQnOiAnJiMyMjg7JywgLy8gw6RcbiAgJyVDMyVBNSc6ICcmIzIyOTsnLCAvLyDDpVxuICAnJUMzJUE2JzogJyYjMjMwOycsIC8vIMOmXG4gICclQzMlQTcnOiAnJiMyMzE7JywgLy8gw6dcblxuICAnJUMzJUE4JzogJyYjMjMyOycsIC8vIMOoXG4gICclQzMlQTknOiAnJiMyMzM7JywgLy8gw6lcbiAgJyVDMyVBQSc6ICcmIzIzNDsnLCAvLyDDqlxuICAnJUMzJUFCJzogJyYjMjM1OycsIC8vIMOrXG5cbiAgJyVDMyVBQyc6ICcmIzIzNjsnLCAvLyDDrFxuICAnJUMzJUFEJzogJyYjMjM3OycsIC8vIMOtXG4gICclQzMlQUUnOiAnJiMyMzg7JywgLy8gw65cbiAgJyVDMyVBRic6ICcmIzIzOTsnLCAvLyDDr1xuXG4gICclQzMlQjAnOiAnJiMyNDA7JywgLy8gw7BcbiAgJyVDMyVCMSc6ICcmIzI0MTsnLCAvLyDDsVxuXG4gICclQzMlQjInOiAnJiMyNDI7JywgLy8gw7JcbiAgJyVDMyVCMyc6ICcmIzI0MzsnLCAvLyDDs1xuICAnJUMzJUI0JzogJyYjMjQ0OycsIC8vIMO0XG4gICclQzMlQjUnOiAnJiMyNDU7JywgLy8gw7VcbiAgJyVDMyVCNic6ICcmIzI0NjsnLCAvLyDDtlxuXG4gICclQzMlQjknOiAnJiMyNDk7JywgLy8gw7lcbiAgJyVDMyVCQSc6ICcmIzI1MDsnLCAvLyDDulxuICAnJUMzJUJCJzogJyYjMjUxOycsIC8vIMO7XG4gICclQzMlQkMnOiAnJiMyNTI7JywgLy8gw7xcbiAgJyVDMyVCRic6ICcmIzI1NTsnLCAvLyDDv1xuICAnJUM1JUI4JzogJyYjMzc2OycsIC8vIMW4XG5cbiAgJyVDMyU5Ric6ICcmIzIyMzsnLCAvLyDDn1xuXG4gICclQzIlQkYnOiAnJiMxOTE7JywgLy8gwr9cbiAgJyVDMiVBMSc6ICcmIzE2MTsnIH07XG5cbi8vIMKhXG5tb2R1bGUuZXhwb3J0cyA9IENIQVJfQ09ERVM7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jaGFyLWNvZGVzLmpzLm1hcFxuIiwiLyoqXHJcbiBNdWx0aXRyYW4gdHJhbnNsYXRlIGVuZ2luZVxyXG4gUHJvdmlkZXMgcHJvZ3JhbSBpbnRlcmZhY2UgZm9yIG1ha2luZyB0cmFuc2xhdGUgcXVlcmllcyB0byBtdWx0aXRyYW4gYW5kIGdldCBjbGVhbiByZXNwb25zZVxyXG5cclxuIEFsbCBlbmdpbmVzIG11c3QgZm9sbG93IGNvbW1vbiBpbnRlcmZhY2UgYW5kIHByb3ZpZGUgbWV0aG9kczpcclxuIC0gc2VhcmNoIChsYW5ndWFuZ2UsIHN1Y2Nlc3NIYW5kbGVyKSAgY2xlYW4gdHJhbnNsYXRpb24gbXVzdCBiZSBwYXNzZWQgaW50byBzdWNjZXNzSGFuZGxlclxyXG4gLSBjbGlja1xyXG5cclxuIFRyYW5zbGF0aW9uLW1vZHVsZSB0aGF0IG1ha2VzIHJlcXVlc3RzIHRvIGxhbmd1YWdlLWVuZ2luZSxcclxuIHBhcnNlcyByZXN1bHRzIGFuZCBzZW5kcyBwbHVnaW4tZ2xvYmFsIG1lc3NhZ2Ugd2l0aCB0cmFuc2xhdGlvbiBkYXRhXHJcbiAqKi9cblxuJ3VzZSBzdHJpY3QnO1xuXG52YXIgX2NyZWF0ZUNsYXNzID0gKGZ1bmN0aW9uICgpIHsgZnVuY3Rpb24gZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIHByb3BzKSB7IGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpKyspIHsgdmFyIGRlc2NyaXB0b3IgPSBwcm9wc1tpXTsgZGVzY3JpcHRvci5lbnVtZXJhYmxlID0gZGVzY3JpcHRvci5lbnVtZXJhYmxlIHx8IGZhbHNlOyBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSA9IHRydWU7IGlmICgndmFsdWUnIGluIGRlc2NyaXB0b3IpIGRlc2NyaXB0b3Iud3JpdGFibGUgPSB0cnVlOyBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBkZXNjcmlwdG9yLmtleSwgZGVzY3JpcHRvcik7IH0gfSByZXR1cm4gZnVuY3Rpb24gKENvbnN0cnVjdG9yLCBwcm90b1Byb3BzLCBzdGF0aWNQcm9wcykgeyBpZiAocHJvdG9Qcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvci5wcm90b3R5cGUsIHByb3RvUHJvcHMpOyBpZiAoc3RhdGljUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IsIHN0YXRpY1Byb3BzKTsgcmV0dXJuIENvbnN0cnVjdG9yOyB9OyB9KSgpO1xuXG5mdW5jdGlvbiBfY2xhc3NDYWxsQ2hlY2soaW5zdGFuY2UsIENvbnN0cnVjdG9yKSB7IGlmICghKGluc3RhbmNlIGluc3RhbmNlb2YgQ29uc3RydWN0b3IpKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoJ0Nhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvbicpOyB9IH1cblxudmFyIENIQVJfQ09ERVMgPSByZXF1aXJlKCcuL2NoYXItY29kZXMuanMnKTtcblxudmFyIFRyYW4gPSAoZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBUcmFuKCkge1xuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBUcmFuKTtcblxuICAgIHRoaXMuVEFCTEVfQ0xBU1MgPSBcIl9fX210dF90cmFuc2xhdGVfdGFibGVcIjtcbiAgICB0aGlzLnByb3RvY29sID0gJ2h0dHAnO1xuICAgIHRoaXMuaG9zdCA9ICd3d3cubXVsdGl0cmFuLnJ1JztcbiAgICB0aGlzLnBhdGggPSAnL2MvbS5leGUnO1xuICAgIHRoaXMucXVlcnkgPSAnJnM9JztcbiAgICB0aGlzLmxhbmcgPSAnP2wxPTImbDI9MSc7IC8vIGZyb20gcnVzc2lhbiB0byBlbmdsaXNoIGJ5IGRlZmF1bHRcbiAgICB0aGlzLnhociA9IHt9O1xuICB9XG5cbiAgLyoqXHJcbiAgICogQ29udGV4dCBtZW51IGNsaWNrIGhhbmRsZXJcclxuICAgKi9cblxuICBfY3JlYXRlQ2xhc3MoVHJhbiwgW3tcbiAgICBrZXk6ICdjbGljaycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNsaWNrKGRhdGEpIHtcbiAgICAgIGlmICh0eXBlb2YgZGF0YS5zaWxlbnQgPT09IFwidW5kZWZpbmVkXCIgfHwgZGF0YS5zaWxlbnQgPT09IG51bGwpIHtcbiAgICAgICAgZGF0YS5zaWxlbnQgPSB0cnVlOyAvLyB0cnVlIGJ5IGRlZmF1bHRcbiAgICAgIH1cbiAgICAgIHZhciBzZWxlY3Rpb25UZXh0ID0gdGhpcy5yZW1vdmVIeXBoZW5hdGlvbihkYXRhLnNlbGVjdGlvblRleHQpO1xuICAgICAgdGhpcy5zZWFyY2goe1xuICAgICAgICB2YWx1ZTogc2VsZWN0aW9uVGV4dCxcbiAgICAgICAgc3VjY2VzczogdGhpcy5zdWNjZXNzdEhhbmRsZXIuYmluZCh0aGlzKSxcbiAgICAgICAgc2lsZW50OiBkYXRhLnNpbGVudCAvLyBpZiB0cmFuc2xhdGlvbiBmYWlsZWQgZG8gbm90IHNob3cgZGlhbG9nXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcclxuICAgICAqIERpc2NhcmQgc29mdCBoeXBoZW4gY2hhcmFjdGVyIChVKzAwQUQsICZzaHk7KSBmcm9tIHRoZSBpbnB1dFxyXG4gICAgICovXG4gIH0sIHtcbiAgICBrZXk6ICdyZW1vdmVIeXBoZW5hdGlvbicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJlbW92ZUh5cGhlbmF0aW9uKHRleHQpIHtcbiAgICAgIHJldHVybiB0ZXh0LnJlcGxhY2UoL1xceGFkL2csICcnKTtcbiAgICB9XG5cbiAgICAvKipcclxuICAgICAqIEluaXRpYXRlIHRyYW5zbGF0aW9uIHNlYXJjaFxyXG4gICAgICovXG4gIH0sIHtcbiAgICBrZXk6ICdzZWFyY2gnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzZWFyY2gocGFyYW1zKSB7XG4gICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgICAvL3ZhbHVlLCBjYWxsYmFjaywgZXJyXG4gICAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7IGxhbmd1YWdlOiAnMScgfSwgZnVuY3Rpb24gKGl0ZW1zKSB7XG4gICAgICAgIGlmIChpdGVtcy5sYW5ndWFnZSA9PT0gJycpIHtcbiAgICAgICAgICBpdGVtcy5sYW5ndWFnZSA9ICcxJztcbiAgICAgICAgfVxuICAgICAgICBfdGhpcy5zZXRMYW5ndWFnZShpdGVtcy5sYW5ndWFnZSk7XG4gICAgICAgIHZhciB1cmwgPSBfdGhpcy5tYWtlVXJsKHBhcmFtcy52YWx1ZSk7XG4gICAgICAgIC8vIGRlY29yYXRlIHN1Y2Nlc3MgdG8gbWFrZSBwcmVsaW1pbmFyeSBwYXJzaW5nXG4gICAgICAgIHZhciBvcmlnU3VjY2VzcyA9IHBhcmFtcy5zdWNjZXNzO1xuICAgICAgICBwYXJhbXMuc3VjY2VzcyA9IGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgICAgIHZhciB0cmFuc2xhdGVkID0gX3RoaXMucGFyc2UocmVzcG9uc2UsIHBhcmFtcy5zaWxlbnQpO1xuICAgICAgICAgIG9yaWdTdWNjZXNzLmNhbGwoX3RoaXMsIHRyYW5zbGF0ZWQpO1xuICAgICAgICB9O1xuICAgICAgICBjb25zb2xlLmxvZygncGFyYW1zLnN1Y2Nlc3M9JywgcGFyYW1zLnN1Y2Nlc3MpO1xuICAgICAgICBfdGhpcy5yZXF1ZXN0KHtcbiAgICAgICAgICB1cmw6IHVybCxcbiAgICAgICAgICBzdWNjZXNzOiBwYXJhbXMuc3VjY2VzcyxcbiAgICAgICAgICBlcnJvcjogcGFyYW1zLmVycm9yXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnc2V0TGFuZ3VhZ2UnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzZXRMYW5ndWFnZShsYW5ndWFnZSkge1xuICAgICAgdGhpcy5jdXJyZW50TGFuZ3VhZ2UgPSBsYW5ndWFnZTtcbiAgICAgIHRoaXMubGFuZyA9ICc/bDE9MiZsMj0nICsgbGFuZ3VhZ2U7XG4gICAgfVxuXG4gICAgLyoqXHJcbiAgICAgKiBSZXF1ZXN0IHRyYW5zbGF0aW9uIGFuZCBydW4gY2FsbGJhY2sgZnVuY3Rpb25cclxuICAgICAqIHBhc3NpbmcgdHJhbnNsYXRlZCByZXN1bHQgb3IgZXJyb3IgdG8gY2FsbGJhY2tcclxuICAgICAqIEBwYXJhbSBvcHRzXHJcbiAgICAgKi9cbiAgfSwge1xuICAgIGtleTogJ3JlcXVlc3QnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiByZXF1ZXN0KG9wdHMpIHtcbiAgICAgIHZhciBfdGhpczIgPSB0aGlzO1xuXG4gICAgICB2YXIgeGhyID0gdGhpcy54aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgIHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSBmdW5jdGlvbiAoZSkge1xuICAgICAgICB4aHIgPSBfdGhpczIueGhyO1xuICAgICAgICBpZiAoeGhyLnJlYWR5U3RhdGUgPCA0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9IGVsc2UgaWYgKHhoci5zdGF0dXMgIT09IDIwMCkge1xuICAgICAgICAgIF90aGlzMi5lcnJvckhhbmRsZXIoeGhyKTtcbiAgICAgICAgICBpZiAodHlwZW9mIG9wdHMuZXJyb3IgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIG9wdHMuZXJyb3IuY2FsbChfdGhpczIpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH0gZWxzZSBpZiAoeGhyLnJlYWR5U3RhdGUgPT0gNCkge1xuICAgICAgICAgIHJldHVybiBvcHRzLnN1Y2Nlc3MoZS50YXJnZXQucmVzcG9uc2UpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB4aHI7XG4gICAgICB9O1xuXG4gICAgICB4aHIub3BlbihcIkdFVFwiLCBvcHRzLnVybCwgdHJ1ZSk7XG4gICAgICB4aHIuc2VuZCgpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ21ha2VVcmwnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlVXJsKHZhbHVlKSB7XG4gICAgICByZXR1cm4gdGhpcy5wcm90b2NvbCArICc6Ly8nICsgdGhpcy5ob3N0ICsgdGhpcy5wYXRoICsgdGhpcy5sYW5nICsgdGhpcy5xdWVyeSArIHRoaXMuZ2V0RW5jb2RlZFZhbHVlKHZhbHVlKTtcbiAgICB9XG5cbiAgICAvLyBSZXBsYWNlIHNwZWNpYWwgbGFuZ3VhZ2UgY2hhcmFjdGVycyB0byBodG1sIGNvZGVzXG4gIH0sIHtcbiAgICBrZXk6ICdnZXRFbmNvZGVkVmFsdWUnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBnZXRFbmNvZGVkVmFsdWUodmFsdWUpIHtcbiAgICAgIC8vdG8gZmluZCBzcGVjIHN5bWJvbHMgd2UgZmlyc3QgZW5jb2RlIHRoZW0gKHJhdyBzZWFyY2ggZm9yIHRoYXQgc3ltYm9sIGRvZXNuJ3Qgd29yaylcbiAgICAgIHZhciB2YWwgPSBlbmNvZGVVUklDb21wb25lbnQodmFsdWUpO1xuICAgICAgdmFyIGNvZGUgPSB1bmRlZmluZWQsXG4gICAgICAgICAgY2MgPSB1bmRlZmluZWQ7XG4gICAgICBmb3IgKHZhciBjaGFyIGluIENIQVJfQ09ERVMpIHtcbiAgICAgICAgaWYgKENIQVJfQ09ERVMuaGFzT3duUHJvcGVydHkoY2hhcikpIHtcbiAgICAgICAgICBjb2RlID0gQ0hBUl9DT0RFU1tjaGFyXTtcbiAgICAgICAgICBpZiAodHlwZW9mIGNvZGUgPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICAvLyBydXNzaWFuIGhhcyBzcGVjaWFsIGNvZGVzXG4gICAgICAgICAgICBjYyA9IGNvZGUudmFsO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvL2ZvciBhbGwgbGFuZ3MgZXhjZXB0IHJ1c3NpYW4gZW5jb2RlIGh0bWwtY29kZXMgbmVlZGVkXG4gICAgICAgICAgICBjYyA9IGVuY29kZVVSSUNvbXBvbmVudChjb2RlKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFsID0gdmFsLnJlcGxhY2UoY2hhciwgY2MpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdmFsO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2Vycm9ySGFuZGxlcicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGVycm9ySGFuZGxlcih4aHIpIHtcbiAgICAgIGNvbnNvbGUubG9nKCd4aHIgZXJyb3I6JywgeGhyKTtcbiAgICB9XG5cbiAgICAvL1JlY2VpdmluZyBkYXRhIGZyb20gdHJhbnNsYXRpb24tZW5naW5lIGFuZCBzZW5kIHJlYWR5IG1lc3NhZ2Ugd2l0aCBkYXRhXG4gIH0sIHtcbiAgICBrZXk6ICdzdWNjZXNzdEhhbmRsZXInLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzdWNjZXNzdEhhbmRsZXIodHJhbnNsYXRlZCkge1xuICAgICAgdmFyIF90aGlzMyA9IHRoaXM7XG5cbiAgICAgIGlmICh0cmFuc2xhdGVkKSB7XG4gICAgICAgIGNocm9tZS50YWJzLmdldFNlbGVjdGVkKG51bGwsIGZ1bmN0aW9uICh0YWIpIHtcbiAgICAgICAgICBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWIuaWQsIHtcbiAgICAgICAgICAgIGFjdGlvbjogX3RoaXMzLm1lc3NhZ2VUeXBlKHRyYW5zbGF0ZWQpLFxuICAgICAgICAgICAgZGF0YTogdHJhbnNsYXRlZC5vdXRlckhUTUwsXG4gICAgICAgICAgICBzdWNjZXNzOiAhdHJhbnNsYXRlZC5jbGFzc0xpc3QuY29udGFpbnMoJ2ZhaWxUcmFuc2xhdGUnKVxuICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdtZXNzYWdlVHlwZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG1lc3NhZ2VUeXBlKHRyYW5zbGF0ZWQpIHtcbiAgICAgIGlmICh0cmFuc2xhdGVkICYmIHRyYW5zbGF0ZWQucm93cyAmJiB0cmFuc2xhdGVkLnJvd3MubGVuZ3RoID09PSAxKSB7XG4gICAgICAgIHJldHVybiAnc2ltaWxhcl93b3Jkcyc7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gJ29wZW5fdG9vbHRpcCc7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy9QYXJzZSByZXNwb25zZSBmcm9tIHRyYW5zbGF0aW9uIGVuZ2luZVxuICB9LCB7XG4gICAga2V5OiAncGFyc2UnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBwYXJzZShyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUpIHtcbiAgICAgIHRyYW5zbGF0ZSA9IHRyYW5zbGF0ZSB8fCBudWxsO1xuICAgICAgdmFyIGRvYyA9IHRoaXMuc3RyaXBTY3JpcHRzKHJlc3BvbnNlKTtcbiAgICAgIHZhciBmcmFnbWVudCA9IHRoaXMubWFrZUZyYWdtZW50KGRvYyk7XG4gICAgICBpZiAoZnJhZ21lbnQpIHtcbiAgICAgICAgdHJhbnNsYXRlID0gZnJhZ21lbnQucXVlcnlTZWxlY3RvcignI3RyYW5zbGF0aW9uIH4gdGFibGUnKTtcbiAgICAgICAgaWYgKHRyYW5zbGF0ZSkge1xuICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSB0aGlzLlRBQkxFX0NMQVNTO1xuICAgICAgICAgIHRyYW5zbGF0ZS5zZXRBdHRyaWJ1dGUoXCJjZWxscGFkZGluZ1wiLCBcIjVcIik7XG4gICAgICAgICAgdGhpcy5maXhJbWFnZXModHJhbnNsYXRlKTtcbiAgICAgICAgICB0aGlzLmZpeExpbmtzKHRyYW5zbGF0ZSk7XG4gICAgICAgIH0gZWxzZSBpZiAoIXNpbGVudCkge1xuICAgICAgICAgIHRyYW5zbGF0ZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSAnZmFpbFRyYW5zbGF0ZSc7XG4gICAgICAgICAgdHJhbnNsYXRlLmlubmVyVGV4dCA9IFwiVW5mb3J0dW5hdGVseSwgY291bGQgbm90IHRyYW5zbGF0ZVwiO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJhbnNsYXRlO1xuICAgIH1cblxuICAgIC8vICBTdHJpcCBzY3JpcHQgdGFncyBmcm9tIHJlc3BvbnNlIGh0bWxcbiAgfSwge1xuICAgIGtleTogJ3N0cmlwU2NyaXB0cycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHN0cmlwU2NyaXB0cyhyZXMpIHtcbiAgICAgIHZhciBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGRpdi5pbm5lckhUTUwgPSByZXM7XG4gICAgICB2YXIgc2NyaXB0cyA9IGRpdi5nZXRFbGVtZW50c0J5VGFnTmFtZSgnc2NyaXB0Jyk7XG4gICAgICB2YXIgaSA9IHNjcmlwdHMubGVuZ3RoO1xuICAgICAgd2hpbGUgKGktLSkge1xuICAgICAgICBzY3JpcHRzW2ldLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc2NyaXB0c1tpXSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZGl2LmlubmVySFRNTDtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdtYWtlRnJhZ21lbnQnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlRnJhZ21lbnQoZG9jLCBmcmFnbWVudCkge1xuICAgICAgZnJhZ21lbnQgPSBmcmFnbWVudCB8fCBudWxsO1xuICAgICAgdmFyIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICBkaXYuaW5uZXJIVE1MID0gZG9jO1xuICAgICAgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG4gICAgICB3aGlsZSAoZGl2LmZpcnN0Q2hpbGQpIHtcbiAgICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoZGl2LmZpcnN0Q2hpbGQpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZyYWdtZW50O1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2ZpeEltYWdlcycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGZpeEltYWdlcyhmcmFnbWVudCkge1xuICAgICAgZnJhZ21lbnQgPSBmcmFnbWVudCB8fCBudWxsO1xuICAgICAgdGhpcy5maXhVcmwoZnJhZ21lbnQsICdpbWcnLCAnc3JjJyk7XG4gICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnZml4TGlua3MnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBmaXhMaW5rcygpIHtcbiAgICAgIHZhciBmcmFnbWVudCA9IGFyZ3VtZW50cy5sZW5ndGggPD0gMCB8fCBhcmd1bWVudHNbMF0gPT09IHVuZGVmaW5lZCA/IG51bGwgOiBhcmd1bWVudHNbMF07XG5cbiAgICAgIHRoaXMuZml4VXJsKGZyYWdtZW50LCAnYScsICdocmVmJyk7XG4gICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnZml4VXJsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZml4VXJsKGZyYWdtZW50LCB0YWcsIGF0dHIpIHtcbiAgICAgIGlmIChmcmFnbWVudCA9PT0gdW5kZWZpbmVkKSBmcmFnbWVudCA9IG51bGw7XG5cbiAgICAgIHZhciB0YWdzID0ge307XG4gICAgICBpZiAoZnJhZ21lbnQpIHtcbiAgICAgICAgdGFncyA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3JBbGwodGFnKTtcbiAgICAgIH1cbiAgICAgIHZhciBwYXJzZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICBmb3IgKHZhciBfdGFnIGluIHRhZ3MpIHtcbiAgICAgICAgaWYgKHRhZ3MuaGFzT3duUHJvcGVydHkoX3RhZykpIHtcbiAgICAgICAgICBwYXJzZXIuaHJlZiA9IF90YWdbYXR0cl07XG4gICAgICAgICAgcGFyc2VyLmhvc3QgPSB0aGlzLmhvc3Q7XG4gICAgICAgICAgcGFyc2VyLnByb3RvY29sID0gdGhpcy5wcm90b2NvbDtcbiAgICAgICAgICAvLyBmaXggcmVsYXRpdmUgbGlua3NcbiAgICAgICAgICBpZiAoX3RhZy50YWdNZXNzYWdlID09PSAnQScpIHtcbiAgICAgICAgICAgIF90YWcuY2xhc3NMaXN0LmFkZCgnbXR0X2xpbmsnKTtcbiAgICAgICAgICAgIGlmIChwYXJzZXIucGF0aG5hbWUuaW5kZXhPZignbS5leGUnKSAhPT0gLTEpIHtcbiAgICAgICAgICAgICAgcGFyc2VyLnBhdGhuYW1lID0gJy9jJyArIHBhcnNlci5wYXRobmFtZTtcbiAgICAgICAgICAgICAgX3RhZy5zZXRBdHRyaWJ1dGUoJ3RhcmdldCcsICdfYmxhbmsnKTtcbiAgICAgICAgICAgICAgX3RhZy5zZXRBdHRyaWJ1dGUoYXR0ciwgcGFyc2VyLmhyZWYpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSBpZiAoX3RhZy50YWdOYW1lID09PSAnSU1HJykge1xuICAgICAgICAgICAgX3RhZy5jbGFzc0xpc3QuYWRkKCdtdHRfaW1nJyk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XSk7XG5cbiAgcmV0dXJuIFRyYW47XG59KSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBUcmFuKCk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD10cmFuLmpzLm1hcFxuIl19
