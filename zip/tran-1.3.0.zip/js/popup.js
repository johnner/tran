(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
// turkishdictionary codings
'use strict';

var DICT = {
    350: '%DE', //Ş
    286: '%D0', //Ğ
    287: '%F0', //ğ
    351: '%FE', //ş
    305: '%FD', //ı
    304: '%DD', //İ
    252: '%FC', //ü
    220: '%DC', //Ü
    231: '%E7', //ç
    199: '%C7', //Ç
    246: '%F6', //ö
    244: '%F4', //ô
    214: '%D6', //Ö
    212: '%D4', //Ô
    251: '%FB', //û
    219: '%DB', //Û
    194: '%C2', //Â
    226: '%E2', //â
    39: '' };

//'
module.exports = DICT;
//# sourceMappingURL=char-codes-turk.js.map

},{}],2:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/
'use strict';

var CHAR_CODES = {
  //russian
  '%D1%8A': { val: '%FA', lang: 'ru' }, // ъ
  '%D0%AA': { val: '%DA', lang: 'ru' }, // Ъ

  '%C3%80': '&#192;', // À
  '%C3%81': '&#193;', // Á
  '%C3%82': '&#194;', // Â
  '%C3%83': '&#195;', // Ã
  '%C3%84': '&#196;', // Ä
  '%C3%85': '&#197;', // Å
  '%C3%86': '&#198;', // Æ

  '%C3%87': '&#199;', // Ç
  '%C3%88': '&#200;', // È
  '%C3%89': '&#201;', // É
  '%C3%8A': '&#202;', // Ê
  '%C3%8B': '&#203;', // Ë

  '%C3%8C': '&#204;', // Ì
  '%C3%8D': '&#205;', // Í
  '%C3%8E': '&#206;', // Î
  '%C3%8F': '&#207;', // Ï

  '%C3%91': '&#209;', // Ñ
  '%C3%92': '&#210;', // Ò
  '%C3%93': '&#211;', // Ó
  '%C3%94': '&#212;', // Ô
  '%C3%95': '&#213;', // Õ
  '%C3%96': '&#214;', // Ö

  '%C3%99': '&#217;', // Ù
  '%C3%9A': '&#218;', // Ú
  '%C3%9B': '&#219;', // Û
  '%C3%9C': '&#220;', // Ü

  '%C3%A0': '&#224;', // à
  '%C3%A1': '&#225;', // á
  '%C3%A2': '&#226;', // â
  '%C3%A3': '&#227;', // ã
  '%C3%A4': '&#228;', // ä
  '%C3%A5': '&#229;', // å
  '%C3%A6': '&#230;', // æ
  '%C3%A7': '&#231;', // ç

  '%C3%A8': '&#232;', // è
  '%C3%A9': '&#233;', // é
  '%C3%AA': '&#234;', // ê
  '%C3%AB': '&#235;', // ë

  '%C3%AC': '&#236;', // ì
  '%C3%AD': '&#237;', // í
  '%C3%AE': '&#238;', // î
  '%C3%AF': '&#239;', // ï

  '%C3%B0': '&#240;', // ð
  '%C3%B1': '&#241;', // ñ

  '%C3%B2': '&#242;', // ò
  '%C3%B3': '&#243;', // ó
  '%C3%B4': '&#244;', // ô
  '%C3%B5': '&#245;', // õ
  '%C3%B6': '&#246;', // ö

  '%C3%B9': '&#249;', // ù
  '%C3%BA': '&#250;', // ú
  '%C3%BB': '&#251;', // û
  '%C3%BC': '&#252;', // ü
  '%C3%BF': '&#255;', // ÿ
  '%C5%B8': '&#376;', // Ÿ

  '%C3%9F': '&#223;', // ß

  '%C2%BF': '&#191;', // ¿
  '%C2%A1': '&#161;' };

// ¡
module.exports = CHAR_CODES;
//# sourceMappingURL=char-codes.js.map

},{}],3:[function(require,module,exports){

/*
  Dropdown language menu
  @param opts takes element and onSelect handler
  example:
  new Dropdown({
   el: document.getElementById('#menu');
   onSelect: function () {}
  })
 */
var DICT_CODE, Dropdown, LANG_CODE;

LANG_CODE = {
  '1': 'Eng',
  '2': 'Rus',
  '3': 'Ger',
  '4': 'Fre',
  '5': 'Spa',
  '23': 'Ita',
  '24': 'Dut',
  '26': 'Est',
  '27': 'Lav',
  '31': 'Afr',
  '34': 'Epo',
  '35': 'Xal',
  '1000': 'Tur'
};

DICT_CODE = {
  '1': 'multitran',
  '1000': 'turkish'
};

Dropdown = (function() {
  function Dropdown(opts) {
    this.el = opts.el || document.createElement('div');
    this.onSelect = opts.onSelect;
    this.menu = this.el.querySelector('.dropdown-menu');
    if (this.menu) {
      this.menu.style.display = 'none';
      this.items = this.menu.getElementsByClassName('language-type');
      this.button = this.el.querySelector('.dropdown-toggle');
      this.addListeners();
      this.initLanguage();
    }
  }

  Dropdown.prototype.addListeners = function() {
    this.button.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.toggle(e);
      };
    })(this));
    document.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.hide(e);
      };
    })(this));
    return this.menu.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.choose(e);
      };
    })(this));
  };

  Dropdown.prototype.initLanguage = function() {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(store) {
        return _this.setTitle(store.language);
      };
    })(this));
  };

  Dropdown.prototype.toggle = function(e) {
    e.stopPropagation();
    this.setActiveItem();
    if (this.menu && this.menu.style.display === 'none') {
      return this.show();
    } else {
      return this.hide();
    }
  };

  Dropdown.prototype.setActiveItem = function() {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(store) {
        var item, _i, _len, _ref, _results;
        _ref = _this.items;
        _results = [];
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          item = _ref[_i];
          if (item.getAttribute('data-val') === store.language) {
            _results.push(item.classList.add('active'));
          } else {
            _results.push(item.classList.remove('active'));
          }
        }
        return _results;
      };
    })(this));
  };

  Dropdown.prototype.hide = function() {
    return this.menu.style.display = 'none';
  };

  Dropdown.prototype.show = function() {
    return this.menu.style.display = 'block';
  };

  Dropdown.prototype.choose = function(e) {
    var dictionary, language;
    e.stopPropagation();
    e.preventDefault();
    language = e.target.getAttribute('data-val');
    dictionary = this.getDictionary(language);
    chrome.storage.sync.set({
      language: language,
      dictionary: dictionary
    }, this.onSelect);
    this.setTitle(language);
    return this.hide();
  };

  Dropdown.prototype.getDictionary = function(lang) {
    var dict;
    console.log('choose dict: for', lang);
    dict = DICT_CODE[lang] || 'multitran';
    console.log('dict', dict);
    return dict;
  };

  Dropdown.prototype.setTitle = function(language) {
    var html;
    html = LANG_CODE[language] + ' <span class="caret"></span>';
    return this.button.innerHTML = html;
  };

  return Dropdown;

})();

module.exports = Dropdown;


},{}],4:[function(require,module,exports){

/*
  Extension popup window
  Shows search form and dropdown menu with languages
 */
var SearchForm;

SearchForm = require('./search_form.coffee');

document.addEventListener("DOMContentLoaded", function() {
  var form, link;
  form = new SearchForm(document.getElementById('tran-form'));
  link = document.getElementById('header-link');
  if (link) {
    return link.addEventListener('click', function(e) {
      var href;
      e.preventDefault();
      href = e.target.getAttribute('href') + form.getValue();
      return chrome.tabs.create({
        url: href
      });
    });
  }
});


},{"./search_form.coffee":5}],5:[function(require,module,exports){

/*
  Serves search input and form

  @param form DOM elemnt
  @constructor
 */
var Dropdown, SearchForm, TRANSLATE_ENGINES, tran, turkishdictionary,
  __indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

Dropdown = require('./dropdown.coffee');

tran = require('../tran.js');

turkishdictionary = require('../turkishdictionary.js');

TRANSLATE_ENGINES = {
  'multitran': tran,
  'turkish': turkishdictionary
};

SearchForm = (function() {
  function SearchForm(form) {
    this.form = form;
    this.input = document.getElementById('translate-txt');
    this.input.focus();
    this.result = document.getElementById('result');
    this.addListeners();
    this.dropdown = new Dropdown({
      el: document.querySelector('.dropdown-el'),
      onSelect: (function(_this) {
        return function() {
          return _this.search();
        };
      })(this)
    });
  }

  SearchForm.prototype.addListeners = function() {
    if (this.form && this.result) {
      this.form.addEventListener('submit', (function(_this) {
        return function(e) {
          return _this.search(e);
        };
      })(this));
      return this.result.addEventListener('click', (function(_this) {
        return function(e) {
          return _this.resultClickHandler(e);
        };
      })(this));
    }
  };

  SearchForm.prototype.search = function(e) {
    e && e.preventDefault && e.preventDefault();
    if (this.input.value.length > 0) {
      return chrome.storage.sync.get({
        language: '1',
        dictionary: 'multitran'
      }, (function(_this) {
        return function(items) {
          console.log('ITEMS:', items);
          return TRANSLATE_ENGINES[items.dictionary].search({
            value: _this.input.value,
            success: _this.successHandler.bind(_this)
          });
        };
      })(this));
    }
  };

  SearchForm.prototype.successHandler = function(response) {
    this.clean(this.result);
    return this.result.appendChild(response);
  };

  SearchForm.prototype.clean = function(el) {
    var _results;
    _results = [];
    while (el.lastChild) {
      _results.push(el.removeChild(el.lastChild));
    }
    return _results;
  };

  SearchForm.prototype.resultClickHandler = function(e) {
    var linkTags, _ref;
    e.preventDefault();
    linkTags = ['A', 'a'];
    if (_ref = e.target.tagName, __indexOf.call(linkTags, _ref) >= 0) {
      this.input.value = e.target.innerText;
      return this.search(e);
    }
  };

  SearchForm.prototype.getValue = function() {
    return this.input.value;
  };

  return SearchForm;

})();

module.exports = SearchForm;


},{"../tran.js":6,"../turkishdictionary.js":7,"./dropdown.coffee":3}],6:[function(require,module,exports){
/**
 Multitran translate engine
 Provides program interface for making translate queries to multitran and get clean response

 All engines must follow common interface and provide methods:
 - search (languange, successHandler)  clean translation must be passed into successHandler
 - click

 Translation-module that makes requests to language-engine,
 parses results and sends plugin-global message with translation data
 **/
// var iconv = require('iconv-lite');

'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var CHAR_CODES = require('./char-codes.js');

var Tran = (function () {
  function Tran() {
    _classCallCheck(this, Tran);

    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1'; // from russian to english by default
    this.xhr = {};
  }

  /**
   * Context menu click handler
   */

  _createClass(Tran, [{
    key: 'click',
    value: function click(data) {
      if (typeof data.silent === "undefined" || data.silent === null) {
        data.silent = true; // true by default
      }
      var selectionText = this.removeHyphenation(data.selectionText);
      this.search({
        value: selectionText,
        success: this.successtHandler.bind(this),
        silent: data.silent // if translation failed do not show dialog
      });
    }

    /**
     * Discard soft hyphen character (U+00AD, &shy;) from the input
     */
  }, {
    key: 'removeHyphenation',
    value: function removeHyphenation(text) {
      return text.replace(/\xad/g, '');
    }

    /**
     * Initiate translation search
     */
  }, {
    key: 'search',
    value: function search(params) {
      var _this = this;

      //value, callback, err
      chrome.storage.sync.get({ language: '1' }, function (items) {
        if (items.language === '') {
          items.language = '1';
        }
        _this.setLanguage(items.language);
        var url = _this.makeUrl(params.value);
        // decorate success to make preliminary parsing
        var origSuccess = params.success;
        params.success = function (response) {
          var translated = _this.parse(response, params.silent);
          origSuccess.call(_this, translated);
        };
        console.log('params.success=', params.success);
        _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      });
    }

    //Parse response from translation engine
  }, {
    key: 'parse',
    value: function parse(response, silent, translate) {
      translate = translate || null;
      var doc = this.stripScripts(response);
      var fragment = this.makeFragment(doc);
      if (fragment) {
        translate = fragment.querySelector('#translation ~ table');
        if (translate) {
          translate.className = this.TABLE_CLASS;
          translate.setAttribute("cellpadding", "5");
          this.fixImages(translate);
          this.fixLinks(translate);
        } else if (!silent) {
          translate = document.createElement('div');
          translate.className = 'failTranslate';
          translate.innerText = "Unfortunately, could not translate";
        }
      }
      return translate;
    }
  }, {
    key: 'setLanguage',
    value: function setLanguage(language) {
      this.currentLanguage = language;
      this.lang = '?l1=2&l2=' + language;
    }

    /**
     * Request translation and run callback function
     * passing translated result or error to callback
     * @param opts
     */
  }, {
    key: 'request',
    value: function request(opts) {
      var _this2 = this;

      var xhr = this.xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function (e) {
        xhr = _this2.xhr;
        if (xhr.readyState < 4) {
          return;
        } else if (xhr.status !== 200) {
          _this2.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error.call(_this2);
          }
          return;
        } else if (xhr.readyState == 4) {
          return opts.success(e.target.response);
        }
        return xhr;
      };
      xhr.overrideMimeType("text/html;charset=cp1251");
      xhr.open("GET", opts.url, true);

      xhr.send();
    }
  }, {
    key: 'makeUrl',
    value: function makeUrl(value) {
      return this.protocol + '://' + this.host + this.path + this.lang + this.query + this.getEncodedValue(value);
    }

    // Replace special language characters to html codes
  }, {
    key: 'getEncodedValue',
    value: function getEncodedValue(value) {
      //to find spec symbols we first encode them (raw search for that symbol doesn't work)
      var val = encodeURIComponent(value);
      var code = undefined,
          cc = undefined;
      for (var char in CHAR_CODES) {
        if (CHAR_CODES.hasOwnProperty(char)) {
          code = CHAR_CODES[char];
          if (typeof code === 'object') {
            // russian has special codes
            cc = code.val;
          } else {
            //for all langs except russian encode html-codes needed
            cc = encodeURIComponent(code);
          }
          val = val.replace(char, cc);
        }
      }
      return val;
    }
  }, {
    key: 'errorHandler',
    value: function errorHandler(xhr) {
      console.log('xhr error:', xhr);
    }

    //Receiving data from translation-engine and send ready message with data
  }, {
    key: 'successtHandler',
    value: function successtHandler(translated) {
      var _this3 = this;

      if (translated) {
        chrome.tabs.getSelected(null, function (tab) {
          chrome.tabs.sendMessage(tab.id, {
            action: _this3.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        });
      }
    }
  }, {
    key: 'messageType',
    value: function messageType(translated) {
      if (translated && translated.rows && translated.rows.length === 1) {
        return 'similar_words';
      } else {
        return 'open_tooltip';
      }
    }

    //  Strip script tags from response html
  }, {
    key: 'stripScripts',
    value: function stripScripts(res) {
      var div = document.createElement('div');
      div.innerHTML = res;
      var scripts = div.getElementsByTagName('script');
      var i = scripts.length;
      while (i--) {
        scripts[i].parentNode.removeChild(scripts[i]);
      }
      return div.innerHTML;
    }
  }, {
    key: 'makeFragment',
    value: function makeFragment(doc, fragment) {
      fragment = fragment || null;
      var div = document.createElement("div");
      div.innerHTML = doc;
      fragment = document.createDocumentFragment();
      while (div.firstChild) {
        fragment.appendChild(div.firstChild);
      }
      return fragment;
    }
  }, {
    key: 'fixImages',
    value: function fixImages(fragment) {
      fragment = fragment || null;
      this.fixUrl(fragment, 'img', 'src');
      return fragment;
    }
  }, {
    key: 'fixLinks',
    value: function fixLinks() {
      var fragment = arguments.length <= 0 || arguments[0] === undefined ? null : arguments[0];

      this.fixUrl(fragment, 'a', 'href');
      return fragment;
    }
  }, {
    key: 'fixUrl',
    value: function fixUrl(fragment, tag, attr) {
      if (fragment === undefined) fragment = null;

      var tags = {};
      if (fragment) {
        tags = fragment.querySelectorAll(tag);
      }
      var parser = document.createElement('a');
      for (var _tag in tags) {
        if (tags.hasOwnProperty(_tag)) {
          parser.href = _tag[attr];
          parser.host = this.host;
          parser.protocol = this.protocol;
          // fix relative links
          if (_tag.tagMessage === 'A') {
            _tag.classList.add('mtt_link');
            if (parser.pathname.indexOf('m.exe') !== -1) {
              parser.pathname = '/c' + parser.pathname;
              _tag.setAttribute('target', '_blank');
              _tag.setAttribute(attr, parser.href);
            }
          } else if (_tag.tagName === 'IMG') {
            _tag.classList.add('mtt_img');
            _tag.src = '' + this.host + _tag.src;
          }
        }
      }
    }
  }]);

  return Tran;
})();

module.exports = new Tran();
//# sourceMappingURL=tran.js.map

},{"./char-codes.js":2}],7:[function(require,module,exports){
/*
  Translation engine: http://www.turkishdictionary.net
  For translating turkish-russian and vice versa
*/
'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var CHAR_CODES = require('./char-codes-turk.js');

var TurkishDictionary = (function () {
  function TurkishDictionary() {
    _classCallCheck(this, TurkishDictionary);

    this.host = 'http://www.turkishdictionary.net/?word=%FC';
    this.path = '';
    this.protocol = 'http';
    this.query = '&s=';
    this.TABLE_CLASS = '___mtt_translate_table';
    // this flag indicates that if translation was successful then publish it all over extension
    this.need_publish = true;
  }

  // Singletone

  _createClass(TurkishDictionary, [{
    key: 'search',
    value: function search(data) {
      data.url = this.makeUrl(data.value);
      this.need_publish = false;
      return this.request(data);
    }
  }, {
    key: 'translate',
    value: function translate(data) {
      data.url = this.makeUrl(data.selectionText);
      this.need_publish = true;
      this.request(data);
    }
  }, {
    key: 'makeUrl',
    value: function makeUrl(text) {
      var text = this.getEncodedValue(text);
      return ['http://www.turkishdictionary.net/?word=', text].join('');
    }

    // Replace special language characters to html codes
  }, {
    key: 'getEncodedValue',
    value: function getEncodedValue(value) {
      // to find spec symbols we first encode them (raw search for that symbol doesn't wor)
      return encodeURIComponent(value);
      //return this.makeStringTransferable(value);
    }

    /** converting script from the turkishdict */
  }, {
    key: 'makeStringTransferable',
    value: function makeStringTransferable(inputText) {
      var text = "";
      if (inputText.length > 0) {
        text = inputText;
        for (var i = 0; i < text.length; i++) {
          if (CHAR_CODES[text.charCodeAt(i)]) {
            text = text.substring(0, i) + CHAR_CODES[text.charCodeAt(i)] + text.substring(i + 1, text.length);
          } else if (text.charAt(i) == ' ') {
            // replace spaces
            text = text.substring(0, i) + '___' + text.substring(i + 1, text.length);
          }
        }
      }
      return text;
    }

    /*
      Request translation and run callback function
      passing translated result or error to callback
    */
  }, {
    key: 'request',
    value: function request(opts) {
      console.log('start request');
      this.xhr = new XMLHttpRequest();
      this.xhr.onreadystatechange = this.onReadyStateChange.bind(this, opts);
      this.xhr.open("GET", opts.url, true);
      this.xhr.send();
    }
  }, {
    key: 'onReadyStateChange',
    value: function onReadyStateChange(opts, e) {
      var xhr = this.xhr;
      if (xhr.readyState < 4) {
        return;
      } else if (xhr.status != 200) {
        this.errorHandler(xhr);
        return opts.error && opts.error();
      } else if (xhr.readyState == 4) {
        var translation = this.successHandler(e.target.response);
        console.log('success turkish translate', translation);
        console.log('call', opts.success);
        return opts.success && opts.success(translation);
      }
    }
  }, {
    key: 'successHandler',
    value: function successHandler(response) {
      var data = this.parse(response);
      if (this.need_publish) {
        chrome.tabs.getSelected(null, this.publishTranslation.bind(this, data));
      }
      return data;
    }

    /* publish successfuly translated text all over extension */
  }, {
    key: 'publishTranslation',
    value: function publishTranslation(translation, tab) {
      console.log('publish translation');
      chrome.tabs.sendMessage(tab.id, {
        action: this.tooltipAction(translation),
        data: translation.outerHTML,
        success: !translation.classList.contains('failTranslate')
      });
    }
  }, {
    key: 'tooltipAction',
    value: function tooltipAction(translation) {
      if (translation.textContent.trim().indexOf('was not found in our dictionary') != -1) {
        console.log('similar words');
        return 'similar_words';
      } else {
        console.log('open tooltip');
        return 'open_tooltip';
      }
    }
  }, {
    key: 'errorHandler',
    value: function errorHandler(response) {
      console.log('error ajax', response);
    }

    /* Parse response from translation engine */
  }, {
    key: 'parse',
    value: function parse(response, silent, translate) {
      var doc = this.stripScripts(response),
          fragment = this.makeFragment(doc);
      if (fragment) {
        translate = fragment.querySelector('#meaning_div > table');
        if (translate) {
          translate.className = this.TABLE_CLASS;
          translate.setAttribute("cellpadding", "5");
          // @fixImages(translate)
          // @fixLinks(translate)
        } else if (!silent) {
            translate = document.createElement('div');
            translate.className = 'failTranslate';
            translate.innerText = "Unfortunately, could not translate";
          }
      }
      return translate;
    }

    /** parsing of terrible html markup */
  }, {
    key: 'parseText',
    value: function parseText(response, silent, translate) {
      var _this = this;

      var doc = this.stripScripts(response),
          fragment = this.makeFragment(doc);

      if (fragment) {
        var i;

        var _ret = (function () {
          var stopIndex = null;
          var tr = fragment.querySelectorAll('#meaning_div>table>tbody>tr');
          tr = Array.prototype.slice.call(tr);

          var trans = tr.filter(function (tr, index) {
            if (!isNaN(parseInt(stopIndex, 10)) && index >= stopIndex) {
              return;
            } else {
              tr = $(tr);
              // take every row before next section (which is English->English)
              if (tr.attr('bgcolor') == "e0e6ff") {
                stopIndex = index;return;
              } else {
                return $.trim(tr.find('td').text()).length;
              }
            }
          });
          trans = trans.slice(1, trans.length - 1);
          trans = trans.filter(function (el, indx) {
            return indx % 2;
          });
          var frag = _this.fragmentFromList(trans);
          var fonts = frag.querySelectorAll('font');
          var text = '';
          for (i = 0; i < fonts.length; i++) {
            text += ' ' + fonts[i].textContent.trim();
          }
          return {
            v: text
          };
        })();

        if (typeof _ret === 'object') return _ret.v;
      } else {
        throw "HTML fragment could not be parsed";
      }
    }

    //TODO extract to base engine class
    /* removes <script> tags from html code */
  }, {
    key: 'stripScripts',
    value: function stripScripts(html) {
      var div = document.createElement('div');
      div.innerHTML = html;
      var scripts = div.getElementsByTagName('script');
      var i = scripts.length;
      while (i--) scripts[i].parentNode.removeChild(scripts[i]);
      return div.innerHTML;
    }

    //TODO extract to base engine class
    /* creates temp object to parse translation from page 
      (since it's not a friendly api) 
    */
  }, {
    key: 'makeFragment',
    value: function makeFragment(html) {
      var fragment = document.createDocumentFragment(),
          div = document.createElement("div");
      div.innerHTML = html;
      while (div.firstChild) {
        fragment.appendChild(div.firstChild);
      }
      return fragment;
    }

    /** create fragment from list of DOM elements */
  }, {
    key: 'fragmentFromList',
    value: function fragmentFromList(list) {
      var fragment = document.createDocumentFragment(),
          len = list.length;
      while (len--) {
        fragment.appendChild(list[len]);
      }
      return fragment;
    }
  }]);

  return TurkishDictionary;
})();

module.exports = new TurkishDictionary();
//# sourceMappingURL=turkishdictionary.js.map

},{"./char-codes-turk.js":1}]},{},[4])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxkZXZcXHRyYW5cXG5vZGVfbW9kdWxlc1xcYnJvd3Nlci1wYWNrXFxfcHJlbHVkZS5qcyIsIkM6L2Rldi90cmFuL2pzL2VzNS9jaGFyLWNvZGVzLXR1cmsuanMiLCJDOi9kZXYvdHJhbi9qcy9lczUvY2hhci1jb2Rlcy5qcyIsIkM6XFxkZXZcXHRyYW5cXGpzXFxlczVcXHBvcHVwXFxkcm9wZG93bi5jb2ZmZWUiLCJDOlxcZGV2XFx0cmFuXFxqc1xcZXM1XFxwb3B1cFxccG9wdXAuY29mZmVlIiwiQzpcXGRldlxcdHJhblxcanNcXGVzNVxccG9wdXBcXHNlYXJjaF9mb3JtLmNvZmZlZSIsIkM6L2Rldi90cmFuL2pzL2VzNS90cmFuLmpzIiwiQzovZGV2L3RyYW4vanMvZXM1L3R1cmtpc2hkaWN0aW9uYXJ5LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDM0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbEZBO0FBQUE7Ozs7Ozs7O0dBQUE7QUFBQSxJQUFBLDhCQUFBOztBQUFBLFNBU0EsR0FDRTtBQUFBLEVBQUEsR0FBQSxFQUFLLEtBQUw7QUFBQSxFQUNBLEdBQUEsRUFBSyxLQURMO0FBQUEsRUFFQSxHQUFBLEVBQUssS0FGTDtBQUFBLEVBR0EsR0FBQSxFQUFLLEtBSEw7QUFBQSxFQUlBLEdBQUEsRUFBSyxLQUpMO0FBQUEsRUFLQSxJQUFBLEVBQU0sS0FMTjtBQUFBLEVBTUEsSUFBQSxFQUFNLEtBTk47QUFBQSxFQU9BLElBQUEsRUFBTSxLQVBOO0FBQUEsRUFRQSxJQUFBLEVBQU0sS0FSTjtBQUFBLEVBU0EsSUFBQSxFQUFNLEtBVE47QUFBQSxFQVVBLElBQUEsRUFBTSxLQVZOO0FBQUEsRUFXQSxJQUFBLEVBQU0sS0FYTjtBQUFBLEVBWUEsTUFBQSxFQUFRLEtBWlI7Q0FWRixDQUFBOztBQUFBLFNBd0JBLEdBQ0U7QUFBQSxFQUFBLEdBQUEsRUFBSyxXQUFMO0FBQUEsRUFDQSxNQUFBLEVBQVEsU0FEUjtDQXpCRixDQUFBOztBQUFBO0FBNkJlLEVBQUEsa0JBQUMsSUFBRCxHQUFBO0FBQ1gsSUFBQSxJQUFDLENBQUEsRUFBRCxHQUFNLElBQUksQ0FBQyxFQUFMLElBQVcsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBakIsQ0FBQTtBQUFBLElBRUEsSUFBQyxDQUFBLFFBQUQsR0FBWSxJQUFJLENBQUMsUUFGakIsQ0FBQTtBQUFBLElBSUEsSUFBQyxDQUFBLElBQUQsR0FBUSxJQUFDLENBQUEsRUFBRSxDQUFDLGFBQUosQ0FBa0IsZ0JBQWxCLENBSlIsQ0FBQTtBQUtBLElBQUEsSUFBRyxJQUFDLENBQUEsSUFBSjtBQUNFLE1BQUEsSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWixHQUFzQixNQUF0QixDQUFBO0FBQUEsTUFDQSxJQUFDLENBQUEsS0FBRCxHQUFTLElBQUMsQ0FBQSxJQUFJLENBQUMsc0JBQU4sQ0FBNkIsZUFBN0IsQ0FEVCxDQUFBO0FBQUEsTUFFQSxJQUFDLENBQUEsTUFBRCxHQUFVLElBQUMsQ0FBQSxFQUFFLENBQUMsYUFBSixDQUFrQixrQkFBbEIsQ0FGVixDQUFBO0FBQUEsTUFHQSxJQUFDLENBQUEsWUFBRCxDQUFBLENBSEEsQ0FBQTtBQUFBLE1BSUEsSUFBQyxDQUFBLFlBQUQsQ0FBQSxDQUpBLENBREY7S0FOVztFQUFBLENBQWI7O0FBQUEscUJBYUEsWUFBQSxHQUFjLFNBQUEsR0FBQTtBQUNaLElBQUEsSUFBQyxDQUFBLE1BQU0sQ0FBQyxnQkFBUixDQUF5QixPQUF6QixFQUFrQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7ZUFBTyxLQUFDLENBQUEsTUFBRCxDQUFRLENBQVIsRUFBUDtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxDLENBQUEsQ0FBQTtBQUFBLElBQ0EsUUFBUSxDQUFDLGdCQUFULENBQTBCLE9BQTFCLEVBQW1DLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLENBQUQsR0FBQTtlQUFPLEtBQUMsQ0FBQSxJQUFELENBQU0sQ0FBTixFQUFQO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbkMsQ0FEQSxDQUFBO1dBRUEsSUFBQyxDQUFBLElBQUksQ0FBQyxnQkFBTixDQUF1QixPQUF2QixFQUFnQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7ZUFBTyxLQUFDLENBQUEsTUFBRCxDQUFRLENBQVIsRUFBUDtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWhDLEVBSFk7RUFBQSxDQWJkLENBQUE7O0FBQUEscUJBbUJBLFlBQUEsR0FBYyxTQUFBLEdBQUE7V0FDWixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUUsUUFBQSxFQUFVLEdBQVo7S0FBeEIsRUFBMEMsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsS0FBRCxHQUFBO2VBQ3hDLEtBQUMsQ0FBQSxRQUFELENBQVUsS0FBSyxDQUFDLFFBQWhCLEVBRHdDO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBMUMsRUFEWTtFQUFBLENBbkJkLENBQUE7O0FBQUEscUJBd0JBLE1BQUEsR0FBUSxTQUFDLENBQUQsR0FBQTtBQUNOLElBQUEsQ0FBQyxDQUFDLGVBQUYsQ0FBQSxDQUFBLENBQUE7QUFBQSxJQUNBLElBQUMsQ0FBQSxhQUFELENBQUEsQ0FEQSxDQUFBO0FBRUEsSUFBQSxJQUFHLElBQUMsQ0FBQSxJQUFELElBQVUsSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWixLQUF1QixNQUFwQzthQUNFLElBQUMsQ0FBQSxJQUFELENBQUEsRUFERjtLQUFBLE1BQUE7YUFHRSxJQUFDLENBQUEsSUFBRCxDQUFBLEVBSEY7S0FITTtFQUFBLENBeEJSLENBQUE7O0FBQUEscUJBaUNBLGFBQUEsR0FBZSxTQUFBLEdBQUE7V0FDYixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUMsUUFBQSxFQUFVLEdBQVg7S0FBeEIsRUFBeUMsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsS0FBRCxHQUFBO0FBQ3ZDLFlBQUEsOEJBQUE7QUFBQTtBQUFBO2FBQUEsMkNBQUE7MEJBQUE7QUFDRSxVQUFBLElBQUcsSUFBSSxDQUFDLFlBQUwsQ0FBa0IsVUFBbEIsQ0FBQSxLQUFpQyxLQUFLLENBQUMsUUFBMUM7MEJBQ0UsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFmLENBQW1CLFFBQW5CLEdBREY7V0FBQSxNQUFBOzBCQUdFLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBZixDQUFzQixRQUF0QixHQUhGO1dBREY7QUFBQTt3QkFEdUM7TUFBQSxFQUFBO0lBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUF6QyxFQURhO0VBQUEsQ0FqQ2YsQ0FBQTs7QUFBQSxxQkF5Q0EsSUFBQSxHQUFNLFNBQUEsR0FBQTtXQUNKLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQVosR0FBc0IsT0FEbEI7RUFBQSxDQXpDTixDQUFBOztBQUFBLHFCQTRDQSxJQUFBLEdBQU0sU0FBQSxHQUFBO1dBQ0osSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWixHQUFzQixRQURsQjtFQUFBLENBNUNOLENBQUE7O0FBQUEscUJBaURBLE1BQUEsR0FBUSxTQUFDLENBQUQsR0FBQTtBQUNOLFFBQUEsb0JBQUE7QUFBQSxJQUFBLENBQUMsQ0FBQyxlQUFGLENBQUEsQ0FBQSxDQUFBO0FBQUEsSUFDQSxDQUFDLENBQUMsY0FBRixDQUFBLENBREEsQ0FBQTtBQUFBLElBRUEsUUFBQSxHQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBVCxDQUFzQixVQUF0QixDQUZYLENBQUE7QUFBQSxJQUdBLFVBQUEsR0FBYSxJQUFDLENBQUEsYUFBRCxDQUFlLFFBQWYsQ0FIYixDQUFBO0FBQUEsSUFJQSxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUMsUUFBQSxFQUFVLFFBQVg7QUFBQSxNQUFxQixVQUFBLEVBQVksVUFBakM7S0FBeEIsRUFBc0UsSUFBQyxDQUFBLFFBQXZFLENBSkEsQ0FBQTtBQUFBLElBS0EsSUFBQyxDQUFBLFFBQUQsQ0FBVSxRQUFWLENBTEEsQ0FBQTtXQU1BLElBQUMsQ0FBQSxJQUFELENBQUEsRUFQTTtFQUFBLENBakRSLENBQUE7O0FBQUEscUJBNERBLGFBQUEsR0FBZSxTQUFDLElBQUQsR0FBQTtBQUNiLFFBQUEsSUFBQTtBQUFBLElBQUEsT0FBTyxDQUFDLEdBQVIsQ0FBWSxrQkFBWixFQUErQixJQUEvQixDQUFBLENBQUE7QUFBQSxJQUNBLElBQUEsR0FBTyxTQUFVLENBQUEsSUFBQSxDQUFWLElBQW1CLFdBRDFCLENBQUE7QUFBQSxJQUVBLE9BQU8sQ0FBQyxHQUFSLENBQVksTUFBWixFQUFtQixJQUFuQixDQUZBLENBQUE7QUFHQSxXQUFPLElBQVAsQ0FKYTtFQUFBLENBNURmLENBQUE7O0FBQUEscUJBbUVBLFFBQUEsR0FBVSxTQUFDLFFBQUQsR0FBQTtBQUNSLFFBQUEsSUFBQTtBQUFBLElBQUEsSUFBQSxHQUFPLFNBQVUsQ0FBQSxRQUFBLENBQVYsR0FBc0IsOEJBQTdCLENBQUE7V0FDQSxJQUFDLENBQUEsTUFBTSxDQUFDLFNBQVIsR0FBb0IsS0FGWjtFQUFBLENBbkVWLENBQUE7O2tCQUFBOztJQTdCRixDQUFBOztBQUFBLE1BcUdNLENBQUMsT0FBUCxHQUFpQixRQXJHakIsQ0FBQTs7OztBQ0FBO0FBQUE7OztHQUFBO0FBQUEsSUFBQSxVQUFBOztBQUFBLFVBSUEsR0FBYSxPQUFBLENBQVEsc0JBQVIsQ0FKYixDQUFBOztBQUFBLFFBTVEsQ0FBQyxnQkFBVCxDQUEwQixrQkFBMUIsRUFBOEMsU0FBQSxHQUFBO0FBQzVDLE1BQUEsVUFBQTtBQUFBLEVBQUEsSUFBQSxHQUFXLElBQUEsVUFBQSxDQUFXLFFBQVEsQ0FBQyxjQUFULENBQXdCLFdBQXhCLENBQVgsQ0FBWCxDQUFBO0FBQUEsRUFDQSxJQUFBLEdBQU8sUUFBUSxDQUFDLGNBQVQsQ0FBd0IsYUFBeEIsQ0FEUCxDQUFBO0FBRUEsRUFBQSxJQUFHLElBQUg7V0FDRSxJQUFJLENBQUMsZ0JBQUwsQ0FBc0IsT0FBdEIsRUFBK0IsU0FBQyxDQUFELEdBQUE7QUFDN0IsVUFBQSxJQUFBO0FBQUEsTUFBQSxDQUFDLENBQUMsY0FBRixDQUFBLENBQUEsQ0FBQTtBQUFBLE1BQ0EsSUFBQSxHQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBVCxDQUFzQixNQUF0QixDQUFBLEdBQWdDLElBQUksQ0FBQyxRQUFMLENBQUEsQ0FEdkMsQ0FBQTthQUVBLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBWixDQUFtQjtBQUFBLFFBQUUsR0FBQSxFQUFLLElBQVA7T0FBbkIsRUFINkI7SUFBQSxDQUEvQixFQURGO0dBSDRDO0FBQUEsQ0FBOUMsQ0FOQSxDQUFBOzs7O0FDQUE7QUFBQTs7Ozs7R0FBQTtBQUFBLElBQUEsZ0VBQUE7RUFBQSxxSkFBQTs7QUFBQSxRQU1BLEdBQVcsT0FBQSxDQUFRLG1CQUFSLENBTlgsQ0FBQTs7QUFBQSxJQVNBLEdBQU8sT0FBQSxDQUFRLFlBQVIsQ0FUUCxDQUFBOztBQUFBLGlCQVVBLEdBQW9CLE9BQUEsQ0FBUSx5QkFBUixDQVZwQixDQUFBOztBQUFBLGlCQWNBLEdBQ0U7QUFBQSxFQUFBLFdBQUEsRUFBYSxJQUFiO0FBQUEsRUFDQSxTQUFBLEVBQVcsaUJBRFg7Q0FmRixDQUFBOztBQUFBO0FBbUJlLEVBQUEsb0JBQUUsSUFBRixHQUFBO0FBQ1gsSUFEWSxJQUFDLENBQUEsT0FBQSxJQUNiLENBQUE7QUFBQSxJQUFBLElBQUMsQ0FBQSxLQUFELEdBQVMsUUFBUSxDQUFDLGNBQVQsQ0FBd0IsZUFBeEIsQ0FBVCxDQUFBO0FBQUEsSUFDQSxJQUFDLENBQUEsS0FBSyxDQUFDLEtBQVAsQ0FBQSxDQURBLENBQUE7QUFBQSxJQUdBLElBQUMsQ0FBQSxNQUFELEdBQVUsUUFBUSxDQUFDLGNBQVQsQ0FBd0IsUUFBeEIsQ0FIVixDQUFBO0FBQUEsSUFJQSxJQUFDLENBQUEsWUFBRCxDQUFBLENBSkEsQ0FBQTtBQUFBLElBS0EsSUFBQyxDQUFBLFFBQUQsR0FBZ0IsSUFBQSxRQUFBLENBQVM7QUFBQSxNQUN2QixFQUFBLEVBQUksUUFBUSxDQUFDLGFBQVQsQ0FBdUIsY0FBdkIsQ0FEbUI7QUFBQSxNQUV2QixRQUFBLEVBQVUsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUEsR0FBQTtpQkFBRyxLQUFDLENBQUEsTUFBRCxDQUFBLEVBQUg7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUZhO0tBQVQsQ0FMaEIsQ0FEVztFQUFBLENBQWI7O0FBQUEsdUJBV0EsWUFBQSxHQUFjLFNBQUEsR0FBQTtBQUNaLElBQUEsSUFBRyxJQUFDLENBQUEsSUFBRCxJQUFVLElBQUMsQ0FBQSxNQUFkO0FBQ0UsTUFBQSxJQUFDLENBQUEsSUFBSSxDQUFDLGdCQUFOLENBQXVCLFFBQXZCLEVBQWlDLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLENBQUQsR0FBQTtpQkFBTyxLQUFDLENBQUEsTUFBRCxDQUFRLENBQVIsRUFBUDtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWpDLENBQUEsQ0FBQTthQUNBLElBQUMsQ0FBQSxNQUFNLENBQUMsZ0JBQVIsQ0FBeUIsT0FBekIsRUFBa0MsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsQ0FBRCxHQUFBO2lCQUFPLEtBQUMsQ0FBQSxrQkFBRCxDQUFvQixDQUFwQixFQUFQO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbEMsRUFGRjtLQURZO0VBQUEsQ0FYZCxDQUFBOztBQUFBLHVCQWdCQSxNQUFBLEdBQVEsU0FBQyxDQUFELEdBQUE7QUFDTixJQUFBLENBQUEsSUFBSyxDQUFDLENBQUMsY0FBUCxJQUF5QixDQUFDLENBQUMsY0FBRixDQUFBLENBQXpCLENBQUE7QUFDQSxJQUFBLElBQUcsSUFBQyxDQUFBLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBYixHQUFzQixDQUF6QjthQUVFLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsUUFBQyxRQUFBLEVBQVUsR0FBWDtBQUFBLFFBQWdCLFVBQUEsRUFBWSxXQUE1QjtPQUF4QixFQUFrRSxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxLQUFELEdBQUE7QUFDaEUsVUFBQSxPQUFPLENBQUMsR0FBUixDQUFZLFFBQVosRUFBc0IsS0FBdEIsQ0FBQSxDQUFBO2lCQUNBLGlCQUFrQixDQUFBLEtBQUssQ0FBQyxVQUFOLENBQWlCLENBQUMsTUFBcEMsQ0FDRTtBQUFBLFlBQUEsS0FBQSxFQUFPLEtBQUMsQ0FBQSxLQUFLLENBQUMsS0FBZDtBQUFBLFlBQ0EsT0FBQSxFQUFTLEtBQUMsQ0FBQSxjQUFjLENBQUMsSUFBaEIsQ0FBcUIsS0FBckIsQ0FEVDtXQURGLEVBRmdFO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbEUsRUFGRjtLQUZNO0VBQUEsQ0FoQlIsQ0FBQTs7QUFBQSx1QkEyQkEsY0FBQSxHQUFnQixTQUFDLFFBQUQsR0FBQTtBQUNaLElBQUEsSUFBQyxDQUFBLEtBQUQsQ0FBTyxJQUFDLENBQUEsTUFBUixDQUFBLENBQUE7V0FDQSxJQUFDLENBQUEsTUFBTSxDQUFDLFdBQVIsQ0FBb0IsUUFBcEIsRUFGWTtFQUFBLENBM0JoQixDQUFBOztBQUFBLHVCQStCQSxLQUFBLEdBQU8sU0FBQyxFQUFELEdBQUE7QUFDTCxRQUFBLFFBQUE7QUFBQTtXQUFPLEVBQUUsQ0FBQyxTQUFWLEdBQUE7QUFDRSxvQkFBQSxFQUFFLENBQUMsV0FBSCxDQUFlLEVBQUUsQ0FBQyxTQUFsQixFQUFBLENBREY7SUFBQSxDQUFBO29CQURLO0VBQUEsQ0EvQlAsQ0FBQTs7QUFBQSx1QkFtQ0Esa0JBQUEsR0FBb0IsU0FBQyxDQUFELEdBQUE7QUFDbEIsUUFBQSxjQUFBO0FBQUEsSUFBQSxDQUFDLENBQUMsY0FBRixDQUFBLENBQUEsQ0FBQTtBQUFBLElBQ0EsUUFBQSxHQUFXLENBQUMsR0FBRCxFQUFNLEdBQU4sQ0FEWCxDQUFBO0FBRUEsSUFBQSxXQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBVCxFQUFBLGVBQW9CLFFBQXBCLEVBQUEsSUFBQSxNQUFIO0FBQ0UsTUFBQSxJQUFDLENBQUEsS0FBSyxDQUFDLEtBQVAsR0FBZSxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQXhCLENBQUE7YUFDQSxJQUFDLENBQUEsTUFBRCxDQUFRLENBQVIsRUFGRjtLQUhrQjtFQUFBLENBbkNwQixDQUFBOztBQUFBLHVCQTBDQSxRQUFBLEdBQVUsU0FBQSxHQUFBO0FBQ1IsV0FBTyxJQUFDLENBQUEsS0FBSyxDQUFDLEtBQWQsQ0FEUTtFQUFBLENBMUNWLENBQUE7O29CQUFBOztJQW5CRixDQUFBOztBQUFBLE1BaUVNLENBQUMsT0FBUCxHQUFpQixVQWpFakIsQ0FBQTs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDalNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpfXZhciBmPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChmLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGYsZi5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCIvLyB0dXJraXNoZGljdGlvbmFyeSBjb2RpbmdzXG4ndXNlIHN0cmljdCc7XG5cbnZhciBESUNUID0ge1xuICAgIDM1MDogJyVERScsIC8vxZ5cbiAgICAyODY6ICclRDAnLCAvL8SeXG4gICAgMjg3OiAnJUYwJywgLy/En1xuICAgIDM1MTogJyVGRScsIC8vxZ9cbiAgICAzMDU6ICclRkQnLCAvL8SxXG4gICAgMzA0OiAnJUREJywgLy/EsFxuICAgIDI1MjogJyVGQycsIC8vw7xcbiAgICAyMjA6ICclREMnLCAvL8OcXG4gICAgMjMxOiAnJUU3JywgLy/Dp1xuICAgIDE5OTogJyVDNycsIC8vw4dcbiAgICAyNDY6ICclRjYnLCAvL8O2XG4gICAgMjQ0OiAnJUY0JywgLy/DtFxuICAgIDIxNDogJyVENicsIC8vw5ZcbiAgICAyMTI6ICclRDQnLCAvL8OUXG4gICAgMjUxOiAnJUZCJywgLy/Du1xuICAgIDIxOTogJyVEQicsIC8vw5tcbiAgICAxOTQ6ICclQzInLCAvL8OCXG4gICAgMjI2OiAnJUUyJywgLy/DolxuICAgIDM5OiAnJyB9O1xuXG4vLydcbm1vZHVsZS5leHBvcnRzID0gRElDVDtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNoYXItY29kZXMtdHVyay5qcy5tYXBcbiIsIi8qXHIgIE11bHRpdHJhbiBkZXBlbmRzIG9uIGh0bWwtZXNjYXBpbmcgKG5vdCBVVEYtOCkgcnVsZXMgZm9yIHNwZWNpYWwgc3ltYm9sc1xyICDDoCwgw6gsIMOsLCDDsiwgw7kgLSDDgCwgw4gsIMOMLCDDkiwgw5lcciAgw6EsIMOpLCDDrSwgw7MsIMO6LCDDvSAtIMOBLCDDiSwgw40sIMOTLCDDmiwgw51cciAgw6IsIMOqLCDDriwgw7QsIMO7IMOCLCDDiiwgw44sIMOULCDDm1xyICDDoywgw7EsIMO1IMODLCDDkSwgw5VcciAgw6QsIMOrLCDDrywgw7YsIMO8LCDDvyDDhCwgw4ssIMOPLCDDliwgw5wsXHIgIMOlLCDDhVxyICDDpiwgw4ZcciAgw6csIMOHXHIgIMOwLCDDkFxyICDDuCwgw5hcciAgwr8gwqEgw59cciovXG4ndXNlIHN0cmljdCc7XG5cbnZhciBDSEFSX0NPREVTID0ge1xuICAvL3J1c3NpYW5cbiAgJyVEMSU4QSc6IHsgdmFsOiAnJUZBJywgbGFuZzogJ3J1JyB9LCAvLyDRilxuICAnJUQwJUFBJzogeyB2YWw6ICclREEnLCBsYW5nOiAncnUnIH0sIC8vINCqXG5cbiAgJyVDMyU4MCc6ICcmIzE5MjsnLCAvLyDDgFxuICAnJUMzJTgxJzogJyYjMTkzOycsIC8vIMOBXG4gICclQzMlODInOiAnJiMxOTQ7JywgLy8gw4JcbiAgJyVDMyU4Myc6ICcmIzE5NTsnLCAvLyDDg1xuICAnJUMzJTg0JzogJyYjMTk2OycsIC8vIMOEXG4gICclQzMlODUnOiAnJiMxOTc7JywgLy8gw4VcbiAgJyVDMyU4Nic6ICcmIzE5ODsnLCAvLyDDhlxuXG4gICclQzMlODcnOiAnJiMxOTk7JywgLy8gw4dcbiAgJyVDMyU4OCc6ICcmIzIwMDsnLCAvLyDDiFxuICAnJUMzJTg5JzogJyYjMjAxOycsIC8vIMOJXG4gICclQzMlOEEnOiAnJiMyMDI7JywgLy8gw4pcbiAgJyVDMyU4Qic6ICcmIzIwMzsnLCAvLyDDi1xuXG4gICclQzMlOEMnOiAnJiMyMDQ7JywgLy8gw4xcbiAgJyVDMyU4RCc6ICcmIzIwNTsnLCAvLyDDjVxuICAnJUMzJThFJzogJyYjMjA2OycsIC8vIMOOXG4gICclQzMlOEYnOiAnJiMyMDc7JywgLy8gw49cblxuICAnJUMzJTkxJzogJyYjMjA5OycsIC8vIMORXG4gICclQzMlOTInOiAnJiMyMTA7JywgLy8gw5JcbiAgJyVDMyU5Myc6ICcmIzIxMTsnLCAvLyDDk1xuICAnJUMzJTk0JzogJyYjMjEyOycsIC8vIMOUXG4gICclQzMlOTUnOiAnJiMyMTM7JywgLy8gw5VcbiAgJyVDMyU5Nic6ICcmIzIxNDsnLCAvLyDDllxuXG4gICclQzMlOTknOiAnJiMyMTc7JywgLy8gw5lcbiAgJyVDMyU5QSc6ICcmIzIxODsnLCAvLyDDmlxuICAnJUMzJTlCJzogJyYjMjE5OycsIC8vIMObXG4gICclQzMlOUMnOiAnJiMyMjA7JywgLy8gw5xcblxuICAnJUMzJUEwJzogJyYjMjI0OycsIC8vIMOgXG4gICclQzMlQTEnOiAnJiMyMjU7JywgLy8gw6FcbiAgJyVDMyVBMic6ICcmIzIyNjsnLCAvLyDDolxuICAnJUMzJUEzJzogJyYjMjI3OycsIC8vIMOjXG4gICclQzMlQTQnOiAnJiMyMjg7JywgLy8gw6RcbiAgJyVDMyVBNSc6ICcmIzIyOTsnLCAvLyDDpVxuICAnJUMzJUE2JzogJyYjMjMwOycsIC8vIMOmXG4gICclQzMlQTcnOiAnJiMyMzE7JywgLy8gw6dcblxuICAnJUMzJUE4JzogJyYjMjMyOycsIC8vIMOoXG4gICclQzMlQTknOiAnJiMyMzM7JywgLy8gw6lcbiAgJyVDMyVBQSc6ICcmIzIzNDsnLCAvLyDDqlxuICAnJUMzJUFCJzogJyYjMjM1OycsIC8vIMOrXG5cbiAgJyVDMyVBQyc6ICcmIzIzNjsnLCAvLyDDrFxuICAnJUMzJUFEJzogJyYjMjM3OycsIC8vIMOtXG4gICclQzMlQUUnOiAnJiMyMzg7JywgLy8gw65cbiAgJyVDMyVBRic6ICcmIzIzOTsnLCAvLyDDr1xuXG4gICclQzMlQjAnOiAnJiMyNDA7JywgLy8gw7BcbiAgJyVDMyVCMSc6ICcmIzI0MTsnLCAvLyDDsVxuXG4gICclQzMlQjInOiAnJiMyNDI7JywgLy8gw7JcbiAgJyVDMyVCMyc6ICcmIzI0MzsnLCAvLyDDs1xuICAnJUMzJUI0JzogJyYjMjQ0OycsIC8vIMO0XG4gICclQzMlQjUnOiAnJiMyNDU7JywgLy8gw7VcbiAgJyVDMyVCNic6ICcmIzI0NjsnLCAvLyDDtlxuXG4gICclQzMlQjknOiAnJiMyNDk7JywgLy8gw7lcbiAgJyVDMyVCQSc6ICcmIzI1MDsnLCAvLyDDulxuICAnJUMzJUJCJzogJyYjMjUxOycsIC8vIMO7XG4gICclQzMlQkMnOiAnJiMyNTI7JywgLy8gw7xcbiAgJyVDMyVCRic6ICcmIzI1NTsnLCAvLyDDv1xuICAnJUM1JUI4JzogJyYjMzc2OycsIC8vIMW4XG5cbiAgJyVDMyU5Ric6ICcmIzIyMzsnLCAvLyDDn1xuXG4gICclQzIlQkYnOiAnJiMxOTE7JywgLy8gwr9cbiAgJyVDMiVBMSc6ICcmIzE2MTsnIH07XG5cbi8vIMKhXG5tb2R1bGUuZXhwb3J0cyA9IENIQVJfQ09ERVM7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jaGFyLWNvZGVzLmpzLm1hcFxuIiwiIyMjXG4gIERyb3Bkb3duIGxhbmd1YWdlIG1lbnVcbiAgQHBhcmFtIG9wdHMgdGFrZXMgZWxlbWVudCBhbmQgb25TZWxlY3QgaGFuZGxlclxuICBleGFtcGxlOlxuICBuZXcgRHJvcGRvd24oe1xuICAgZWw6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCcjbWVudScpO1xuICAgb25TZWxlY3Q6IGZ1bmN0aW9uICgpIHt9XG4gIH0pXG4jIyNcbkxBTkdfQ09ERSA9XG4gICcxJzogJ0VuZydcbiAgJzInOiAnUnVzJ1xuICAnMyc6ICdHZXInXG4gICc0JzogJ0ZyZSdcbiAgJzUnOiAnU3BhJ1xuICAnMjMnOiAnSXRhJ1xuICAnMjQnOiAnRHV0J1xuICAnMjYnOiAnRXN0J1xuICAnMjcnOiAnTGF2J1xuICAnMzEnOiAnQWZyJ1xuICAnMzQnOiAnRXBvJ1xuICAnMzUnOiAnWGFsJyxcbiAgJzEwMDAnOiAnVHVyJ1xuXG5ESUNUX0NPREUgPVxuICAnMSc6ICdtdWx0aXRyYW4nXG4gICcxMDAwJzogJ3R1cmtpc2gnXG5cbmNsYXNzIERyb3Bkb3duXG4gIGNvbnN0cnVjdG9yOiAob3B0cykgLT5cbiAgICBAZWwgPSBvcHRzLmVsIG9yIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgIyBvblNlbGVjdCBoYW5kbGVyIHNldCBieSBhZ2dyZWdhdGUgY2xhc3NcbiAgICBAb25TZWxlY3QgPSBvcHRzLm9uU2VsZWN0XG5cbiAgICBAbWVudSA9IEBlbC5xdWVyeVNlbGVjdG9yKCcuZHJvcGRvd24tbWVudScpXG4gICAgaWYgQG1lbnVcbiAgICAgIEBtZW51LnN0eWxlLmRpc3BsYXkgPSAnbm9uZSdcbiAgICAgIEBpdGVtcyA9IEBtZW51LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoJ2xhbmd1YWdlLXR5cGUnKVxuICAgICAgQGJ1dHRvbiA9IEBlbC5xdWVyeVNlbGVjdG9yKCcuZHJvcGRvd24tdG9nZ2xlJylcbiAgICAgIEBhZGRMaXN0ZW5lcnMoKVxuICAgICAgQGluaXRMYW5ndWFnZSgpXG5cbiAgYWRkTGlzdGVuZXJzOiAtPlxuICAgIEBidXR0b24uYWRkRXZlbnRMaXN0ZW5lciAnY2xpY2snLCAoZSkgPT4gQHRvZ2dsZShlKVxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIgJ2NsaWNrJywgKGUpID0+IEBoaWRlKGUpXG4gICAgQG1lbnUuYWRkRXZlbnRMaXN0ZW5lciAnY2xpY2snLCAoZSkgPT4gQGNob29zZShlKVxuXG4gICMgT24gaW5pdCB0cnlpbmcgdG8gZ2V0IGN1cnJlbnQgbGFuZ3VhZ2UgZnJvbSBzdG9yYWdlIG9yIHVzaW5nIGRlZmF1bHQoIDE6ZW5nbGlzaClcbiAgaW5pdExhbmd1YWdlOiAtPlxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHsgbGFuZ3VhZ2U6ICcxJ30sIChzdG9yZSkgPT5cbiAgICAgIEBzZXRUaXRsZShzdG9yZS5sYW5ndWFnZSk7XG4gICAgKVxuXG4gIHRvZ2dsZTogKGUpIC0+XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKVxuICAgIEBzZXRBY3RpdmVJdGVtKClcbiAgICBpZiBAbWVudSBhbmQgQG1lbnUuc3R5bGUuZGlzcGxheSBpcyAnbm9uZSdcbiAgICAgIEBzaG93KClcbiAgICBlbHNlXG4gICAgICBAaGlkZSgpXG5cbiAgIyBSZWFkIGN1cnJlbnQgbGFuZ3VhZ2UgZnJvbSBDaHJvbWUgU3RvcmFnZSBhbmQgY29sb3IgYWN0aXZlIGxpbmVcbiAgc2V0QWN0aXZlSXRlbTogLT5cbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCB7bGFuZ3VhZ2U6ICcxJ30sIChzdG9yZSkgPT5cbiAgICAgIGZvciBpdGVtIGluIEBpdGVtc1xuICAgICAgICBpZiBpdGVtLmdldEF0dHJpYnV0ZSgnZGF0YS12YWwnKSA9PSBzdG9yZS5sYW5ndWFnZVxuICAgICAgICAgIGl0ZW0uY2xhc3NMaXN0LmFkZCgnYWN0aXZlJylcbiAgICAgICAgZWxzZVxuICAgICAgICAgIGl0ZW0uY2xhc3NMaXN0LnJlbW92ZSgnYWN0aXZlJylcblxuICBoaWRlOiAtPlxuICAgIEBtZW51LnN0eWxlLmRpc3BsYXkgPSAnbm9uZSdcblxuICBzaG93OiAtPlxuICAgIEBtZW51LnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snXG5cbiAgIyBTYXZlcyBjaG9zZW4gbGFuZ3VhZ2UgdG8gY2hyb21lLnN0b3JhZ2UgYW5kIGRlY2lkZSB3aGljaCBkaWN0aW9uYXJ5IHRvIHVzZVxuICAjIFRoZW4gY2FsbGVkIG9uU2VsZWN0IGhhbmRsZXIgb2YgdGhlIGNvbnRhaW5lciBjbGFzc1xuICBjaG9vc2U6IChlKSAtPlxuICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBsYW5ndWFnZSA9IGUudGFyZ2V0LmdldEF0dHJpYnV0ZSgnZGF0YS12YWwnKVxuICAgIGRpY3Rpb25hcnkgPSBAZ2V0RGljdGlvbmFyeShsYW5ndWFnZSlcbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLnNldCh7bGFuZ3VhZ2U6IGxhbmd1YWdlLCBkaWN0aW9uYXJ5OiBkaWN0aW9uYXJ5fSwgQG9uU2VsZWN0KVxuICAgIEBzZXRUaXRsZShsYW5ndWFnZSlcbiAgICBAaGlkZSgpXG5cbiAgIyBTb21lIGxhbmd1YWdlcyBhcmUgbm90IHByZXNlbnQgaW4gbXVsdGl0cmFuIChlLmcuIHR1cmtpc2gpXG4gICMgc28gd2UgY2hvb3NlIGFub3RoZXIgc2VydmljZVxuICBnZXREaWN0aW9uYXJ5OiAobGFuZykgLT5cbiAgICBjb25zb2xlLmxvZygnY2hvb3NlIGRpY3Q6IGZvcicsbGFuZyk7XG4gICAgZGljdCA9IERJQ1RfQ09ERVtsYW5nXSB8fCAnbXVsdGl0cmFuJ1xuICAgIGNvbnNvbGUubG9nKCdkaWN0JyxkaWN0KVxuICAgIHJldHVybiBkaWN0XG5cbiAgI1NldCBjdXJyZW50IGxhbmd1YWdlIGxhYmVsXG4gIHNldFRpdGxlOiAobGFuZ3VhZ2UpIC0+XG4gICAgaHRtbCA9IExBTkdfQ09ERVtsYW5ndWFnZV0gKyAnIDxzcGFuIGNsYXNzPVwiY2FyZXRcIj48L3NwYW4+J1xuICAgIEBidXR0b24uaW5uZXJIVE1MID0gaHRtbFxuXG5cbm1vZHVsZS5leHBvcnRzID0gRHJvcGRvd24iLCIjIyNcbiAgRXh0ZW5zaW9uIHBvcHVwIHdpbmRvd1xuICBTaG93cyBzZWFyY2ggZm9ybSBhbmQgZHJvcGRvd24gbWVudSB3aXRoIGxhbmd1YWdlc1xuIyMjXG5TZWFyY2hGb3JtID0gcmVxdWlyZSgnLi9zZWFyY2hfZm9ybS5jb2ZmZWUnKVxuXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyIFwiRE9NQ29udGVudExvYWRlZFwiLCAtPlxuICBmb3JtID0gbmV3IFNlYXJjaEZvcm0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RyYW4tZm9ybScpXG4gIGxpbmsgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnaGVhZGVyLWxpbmsnKVxuICBpZiBsaW5rXG4gICAgbGluay5hZGRFdmVudExpc3RlbmVyICdjbGljaycsIChlKSAtPlxuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgaHJlZiA9IGUudGFyZ2V0LmdldEF0dHJpYnV0ZSgnaHJlZicpICsgZm9ybS5nZXRWYWx1ZSgpXG4gICAgICBjaHJvbWUudGFicy5jcmVhdGUoeyB1cmw6IGhyZWYgfSlcbiIsIiMjI1xuICBTZXJ2ZXMgc2VhcmNoIGlucHV0IGFuZCBmb3JtXG5cbiAgQHBhcmFtIGZvcm0gRE9NIGVsZW1udFxuICBAY29uc3RydWN0b3JcbiMjI1xuRHJvcGRvd24gPSByZXF1aXJlKCcuL2Ryb3Bkb3duLmNvZmZlZScpXG5cbiN0cmFuc2xhdGUgZW5naW5lc1xudHJhbiA9IHJlcXVpcmUoJy4uL3RyYW4uanMnKVxudHVya2lzaGRpY3Rpb25hcnkgPSByZXF1aXJlKCcuLi90dXJraXNoZGljdGlvbmFyeS5qcycpXG5cblxuI1RyYW5zbGF0ZSBlbmdpbmVzXG5UUkFOU0xBVEVfRU5HSU5FUyA9XG4gICdtdWx0aXRyYW4nOiB0cmFuXG4gICd0dXJraXNoJzogdHVya2lzaGRpY3Rpb25hcnlcblxuY2xhc3MgU2VhcmNoRm9ybVxuICBjb25zdHJ1Y3RvcjogKEBmb3JtKSAtPlxuICAgIEBpbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0cmFuc2xhdGUtdHh0JylcbiAgICBAaW5wdXQuZm9jdXMoKVxuXG4gICAgQHJlc3VsdCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyZXN1bHQnKVxuICAgIEBhZGRMaXN0ZW5lcnMoKTtcbiAgICBAZHJvcGRvd24gPSBuZXcgRHJvcGRvd24oe1xuICAgICAgZWw6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5kcm9wZG93bi1lbCcpLFxuICAgICAgb25TZWxlY3Q6ID0+IEBzZWFyY2goKVxuICAgIH0pO1xuXG4gIGFkZExpc3RlbmVyczogLT5cbiAgICBpZiBAZm9ybSBhbmQgQHJlc3VsdFxuICAgICAgQGZvcm0uYWRkRXZlbnRMaXN0ZW5lciAnc3VibWl0JywgKGUpID0+IEBzZWFyY2goZSlcbiAgICAgIEByZXN1bHQuYWRkRXZlbnRMaXN0ZW5lciAnY2xpY2snLCAoZSkgPT4gQHJlc3VsdENsaWNrSGFuZGxlcihlKVxuXG4gIHNlYXJjaDogKGUpIC0+XG4gICAgZSAmJiBlLnByZXZlbnREZWZhdWx0ICYmIGUucHJldmVudERlZmF1bHQoKVxuICAgIGlmIEBpbnB1dC52YWx1ZS5sZW5ndGggPiAwXG4gICAgICAjY2hvb3NlIGVuZ2luZSBhbmQgc2VhcmNoIGZvciB0cmFuc2xhdGlvbiAoYnkgZGVmYXVsdCBlbmdsaXNoLW11bHRpdHJhbilcbiAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHtsYW5ndWFnZTogJzEnLCBkaWN0aW9uYXJ5OiAnbXVsdGl0cmFuJ30sIChpdGVtcykgPT5cbiAgICAgICAgY29uc29sZS5sb2coJ0lURU1TOicsIGl0ZW1zKTtcbiAgICAgICAgVFJBTlNMQVRFX0VOR0lORVNbaXRlbXMuZGljdGlvbmFyeV0uc2VhcmNoXG4gICAgICAgICAgdmFsdWU6IEBpbnB1dC52YWx1ZVxuICAgICAgICAgIHN1Y2Nlc3M6IEBzdWNjZXNzSGFuZGxlci5iaW5kKEApXG4gICAgICApXG5cbiAgc3VjY2Vzc0hhbmRsZXI6IChyZXNwb25zZSkgLT5cbiAgICAgIEBjbGVhbihAcmVzdWx0KVxuICAgICAgQHJlc3VsdC5hcHBlbmRDaGlsZChyZXNwb25zZSlcblxuICBjbGVhbjogKGVsKSAtPlxuICAgIHdoaWxlIChlbC5sYXN0Q2hpbGQpXG4gICAgICBlbC5yZW1vdmVDaGlsZChlbC5sYXN0Q2hpbGQpXG5cbiAgcmVzdWx0Q2xpY2tIYW5kbGVyOiAoZSkgLT5cbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgbGlua1RhZ3MgPSBbJ0EnLCAnYSddXG4gICAgaWYgZS50YXJnZXQudGFnTmFtZSBpbiBsaW5rVGFnc1xuICAgICAgQGlucHV0LnZhbHVlID0gZS50YXJnZXQuaW5uZXJUZXh0O1xuICAgICAgQHNlYXJjaChlKVxuXG4gIGdldFZhbHVlOiAtPlxuICAgIHJldHVybiBAaW5wdXQudmFsdWVcblxuXG5tb2R1bGUuZXhwb3J0cyA9IFNlYXJjaEZvcm1cbiIsIi8qKlxyXG4gTXVsdGl0cmFuIHRyYW5zbGF0ZSBlbmdpbmVcclxuIFByb3ZpZGVzIHByb2dyYW0gaW50ZXJmYWNlIGZvciBtYWtpbmcgdHJhbnNsYXRlIHF1ZXJpZXMgdG8gbXVsdGl0cmFuIGFuZCBnZXQgY2xlYW4gcmVzcG9uc2VcclxuXHJcbiBBbGwgZW5naW5lcyBtdXN0IGZvbGxvdyBjb21tb24gaW50ZXJmYWNlIGFuZCBwcm92aWRlIG1ldGhvZHM6XHJcbiAtIHNlYXJjaCAobGFuZ3VhbmdlLCBzdWNjZXNzSGFuZGxlcikgIGNsZWFuIHRyYW5zbGF0aW9uIG11c3QgYmUgcGFzc2VkIGludG8gc3VjY2Vzc0hhbmRsZXJcclxuIC0gY2xpY2tcclxuXHJcbiBUcmFuc2xhdGlvbi1tb2R1bGUgdGhhdCBtYWtlcyByZXF1ZXN0cyB0byBsYW5ndWFnZS1lbmdpbmUsXHJcbiBwYXJzZXMgcmVzdWx0cyBhbmQgc2VuZHMgcGx1Z2luLWdsb2JhbCBtZXNzYWdlIHdpdGggdHJhbnNsYXRpb24gZGF0YVxyXG4gKiovXG4vLyB2YXIgaWNvbnYgPSByZXF1aXJlKCdpY29udi1saXRlJyk7XG5cbid1c2Ugc3RyaWN0JztcblxudmFyIF9jcmVhdGVDbGFzcyA9IChmdW5jdGlvbiAoKSB7IGZ1bmN0aW9uIGRlZmluZVByb3BlcnRpZXModGFyZ2V0LCBwcm9wcykgeyBmb3IgKHZhciBpID0gMDsgaSA8IHByb3BzLmxlbmd0aDsgaSsrKSB7IHZhciBkZXNjcmlwdG9yID0gcHJvcHNbaV07IGRlc2NyaXB0b3IuZW51bWVyYWJsZSA9IGRlc2NyaXB0b3IuZW51bWVyYWJsZSB8fCBmYWxzZTsgZGVzY3JpcHRvci5jb25maWd1cmFibGUgPSB0cnVlOyBpZiAoJ3ZhbHVlJyBpbiBkZXNjcmlwdG9yKSBkZXNjcmlwdG9yLndyaXRhYmxlID0gdHJ1ZTsgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgZGVzY3JpcHRvci5rZXksIGRlc2NyaXB0b3IpOyB9IH0gcmV0dXJuIGZ1bmN0aW9uIChDb25zdHJ1Y3RvciwgcHJvdG9Qcm9wcywgc3RhdGljUHJvcHMpIHsgaWYgKHByb3RvUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IucHJvdG90eXBlLCBwcm90b1Byb3BzKTsgaWYgKHN0YXRpY1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLCBzdGF0aWNQcm9wcyk7IHJldHVybiBDb25zdHJ1Y3RvcjsgfTsgfSkoKTtcblxuZnVuY3Rpb24gX2NsYXNzQ2FsbENoZWNrKGluc3RhbmNlLCBDb25zdHJ1Y3RvcikgeyBpZiAoIShpbnN0YW5jZSBpbnN0YW5jZW9mIENvbnN0cnVjdG9yKSkgeyB0aHJvdyBuZXcgVHlwZUVycm9yKCdDYW5ub3QgY2FsbCBhIGNsYXNzIGFzIGEgZnVuY3Rpb24nKTsgfSB9XG5cbnZhciBDSEFSX0NPREVTID0gcmVxdWlyZSgnLi9jaGFyLWNvZGVzLmpzJyk7XG5cbnZhciBUcmFuID0gKGZ1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gVHJhbigpIHtcbiAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgVHJhbik7XG5cbiAgICB0aGlzLlRBQkxFX0NMQVNTID0gXCJfX19tdHRfdHJhbnNsYXRlX3RhYmxlXCI7XG4gICAgdGhpcy5wcm90b2NvbCA9ICdodHRwJztcbiAgICB0aGlzLmhvc3QgPSAnd3d3Lm11bHRpdHJhbi5ydSc7XG4gICAgdGhpcy5wYXRoID0gJy9jL20uZXhlJztcbiAgICB0aGlzLnF1ZXJ5ID0gJyZzPSc7XG4gICAgdGhpcy5sYW5nID0gJz9sMT0yJmwyPTEnOyAvLyBmcm9tIHJ1c3NpYW4gdG8gZW5nbGlzaCBieSBkZWZhdWx0XG4gICAgdGhpcy54aHIgPSB7fTtcbiAgfVxuXG4gIC8qKlxyXG4gICAqIENvbnRleHQgbWVudSBjbGljayBoYW5kbGVyXHJcbiAgICovXG5cbiAgX2NyZWF0ZUNsYXNzKFRyYW4sIFt7XG4gICAga2V5OiAnY2xpY2snLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjbGljayhkYXRhKSB7XG4gICAgICBpZiAodHlwZW9mIGRhdGEuc2lsZW50ID09PSBcInVuZGVmaW5lZFwiIHx8IGRhdGEuc2lsZW50ID09PSBudWxsKSB7XG4gICAgICAgIGRhdGEuc2lsZW50ID0gdHJ1ZTsgLy8gdHJ1ZSBieSBkZWZhdWx0XG4gICAgICB9XG4gICAgICB2YXIgc2VsZWN0aW9uVGV4dCA9IHRoaXMucmVtb3ZlSHlwaGVuYXRpb24oZGF0YS5zZWxlY3Rpb25UZXh0KTtcbiAgICAgIHRoaXMuc2VhcmNoKHtcbiAgICAgICAgdmFsdWU6IHNlbGVjdGlvblRleHQsXG4gICAgICAgIHN1Y2Nlc3M6IHRoaXMuc3VjY2Vzc3RIYW5kbGVyLmJpbmQodGhpcyksXG4gICAgICAgIHNpbGVudDogZGF0YS5zaWxlbnQgLy8gaWYgdHJhbnNsYXRpb24gZmFpbGVkIGRvIG5vdCBzaG93IGRpYWxvZ1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXHJcbiAgICAgKiBEaXNjYXJkIHNvZnQgaHlwaGVuIGNoYXJhY3RlciAoVSswMEFELCAmc2h5OykgZnJvbSB0aGUgaW5wdXRcclxuICAgICAqL1xuICB9LCB7XG4gICAga2V5OiAncmVtb3ZlSHlwaGVuYXRpb24nLFxuICAgIHZhbHVlOiBmdW5jdGlvbiByZW1vdmVIeXBoZW5hdGlvbih0ZXh0KSB7XG4gICAgICByZXR1cm4gdGV4dC5yZXBsYWNlKC9cXHhhZC9nLCAnJyk7XG4gICAgfVxuXG4gICAgLyoqXHJcbiAgICAgKiBJbml0aWF0ZSB0cmFuc2xhdGlvbiBzZWFyY2hcclxuICAgICAqL1xuICB9LCB7XG4gICAga2V5OiAnc2VhcmNoJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc2VhcmNoKHBhcmFtcykge1xuICAgICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgICAgLy92YWx1ZSwgY2FsbGJhY2ssIGVyclxuICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoeyBsYW5ndWFnZTogJzEnIH0sIGZ1bmN0aW9uIChpdGVtcykge1xuICAgICAgICBpZiAoaXRlbXMubGFuZ3VhZ2UgPT09ICcnKSB7XG4gICAgICAgICAgaXRlbXMubGFuZ3VhZ2UgPSAnMSc7XG4gICAgICAgIH1cbiAgICAgICAgX3RoaXMuc2V0TGFuZ3VhZ2UoaXRlbXMubGFuZ3VhZ2UpO1xuICAgICAgICB2YXIgdXJsID0gX3RoaXMubWFrZVVybChwYXJhbXMudmFsdWUpO1xuICAgICAgICAvLyBkZWNvcmF0ZSBzdWNjZXNzIHRvIG1ha2UgcHJlbGltaW5hcnkgcGFyc2luZ1xuICAgICAgICB2YXIgb3JpZ1N1Y2Nlc3MgPSBwYXJhbXMuc3VjY2VzcztcbiAgICAgICAgcGFyYW1zLnN1Y2Nlc3MgPSBmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICB2YXIgdHJhbnNsYXRlZCA9IF90aGlzLnBhcnNlKHJlc3BvbnNlLCBwYXJhbXMuc2lsZW50KTtcbiAgICAgICAgICBvcmlnU3VjY2Vzcy5jYWxsKF90aGlzLCB0cmFuc2xhdGVkKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc29sZS5sb2coJ3BhcmFtcy5zdWNjZXNzPScsIHBhcmFtcy5zdWNjZXNzKTtcbiAgICAgICAgX3RoaXMucmVxdWVzdCh7XG4gICAgICAgICAgdXJsOiB1cmwsXG4gICAgICAgICAgc3VjY2VzczogcGFyYW1zLnN1Y2Nlc3MsXG4gICAgICAgICAgZXJyb3I6IHBhcmFtcy5lcnJvclxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIC8vUGFyc2UgcmVzcG9uc2UgZnJvbSB0cmFuc2xhdGlvbiBlbmdpbmVcbiAgfSwge1xuICAgIGtleTogJ3BhcnNlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gcGFyc2UocmVzcG9uc2UsIHNpbGVudCwgdHJhbnNsYXRlKSB7XG4gICAgICB0cmFuc2xhdGUgPSB0cmFuc2xhdGUgfHwgbnVsbDtcbiAgICAgIHZhciBkb2MgPSB0aGlzLnN0cmlwU2NyaXB0cyhyZXNwb25zZSk7XG4gICAgICB2YXIgZnJhZ21lbnQgPSB0aGlzLm1ha2VGcmFnbWVudChkb2MpO1xuICAgICAgaWYgKGZyYWdtZW50KSB7XG4gICAgICAgIHRyYW5zbGF0ZSA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3IoJyN0cmFuc2xhdGlvbiB+IHRhYmxlJyk7XG4gICAgICAgIGlmICh0cmFuc2xhdGUpIHtcbiAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gdGhpcy5UQUJMRV9DTEFTUztcbiAgICAgICAgICB0cmFuc2xhdGUuc2V0QXR0cmlidXRlKFwiY2VsbHBhZGRpbmdcIiwgXCI1XCIpO1xuICAgICAgICAgIHRoaXMuZml4SW1hZ2VzKHRyYW5zbGF0ZSk7XG4gICAgICAgICAgdGhpcy5maXhMaW5rcyh0cmFuc2xhdGUpO1xuICAgICAgICB9IGVsc2UgaWYgKCFzaWxlbnQpIHtcbiAgICAgICAgICB0cmFuc2xhdGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gJ2ZhaWxUcmFuc2xhdGUnO1xuICAgICAgICAgIHRyYW5zbGF0ZS5pbm5lclRleHQgPSBcIlVuZm9ydHVuYXRlbHksIGNvdWxkIG5vdCB0cmFuc2xhdGVcIjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRyYW5zbGF0ZTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdzZXRMYW5ndWFnZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHNldExhbmd1YWdlKGxhbmd1YWdlKSB7XG4gICAgICB0aGlzLmN1cnJlbnRMYW5ndWFnZSA9IGxhbmd1YWdlO1xuICAgICAgdGhpcy5sYW5nID0gJz9sMT0yJmwyPScgKyBsYW5ndWFnZTtcbiAgICB9XG5cbiAgICAvKipcclxuICAgICAqIFJlcXVlc3QgdHJhbnNsYXRpb24gYW5kIHJ1biBjYWxsYmFjayBmdW5jdGlvblxyXG4gICAgICogcGFzc2luZyB0cmFuc2xhdGVkIHJlc3VsdCBvciBlcnJvciB0byBjYWxsYmFja1xyXG4gICAgICogQHBhcmFtIG9wdHNcclxuICAgICAqL1xuICB9LCB7XG4gICAga2V5OiAncmVxdWVzdCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJlcXVlc3Qob3B0cykge1xuICAgICAgdmFyIF90aGlzMiA9IHRoaXM7XG5cbiAgICAgIHZhciB4aHIgPSB0aGlzLnhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgeGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHhociA9IF90aGlzMi54aHI7XG4gICAgICAgIGlmICh4aHIucmVhZHlTdGF0ZSA8IDQpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH0gZWxzZSBpZiAoeGhyLnN0YXR1cyAhPT0gMjAwKSB7XG4gICAgICAgICAgX3RoaXMyLmVycm9ySGFuZGxlcih4aHIpO1xuICAgICAgICAgIGlmICh0eXBlb2Ygb3B0cy5lcnJvciA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgb3B0cy5lcnJvci5jYWxsKF90aGlzMik7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSBlbHNlIGlmICh4aHIucmVhZHlTdGF0ZSA9PSA0KSB7XG4gICAgICAgICAgcmV0dXJuIG9wdHMuc3VjY2VzcyhlLnRhcmdldC5yZXNwb25zZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHhocjtcbiAgICAgIH07XG4gICAgICB4aHIub3ZlcnJpZGVNaW1lVHlwZShcInRleHQvaHRtbDtjaGFyc2V0PWNwMTI1MVwiKTtcbiAgICAgIHhoci5vcGVuKFwiR0VUXCIsIG9wdHMudXJsLCB0cnVlKTtcblxuICAgICAgeGhyLnNlbmQoKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdtYWtlVXJsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZVVybCh2YWx1ZSkge1xuICAgICAgcmV0dXJuIHRoaXMucHJvdG9jb2wgKyAnOi8vJyArIHRoaXMuaG9zdCArIHRoaXMucGF0aCArIHRoaXMubGFuZyArIHRoaXMucXVlcnkgKyB0aGlzLmdldEVuY29kZWRWYWx1ZSh2YWx1ZSk7XG4gICAgfVxuXG4gICAgLy8gUmVwbGFjZSBzcGVjaWFsIGxhbmd1YWdlIGNoYXJhY3RlcnMgdG8gaHRtbCBjb2Rlc1xuICB9LCB7XG4gICAga2V5OiAnZ2V0RW5jb2RlZFZhbHVlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZ2V0RW5jb2RlZFZhbHVlKHZhbHVlKSB7XG4gICAgICAvL3RvIGZpbmQgc3BlYyBzeW1ib2xzIHdlIGZpcnN0IGVuY29kZSB0aGVtIChyYXcgc2VhcmNoIGZvciB0aGF0IHN5bWJvbCBkb2Vzbid0IHdvcmspXG4gICAgICB2YXIgdmFsID0gZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcbiAgICAgIHZhciBjb2RlID0gdW5kZWZpbmVkLFxuICAgICAgICAgIGNjID0gdW5kZWZpbmVkO1xuICAgICAgZm9yICh2YXIgY2hhciBpbiBDSEFSX0NPREVTKSB7XG4gICAgICAgIGlmIChDSEFSX0NPREVTLmhhc093blByb3BlcnR5KGNoYXIpKSB7XG4gICAgICAgICAgY29kZSA9IENIQVJfQ09ERVNbY2hhcl07XG4gICAgICAgICAgaWYgKHR5cGVvZiBjb2RlID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgLy8gcnVzc2lhbiBoYXMgc3BlY2lhbCBjb2Rlc1xuICAgICAgICAgICAgY2MgPSBjb2RlLnZhbDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy9mb3IgYWxsIGxhbmdzIGV4Y2VwdCBydXNzaWFuIGVuY29kZSBodG1sLWNvZGVzIG5lZWRlZFxuICAgICAgICAgICAgY2MgPSBlbmNvZGVVUklDb21wb25lbnQoY29kZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHZhbCA9IHZhbC5yZXBsYWNlKGNoYXIsIGNjKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHZhbDtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdlcnJvckhhbmRsZXInLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBlcnJvckhhbmRsZXIoeGhyKSB7XG4gICAgICBjb25zb2xlLmxvZygneGhyIGVycm9yOicsIHhocik7XG4gICAgfVxuXG4gICAgLy9SZWNlaXZpbmcgZGF0YSBmcm9tIHRyYW5zbGF0aW9uLWVuZ2luZSBhbmQgc2VuZCByZWFkeSBtZXNzYWdlIHdpdGggZGF0YVxuICB9LCB7XG4gICAga2V5OiAnc3VjY2Vzc3RIYW5kbGVyJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc3VjY2Vzc3RIYW5kbGVyKHRyYW5zbGF0ZWQpIHtcbiAgICAgIHZhciBfdGhpczMgPSB0aGlzO1xuXG4gICAgICBpZiAodHJhbnNsYXRlZCkge1xuICAgICAgICBjaHJvbWUudGFicy5nZXRTZWxlY3RlZChudWxsLCBmdW5jdGlvbiAodGFiKSB7XG4gICAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgICBhY3Rpb246IF90aGlzMy5tZXNzYWdlVHlwZSh0cmFuc2xhdGVkKSxcbiAgICAgICAgICAgIGRhdGE6IHRyYW5zbGF0ZWQub3V0ZXJIVE1MLFxuICAgICAgICAgICAgc3VjY2VzczogIXRyYW5zbGF0ZWQuY2xhc3NMaXN0LmNvbnRhaW5zKCdmYWlsVHJhbnNsYXRlJylcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnbWVzc2FnZVR5cGUnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtZXNzYWdlVHlwZSh0cmFuc2xhdGVkKSB7XG4gICAgICBpZiAodHJhbnNsYXRlZCAmJiB0cmFuc2xhdGVkLnJvd3MgJiYgdHJhbnNsYXRlZC5yb3dzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICByZXR1cm4gJ3NpbWlsYXJfd29yZHMnO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuICdvcGVuX3Rvb2x0aXAnO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vICBTdHJpcCBzY3JpcHQgdGFncyBmcm9tIHJlc3BvbnNlIGh0bWxcbiAgfSwge1xuICAgIGtleTogJ3N0cmlwU2NyaXB0cycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHN0cmlwU2NyaXB0cyhyZXMpIHtcbiAgICAgIHZhciBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGRpdi5pbm5lckhUTUwgPSByZXM7XG4gICAgICB2YXIgc2NyaXB0cyA9IGRpdi5nZXRFbGVtZW50c0J5VGFnTmFtZSgnc2NyaXB0Jyk7XG4gICAgICB2YXIgaSA9IHNjcmlwdHMubGVuZ3RoO1xuICAgICAgd2hpbGUgKGktLSkge1xuICAgICAgICBzY3JpcHRzW2ldLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc2NyaXB0c1tpXSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZGl2LmlubmVySFRNTDtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdtYWtlRnJhZ21lbnQnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlRnJhZ21lbnQoZG9jLCBmcmFnbWVudCkge1xuICAgICAgZnJhZ21lbnQgPSBmcmFnbWVudCB8fCBudWxsO1xuICAgICAgdmFyIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICBkaXYuaW5uZXJIVE1MID0gZG9jO1xuICAgICAgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG4gICAgICB3aGlsZSAoZGl2LmZpcnN0Q2hpbGQpIHtcbiAgICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoZGl2LmZpcnN0Q2hpbGQpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZyYWdtZW50O1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2ZpeEltYWdlcycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGZpeEltYWdlcyhmcmFnbWVudCkge1xuICAgICAgZnJhZ21lbnQgPSBmcmFnbWVudCB8fCBudWxsO1xuICAgICAgdGhpcy5maXhVcmwoZnJhZ21lbnQsICdpbWcnLCAnc3JjJyk7XG4gICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnZml4TGlua3MnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBmaXhMaW5rcygpIHtcbiAgICAgIHZhciBmcmFnbWVudCA9IGFyZ3VtZW50cy5sZW5ndGggPD0gMCB8fCBhcmd1bWVudHNbMF0gPT09IHVuZGVmaW5lZCA/IG51bGwgOiBhcmd1bWVudHNbMF07XG5cbiAgICAgIHRoaXMuZml4VXJsKGZyYWdtZW50LCAnYScsICdocmVmJyk7XG4gICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnZml4VXJsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZml4VXJsKGZyYWdtZW50LCB0YWcsIGF0dHIpIHtcbiAgICAgIGlmIChmcmFnbWVudCA9PT0gdW5kZWZpbmVkKSBmcmFnbWVudCA9IG51bGw7XG5cbiAgICAgIHZhciB0YWdzID0ge307XG4gICAgICBpZiAoZnJhZ21lbnQpIHtcbiAgICAgICAgdGFncyA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3JBbGwodGFnKTtcbiAgICAgIH1cbiAgICAgIHZhciBwYXJzZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICBmb3IgKHZhciBfdGFnIGluIHRhZ3MpIHtcbiAgICAgICAgaWYgKHRhZ3MuaGFzT3duUHJvcGVydHkoX3RhZykpIHtcbiAgICAgICAgICBwYXJzZXIuaHJlZiA9IF90YWdbYXR0cl07XG4gICAgICAgICAgcGFyc2VyLmhvc3QgPSB0aGlzLmhvc3Q7XG4gICAgICAgICAgcGFyc2VyLnByb3RvY29sID0gdGhpcy5wcm90b2NvbDtcbiAgICAgICAgICAvLyBmaXggcmVsYXRpdmUgbGlua3NcbiAgICAgICAgICBpZiAoX3RhZy50YWdNZXNzYWdlID09PSAnQScpIHtcbiAgICAgICAgICAgIF90YWcuY2xhc3NMaXN0LmFkZCgnbXR0X2xpbmsnKTtcbiAgICAgICAgICAgIGlmIChwYXJzZXIucGF0aG5hbWUuaW5kZXhPZignbS5leGUnKSAhPT0gLTEpIHtcbiAgICAgICAgICAgICAgcGFyc2VyLnBhdGhuYW1lID0gJy9jJyArIHBhcnNlci5wYXRobmFtZTtcbiAgICAgICAgICAgICAgX3RhZy5zZXRBdHRyaWJ1dGUoJ3RhcmdldCcsICdfYmxhbmsnKTtcbiAgICAgICAgICAgICAgX3RhZy5zZXRBdHRyaWJ1dGUoYXR0ciwgcGFyc2VyLmhyZWYpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSBpZiAoX3RhZy50YWdOYW1lID09PSAnSU1HJykge1xuICAgICAgICAgICAgX3RhZy5jbGFzc0xpc3QuYWRkKCdtdHRfaW1nJyk7XG4gICAgICAgICAgICBfdGFnLnNyYyA9ICcnICsgdGhpcy5ob3N0ICsgX3RhZy5zcmM7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XSk7XG5cbiAgcmV0dXJuIFRyYW47XG59KSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBUcmFuKCk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD10cmFuLmpzLm1hcFxuIiwiLypcbiAgVHJhbnNsYXRpb24gZW5naW5lOiBodHRwOi8vd3d3LnR1cmtpc2hkaWN0aW9uYXJ5Lm5ldFxuICBGb3IgdHJhbnNsYXRpbmcgdHVya2lzaC1ydXNzaWFuIGFuZCB2aWNlIHZlcnNhXG4qL1xuJ3VzZSBzdHJpY3QnO1xuXG52YXIgX2NyZWF0ZUNsYXNzID0gKGZ1bmN0aW9uICgpIHsgZnVuY3Rpb24gZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIHByb3BzKSB7IGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpKyspIHsgdmFyIGRlc2NyaXB0b3IgPSBwcm9wc1tpXTsgZGVzY3JpcHRvci5lbnVtZXJhYmxlID0gZGVzY3JpcHRvci5lbnVtZXJhYmxlIHx8IGZhbHNlOyBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSA9IHRydWU7IGlmICgndmFsdWUnIGluIGRlc2NyaXB0b3IpIGRlc2NyaXB0b3Iud3JpdGFibGUgPSB0cnVlOyBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBkZXNjcmlwdG9yLmtleSwgZGVzY3JpcHRvcik7IH0gfSByZXR1cm4gZnVuY3Rpb24gKENvbnN0cnVjdG9yLCBwcm90b1Byb3BzLCBzdGF0aWNQcm9wcykgeyBpZiAocHJvdG9Qcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvci5wcm90b3R5cGUsIHByb3RvUHJvcHMpOyBpZiAoc3RhdGljUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IsIHN0YXRpY1Byb3BzKTsgcmV0dXJuIENvbnN0cnVjdG9yOyB9OyB9KSgpO1xuXG5mdW5jdGlvbiBfY2xhc3NDYWxsQ2hlY2soaW5zdGFuY2UsIENvbnN0cnVjdG9yKSB7IGlmICghKGluc3RhbmNlIGluc3RhbmNlb2YgQ29uc3RydWN0b3IpKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoJ0Nhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvbicpOyB9IH1cblxudmFyIENIQVJfQ09ERVMgPSByZXF1aXJlKCcuL2NoYXItY29kZXMtdHVyay5qcycpO1xuXG52YXIgVHVya2lzaERpY3Rpb25hcnkgPSAoZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBUdXJraXNoRGljdGlvbmFyeSgpIHtcbiAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgVHVya2lzaERpY3Rpb25hcnkpO1xuXG4gICAgdGhpcy5ob3N0ID0gJ2h0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0Lz93b3JkPSVGQyc7XG4gICAgdGhpcy5wYXRoID0gJyc7XG4gICAgdGhpcy5wcm90b2NvbCA9ICdodHRwJztcbiAgICB0aGlzLnF1ZXJ5ID0gJyZzPSc7XG4gICAgdGhpcy5UQUJMRV9DTEFTUyA9ICdfX19tdHRfdHJhbnNsYXRlX3RhYmxlJztcbiAgICAvLyB0aGlzIGZsYWcgaW5kaWNhdGVzIHRoYXQgaWYgdHJhbnNsYXRpb24gd2FzIHN1Y2Nlc3NmdWwgdGhlbiBwdWJsaXNoIGl0IGFsbCBvdmVyIGV4dGVuc2lvblxuICAgIHRoaXMubmVlZF9wdWJsaXNoID0gdHJ1ZTtcbiAgfVxuXG4gIC8vIFNpbmdsZXRvbmVcblxuICBfY3JlYXRlQ2xhc3MoVHVya2lzaERpY3Rpb25hcnksIFt7XG4gICAga2V5OiAnc2VhcmNoJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc2VhcmNoKGRhdGEpIHtcbiAgICAgIGRhdGEudXJsID0gdGhpcy5tYWtlVXJsKGRhdGEudmFsdWUpO1xuICAgICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSBmYWxzZTtcbiAgICAgIHJldHVybiB0aGlzLnJlcXVlc3QoZGF0YSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAndHJhbnNsYXRlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gdHJhbnNsYXRlKGRhdGEpIHtcbiAgICAgIGRhdGEudXJsID0gdGhpcy5tYWtlVXJsKGRhdGEuc2VsZWN0aW9uVGV4dCk7XG4gICAgICB0aGlzLm5lZWRfcHVibGlzaCA9IHRydWU7XG4gICAgICB0aGlzLnJlcXVlc3QoZGF0YSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnbWFrZVVybCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG1ha2VVcmwodGV4dCkge1xuICAgICAgdmFyIHRleHQgPSB0aGlzLmdldEVuY29kZWRWYWx1ZSh0ZXh0KTtcbiAgICAgIHJldHVybiBbJ2h0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0Lz93b3JkPScsIHRleHRdLmpvaW4oJycpO1xuICAgIH1cblxuICAgIC8vIFJlcGxhY2Ugc3BlY2lhbCBsYW5ndWFnZSBjaGFyYWN0ZXJzIHRvIGh0bWwgY29kZXNcbiAgfSwge1xuICAgIGtleTogJ2dldEVuY29kZWRWYWx1ZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGdldEVuY29kZWRWYWx1ZSh2YWx1ZSkge1xuICAgICAgLy8gdG8gZmluZCBzcGVjIHN5bWJvbHMgd2UgZmlyc3QgZW5jb2RlIHRoZW0gKHJhdyBzZWFyY2ggZm9yIHRoYXQgc3ltYm9sIGRvZXNuJ3Qgd29yKVxuICAgICAgcmV0dXJuIGVuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSk7XG4gICAgICAvL3JldHVybiB0aGlzLm1ha2VTdHJpbmdUcmFuc2ZlcmFibGUodmFsdWUpO1xuICAgIH1cblxuICAgIC8qKiBjb252ZXJ0aW5nIHNjcmlwdCBmcm9tIHRoZSB0dXJraXNoZGljdCAqL1xuICB9LCB7XG4gICAga2V5OiAnbWFrZVN0cmluZ1RyYW5zZmVyYWJsZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG1ha2VTdHJpbmdUcmFuc2ZlcmFibGUoaW5wdXRUZXh0KSB7XG4gICAgICB2YXIgdGV4dCA9IFwiXCI7XG4gICAgICBpZiAoaW5wdXRUZXh0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgdGV4dCA9IGlucHV0VGV4dDtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0ZXh0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgaWYgKENIQVJfQ09ERVNbdGV4dC5jaGFyQ29kZUF0KGkpXSkge1xuICAgICAgICAgICAgdGV4dCA9IHRleHQuc3Vic3RyaW5nKDAsIGkpICsgQ0hBUl9DT0RFU1t0ZXh0LmNoYXJDb2RlQXQoaSldICsgdGV4dC5zdWJzdHJpbmcoaSArIDEsIHRleHQubGVuZ3RoKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHRleHQuY2hhckF0KGkpID09ICcgJykge1xuICAgICAgICAgICAgLy8gcmVwbGFjZSBzcGFjZXNcbiAgICAgICAgICAgIHRleHQgPSB0ZXh0LnN1YnN0cmluZygwLCBpKSArICdfX18nICsgdGV4dC5zdWJzdHJpbmcoaSArIDEsIHRleHQubGVuZ3RoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiB0ZXh0O1xuICAgIH1cblxuICAgIC8qXG4gICAgICBSZXF1ZXN0IHRyYW5zbGF0aW9uIGFuZCBydW4gY2FsbGJhY2sgZnVuY3Rpb25cbiAgICAgIHBhc3NpbmcgdHJhbnNsYXRlZCByZXN1bHQgb3IgZXJyb3IgdG8gY2FsbGJhY2tcbiAgICAqL1xuICB9LCB7XG4gICAga2V5OiAncmVxdWVzdCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJlcXVlc3Qob3B0cykge1xuICAgICAgY29uc29sZS5sb2coJ3N0YXJ0IHJlcXVlc3QnKTtcbiAgICAgIHRoaXMueGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICB0aGlzLnhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSB0aGlzLm9uUmVhZHlTdGF0ZUNoYW5nZS5iaW5kKHRoaXMsIG9wdHMpO1xuICAgICAgdGhpcy54aHIub3BlbihcIkdFVFwiLCBvcHRzLnVybCwgdHJ1ZSk7XG4gICAgICB0aGlzLnhoci5zZW5kKCk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnb25SZWFkeVN0YXRlQ2hhbmdlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gb25SZWFkeVN0YXRlQ2hhbmdlKG9wdHMsIGUpIHtcbiAgICAgIHZhciB4aHIgPSB0aGlzLnhocjtcbiAgICAgIGlmICh4aHIucmVhZHlTdGF0ZSA8IDQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSBlbHNlIGlmICh4aHIuc3RhdHVzICE9IDIwMCkge1xuICAgICAgICB0aGlzLmVycm9ySGFuZGxlcih4aHIpO1xuICAgICAgICByZXR1cm4gb3B0cy5lcnJvciAmJiBvcHRzLmVycm9yKCk7XG4gICAgICB9IGVsc2UgaWYgKHhoci5yZWFkeVN0YXRlID09IDQpIHtcbiAgICAgICAgdmFyIHRyYW5zbGF0aW9uID0gdGhpcy5zdWNjZXNzSGFuZGxlcihlLnRhcmdldC5yZXNwb25zZSk7XG4gICAgICAgIGNvbnNvbGUubG9nKCdzdWNjZXNzIHR1cmtpc2ggdHJhbnNsYXRlJywgdHJhbnNsYXRpb24pO1xuICAgICAgICBjb25zb2xlLmxvZygnY2FsbCcsIG9wdHMuc3VjY2Vzcyk7XG4gICAgICAgIHJldHVybiBvcHRzLnN1Y2Nlc3MgJiYgb3B0cy5zdWNjZXNzKHRyYW5zbGF0aW9uKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdzdWNjZXNzSGFuZGxlcicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHN1Y2Nlc3NIYW5kbGVyKHJlc3BvbnNlKSB7XG4gICAgICB2YXIgZGF0YSA9IHRoaXMucGFyc2UocmVzcG9uc2UpO1xuICAgICAgaWYgKHRoaXMubmVlZF9wdWJsaXNoKSB7XG4gICAgICAgIGNocm9tZS50YWJzLmdldFNlbGVjdGVkKG51bGwsIHRoaXMucHVibGlzaFRyYW5zbGF0aW9uLmJpbmQodGhpcywgZGF0YSkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGRhdGE7XG4gICAgfVxuXG4gICAgLyogcHVibGlzaCBzdWNjZXNzZnVseSB0cmFuc2xhdGVkIHRleHQgYWxsIG92ZXIgZXh0ZW5zaW9uICovXG4gIH0sIHtcbiAgICBrZXk6ICdwdWJsaXNoVHJhbnNsYXRpb24nLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBwdWJsaXNoVHJhbnNsYXRpb24odHJhbnNsYXRpb24sIHRhYikge1xuICAgICAgY29uc29sZS5sb2coJ3B1Ymxpc2ggdHJhbnNsYXRpb24nKTtcbiAgICAgIGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhYi5pZCwge1xuICAgICAgICBhY3Rpb246IHRoaXMudG9vbHRpcEFjdGlvbih0cmFuc2xhdGlvbiksXG4gICAgICAgIGRhdGE6IHRyYW5zbGF0aW9uLm91dGVySFRNTCxcbiAgICAgICAgc3VjY2VzczogIXRyYW5zbGF0aW9uLmNsYXNzTGlzdC5jb250YWlucygnZmFpbFRyYW5zbGF0ZScpXG4gICAgICB9KTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICd0b29sdGlwQWN0aW9uJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gdG9vbHRpcEFjdGlvbih0cmFuc2xhdGlvbikge1xuICAgICAgaWYgKHRyYW5zbGF0aW9uLnRleHRDb250ZW50LnRyaW0oKS5pbmRleE9mKCd3YXMgbm90IGZvdW5kIGluIG91ciBkaWN0aW9uYXJ5JykgIT0gLTEpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ3NpbWlsYXIgd29yZHMnKTtcbiAgICAgICAgcmV0dXJuICdzaW1pbGFyX3dvcmRzJztcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdvcGVuIHRvb2x0aXAnKTtcbiAgICAgICAgcmV0dXJuICdvcGVuX3Rvb2x0aXAnO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2Vycm9ySGFuZGxlcicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGVycm9ySGFuZGxlcihyZXNwb25zZSkge1xuICAgICAgY29uc29sZS5sb2coJ2Vycm9yIGFqYXgnLCByZXNwb25zZSk7XG4gICAgfVxuXG4gICAgLyogUGFyc2UgcmVzcG9uc2UgZnJvbSB0cmFuc2xhdGlvbiBlbmdpbmUgKi9cbiAgfSwge1xuICAgIGtleTogJ3BhcnNlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gcGFyc2UocmVzcG9uc2UsIHNpbGVudCwgdHJhbnNsYXRlKSB7XG4gICAgICB2YXIgZG9jID0gdGhpcy5zdHJpcFNjcmlwdHMocmVzcG9uc2UpLFxuICAgICAgICAgIGZyYWdtZW50ID0gdGhpcy5tYWtlRnJhZ21lbnQoZG9jKTtcbiAgICAgIGlmIChmcmFnbWVudCkge1xuICAgICAgICB0cmFuc2xhdGUgPSBmcmFnbWVudC5xdWVyeVNlbGVjdG9yKCcjbWVhbmluZ19kaXYgPiB0YWJsZScpO1xuICAgICAgICBpZiAodHJhbnNsYXRlKSB7XG4gICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9IHRoaXMuVEFCTEVfQ0xBU1M7XG4gICAgICAgICAgdHJhbnNsYXRlLnNldEF0dHJpYnV0ZShcImNlbGxwYWRkaW5nXCIsIFwiNVwiKTtcbiAgICAgICAgICAvLyBAZml4SW1hZ2VzKHRyYW5zbGF0ZSlcbiAgICAgICAgICAvLyBAZml4TGlua3ModHJhbnNsYXRlKVxuICAgICAgICB9IGVsc2UgaWYgKCFzaWxlbnQpIHtcbiAgICAgICAgICAgIHRyYW5zbGF0ZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9ICdmYWlsVHJhbnNsYXRlJztcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5pbm5lclRleHQgPSBcIlVuZm9ydHVuYXRlbHksIGNvdWxkIG5vdCB0cmFuc2xhdGVcIjtcbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJhbnNsYXRlO1xuICAgIH1cblxuICAgIC8qKiBwYXJzaW5nIG9mIHRlcnJpYmxlIGh0bWwgbWFya3VwICovXG4gIH0sIHtcbiAgICBrZXk6ICdwYXJzZVRleHQnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBwYXJzZVRleHQocmVzcG9uc2UsIHNpbGVudCwgdHJhbnNsYXRlKSB7XG4gICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgICB2YXIgZG9jID0gdGhpcy5zdHJpcFNjcmlwdHMocmVzcG9uc2UpLFxuICAgICAgICAgIGZyYWdtZW50ID0gdGhpcy5tYWtlRnJhZ21lbnQoZG9jKTtcblxuICAgICAgaWYgKGZyYWdtZW50KSB7XG4gICAgICAgIHZhciBpO1xuXG4gICAgICAgIHZhciBfcmV0ID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgc3RvcEluZGV4ID0gbnVsbDtcbiAgICAgICAgICB2YXIgdHIgPSBmcmFnbWVudC5xdWVyeVNlbGVjdG9yQWxsKCcjbWVhbmluZ19kaXY+dGFibGU+dGJvZHk+dHInKTtcbiAgICAgICAgICB0ciA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKHRyKTtcblxuICAgICAgICAgIHZhciB0cmFucyA9IHRyLmZpbHRlcihmdW5jdGlvbiAodHIsIGluZGV4KSB7XG4gICAgICAgICAgICBpZiAoIWlzTmFOKHBhcnNlSW50KHN0b3BJbmRleCwgMTApKSAmJiBpbmRleCA+PSBzdG9wSW5kZXgpIHtcbiAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgdHIgPSAkKHRyKTtcbiAgICAgICAgICAgICAgLy8gdGFrZSBldmVyeSByb3cgYmVmb3JlIG5leHQgc2VjdGlvbiAod2hpY2ggaXMgRW5nbGlzaC0+RW5nbGlzaClcbiAgICAgICAgICAgICAgaWYgKHRyLmF0dHIoJ2JnY29sb3InKSA9PSBcImUwZTZmZlwiKSB7XG4gICAgICAgICAgICAgICAgc3RvcEluZGV4ID0gaW5kZXg7cmV0dXJuO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJldHVybiAkLnRyaW0odHIuZmluZCgndGQnKS50ZXh0KCkpLmxlbmd0aDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHRyYW5zID0gdHJhbnMuc2xpY2UoMSwgdHJhbnMubGVuZ3RoIC0gMSk7XG4gICAgICAgICAgdHJhbnMgPSB0cmFucy5maWx0ZXIoZnVuY3Rpb24gKGVsLCBpbmR4KSB7XG4gICAgICAgICAgICByZXR1cm4gaW5keCAlIDI7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgdmFyIGZyYWcgPSBfdGhpcy5mcmFnbWVudEZyb21MaXN0KHRyYW5zKTtcbiAgICAgICAgICB2YXIgZm9udHMgPSBmcmFnLnF1ZXJ5U2VsZWN0b3JBbGwoJ2ZvbnQnKTtcbiAgICAgICAgICB2YXIgdGV4dCA9ICcnO1xuICAgICAgICAgIGZvciAoaSA9IDA7IGkgPCBmb250cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdGV4dCArPSAnICcgKyBmb250c1tpXS50ZXh0Q29udGVudC50cmltKCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB2OiB0ZXh0XG4gICAgICAgICAgfTtcbiAgICAgICAgfSkoKTtcblxuICAgICAgICBpZiAodHlwZW9mIF9yZXQgPT09ICdvYmplY3QnKSByZXR1cm4gX3JldC52O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgXCJIVE1MIGZyYWdtZW50IGNvdWxkIG5vdCBiZSBwYXJzZWRcIjtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvL1RPRE8gZXh0cmFjdCB0byBiYXNlIGVuZ2luZSBjbGFzc1xuICAgIC8qIHJlbW92ZXMgPHNjcmlwdD4gdGFncyBmcm9tIGh0bWwgY29kZSAqL1xuICB9LCB7XG4gICAga2V5OiAnc3RyaXBTY3JpcHRzJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc3RyaXBTY3JpcHRzKGh0bWwpIHtcbiAgICAgIHZhciBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGRpdi5pbm5lckhUTUwgPSBodG1sO1xuICAgICAgdmFyIHNjcmlwdHMgPSBkaXYuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ3NjcmlwdCcpO1xuICAgICAgdmFyIGkgPSBzY3JpcHRzLmxlbmd0aDtcbiAgICAgIHdoaWxlIChpLS0pIHNjcmlwdHNbaV0ucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChzY3JpcHRzW2ldKTtcbiAgICAgIHJldHVybiBkaXYuaW5uZXJIVE1MO1xuICAgIH1cblxuICAgIC8vVE9ETyBleHRyYWN0IHRvIGJhc2UgZW5naW5lIGNsYXNzXG4gICAgLyogY3JlYXRlcyB0ZW1wIG9iamVjdCB0byBwYXJzZSB0cmFuc2xhdGlvbiBmcm9tIHBhZ2UgXG4gICAgICAoc2luY2UgaXQncyBub3QgYSBmcmllbmRseSBhcGkpIFxuICAgICovXG4gIH0sIHtcbiAgICBrZXk6ICdtYWtlRnJhZ21lbnQnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlRnJhZ21lbnQoaHRtbCkge1xuICAgICAgdmFyIGZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpLFxuICAgICAgICAgIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcbiAgICAgIHdoaWxlIChkaXYuZmlyc3RDaGlsZCkge1xuICAgICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZChkaXYuZmlyc3RDaGlsZCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgfVxuXG4gICAgLyoqIGNyZWF0ZSBmcmFnbWVudCBmcm9tIGxpc3Qgb2YgRE9NIGVsZW1lbnRzICovXG4gIH0sIHtcbiAgICBrZXk6ICdmcmFnbWVudEZyb21MaXN0JyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZnJhZ21lbnRGcm9tTGlzdChsaXN0KSB7XG4gICAgICB2YXIgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCksXG4gICAgICAgICAgbGVuID0gbGlzdC5sZW5ndGg7XG4gICAgICB3aGlsZSAobGVuLS0pIHtcbiAgICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQobGlzdFtsZW5dKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmcmFnbWVudDtcbiAgICB9XG4gIH1dKTtcblxuICByZXR1cm4gVHVya2lzaERpY3Rpb25hcnk7XG59KSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBUdXJraXNoRGljdGlvbmFyeSgpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dHVya2lzaGRpY3Rpb25hcnkuanMubWFwXG4iXX0=
