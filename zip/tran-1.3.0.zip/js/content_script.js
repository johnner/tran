(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
/* global chrome */
/*
 Script embedded on each user page
 Listens messages from translation module and renders popup
 with translated text
*/
"use strict";

require("../polyfills/Array.from.js");

var View = require('./view.js');
var content = new View();
//# sourceMappingURL=content.js.map

},{"../polyfills/Array.from.js":4,"./view.js":3}],2:[function(require,module,exports){
// TODO вынести настройки подключения в settings.js
//var HOST = 'http://tran-service.com'
'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var HOST = 'http://localhost:5000';

var TOOLTIP_CLASS_PREFIX = '__mtt_translate_dialog__';
var ctrlDown = false;
var ctrlKey = 17;
var cmdKey = 91;
var cKey = 67;
var add_title = 'Добавить в персональный словарь';

var _ = require('../utils.js');

var Tooltip = (function () {
  function Tooltip(coordinates) {
    _classCallCheck(this, Tooltip);

    this.setListeners();
    this.clickTarget = null;
  }

  _createClass(Tooltip, [{
    key: 'createEl',
    value: function createEl(storage) {
      this.el = document.createElement('div');
      this.memorizeButton = this.createMemoBtn();
      this.elContainer = this.createContainer();
      this.el.appendChild(this.memorizeButton);
      this.el.appendChild(this.elContainer);
      this.el.classList.add(TOOLTIP_CLASS_PREFIX);
      this.addListeners();
    }
  }, {
    key: 'addListeners',
    value: function addListeners() {
      this.el.addEventListener('mousedown', function (e) {
        return e.stopPropagation();
      });
      this.el.addEventListener('keydown', this.onKeyDown);
      this.memorizeButton.addEventListener('click', this.memoClick);
    }
  }, {
    key: 'createMemoBtn',
    value: function createMemoBtn() {
      var t = document.createElement('template');
      var tmpl = '<a title="' + add_title + '"\n                   class="btn-floating waves-effect waves-light blue word-add">\n                  <i class="material-icons">+</i>\n                </a>';
      t.innerHTML = tmpl;
      return t.content;
    }
  }, {
    key: 'memoClick',
    value: function memoClick(e) {
      e.stopPropagation();
      e.preventDefault();
      _.post(HOST + '/api/plugin/add_word/', { data: 'blabla' });
    }
  }, {
    key: 'createContainer',
    value: function createContainer() {
      var docFragment = document.createDocumentFragment();
      var container = document.createElement('div');
      container.classList.add(TOOLTIP_CLASS_PREFIX + 'container');
      return container;
    }
  }, {
    key: 'onKeyDown',
    value: function onKeyDown(e) {
      if (ctrlDown && (e.keyCode == vKey || e.keyCode == cKey)) {
        e.stopPropagation();
        return true;
      }
    }
  }, {
    key: 'setListeners',
    value: function setListeners() {
      var _this = this;

      window.addEventListener('mousedown', function (e) {
        return _this.destroy(e);
      });
      document.addEventListener('mousedown', function (e) {
        return _this.destroy(e);
      });
      window.addEventListener('blur', function (e) {
        return _this.destroy(e);
      });
      document.addEventListener('keydown', function (e) {
        return _this.keydown(e);
      });
      document.addEventListener('keyup', function (e) {
        return _this.keyup(e);
      });
    }
  }, {
    key: 'render',
    value: function render(data) {
      var transform = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];

      if (!this.el) {
        this.createEl();
      }
      this.checkMemorize();
      this.elContainer.innerHTML = data;
      if (transform) {
        transform(this.el);
      }
      this.el.style.left = this.coordinates.mouseX + 'px';
      this.el.style.top = this.coordinates.mouseY + 'px';
      document.body.appendChild(this.el);
      if (this.coordinates.mouseX + this.el.offsetWidth > window.innerWidth) {
        this.el.style.left = this.coordinates.mouseX - this.el.offsetWidth + 'px';
      }
    }
  }, {
    key: 'checkMemorize',
    value: function checkMemorize() {
      var self = this;
      chrome.storage.sync.get({ memorize: false, auth_token: null }, function (storage) {
        if (storage.memorize && storage.auth_token) {
          self.el.classList.add('memorize');
        } else {
          self.el.classList.remove('memorize');
        }
      });
    }
  }, {
    key: 'keydown',
    value: function keydown(e) {
      if (e.keyCode == ctrlKey || e.keyCode == cmdKey) {
        ctrlDown = true;
      }
      if (ctrlDown && (e.keyCode == ctrlKey || e.keyCode == cKey || e.keyCode == cmdKey)) {
        return true;
      } else {
        this.destroy(e);
      }
    }
  }, {
    key: 'keyup',
    value: function keyup(e) {
      if (e.keyCode == ctrlKey) {
        ctrlDown = false;
      }
    }
  }, {
    key: 'destroy',
    value: function destroy(e) {
      if (this.el && this.el.parentNode == document.body) {
        document.body.removeChild(this.el);
        this.el = null;
        this.clickTarget = null; // reset click target
      }
    }
  }, {
    key: 'setCoordinates',
    value: function setCoordinates(coordinates) {
      this.coordinates = coordinates;
    }
  }]);

  return Tooltip;
})();

module.exports = Tooltip;
//# sourceMappingURL=tooltip.js.map

},{"../utils.js":5}],3:[function(require,module,exports){
'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var Tooltip = require('./tooltip.js');
var TEXTBOX_TAGS = ['input', 'textarea'];

var Main = (function () {
  function Main() {
    _classCallCheck(this, Main);

    this.addEventListeners();
    this.coordinates = { mouseX: 0, mouseY: 0 };
    this.tooltip = new Tooltip(this.coordinates);
    chrome.runtime.onMessage.addListener(this.renderResult.bind(this));
  }

  _createClass(Main, [{
    key: 'addEventListeners',
    value: function addEventListeners() {
      var _this = this;

      window.addEventListener('mousedown', function (e) {
        return _this.mouseDownEvent(e);
      });
      document.addEventListener('mousedown', function (e) {
        return _this.mouseDownEvent(e);
      });
      window.addEventListener('mouseup', function (e) {
        return _this.mouseUpEvent(e);
      });
      document.addEventListener('contextmenu', function (e) {
        return _this.saveMousePosition(e);
      });
    }
  }, {
    key: 'renderResult',
    value: function renderResult(msg) {
      if (msg.action == 'open_tooltip' || msg.action == 'similar_words') {
        //don't show annoying tooltip when typing
        if (!msg.success && this.tooltip.clickTarget == 'textbox') {
          return;
        } else if (msg.action == 'similar_words') {
          this.tooltip.render(msg.data, this.attachSimilarWordsHandlers.bind(this));
        } else {
          this.tooltip.render(msg.data);
        }
      }
    }
  }, {
    key: 'requestSearch',
    value: function requestSearch(selection) {
      chrome.runtime.sendMessage({
        method: "request_search",
        data: {
          selectionText: selection
        }
      });
    }
  }, {
    key: 'saveMousePosition',
    value: function saveMousePosition(e) {
      this.coordinates.mouseX = e.pageX + 5;
      this.coordinates.mouseY = e.pageY + 10;
      this.tooltip.setCoordinates(this.coordinates);
    }
  }, {
    key: 'mouseDownEvent',
    value: function mouseDownEvent(e) {
      var tag = e.target.tagName.toLowerCase();
      if (TEXTBOX_TAGS.indexOf(tag) != -1) {
        this.tooltip.clickTarget = 'textbox';
      }
    }
  }, {
    key: 'mouseUpEvent',
    value: function mouseUpEvent(e) {
      // fix for accidental tooltip appearance when clicked on text
      setTimeout(this.clickHandler.bind(this, e), 10);
      return true;
    }
  }, {
    key: 'clickHandler',
    value: function clickHandler(e) {
      this.saveMousePosition(e);
      var selection = this.getSelection();
      var self = this;
      if (selection.length > 0) {
        chrome.storage.sync.get({ fast: true }, function (items) {
          if (items.fast) {
            self.requestSearch(selection);
          }
        });
      }
    }
  }, {
    key: 'getSelection',
    value: function getSelection(e) {
      var txt = window.getSelection().toString();
      var span = document.createElement('SPAN');
      span.innerHTML = txt;
      var selection = span.textContent.trim();
      return selection;
    }
  }, {
    key: 'attachSimilarWordsHandlers',
    value: function attachSimilarWordsHandlers(fragment) {
      var _this2 = this;

      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        var _loop = function () {
          var link = _step.value;

          // sanitize
          link.removeAttribute('onclick');
          link.onclick = null;
          var clone = link.cloneNode(true);
          link.parentNode.replaceChild(clone, link);
          var word = clone.textContent;
          // Prevent link from being followed.
          clone.addEventListener('click', function (e) {
            e.stopPropagation();e.preventDefault();
          });
          // Don't let @mouseUpEvent fire again with the wrong word.
          self = _this2;

          clone.addEventListener('mouseup', function (e) {
            e.stopPropagation();
            self.requestSearch(word);
          });
        };

        for (var _iterator = Array.from(fragment.querySelectorAll('a'))[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var self;

          _loop();
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator['return']) {
            _iterator['return']();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return true;
    }
  }]);

  return Main;
})();

module.exports = Main;
//# sourceMappingURL=view.js.map

},{"./tooltip.js":2}],4:[function(require,module,exports){
"use strict";

Array.from || !(function () {
  "use strict";var r = (function () {
    try {
      var r = {},
          e = Object.defineProperty,
          t = e(r, r, r) && e;
    } catch (n) {}return t || function (r, e, t) {
      r[e] = t.value;
    };
  })(),
      e = Object.prototype.toString,
      t = function t(r) {
    return "function" == typeof r || "[object Function]" == e.call(r);
  },
      n = function n(r) {
    var e = Number(r);return isNaN(e) ? 0 : 0 != e && isFinite(e) ? (e > 0 ? 1 : -1) * Math.floor(Math.abs(e)) : e;
  },
      a = Math.pow(2, 53) - 1,
      o = function o(r) {
    var e = n(r);return Math.min(Math.max(e, 0), a);
  },
      u = function u(e) {
    var n = this;if (null == e) throw new TypeError("`Array.from` requires an array-like object, not `null` or `undefined`");{
      var a,
          u,
          i = Object(e);arguments.length > 1;
    }if (arguments.length > 1) {
      if ((a = arguments[1], !t(a))) throw new TypeError("When provided, the second argument to `Array.from` must be a function");arguments.length > 2 && (u = arguments[2]);
    }for (var f, c, l = o(i.length), h = t(n) ? Object(new n(l)) : new Array(l), m = 0; l > m;) f = i[m], c = a ? "undefined" == typeof u ? a(f, m) : a.call(u, f, m) : f, r(h, m, { value: c, configurable: !0, enumerable: !0, writable: !0 }), ++m;return h.length = l, h;
  };r(Array, "from", { value: u, configurable: !0, writable: !0 });
})();
//# sourceMappingURL=Array.from.js.map

},{}],5:[function(require,module,exports){
"use strict";

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Utils = (function () {
  function Utils() {
    _classCallCheck(this, Utils);
  }

  _createClass(Utils, [{
    key: "request",
    value: function request(type, url, opts) {
      // Return a new promise.
      return new Promise(function (resolve, reject) {
        // Do the usual XHR stuff
        var req = new XMLHttpRequest();
        req.withCredentials = true;
        req.open(type, url);
        if (type == 'POST') {
          req.setRequestHeader("Content-Type", "application/json");
        }
        req.onload = function () {
          // This is called even on 404 etc
          // so check the status
          if (req.status == 200) {
            // Resolve the promise with the response text
            resolve(req.response);
          } else {
            // Otherwise reject with the status text
            // which will hopefully be a meaningful error
            reject(Error(req.statusText));
          }
        };

        // Handle network errors
        req.onerror = function () {
          reject(Error("Network Error"));
        };

        // Set headers
        if (opts.headers) {
          var _iteratorNormalCompletion = true;
          var _didIteratorError = false;
          var _iteratorError = undefined;

          try {
            for (var _iterator = Object.keys(opts.headers)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              var key = _step.value;

              req.setRequestHeader(key, opts.headers[key]);
            }
          } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion && _iterator["return"]) {
                _iterator["return"]();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
          }
        }
        // Make the request
        req.send(JSON.stringify(opts.data));
      });
    }
  }, {
    key: "get",
    value: function get(url) {
      var opts = arguments.length <= 1 || arguments[1] === undefined ? { data: '' } : arguments[1];

      return this.request('GET', url, opts);
    }
  }, {
    key: "post",
    value: function post(url) {
      var opts = arguments.length <= 1 || arguments[1] === undefined ? { data: '' } : arguments[1];

      return this.request('POST', url, opts);
    }
  }]);

  return Utils;
})();

module.exports = new Utils();
//# sourceMappingURL=utils.js.map

},{}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxkZXZcXHRyYW5cXG5vZGVfbW9kdWxlc1xcYnJvd3Nlci1wYWNrXFxfcHJlbHVkZS5qcyIsIkM6L2Rldi90cmFuL2pzL2VzNS9jb250ZW50X3NjcmlwdC9jb250ZW50LmpzIiwiQzovZGV2L3RyYW4vanMvZXM1L2NvbnRlbnRfc2NyaXB0L3Rvb2x0aXAuanMiLCJDOi9kZXYvdHJhbi9qcy9lczUvY29udGVudF9zY3JpcHQvdmlldy5qcyIsIkM6L2Rldi90cmFuL2pzL2VzNS9wb2x5ZmlsbHMvQXJyYXkuZnJvbS5qcyIsIkM6L2Rldi90cmFuL2pzL2VzNS91dGlscy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDYkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDM0tBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN2S0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNsQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKX12YXIgZj1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwoZi5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxmLGYuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiLyogZ2xvYmFsIGNocm9tZSAqL1xuLypcbiBTY3JpcHQgZW1iZWRkZWQgb24gZWFjaCB1c2VyIHBhZ2VcbiBMaXN0ZW5zIG1lc3NhZ2VzIGZyb20gdHJhbnNsYXRpb24gbW9kdWxlIGFuZCByZW5kZXJzIHBvcHVwXG4gd2l0aCB0cmFuc2xhdGVkIHRleHRcbiovXG5cInVzZSBzdHJpY3RcIjtcblxucmVxdWlyZShcIi4uL3BvbHlmaWxscy9BcnJheS5mcm9tLmpzXCIpO1xuXG52YXIgVmlldyA9IHJlcXVpcmUoJy4vdmlldy5qcycpO1xudmFyIGNvbnRlbnQgPSBuZXcgVmlldygpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29udGVudC5qcy5tYXBcbiIsIi8vIFRPRE8g0LLRi9C90LXRgdGC0Lgg0L3QsNGB0YLRgNC+0LnQutC4INC/0L7QtNC60LvRjtGH0LXQvdC40Y8g0LIgc2V0dGluZ3MuanNcbi8vdmFyIEhPU1QgPSAnaHR0cDovL3RyYW4tc2VydmljZS5jb20nXG4ndXNlIHN0cmljdCc7XG5cbnZhciBfY3JlYXRlQ2xhc3MgPSAoZnVuY3Rpb24gKCkgeyBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0aWVzKHRhcmdldCwgcHJvcHMpIHsgZm9yICh2YXIgaSA9IDA7IGkgPCBwcm9wcy5sZW5ndGg7IGkrKykgeyB2YXIgZGVzY3JpcHRvciA9IHByb3BzW2ldOyBkZXNjcmlwdG9yLmVudW1lcmFibGUgPSBkZXNjcmlwdG9yLmVudW1lcmFibGUgfHwgZmFsc2U7IGRlc2NyaXB0b3IuY29uZmlndXJhYmxlID0gdHJ1ZTsgaWYgKCd2YWx1ZScgaW4gZGVzY3JpcHRvcikgZGVzY3JpcHRvci53cml0YWJsZSA9IHRydWU7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGRlc2NyaXB0b3Iua2V5LCBkZXNjcmlwdG9yKTsgfSB9IHJldHVybiBmdW5jdGlvbiAoQ29uc3RydWN0b3IsIHByb3RvUHJvcHMsIHN0YXRpY1Byb3BzKSB7IGlmIChwcm90b1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLnByb3RvdHlwZSwgcHJvdG9Qcm9wcyk7IGlmIChzdGF0aWNQcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvciwgc3RhdGljUHJvcHMpOyByZXR1cm4gQ29uc3RydWN0b3I7IH07IH0pKCk7XG5cbmZ1bmN0aW9uIF9jbGFzc0NhbGxDaGVjayhpbnN0YW5jZSwgQ29uc3RydWN0b3IpIHsgaWYgKCEoaW5zdGFuY2UgaW5zdGFuY2VvZiBDb25zdHJ1Y3RvcikpIHsgdGhyb3cgbmV3IFR5cGVFcnJvcignQ2Fubm90IGNhbGwgYSBjbGFzcyBhcyBhIGZ1bmN0aW9uJyk7IH0gfVxuXG52YXIgSE9TVCA9ICdodHRwOi8vbG9jYWxob3N0OjUwMDAnO1xuXG52YXIgVE9PTFRJUF9DTEFTU19QUkVGSVggPSAnX19tdHRfdHJhbnNsYXRlX2RpYWxvZ19fJztcbnZhciBjdHJsRG93biA9IGZhbHNlO1xudmFyIGN0cmxLZXkgPSAxNztcbnZhciBjbWRLZXkgPSA5MTtcbnZhciBjS2V5ID0gNjc7XG52YXIgYWRkX3RpdGxlID0gJ9CU0L7QsdCw0LLQuNGC0Ywg0LIg0L/QtdGA0YHQvtC90LDQu9GM0L3Ri9C5INGB0LvQvtCy0LDRgNGMJztcblxudmFyIF8gPSByZXF1aXJlKCcuLi91dGlscy5qcycpO1xuXG52YXIgVG9vbHRpcCA9IChmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIFRvb2x0aXAoY29vcmRpbmF0ZXMpIHtcbiAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgVG9vbHRpcCk7XG5cbiAgICB0aGlzLnNldExpc3RlbmVycygpO1xuICAgIHRoaXMuY2xpY2tUYXJnZXQgPSBudWxsO1xuICB9XG5cbiAgX2NyZWF0ZUNsYXNzKFRvb2x0aXAsIFt7XG4gICAga2V5OiAnY3JlYXRlRWwnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjcmVhdGVFbChzdG9yYWdlKSB7XG4gICAgICB0aGlzLmVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICB0aGlzLm1lbW9yaXplQnV0dG9uID0gdGhpcy5jcmVhdGVNZW1vQnRuKCk7XG4gICAgICB0aGlzLmVsQ29udGFpbmVyID0gdGhpcy5jcmVhdGVDb250YWluZXIoKTtcbiAgICAgIHRoaXMuZWwuYXBwZW5kQ2hpbGQodGhpcy5tZW1vcml6ZUJ1dHRvbik7XG4gICAgICB0aGlzLmVsLmFwcGVuZENoaWxkKHRoaXMuZWxDb250YWluZXIpO1xuICAgICAgdGhpcy5lbC5jbGFzc0xpc3QuYWRkKFRPT0xUSVBfQ0xBU1NfUFJFRklYKTtcbiAgICAgIHRoaXMuYWRkTGlzdGVuZXJzKCk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnYWRkTGlzdGVuZXJzJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gYWRkTGlzdGVuZXJzKCkge1xuICAgICAgdGhpcy5lbC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIH0pO1xuICAgICAgdGhpcy5lbC5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgdGhpcy5vbktleURvd24pO1xuICAgICAgdGhpcy5tZW1vcml6ZUJ1dHRvbi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIHRoaXMubWVtb0NsaWNrKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdjcmVhdGVNZW1vQnRuJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gY3JlYXRlTWVtb0J0bigpIHtcbiAgICAgIHZhciB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndGVtcGxhdGUnKTtcbiAgICAgIHZhciB0bXBsID0gJzxhIHRpdGxlPVwiJyArIGFkZF90aXRsZSArICdcIlxcbiAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0bi1mbG9hdGluZyB3YXZlcy1lZmZlY3Qgd2F2ZXMtbGlnaHQgYmx1ZSB3b3JkLWFkZFwiPlxcbiAgICAgICAgICAgICAgICAgIDxpIGNsYXNzPVwibWF0ZXJpYWwtaWNvbnNcIj4rPC9pPlxcbiAgICAgICAgICAgICAgICA8L2E+JztcbiAgICAgIHQuaW5uZXJIVE1MID0gdG1wbDtcbiAgICAgIHJldHVybiB0LmNvbnRlbnQ7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnbWVtb0NsaWNrJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gbWVtb0NsaWNrKGUpIHtcbiAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICBfLnBvc3QoSE9TVCArICcvYXBpL3BsdWdpbi9hZGRfd29yZC8nLCB7IGRhdGE6ICdibGFibGEnIH0pO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2NyZWF0ZUNvbnRhaW5lcicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNyZWF0ZUNvbnRhaW5lcigpIHtcbiAgICAgIHZhciBkb2NGcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKTtcbiAgICAgIHZhciBjb250YWluZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGNvbnRhaW5lci5jbGFzc0xpc3QuYWRkKFRPT0xUSVBfQ0xBU1NfUFJFRklYICsgJ2NvbnRhaW5lcicpO1xuICAgICAgcmV0dXJuIGNvbnRhaW5lcjtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdvbktleURvd24nLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBvbktleURvd24oZSkge1xuICAgICAgaWYgKGN0cmxEb3duICYmIChlLmtleUNvZGUgPT0gdktleSB8fCBlLmtleUNvZGUgPT0gY0tleSkpIHtcbiAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnc2V0TGlzdGVuZXJzJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc2V0TGlzdGVuZXJzKCkge1xuICAgICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlZG93bicsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHJldHVybiBfdGhpcy5kZXN0cm95KGUpO1xuICAgICAgfSk7XG4gICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gX3RoaXMuZGVzdHJveShlKTtcbiAgICAgIH0pO1xuICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2JsdXInLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gX3RoaXMuZGVzdHJveShlKTtcbiAgICAgIH0pO1xuICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHJldHVybiBfdGhpcy5rZXlkb3duKGUpO1xuICAgICAgfSk7XG4gICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdrZXl1cCcsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHJldHVybiBfdGhpcy5rZXl1cChlKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3JlbmRlcicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJlbmRlcihkYXRhKSB7XG4gICAgICB2YXIgdHJhbnNmb3JtID0gYXJndW1lbnRzLmxlbmd0aCA8PSAxIHx8IGFyZ3VtZW50c1sxXSA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGFyZ3VtZW50c1sxXTtcblxuICAgICAgaWYgKCF0aGlzLmVsKSB7XG4gICAgICAgIHRoaXMuY3JlYXRlRWwoKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuY2hlY2tNZW1vcml6ZSgpO1xuICAgICAgdGhpcy5lbENvbnRhaW5lci5pbm5lckhUTUwgPSBkYXRhO1xuICAgICAgaWYgKHRyYW5zZm9ybSkge1xuICAgICAgICB0cmFuc2Zvcm0odGhpcy5lbCk7XG4gICAgICB9XG4gICAgICB0aGlzLmVsLnN0eWxlLmxlZnQgPSB0aGlzLmNvb3JkaW5hdGVzLm1vdXNlWCArICdweCc7XG4gICAgICB0aGlzLmVsLnN0eWxlLnRvcCA9IHRoaXMuY29vcmRpbmF0ZXMubW91c2VZICsgJ3B4JztcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQodGhpcy5lbCk7XG4gICAgICBpZiAodGhpcy5jb29yZGluYXRlcy5tb3VzZVggKyB0aGlzLmVsLm9mZnNldFdpZHRoID4gd2luZG93LmlubmVyV2lkdGgpIHtcbiAgICAgICAgdGhpcy5lbC5zdHlsZS5sZWZ0ID0gdGhpcy5jb29yZGluYXRlcy5tb3VzZVggLSB0aGlzLmVsLm9mZnNldFdpZHRoICsgJ3B4JztcbiAgICAgIH1cbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdjaGVja01lbW9yaXplJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gY2hlY2tNZW1vcml6ZSgpIHtcbiAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHsgbWVtb3JpemU6IGZhbHNlLCBhdXRoX3Rva2VuOiBudWxsIH0sIGZ1bmN0aW9uIChzdG9yYWdlKSB7XG4gICAgICAgIGlmIChzdG9yYWdlLm1lbW9yaXplICYmIHN0b3JhZ2UuYXV0aF90b2tlbikge1xuICAgICAgICAgIHNlbGYuZWwuY2xhc3NMaXN0LmFkZCgnbWVtb3JpemUnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzZWxmLmVsLmNsYXNzTGlzdC5yZW1vdmUoJ21lbW9yaXplJyk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2tleWRvd24nLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBrZXlkb3duKGUpIHtcbiAgICAgIGlmIChlLmtleUNvZGUgPT0gY3RybEtleSB8fCBlLmtleUNvZGUgPT0gY21kS2V5KSB7XG4gICAgICAgIGN0cmxEb3duID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChjdHJsRG93biAmJiAoZS5rZXlDb2RlID09IGN0cmxLZXkgfHwgZS5rZXlDb2RlID09IGNLZXkgfHwgZS5rZXlDb2RlID09IGNtZEtleSkpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmRlc3Ryb3koZSk7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAna2V5dXAnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBrZXl1cChlKSB7XG4gICAgICBpZiAoZS5rZXlDb2RlID09IGN0cmxLZXkpIHtcbiAgICAgICAgY3RybERvd24gPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdkZXN0cm95JyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZGVzdHJveShlKSB7XG4gICAgICBpZiAodGhpcy5lbCAmJiB0aGlzLmVsLnBhcmVudE5vZGUgPT0gZG9jdW1lbnQuYm9keSkge1xuICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKHRoaXMuZWwpO1xuICAgICAgICB0aGlzLmVsID0gbnVsbDtcbiAgICAgICAgdGhpcy5jbGlja1RhcmdldCA9IG51bGw7IC8vIHJlc2V0IGNsaWNrIHRhcmdldFxuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3NldENvb3JkaW5hdGVzJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc2V0Q29vcmRpbmF0ZXMoY29vcmRpbmF0ZXMpIHtcbiAgICAgIHRoaXMuY29vcmRpbmF0ZXMgPSBjb29yZGluYXRlcztcbiAgICB9XG4gIH1dKTtcblxuICByZXR1cm4gVG9vbHRpcDtcbn0pKCk7XG5cbm1vZHVsZS5leHBvcnRzID0gVG9vbHRpcDtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXRvb2x0aXAuanMubWFwXG4iLCIndXNlIHN0cmljdCc7XG5cbnZhciBfY3JlYXRlQ2xhc3MgPSAoZnVuY3Rpb24gKCkgeyBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0aWVzKHRhcmdldCwgcHJvcHMpIHsgZm9yICh2YXIgaSA9IDA7IGkgPCBwcm9wcy5sZW5ndGg7IGkrKykgeyB2YXIgZGVzY3JpcHRvciA9IHByb3BzW2ldOyBkZXNjcmlwdG9yLmVudW1lcmFibGUgPSBkZXNjcmlwdG9yLmVudW1lcmFibGUgfHwgZmFsc2U7IGRlc2NyaXB0b3IuY29uZmlndXJhYmxlID0gdHJ1ZTsgaWYgKCd2YWx1ZScgaW4gZGVzY3JpcHRvcikgZGVzY3JpcHRvci53cml0YWJsZSA9IHRydWU7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGRlc2NyaXB0b3Iua2V5LCBkZXNjcmlwdG9yKTsgfSB9IHJldHVybiBmdW5jdGlvbiAoQ29uc3RydWN0b3IsIHByb3RvUHJvcHMsIHN0YXRpY1Byb3BzKSB7IGlmIChwcm90b1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLnByb3RvdHlwZSwgcHJvdG9Qcm9wcyk7IGlmIChzdGF0aWNQcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvciwgc3RhdGljUHJvcHMpOyByZXR1cm4gQ29uc3RydWN0b3I7IH07IH0pKCk7XG5cbmZ1bmN0aW9uIF9jbGFzc0NhbGxDaGVjayhpbnN0YW5jZSwgQ29uc3RydWN0b3IpIHsgaWYgKCEoaW5zdGFuY2UgaW5zdGFuY2VvZiBDb25zdHJ1Y3RvcikpIHsgdGhyb3cgbmV3IFR5cGVFcnJvcignQ2Fubm90IGNhbGwgYSBjbGFzcyBhcyBhIGZ1bmN0aW9uJyk7IH0gfVxuXG52YXIgVG9vbHRpcCA9IHJlcXVpcmUoJy4vdG9vbHRpcC5qcycpO1xudmFyIFRFWFRCT1hfVEFHUyA9IFsnaW5wdXQnLCAndGV4dGFyZWEnXTtcblxudmFyIE1haW4gPSAoZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBNYWluKCkge1xuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBNYWluKTtcblxuICAgIHRoaXMuYWRkRXZlbnRMaXN0ZW5lcnMoKTtcbiAgICB0aGlzLmNvb3JkaW5hdGVzID0geyBtb3VzZVg6IDAsIG1vdXNlWTogMCB9O1xuICAgIHRoaXMudG9vbHRpcCA9IG5ldyBUb29sdGlwKHRoaXMuY29vcmRpbmF0ZXMpO1xuICAgIGNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcih0aGlzLnJlbmRlclJlc3VsdC5iaW5kKHRoaXMpKTtcbiAgfVxuXG4gIF9jcmVhdGVDbGFzcyhNYWluLCBbe1xuICAgIGtleTogJ2FkZEV2ZW50TGlzdGVuZXJzJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gYWRkRXZlbnRMaXN0ZW5lcnMoKSB7XG4gICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzLm1vdXNlRG93bkV2ZW50KGUpO1xuICAgICAgfSk7XG4gICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gX3RoaXMubW91c2VEb3duRXZlbnQoZSk7XG4gICAgICB9KTtcbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtb3VzZXVwJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzLm1vdXNlVXBFdmVudChlKTtcbiAgICAgIH0pO1xuICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY29udGV4dG1lbnUnLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gX3RoaXMuc2F2ZU1vdXNlUG9zaXRpb24oZSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdyZW5kZXJSZXN1bHQnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiByZW5kZXJSZXN1bHQobXNnKSB7XG4gICAgICBpZiAobXNnLmFjdGlvbiA9PSAnb3Blbl90b29sdGlwJyB8fCBtc2cuYWN0aW9uID09ICdzaW1pbGFyX3dvcmRzJykge1xuICAgICAgICAvL2Rvbid0IHNob3cgYW5ub3lpbmcgdG9vbHRpcCB3aGVuIHR5cGluZ1xuICAgICAgICBpZiAoIW1zZy5zdWNjZXNzICYmIHRoaXMudG9vbHRpcC5jbGlja1RhcmdldCA9PSAndGV4dGJveCcpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH0gZWxzZSBpZiAobXNnLmFjdGlvbiA9PSAnc2ltaWxhcl93b3JkcycpIHtcbiAgICAgICAgICB0aGlzLnRvb2x0aXAucmVuZGVyKG1zZy5kYXRhLCB0aGlzLmF0dGFjaFNpbWlsYXJXb3Jkc0hhbmRsZXJzLmJpbmQodGhpcykpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMudG9vbHRpcC5yZW5kZXIobXNnLmRhdGEpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAncmVxdWVzdFNlYXJjaCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJlcXVlc3RTZWFyY2goc2VsZWN0aW9uKSB7XG4gICAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7XG4gICAgICAgIG1ldGhvZDogXCJyZXF1ZXN0X3NlYXJjaFwiLFxuICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgc2VsZWN0aW9uVGV4dDogc2VsZWN0aW9uXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3NhdmVNb3VzZVBvc2l0aW9uJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc2F2ZU1vdXNlUG9zaXRpb24oZSkge1xuICAgICAgdGhpcy5jb29yZGluYXRlcy5tb3VzZVggPSBlLnBhZ2VYICsgNTtcbiAgICAgIHRoaXMuY29vcmRpbmF0ZXMubW91c2VZID0gZS5wYWdlWSArIDEwO1xuICAgICAgdGhpcy50b29sdGlwLnNldENvb3JkaW5hdGVzKHRoaXMuY29vcmRpbmF0ZXMpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ21vdXNlRG93bkV2ZW50JyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gbW91c2VEb3duRXZlbnQoZSkge1xuICAgICAgdmFyIHRhZyA9IGUudGFyZ2V0LnRhZ05hbWUudG9Mb3dlckNhc2UoKTtcbiAgICAgIGlmIChURVhUQk9YX1RBR1MuaW5kZXhPZih0YWcpICE9IC0xKSB7XG4gICAgICAgIHRoaXMudG9vbHRpcC5jbGlja1RhcmdldCA9ICd0ZXh0Ym94JztcbiAgICAgIH1cbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdtb3VzZVVwRXZlbnQnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtb3VzZVVwRXZlbnQoZSkge1xuICAgICAgLy8gZml4IGZvciBhY2NpZGVudGFsIHRvb2x0aXAgYXBwZWFyYW5jZSB3aGVuIGNsaWNrZWQgb24gdGV4dFxuICAgICAgc2V0VGltZW91dCh0aGlzLmNsaWNrSGFuZGxlci5iaW5kKHRoaXMsIGUpLCAxMCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdjbGlja0hhbmRsZXInLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjbGlja0hhbmRsZXIoZSkge1xuICAgICAgdGhpcy5zYXZlTW91c2VQb3NpdGlvbihlKTtcbiAgICAgIHZhciBzZWxlY3Rpb24gPSB0aGlzLmdldFNlbGVjdGlvbigpO1xuICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgaWYgKHNlbGVjdGlvbi5sZW5ndGggPiAwKSB7XG4gICAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHsgZmFzdDogdHJ1ZSB9LCBmdW5jdGlvbiAoaXRlbXMpIHtcbiAgICAgICAgICBpZiAoaXRlbXMuZmFzdCkge1xuICAgICAgICAgICAgc2VsZi5yZXF1ZXN0U2VhcmNoKHNlbGVjdGlvbik7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdnZXRTZWxlY3Rpb24nLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBnZXRTZWxlY3Rpb24oZSkge1xuICAgICAgdmFyIHR4dCA9IHdpbmRvdy5nZXRTZWxlY3Rpb24oKS50b1N0cmluZygpO1xuICAgICAgdmFyIHNwYW4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdTUEFOJyk7XG4gICAgICBzcGFuLmlubmVySFRNTCA9IHR4dDtcbiAgICAgIHZhciBzZWxlY3Rpb24gPSBzcGFuLnRleHRDb250ZW50LnRyaW0oKTtcbiAgICAgIHJldHVybiBzZWxlY3Rpb247XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnYXR0YWNoU2ltaWxhcldvcmRzSGFuZGxlcnMnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBhdHRhY2hTaW1pbGFyV29yZHNIYW5kbGVycyhmcmFnbWVudCkge1xuICAgICAgdmFyIF90aGlzMiA9IHRoaXM7XG5cbiAgICAgIHZhciBfaXRlcmF0b3JOb3JtYWxDb21wbGV0aW9uID0gdHJ1ZTtcbiAgICAgIHZhciBfZGlkSXRlcmF0b3JFcnJvciA9IGZhbHNlO1xuICAgICAgdmFyIF9pdGVyYXRvckVycm9yID0gdW5kZWZpbmVkO1xuXG4gICAgICB0cnkge1xuICAgICAgICB2YXIgX2xvb3AgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdmFyIGxpbmsgPSBfc3RlcC52YWx1ZTtcblxuICAgICAgICAgIC8vIHNhbml0aXplXG4gICAgICAgICAgbGluay5yZW1vdmVBdHRyaWJ1dGUoJ29uY2xpY2snKTtcbiAgICAgICAgICBsaW5rLm9uY2xpY2sgPSBudWxsO1xuICAgICAgICAgIHZhciBjbG9uZSA9IGxpbmsuY2xvbmVOb2RlKHRydWUpO1xuICAgICAgICAgIGxpbmsucGFyZW50Tm9kZS5yZXBsYWNlQ2hpbGQoY2xvbmUsIGxpbmspO1xuICAgICAgICAgIHZhciB3b3JkID0gY2xvbmUudGV4dENvbnRlbnQ7XG4gICAgICAgICAgLy8gUHJldmVudCBsaW5rIGZyb20gYmVpbmcgZm9sbG93ZWQuXG4gICAgICAgICAgY2xvbmUuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgLy8gRG9uJ3QgbGV0IEBtb3VzZVVwRXZlbnQgZmlyZSBhZ2FpbiB3aXRoIHRoZSB3cm9uZyB3b3JkLlxuICAgICAgICAgIHNlbGYgPSBfdGhpczI7XG5cbiAgICAgICAgICBjbG9uZS5hZGRFdmVudExpc3RlbmVyKCdtb3VzZXVwJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgICAgICBzZWxmLnJlcXVlc3RTZWFyY2god29yZCk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgZm9yICh2YXIgX2l0ZXJhdG9yID0gQXJyYXkuZnJvbShmcmFnbWVudC5xdWVyeVNlbGVjdG9yQWxsKCdhJykpW1N5bWJvbC5pdGVyYXRvcl0oKSwgX3N0ZXA7ICEoX2l0ZXJhdG9yTm9ybWFsQ29tcGxldGlvbiA9IChfc3RlcCA9IF9pdGVyYXRvci5uZXh0KCkpLmRvbmUpOyBfaXRlcmF0b3JOb3JtYWxDb21wbGV0aW9uID0gdHJ1ZSkge1xuICAgICAgICAgIHZhciBzZWxmO1xuXG4gICAgICAgICAgX2xvb3AoKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIF9kaWRJdGVyYXRvckVycm9yID0gdHJ1ZTtcbiAgICAgICAgX2l0ZXJhdG9yRXJyb3IgPSBlcnI7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGlmICghX2l0ZXJhdG9yTm9ybWFsQ29tcGxldGlvbiAmJiBfaXRlcmF0b3JbJ3JldHVybiddKSB7XG4gICAgICAgICAgICBfaXRlcmF0b3JbJ3JldHVybiddKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgIGlmIChfZGlkSXRlcmF0b3JFcnJvcikge1xuICAgICAgICAgICAgdGhyb3cgX2l0ZXJhdG9yRXJyb3I7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfV0pO1xuXG4gIHJldHVybiBNYWluO1xufSkoKTtcblxubW9kdWxlLmV4cG9ydHMgPSBNYWluO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dmlldy5qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuXG5BcnJheS5mcm9tIHx8ICEoZnVuY3Rpb24gKCkge1xuICBcInVzZSBzdHJpY3RcIjt2YXIgciA9IChmdW5jdGlvbiAoKSB7XG4gICAgdHJ5IHtcbiAgICAgIHZhciByID0ge30sXG4gICAgICAgICAgZSA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSxcbiAgICAgICAgICB0ID0gZShyLCByLCByKSAmJiBlO1xuICAgIH0gY2F0Y2ggKG4pIHt9cmV0dXJuIHQgfHwgZnVuY3Rpb24gKHIsIGUsIHQpIHtcbiAgICAgIHJbZV0gPSB0LnZhbHVlO1xuICAgIH07XG4gIH0pKCksXG4gICAgICBlID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZyxcbiAgICAgIHQgPSBmdW5jdGlvbiB0KHIpIHtcbiAgICByZXR1cm4gXCJmdW5jdGlvblwiID09IHR5cGVvZiByIHx8IFwiW29iamVjdCBGdW5jdGlvbl1cIiA9PSBlLmNhbGwocik7XG4gIH0sXG4gICAgICBuID0gZnVuY3Rpb24gbihyKSB7XG4gICAgdmFyIGUgPSBOdW1iZXIocik7cmV0dXJuIGlzTmFOKGUpID8gMCA6IDAgIT0gZSAmJiBpc0Zpbml0ZShlKSA/IChlID4gMCA/IDEgOiAtMSkgKiBNYXRoLmZsb29yKE1hdGguYWJzKGUpKSA6IGU7XG4gIH0sXG4gICAgICBhID0gTWF0aC5wb3coMiwgNTMpIC0gMSxcbiAgICAgIG8gPSBmdW5jdGlvbiBvKHIpIHtcbiAgICB2YXIgZSA9IG4ocik7cmV0dXJuIE1hdGgubWluKE1hdGgubWF4KGUsIDApLCBhKTtcbiAgfSxcbiAgICAgIHUgPSBmdW5jdGlvbiB1KGUpIHtcbiAgICB2YXIgbiA9IHRoaXM7aWYgKG51bGwgPT0gZSkgdGhyb3cgbmV3IFR5cGVFcnJvcihcImBBcnJheS5mcm9tYCByZXF1aXJlcyBhbiBhcnJheS1saWtlIG9iamVjdCwgbm90IGBudWxsYCBvciBgdW5kZWZpbmVkYFwiKTt7XG4gICAgICB2YXIgYSxcbiAgICAgICAgICB1LFxuICAgICAgICAgIGkgPSBPYmplY3QoZSk7YXJndW1lbnRzLmxlbmd0aCA+IDE7XG4gICAgfWlmIChhcmd1bWVudHMubGVuZ3RoID4gMSkge1xuICAgICAgaWYgKChhID0gYXJndW1lbnRzWzFdLCAhdChhKSkpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJXaGVuIHByb3ZpZGVkLCB0aGUgc2Vjb25kIGFyZ3VtZW50IHRvIGBBcnJheS5mcm9tYCBtdXN0IGJlIGEgZnVuY3Rpb25cIik7YXJndW1lbnRzLmxlbmd0aCA+IDIgJiYgKHUgPSBhcmd1bWVudHNbMl0pO1xuICAgIH1mb3IgKHZhciBmLCBjLCBsID0gbyhpLmxlbmd0aCksIGggPSB0KG4pID8gT2JqZWN0KG5ldyBuKGwpKSA6IG5ldyBBcnJheShsKSwgbSA9IDA7IGwgPiBtOykgZiA9IGlbbV0sIGMgPSBhID8gXCJ1bmRlZmluZWRcIiA9PSB0eXBlb2YgdSA/IGEoZiwgbSkgOiBhLmNhbGwodSwgZiwgbSkgOiBmLCByKGgsIG0sIHsgdmFsdWU6IGMsIGNvbmZpZ3VyYWJsZTogITAsIGVudW1lcmFibGU6ICEwLCB3cml0YWJsZTogITAgfSksICsrbTtyZXR1cm4gaC5sZW5ndGggPSBsLCBoO1xuICB9O3IoQXJyYXksIFwiZnJvbVwiLCB7IHZhbHVlOiB1LCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSk7XG59KSgpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9QXJyYXkuZnJvbS5qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuXG52YXIgX2NyZWF0ZUNsYXNzID0gKGZ1bmN0aW9uICgpIHsgZnVuY3Rpb24gZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIHByb3BzKSB7IGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpKyspIHsgdmFyIGRlc2NyaXB0b3IgPSBwcm9wc1tpXTsgZGVzY3JpcHRvci5lbnVtZXJhYmxlID0gZGVzY3JpcHRvci5lbnVtZXJhYmxlIHx8IGZhbHNlOyBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSA9IHRydWU7IGlmIChcInZhbHVlXCIgaW4gZGVzY3JpcHRvcikgZGVzY3JpcHRvci53cml0YWJsZSA9IHRydWU7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGRlc2NyaXB0b3Iua2V5LCBkZXNjcmlwdG9yKTsgfSB9IHJldHVybiBmdW5jdGlvbiAoQ29uc3RydWN0b3IsIHByb3RvUHJvcHMsIHN0YXRpY1Byb3BzKSB7IGlmIChwcm90b1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLnByb3RvdHlwZSwgcHJvdG9Qcm9wcyk7IGlmIChzdGF0aWNQcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvciwgc3RhdGljUHJvcHMpOyByZXR1cm4gQ29uc3RydWN0b3I7IH07IH0pKCk7XG5cbmZ1bmN0aW9uIF9jbGFzc0NhbGxDaGVjayhpbnN0YW5jZSwgQ29uc3RydWN0b3IpIHsgaWYgKCEoaW5zdGFuY2UgaW5zdGFuY2VvZiBDb25zdHJ1Y3RvcikpIHsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvblwiKTsgfSB9XG5cbnZhciBVdGlscyA9IChmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIFV0aWxzKCkge1xuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBVdGlscyk7XG4gIH1cblxuICBfY3JlYXRlQ2xhc3MoVXRpbHMsIFt7XG4gICAga2V5OiBcInJlcXVlc3RcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gcmVxdWVzdCh0eXBlLCB1cmwsIG9wdHMpIHtcbiAgICAgIC8vIFJldHVybiBhIG5ldyBwcm9taXNlLlxuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgLy8gRG8gdGhlIHVzdWFsIFhIUiBzdHVmZlxuICAgICAgICB2YXIgcmVxID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgIHJlcS53aXRoQ3JlZGVudGlhbHMgPSB0cnVlO1xuICAgICAgICByZXEub3Blbih0eXBlLCB1cmwpO1xuICAgICAgICBpZiAodHlwZSA9PSAnUE9TVCcpIHtcbiAgICAgICAgICByZXEuc2V0UmVxdWVzdEhlYWRlcihcIkNvbnRlbnQtVHlwZVwiLCBcImFwcGxpY2F0aW9uL2pzb25cIik7XG4gICAgICAgIH1cbiAgICAgICAgcmVxLm9ubG9hZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAvLyBUaGlzIGlzIGNhbGxlZCBldmVuIG9uIDQwNCBldGNcbiAgICAgICAgICAvLyBzbyBjaGVjayB0aGUgc3RhdHVzXG4gICAgICAgICAgaWYgKHJlcS5zdGF0dXMgPT0gMjAwKSB7XG4gICAgICAgICAgICAvLyBSZXNvbHZlIHRoZSBwcm9taXNlIHdpdGggdGhlIHJlc3BvbnNlIHRleHRcbiAgICAgICAgICAgIHJlc29sdmUocmVxLnJlc3BvbnNlKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gT3RoZXJ3aXNlIHJlamVjdCB3aXRoIHRoZSBzdGF0dXMgdGV4dFxuICAgICAgICAgICAgLy8gd2hpY2ggd2lsbCBob3BlZnVsbHkgYmUgYSBtZWFuaW5nZnVsIGVycm9yXG4gICAgICAgICAgICByZWplY3QoRXJyb3IocmVxLnN0YXR1c1RleHQpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gSGFuZGxlIG5ldHdvcmsgZXJyb3JzXG4gICAgICAgIHJlcS5vbmVycm9yID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHJlamVjdChFcnJvcihcIk5ldHdvcmsgRXJyb3JcIikpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8vIFNldCBoZWFkZXJzXG4gICAgICAgIGlmIChvcHRzLmhlYWRlcnMpIHtcbiAgICAgICAgICB2YXIgX2l0ZXJhdG9yTm9ybWFsQ29tcGxldGlvbiA9IHRydWU7XG4gICAgICAgICAgdmFyIF9kaWRJdGVyYXRvckVycm9yID0gZmFsc2U7XG4gICAgICAgICAgdmFyIF9pdGVyYXRvckVycm9yID0gdW5kZWZpbmVkO1xuXG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGZvciAodmFyIF9pdGVyYXRvciA9IE9iamVjdC5rZXlzKG9wdHMuaGVhZGVycylbU3ltYm9sLml0ZXJhdG9yXSgpLCBfc3RlcDsgIShfaXRlcmF0b3JOb3JtYWxDb21wbGV0aW9uID0gKF9zdGVwID0gX2l0ZXJhdG9yLm5leHQoKSkuZG9uZSk7IF9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gPSB0cnVlKSB7XG4gICAgICAgICAgICAgIHZhciBrZXkgPSBfc3RlcC52YWx1ZTtcblxuICAgICAgICAgICAgICByZXEuc2V0UmVxdWVzdEhlYWRlcihrZXksIG9wdHMuaGVhZGVyc1trZXldKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIF9kaWRJdGVyYXRvckVycm9yID0gdHJ1ZTtcbiAgICAgICAgICAgIF9pdGVyYXRvckVycm9yID0gZXJyO1xuICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICBpZiAoIV9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gJiYgX2l0ZXJhdG9yW1wicmV0dXJuXCJdKSB7XG4gICAgICAgICAgICAgICAgX2l0ZXJhdG9yW1wicmV0dXJuXCJdKCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgIGlmIChfZGlkSXRlcmF0b3JFcnJvcikge1xuICAgICAgICAgICAgICAgIHRocm93IF9pdGVyYXRvckVycm9yO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIE1ha2UgdGhlIHJlcXVlc3RcbiAgICAgICAgcmVxLnNlbmQoSlNPTi5zdHJpbmdpZnkob3B0cy5kYXRhKSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6IFwiZ2V0XCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGdldCh1cmwpIHtcbiAgICAgIHZhciBvcHRzID0gYXJndW1lbnRzLmxlbmd0aCA8PSAxIHx8IGFyZ3VtZW50c1sxXSA9PT0gdW5kZWZpbmVkID8geyBkYXRhOiAnJyB9IDogYXJndW1lbnRzWzFdO1xuXG4gICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KCdHRVQnLCB1cmwsIG9wdHMpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogXCJwb3N0XCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHBvc3QodXJsKSB7XG4gICAgICB2YXIgb3B0cyA9IGFyZ3VtZW50cy5sZW5ndGggPD0gMSB8fCBhcmd1bWVudHNbMV0gPT09IHVuZGVmaW5lZCA/IHsgZGF0YTogJycgfSA6IGFyZ3VtZW50c1sxXTtcblxuICAgICAgcmV0dXJuIHRoaXMucmVxdWVzdCgnUE9TVCcsIHVybCwgb3B0cyk7XG4gICAgfVxuICB9XSk7XG5cbiAgcmV0dXJuIFV0aWxzO1xufSkoKTtcblxubW9kdWxlLmV4cG9ydHMgPSBuZXcgVXRpbHMoKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXV0aWxzLmpzLm1hcFxuIl19
