(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
/* global chrome */
/*
 Script embedded on each user page
 Listens messages from translation module and renders popup
 with translated text
*/
'use strict';

require('../polyfills/Array.from.js');

var View = require('./view.js');
var content = new View();
//# sourceMappingURL=content.js.map

},{"../polyfills/Array.from.js":4,"./view.js":3}],2:[function(require,module,exports){
// TODO вынести настройки подключения в settings.js
//var HOST = 'http://tran-service.com'
'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var HOST = 'http://localhost:5000';

var TOOLTIP_CLASS_PREFIX = '__mtt_translate_dialog__';
var ctrlDown = false;
var ctrlKey = 17;
var cmdKey = 91;
var cKey = 67;
var add_title = 'Добавить в персональный словарь';

var _ = require('../utils.js');

var Tooltip = (function () {
  function Tooltip(coordinates) {
    _classCallCheck(this, Tooltip);

    this.setListeners();
    this.clickTarget = null;
  }

  _createClass(Tooltip, [{
    key: 'createEl',
    value: function createEl(storage) {
      this.el = document.createElement('div');
      this.memorizeButton = this.createMemoBtn();
      this.elContainer = this.createContainer();
      this.el.appendChild(this.memorizeButton);
      this.el.appendChild(this.elContainer);
      this.el.classList.add(TOOLTIP_CLASS_PREFIX);
      this.addListeners();
    }
  }, {
    key: 'addListeners',
    value: function addListeners() {
      this.el.addEventListener('mousedown', function (e) {
        return e.stopPropagation();
      });
      this.el.addEventListener('keydown', this.onKeyDown);
      this.memorizeButton.addEventListener('click', this.memoClick);
    }
  }, {
    key: 'createMemoBtn',
    value: function createMemoBtn() {
      var t = document.createElement('template');
      var tmpl = '<a title="' + add_title + '"\n                   class="btn-floating waves-effect waves-light blue word-add">\n                  <i class="material-icons">+</i>\n                </a>';
      t.innerHTML = tmpl;
      return t.content;
    }
  }, {
    key: 'memoClick',
    value: function memoClick(e) {
      e.stopPropagation();
      e.preventDefault();
      _.post(HOST + '/api/plugin/add_word/', { data: 'blabla' });
    }
  }, {
    key: 'createContainer',
    value: function createContainer() {
      var docFragment = document.createDocumentFragment();
      var container = document.createElement('div');
      container.classList.add(TOOLTIP_CLASS_PREFIX + 'container');
      return container;
    }
  }, {
    key: 'onKeyDown',
    value: function onKeyDown(e) {
      if (ctrlDown && (e.keyCode == vKey || e.keyCode == cKey)) {
        e.stopPropagation();
        return true;
      }
    }
  }, {
    key: 'setListeners',
    value: function setListeners() {
      var _this = this;

      window.addEventListener('mousedown', function (e) {
        return _this.destroy(e);
      });
      document.addEventListener('mousedown', function (e) {
        return _this.destroy(e);
      });
      window.addEventListener('blur', function (e) {
        return _this.destroy(e);
      });
      document.addEventListener('keydown', function (e) {
        return _this.keydown(e);
      });
      document.addEventListener('keyup', function (e) {
        return _this.keyup(e);
      });
    }
  }, {
    key: 'render',
    value: function render(data) {
      var transform = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];

      if (!this.el) {
        this.createEl();
      }
      this.checkMemorize();
      this.elContainer.innerHTML = data;
      if (transform) {
        transform(this.el);
      }
      this.el.style.left = this.coordinates.mouseX + 'px';
      this.el.style.top = this.coordinates.mouseY + 'px';
      document.body.appendChild(this.el);
      if (this.coordinates.mouseX + this.el.offsetWidth > window.innerWidth) {
        this.el.style.left = this.coordinates.mouseX - this.el.offsetWidth + 'px';
      }
    }
  }, {
    key: 'checkMemorize',
    value: function checkMemorize() {
      var self = this;
      chrome.storage.sync.get({ memorize: false, auth_token: null }, function (storage) {
        if (storage.memorize && storage.auth_token) {
          self.el.classList.add('memorize');
        } else {
          self.el.classList.remove('memorize');
        }
      });
    }
  }, {
    key: 'keydown',
    value: function keydown(e) {
      if (e.keyCode == ctrlKey || e.keyCode == cmdKey) {
        ctrlDown = true;
      }
      if (ctrlDown && (e.keyCode == ctrlKey || e.keyCode == cKey || e.keyCode == cmdKey)) {
        return true;
      } else {
        this.destroy(e);
      }
    }
  }, {
    key: 'keyup',
    value: function keyup(e) {
      if (e.keyCode == ctrlKey) {
        ctrlDown = false;
      }
    }
  }, {
    key: 'destroy',
    value: function destroy(e) {
      if (this.el && this.el.parentNode == document.body) {
        document.body.removeChild(this.el);
        this.el = null;
        this.clickTarget = null; // reset click target
      }
    }
  }, {
    key: 'setCoordinates',
    value: function setCoordinates(coordinates) {
      this.coordinates = coordinates;
    }
  }]);

  return Tooltip;
})();

module.exports = Tooltip;
//# sourceMappingURL=tooltip.js.map

},{"../utils.js":5}],3:[function(require,module,exports){
'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var Tooltip = require('./tooltip.js');
var TEXTBOX_TAGS = ['input', 'textarea'];

var Main = (function () {
  function Main() {
    _classCallCheck(this, Main);

    this.addEventListeners();
    this.coordinates = { mouseX: 0, mouseY: 0 };
    this.tooltip = new Tooltip(this.coordinates);
    chrome.runtime.onMessage.addListener(this.renderResult.bind(this));
  }

  _createClass(Main, [{
    key: 'addEventListeners',
    value: function addEventListeners() {
      var _this = this;

      window.addEventListener('mousedown', function (e) {
        return _this.mouseDownEvent(e);
      });
      document.addEventListener('mousedown', function (e) {
        return _this.mouseDownEvent(e);
      });
      window.addEventListener('mouseup', function (e) {
        return _this.mouseUpEvent(e);
      });
      document.addEventListener('contextmenu', function (e) {
        return _this.saveMousePosition(e);
      });
    }
  }, {
    key: 'renderResult',
    value: function renderResult(msg) {
      if (msg.action == 'open_tooltip' || msg.action == 'similar_words') {
        //don't show annoying tooltip when typing
        if (!msg.success && this.tooltip.clickTarget == 'textbox') {
          return;
        } else if (msg.action == 'similar_words') {
          this.tooltip.render(msg.data, this.attachSimilarWordsHandlers.bind(this));
        } else {
          this.tooltip.render(msg.data);
        }
      }
    }
  }, {
    key: 'requestSearch',
    value: function requestSearch(selection) {
      chrome.runtime.sendMessage({
        method: "request_search",
        data: {
          selectionText: selection
        }
      });
    }
  }, {
    key: 'saveMousePosition',
    value: function saveMousePosition(e) {
      this.coordinates.mouseX = e.pageX + 5;
      this.coordinates.mouseY = e.pageY + 10;
      this.tooltip.setCoordinates(this.coordinates);
    }
  }, {
    key: 'mouseDownEvent',
    value: function mouseDownEvent(e) {
      var tag = e.target.tagName.toLowerCase();
      if (TEXTBOX_TAGS.indexOf(tag) != -1) {
        this.tooltip.clickTarget = 'textbox';
      }
    }
  }, {
    key: 'mouseUpEvent',
    value: function mouseUpEvent(e) {
      // fix for accidental tooltip appearance when clicked on text
      setTimeout(this.clickHandler.bind(this, e), 10);
      return true;
    }
  }, {
    key: 'clickHandler',
    value: function clickHandler(e) {
      this.saveMousePosition(e);
      var selection = this.getSelection();
      var self = this;
      if (selection.length > 0) {
        chrome.storage.sync.get({ fast: true }, function (items) {
          if (items.fast) {
            self.requestSearch(selection);
          }
        });
      }
    }
  }, {
    key: 'getSelection',
    value: function getSelection(e) {
      var txt = window.getSelection().toString();
      var span = document.createElement('SPAN');
      span.innerHTML = txt;
      var selection = span.textContent.trim();
      return selection;
    }
  }, {
    key: 'attachSimilarWordsHandlers',
    value: function attachSimilarWordsHandlers(fragment) {
      var _this2 = this;

      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        var _loop = function () {
          var link = _step.value;

          // sanitize
          link.removeAttribute('onclick');
          link.onclick = null;
          var clone = link.cloneNode(true);
          link.parentNode.replaceChild(clone, link);
          var word = clone.textContent;
          // Prevent link from being followed.
          clone.addEventListener('click', function (e) {
            e.stopPropagation();e.preventDefault();
          });
          // Don't let @mouseUpEvent fire again with the wrong word.
          self = _this2;

          clone.addEventListener('mouseup', function (e) {
            e.stopPropagation();
            self.requestSearch(word);
          });
        };

        for (var _iterator = Array.from(fragment.querySelectorAll('a'))[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var self;

          _loop();
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator['return']) {
            _iterator['return']();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return true;
    }
  }]);

  return Main;
})();

module.exports = Main;
//# sourceMappingURL=view.js.map

},{"./tooltip.js":2}],4:[function(require,module,exports){
"use strict";

Array.from || !(function () {
  "use strict";var r = (function () {
    try {
      var r = {},
          e = Object.defineProperty,
          t = e(r, r, r) && e;
    } catch (n) {}return t || function (r, e, t) {
      r[e] = t.value;
    };
  })(),
      e = Object.prototype.toString,
      t = function t(r) {
    return "function" == typeof r || "[object Function]" == e.call(r);
  },
      n = function n(r) {
    var e = Number(r);return isNaN(e) ? 0 : 0 != e && isFinite(e) ? (e > 0 ? 1 : -1) * Math.floor(Math.abs(e)) : e;
  },
      a = Math.pow(2, 53) - 1,
      o = function o(r) {
    var e = n(r);return Math.min(Math.max(e, 0), a);
  },
      u = function u(e) {
    var n = this;if (null == e) throw new TypeError("`Array.from` requires an array-like object, not `null` or `undefined`");{
      var a,
          u,
          i = Object(e);arguments.length > 1;
    }if (arguments.length > 1) {
      if ((a = arguments[1], !t(a))) throw new TypeError("When provided, the second argument to `Array.from` must be a function");arguments.length > 2 && (u = arguments[2]);
    }for (var f, c, l = o(i.length), h = t(n) ? Object(new n(l)) : new Array(l), m = 0; l > m;) f = i[m], c = a ? "undefined" == typeof u ? a(f, m) : a.call(u, f, m) : f, r(h, m, { value: c, configurable: !0, enumerable: !0, writable: !0 }), ++m;return h.length = l, h;
  };r(Array, "from", { value: u, configurable: !0, writable: !0 });
})();
//# sourceMappingURL=Array.from.js.map

},{}],5:[function(require,module,exports){
"use strict";

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Utils = (function () {
  function Utils() {
    _classCallCheck(this, Utils);
  }

  _createClass(Utils, [{
    key: "request",
    value: function request(type, url, opts) {
      // Return a new promise.
      return new Promise(function (resolve, reject) {
        // Do the usual XHR stuff
        var req = new XMLHttpRequest();
        req.withCredentials = true;
        req.open(type, url);
        if (type == 'POST') {
          req.setRequestHeader("Content-Type", "application/json");
        }
        req.onload = function () {
          // This is called even on 404 etc
          // so check the status
          if (req.status == 200) {
            // Resolve the promise with the response text
            resolve(req.response);
          } else {
            // Otherwise reject with the status text
            // which will hopefully be a meaningful error
            reject(Error(req.statusText));
          }
        };

        // Handle network errors
        req.onerror = function () {
          reject(Error("Network Error"));
        };

        // Set headers
        if (opts.headers) {
          var _iteratorNormalCompletion = true;
          var _didIteratorError = false;
          var _iteratorError = undefined;

          try {
            for (var _iterator = Object.keys(opts.headers)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              var key = _step.value;

              req.setRequestHeader(key, opts.headers[key]);
            }
          } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion && _iterator["return"]) {
                _iterator["return"]();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
          }
        }
        // Make the request
        req.send(JSON.stringify(opts.data));
      });
    }
  }, {
    key: "get",
    value: function get(url) {
      var opts = arguments.length <= 1 || arguments[1] === undefined ? { data: '' } : arguments[1];

      return this.request('GET', url, opts);
    }
  }, {
    key: "post",
    value: function post(url) {
      var opts = arguments.length <= 1 || arguments[1] === undefined ? { data: '' } : arguments[1];

      return this.request('POST', url, opts);
    }
  }]);

  return Utils;
})();

module.exports = new Utils();
//# sourceMappingURL=utils.js.map

},{}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxkZXZcXHRyYW5cXG5vZGVfbW9kdWxlc1xcYnJvd3Nlci1wYWNrXFxfcHJlbHVkZS5qcyIsIkM6L2Rldi90cmFuL2pzL2VzNS9jb250ZW50X3NjcmlwdC9jb250ZW50LmpzIiwiQzovZGV2L3RyYW4vanMvZXM1L2NvbnRlbnRfc2NyaXB0L3Rvb2x0aXAuanMiLCJDOi9kZXYvdHJhbi9qcy9lczUvY29udGVudF9zY3JpcHQvdmlldy5qcyIsIkM6L2Rldi90cmFuL2pzL2VzNS9wb2x5ZmlsbHMvQXJyYXkuZnJvbS5qcyIsIkM6L2Rldi90cmFuL2pzL2VzNS91dGlscy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDYkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDM0tBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN2S0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNsQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKX12YXIgZj1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwoZi5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxmLGYuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiLyogZ2xvYmFsIGNocm9tZSAqL1xuLypcbiBTY3JpcHQgZW1iZWRkZWQgb24gZWFjaCB1c2VyIHBhZ2VcbiBMaXN0ZW5zIG1lc3NhZ2VzIGZyb20gdHJhbnNsYXRpb24gbW9kdWxlIGFuZCByZW5kZXJzIHBvcHVwXG4gd2l0aCB0cmFuc2xhdGVkIHRleHRcbiovXG4ndXNlIHN0cmljdCc7XG5cbnJlcXVpcmUoJy4uL3BvbHlmaWxscy9BcnJheS5mcm9tLmpzJyk7XG5cbnZhciBWaWV3ID0gcmVxdWlyZSgnLi92aWV3LmpzJyk7XG52YXIgY29udGVudCA9IG5ldyBWaWV3KCk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb250ZW50LmpzLm1hcFxuIiwiLy8gVE9ETyDQstGL0L3QtdGB0YLQuCDQvdCw0YHRgtGA0L7QudC60Lgg0L/QvtC00LrQu9GO0YfQtdC90LjRjyDQsiBzZXR0aW5ncy5qc1xuLy92YXIgSE9TVCA9ICdodHRwOi8vdHJhbi1zZXJ2aWNlLmNvbSdcbid1c2Ugc3RyaWN0JztcblxudmFyIF9jcmVhdGVDbGFzcyA9IChmdW5jdGlvbiAoKSB7IGZ1bmN0aW9uIGRlZmluZVByb3BlcnRpZXModGFyZ2V0LCBwcm9wcykgeyBmb3IgKHZhciBpID0gMDsgaSA8IHByb3BzLmxlbmd0aDsgaSsrKSB7IHZhciBkZXNjcmlwdG9yID0gcHJvcHNbaV07IGRlc2NyaXB0b3IuZW51bWVyYWJsZSA9IGRlc2NyaXB0b3IuZW51bWVyYWJsZSB8fCBmYWxzZTsgZGVzY3JpcHRvci5jb25maWd1cmFibGUgPSB0cnVlOyBpZiAoJ3ZhbHVlJyBpbiBkZXNjcmlwdG9yKSBkZXNjcmlwdG9yLndyaXRhYmxlID0gdHJ1ZTsgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgZGVzY3JpcHRvci5rZXksIGRlc2NyaXB0b3IpOyB9IH0gcmV0dXJuIGZ1bmN0aW9uIChDb25zdHJ1Y3RvciwgcHJvdG9Qcm9wcywgc3RhdGljUHJvcHMpIHsgaWYgKHByb3RvUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IucHJvdG90eXBlLCBwcm90b1Byb3BzKTsgaWYgKHN0YXRpY1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLCBzdGF0aWNQcm9wcyk7IHJldHVybiBDb25zdHJ1Y3RvcjsgfTsgfSkoKTtcblxuZnVuY3Rpb24gX2NsYXNzQ2FsbENoZWNrKGluc3RhbmNlLCBDb25zdHJ1Y3RvcikgeyBpZiAoIShpbnN0YW5jZSBpbnN0YW5jZW9mIENvbnN0cnVjdG9yKSkgeyB0aHJvdyBuZXcgVHlwZUVycm9yKCdDYW5ub3QgY2FsbCBhIGNsYXNzIGFzIGEgZnVuY3Rpb24nKTsgfSB9XG5cbnZhciBIT1NUID0gJ2h0dHA6Ly9sb2NhbGhvc3Q6NTAwMCc7XG5cbnZhciBUT09MVElQX0NMQVNTX1BSRUZJWCA9ICdfX210dF90cmFuc2xhdGVfZGlhbG9nX18nO1xudmFyIGN0cmxEb3duID0gZmFsc2U7XG52YXIgY3RybEtleSA9IDE3O1xudmFyIGNtZEtleSA9IDkxO1xudmFyIGNLZXkgPSA2NztcbnZhciBhZGRfdGl0bGUgPSAn0JTQvtCx0LDQstC40YLRjCDQsiDQv9C10YDRgdC+0L3QsNC70YzQvdGL0Lkg0YHQu9C+0LLQsNGA0YwnO1xuXG52YXIgXyA9IHJlcXVpcmUoJy4uL3V0aWxzLmpzJyk7XG5cbnZhciBUb29sdGlwID0gKGZ1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gVG9vbHRpcChjb29yZGluYXRlcykge1xuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBUb29sdGlwKTtcblxuICAgIHRoaXMuc2V0TGlzdGVuZXJzKCk7XG4gICAgdGhpcy5jbGlja1RhcmdldCA9IG51bGw7XG4gIH1cblxuICBfY3JlYXRlQ2xhc3MoVG9vbHRpcCwgW3tcbiAgICBrZXk6ICdjcmVhdGVFbCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNyZWF0ZUVsKHN0b3JhZ2UpIHtcbiAgICAgIHRoaXMuZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIHRoaXMubWVtb3JpemVCdXR0b24gPSB0aGlzLmNyZWF0ZU1lbW9CdG4oKTtcbiAgICAgIHRoaXMuZWxDb250YWluZXIgPSB0aGlzLmNyZWF0ZUNvbnRhaW5lcigpO1xuICAgICAgdGhpcy5lbC5hcHBlbmRDaGlsZCh0aGlzLm1lbW9yaXplQnV0dG9uKTtcbiAgICAgIHRoaXMuZWwuYXBwZW5kQ2hpbGQodGhpcy5lbENvbnRhaW5lcik7XG4gICAgICB0aGlzLmVsLmNsYXNzTGlzdC5hZGQoVE9PTFRJUF9DTEFTU19QUkVGSVgpO1xuICAgICAgdGhpcy5hZGRMaXN0ZW5lcnMoKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdhZGRMaXN0ZW5lcnMnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBhZGRMaXN0ZW5lcnMoKSB7XG4gICAgICB0aGlzLmVsLmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlZG93bicsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHJldHVybiBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgfSk7XG4gICAgICB0aGlzLmVsLmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCB0aGlzLm9uS2V5RG93bik7XG4gICAgICB0aGlzLm1lbW9yaXplQnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdGhpcy5tZW1vQ2xpY2spO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2NyZWF0ZU1lbW9CdG4nLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjcmVhdGVNZW1vQnRuKCkge1xuICAgICAgdmFyIHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCd0ZW1wbGF0ZScpO1xuICAgICAgdmFyIHRtcGwgPSAnPGEgdGl0bGU9XCInICsgYWRkX3RpdGxlICsgJ1wiXFxuICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiYnRuLWZsb2F0aW5nIHdhdmVzLWVmZmVjdCB3YXZlcy1saWdodCBibHVlIHdvcmQtYWRkXCI+XFxuICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJtYXRlcmlhbC1pY29uc1wiPis8L2k+XFxuICAgICAgICAgICAgICAgIDwvYT4nO1xuICAgICAgdC5pbm5lckhUTUwgPSB0bXBsO1xuICAgICAgcmV0dXJuIHQuY29udGVudDtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdtZW1vQ2xpY2snLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtZW1vQ2xpY2soZSkge1xuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIF8ucG9zdChIT1NUICsgJy9hcGkvcGx1Z2luL2FkZF93b3JkLycsIHsgZGF0YTogJ2JsYWJsYScgfSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnY3JlYXRlQ29udGFpbmVyJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gY3JlYXRlQ29udGFpbmVyKCkge1xuICAgICAgdmFyIGRvY0ZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpO1xuICAgICAgdmFyIGNvbnRhaW5lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgY29udGFpbmVyLmNsYXNzTGlzdC5hZGQoVE9PTFRJUF9DTEFTU19QUkVGSVggKyAnY29udGFpbmVyJyk7XG4gICAgICByZXR1cm4gY29udGFpbmVyO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ29uS2V5RG93bicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG9uS2V5RG93bihlKSB7XG4gICAgICBpZiAoY3RybERvd24gJiYgKGUua2V5Q29kZSA9PSB2S2V5IHx8IGUua2V5Q29kZSA9PSBjS2V5KSkge1xuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdzZXRMaXN0ZW5lcnMnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzZXRMaXN0ZW5lcnMoKSB7XG4gICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzLmRlc3Ryb3koZSk7XG4gICAgICB9KTtcbiAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlZG93bicsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHJldHVybiBfdGhpcy5kZXN0cm95KGUpO1xuICAgICAgfSk7XG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignYmx1cicsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHJldHVybiBfdGhpcy5kZXN0cm95KGUpO1xuICAgICAgfSk7XG4gICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzLmtleWRvd24oZSk7XG4gICAgICB9KTtcbiAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2tleXVwJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzLmtleXVwKGUpO1xuICAgICAgfSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAncmVuZGVyJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gcmVuZGVyKGRhdGEpIHtcbiAgICAgIHZhciB0cmFuc2Zvcm0gPSBhcmd1bWVudHMubGVuZ3RoIDw9IDEgfHwgYXJndW1lbnRzWzFdID09PSB1bmRlZmluZWQgPyBudWxsIDogYXJndW1lbnRzWzFdO1xuXG4gICAgICBpZiAoIXRoaXMuZWwpIHtcbiAgICAgICAgdGhpcy5jcmVhdGVFbCgpO1xuICAgICAgfVxuICAgICAgdGhpcy5jaGVja01lbW9yaXplKCk7XG4gICAgICB0aGlzLmVsQ29udGFpbmVyLmlubmVySFRNTCA9IGRhdGE7XG4gICAgICBpZiAodHJhbnNmb3JtKSB7XG4gICAgICAgIHRyYW5zZm9ybSh0aGlzLmVsKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuZWwuc3R5bGUubGVmdCA9IHRoaXMuY29vcmRpbmF0ZXMubW91c2VYICsgJ3B4JztcbiAgICAgIHRoaXMuZWwuc3R5bGUudG9wID0gdGhpcy5jb29yZGluYXRlcy5tb3VzZVkgKyAncHgnO1xuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCh0aGlzLmVsKTtcbiAgICAgIGlmICh0aGlzLmNvb3JkaW5hdGVzLm1vdXNlWCArIHRoaXMuZWwub2Zmc2V0V2lkdGggPiB3aW5kb3cuaW5uZXJXaWR0aCkge1xuICAgICAgICB0aGlzLmVsLnN0eWxlLmxlZnQgPSB0aGlzLmNvb3JkaW5hdGVzLm1vdXNlWCAtIHRoaXMuZWwub2Zmc2V0V2lkdGggKyAncHgnO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2NoZWNrTWVtb3JpemUnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjaGVja01lbW9yaXplKCkge1xuICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoeyBtZW1vcml6ZTogZmFsc2UsIGF1dGhfdG9rZW46IG51bGwgfSwgZnVuY3Rpb24gKHN0b3JhZ2UpIHtcbiAgICAgICAgaWYgKHN0b3JhZ2UubWVtb3JpemUgJiYgc3RvcmFnZS5hdXRoX3Rva2VuKSB7XG4gICAgICAgICAgc2VsZi5lbC5jbGFzc0xpc3QuYWRkKCdtZW1vcml6ZScpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNlbGYuZWwuY2xhc3NMaXN0LnJlbW92ZSgnbWVtb3JpemUnKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAna2V5ZG93bicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGtleWRvd24oZSkge1xuICAgICAgaWYgKGUua2V5Q29kZSA9PSBjdHJsS2V5IHx8IGUua2V5Q29kZSA9PSBjbWRLZXkpIHtcbiAgICAgICAgY3RybERvd24gPSB0cnVlO1xuICAgICAgfVxuICAgICAgaWYgKGN0cmxEb3duICYmIChlLmtleUNvZGUgPT0gY3RybEtleSB8fCBlLmtleUNvZGUgPT0gY0tleSB8fCBlLmtleUNvZGUgPT0gY21kS2V5KSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuZGVzdHJveShlKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdrZXl1cCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGtleXVwKGUpIHtcbiAgICAgIGlmIChlLmtleUNvZGUgPT0gY3RybEtleSkge1xuICAgICAgICBjdHJsRG93biA9IGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2Rlc3Ryb3knLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBkZXN0cm95KGUpIHtcbiAgICAgIGlmICh0aGlzLmVsICYmIHRoaXMuZWwucGFyZW50Tm9kZSA9PSBkb2N1bWVudC5ib2R5KSB7XG4gICAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQodGhpcy5lbCk7XG4gICAgICAgIHRoaXMuZWwgPSBudWxsO1xuICAgICAgICB0aGlzLmNsaWNrVGFyZ2V0ID0gbnVsbDsgLy8gcmVzZXQgY2xpY2sgdGFyZ2V0XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnc2V0Q29vcmRpbmF0ZXMnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzZXRDb29yZGluYXRlcyhjb29yZGluYXRlcykge1xuICAgICAgdGhpcy5jb29yZGluYXRlcyA9IGNvb3JkaW5hdGVzO1xuICAgIH1cbiAgfV0pO1xuXG4gIHJldHVybiBUb29sdGlwO1xufSkoKTtcblxubW9kdWxlLmV4cG9ydHMgPSBUb29sdGlwO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dG9vbHRpcC5qcy5tYXBcbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIF9jcmVhdGVDbGFzcyA9IChmdW5jdGlvbiAoKSB7IGZ1bmN0aW9uIGRlZmluZVByb3BlcnRpZXModGFyZ2V0LCBwcm9wcykgeyBmb3IgKHZhciBpID0gMDsgaSA8IHByb3BzLmxlbmd0aDsgaSsrKSB7IHZhciBkZXNjcmlwdG9yID0gcHJvcHNbaV07IGRlc2NyaXB0b3IuZW51bWVyYWJsZSA9IGRlc2NyaXB0b3IuZW51bWVyYWJsZSB8fCBmYWxzZTsgZGVzY3JpcHRvci5jb25maWd1cmFibGUgPSB0cnVlOyBpZiAoJ3ZhbHVlJyBpbiBkZXNjcmlwdG9yKSBkZXNjcmlwdG9yLndyaXRhYmxlID0gdHJ1ZTsgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgZGVzY3JpcHRvci5rZXksIGRlc2NyaXB0b3IpOyB9IH0gcmV0dXJuIGZ1bmN0aW9uIChDb25zdHJ1Y3RvciwgcHJvdG9Qcm9wcywgc3RhdGljUHJvcHMpIHsgaWYgKHByb3RvUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IucHJvdG90eXBlLCBwcm90b1Byb3BzKTsgaWYgKHN0YXRpY1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLCBzdGF0aWNQcm9wcyk7IHJldHVybiBDb25zdHJ1Y3RvcjsgfTsgfSkoKTtcblxuZnVuY3Rpb24gX2NsYXNzQ2FsbENoZWNrKGluc3RhbmNlLCBDb25zdHJ1Y3RvcikgeyBpZiAoIShpbnN0YW5jZSBpbnN0YW5jZW9mIENvbnN0cnVjdG9yKSkgeyB0aHJvdyBuZXcgVHlwZUVycm9yKCdDYW5ub3QgY2FsbCBhIGNsYXNzIGFzIGEgZnVuY3Rpb24nKTsgfSB9XG5cbnZhciBUb29sdGlwID0gcmVxdWlyZSgnLi90b29sdGlwLmpzJyk7XG52YXIgVEVYVEJPWF9UQUdTID0gWydpbnB1dCcsICd0ZXh0YXJlYSddO1xuXG52YXIgTWFpbiA9IChmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIE1haW4oKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIE1haW4pO1xuXG4gICAgdGhpcy5hZGRFdmVudExpc3RlbmVycygpO1xuICAgIHRoaXMuY29vcmRpbmF0ZXMgPSB7IG1vdXNlWDogMCwgbW91c2VZOiAwIH07XG4gICAgdGhpcy50b29sdGlwID0gbmV3IFRvb2x0aXAodGhpcy5jb29yZGluYXRlcyk7XG4gICAgY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKHRoaXMucmVuZGVyUmVzdWx0LmJpbmQodGhpcykpO1xuICB9XG5cbiAgX2NyZWF0ZUNsYXNzKE1haW4sIFt7XG4gICAga2V5OiAnYWRkRXZlbnRMaXN0ZW5lcnMnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBhZGRFdmVudExpc3RlbmVycygpIHtcbiAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gX3RoaXMubW91c2VEb3duRXZlbnQoZSk7XG4gICAgICB9KTtcbiAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlZG93bicsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHJldHVybiBfdGhpcy5tb3VzZURvd25FdmVudChlKTtcbiAgICAgIH0pO1xuICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNldXAnLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICByZXR1cm4gX3RoaXMubW91c2VVcEV2ZW50KGUpO1xuICAgICAgfSk7XG4gICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjb250ZXh0bWVudScsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHJldHVybiBfdGhpcy5zYXZlTW91c2VQb3NpdGlvbihlKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3JlbmRlclJlc3VsdCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJlbmRlclJlc3VsdChtc2cpIHtcbiAgICAgIGlmIChtc2cuYWN0aW9uID09ICdvcGVuX3Rvb2x0aXAnIHx8IG1zZy5hY3Rpb24gPT0gJ3NpbWlsYXJfd29yZHMnKSB7XG4gICAgICAgIC8vZG9uJ3Qgc2hvdyBhbm5veWluZyB0b29sdGlwIHdoZW4gdHlwaW5nXG4gICAgICAgIGlmICghbXNnLnN1Y2Nlc3MgJiYgdGhpcy50b29sdGlwLmNsaWNrVGFyZ2V0ID09ICd0ZXh0Ym94Jykge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSBlbHNlIGlmIChtc2cuYWN0aW9uID09ICdzaW1pbGFyX3dvcmRzJykge1xuICAgICAgICAgIHRoaXMudG9vbHRpcC5yZW5kZXIobXNnLmRhdGEsIHRoaXMuYXR0YWNoU2ltaWxhcldvcmRzSGFuZGxlcnMuYmluZCh0aGlzKSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy50b29sdGlwLnJlbmRlcihtc2cuZGF0YSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdyZXF1ZXN0U2VhcmNoJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gcmVxdWVzdFNlYXJjaChzZWxlY3Rpb24pIHtcbiAgICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHtcbiAgICAgICAgbWV0aG9kOiBcInJlcXVlc3Rfc2VhcmNoXCIsXG4gICAgICAgIGRhdGE6IHtcbiAgICAgICAgICBzZWxlY3Rpb25UZXh0OiBzZWxlY3Rpb25cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnc2F2ZU1vdXNlUG9zaXRpb24nLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzYXZlTW91c2VQb3NpdGlvbihlKSB7XG4gICAgICB0aGlzLmNvb3JkaW5hdGVzLm1vdXNlWCA9IGUucGFnZVggKyA1O1xuICAgICAgdGhpcy5jb29yZGluYXRlcy5tb3VzZVkgPSBlLnBhZ2VZICsgMTA7XG4gICAgICB0aGlzLnRvb2x0aXAuc2V0Q29vcmRpbmF0ZXModGhpcy5jb29yZGluYXRlcyk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnbW91c2VEb3duRXZlbnQnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtb3VzZURvd25FdmVudChlKSB7XG4gICAgICB2YXIgdGFnID0gZS50YXJnZXQudGFnTmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgICAgaWYgKFRFWFRCT1hfVEFHUy5pbmRleE9mKHRhZykgIT0gLTEpIHtcbiAgICAgICAgdGhpcy50b29sdGlwLmNsaWNrVGFyZ2V0ID0gJ3RleHRib3gnO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ21vdXNlVXBFdmVudCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG1vdXNlVXBFdmVudChlKSB7XG4gICAgICAvLyBmaXggZm9yIGFjY2lkZW50YWwgdG9vbHRpcCBhcHBlYXJhbmNlIHdoZW4gY2xpY2tlZCBvbiB0ZXh0XG4gICAgICBzZXRUaW1lb3V0KHRoaXMuY2xpY2tIYW5kbGVyLmJpbmQodGhpcywgZSksIDEwKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2NsaWNrSGFuZGxlcicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNsaWNrSGFuZGxlcihlKSB7XG4gICAgICB0aGlzLnNhdmVNb3VzZVBvc2l0aW9uKGUpO1xuICAgICAgdmFyIHNlbGVjdGlvbiA9IHRoaXMuZ2V0U2VsZWN0aW9uKCk7XG4gICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICBpZiAoc2VsZWN0aW9uLmxlbmd0aCA+IDApIHtcbiAgICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoeyBmYXN0OiB0cnVlIH0sIGZ1bmN0aW9uIChpdGVtcykge1xuICAgICAgICAgIGlmIChpdGVtcy5mYXN0KSB7XG4gICAgICAgICAgICBzZWxmLnJlcXVlc3RTZWFyY2goc2VsZWN0aW9uKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2dldFNlbGVjdGlvbicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGdldFNlbGVjdGlvbihlKSB7XG4gICAgICB2YXIgdHh0ID0gd2luZG93LmdldFNlbGVjdGlvbigpLnRvU3RyaW5nKCk7XG4gICAgICB2YXIgc3BhbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ1NQQU4nKTtcbiAgICAgIHNwYW4uaW5uZXJIVE1MID0gdHh0O1xuICAgICAgdmFyIHNlbGVjdGlvbiA9IHNwYW4udGV4dENvbnRlbnQudHJpbSgpO1xuICAgICAgcmV0dXJuIHNlbGVjdGlvbjtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdhdHRhY2hTaW1pbGFyV29yZHNIYW5kbGVycycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGF0dGFjaFNpbWlsYXJXb3Jkc0hhbmRsZXJzKGZyYWdtZW50KSB7XG4gICAgICB2YXIgX3RoaXMyID0gdGhpcztcblxuICAgICAgdmFyIF9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gPSB0cnVlO1xuICAgICAgdmFyIF9kaWRJdGVyYXRvckVycm9yID0gZmFsc2U7XG4gICAgICB2YXIgX2l0ZXJhdG9yRXJyb3IgPSB1bmRlZmluZWQ7XG5cbiAgICAgIHRyeSB7XG4gICAgICAgIHZhciBfbG9vcCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgbGluayA9IF9zdGVwLnZhbHVlO1xuXG4gICAgICAgICAgLy8gc2FuaXRpemVcbiAgICAgICAgICBsaW5rLnJlbW92ZUF0dHJpYnV0ZSgnb25jbGljaycpO1xuICAgICAgICAgIGxpbmsub25jbGljayA9IG51bGw7XG4gICAgICAgICAgdmFyIGNsb25lID0gbGluay5jbG9uZU5vZGUodHJ1ZSk7XG4gICAgICAgICAgbGluay5wYXJlbnROb2RlLnJlcGxhY2VDaGlsZChjbG9uZSwgbGluayk7XG4gICAgICAgICAgdmFyIHdvcmQgPSBjbG9uZS50ZXh0Q29udGVudDtcbiAgICAgICAgICAvLyBQcmV2ZW50IGxpbmsgZnJvbSBiZWluZyBmb2xsb3dlZC5cbiAgICAgICAgICBjbG9uZS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO2UucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICAvLyBEb24ndCBsZXQgQG1vdXNlVXBFdmVudCBmaXJlIGFnYWluIHdpdGggdGhlIHdyb25nIHdvcmQuXG4gICAgICAgICAgc2VsZiA9IF90aGlzMjtcblxuICAgICAgICAgIGNsb25lLmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNldXAnLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgIHNlbGYucmVxdWVzdFNlYXJjaCh3b3JkKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfTtcblxuICAgICAgICBmb3IgKHZhciBfaXRlcmF0b3IgPSBBcnJheS5mcm9tKGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ2EnKSlbU3ltYm9sLml0ZXJhdG9yXSgpLCBfc3RlcDsgIShfaXRlcmF0b3JOb3JtYWxDb21wbGV0aW9uID0gKF9zdGVwID0gX2l0ZXJhdG9yLm5leHQoKSkuZG9uZSk7IF9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gPSB0cnVlKSB7XG4gICAgICAgICAgdmFyIHNlbGY7XG5cbiAgICAgICAgICBfbG9vcCgpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgX2RpZEl0ZXJhdG9yRXJyb3IgPSB0cnVlO1xuICAgICAgICBfaXRlcmF0b3JFcnJvciA9IGVycjtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgaWYgKCFfaXRlcmF0b3JOb3JtYWxDb21wbGV0aW9uICYmIF9pdGVyYXRvclsncmV0dXJuJ10pIHtcbiAgICAgICAgICAgIF9pdGVyYXRvclsncmV0dXJuJ10oKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgaWYgKF9kaWRJdGVyYXRvckVycm9yKSB7XG4gICAgICAgICAgICB0aHJvdyBfaXRlcmF0b3JFcnJvcjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9XSk7XG5cbiAgcmV0dXJuIE1haW47XG59KSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IE1haW47XG4vLyMgc291cmNlTWFwcGluZ1VSTD12aWV3LmpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbkFycmF5LmZyb20gfHwgIShmdW5jdGlvbiAoKSB7XG4gIFwidXNlIHN0cmljdFwiO3ZhciByID0gKGZ1bmN0aW9uICgpIHtcbiAgICB0cnkge1xuICAgICAgdmFyIHIgPSB7fSxcbiAgICAgICAgICBlID0gT2JqZWN0LmRlZmluZVByb3BlcnR5LFxuICAgICAgICAgIHQgPSBlKHIsIHIsIHIpICYmIGU7XG4gICAgfSBjYXRjaCAobikge31yZXR1cm4gdCB8fCBmdW5jdGlvbiAociwgZSwgdCkge1xuICAgICAgcltlXSA9IHQudmFsdWU7XG4gICAgfTtcbiAgfSkoKSxcbiAgICAgIGUgPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLFxuICAgICAgdCA9IGZ1bmN0aW9uIHQocikge1xuICAgIHJldHVybiBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIHIgfHwgXCJbb2JqZWN0IEZ1bmN0aW9uXVwiID09IGUuY2FsbChyKTtcbiAgfSxcbiAgICAgIG4gPSBmdW5jdGlvbiBuKHIpIHtcbiAgICB2YXIgZSA9IE51bWJlcihyKTtyZXR1cm4gaXNOYU4oZSkgPyAwIDogMCAhPSBlICYmIGlzRmluaXRlKGUpID8gKGUgPiAwID8gMSA6IC0xKSAqIE1hdGguZmxvb3IoTWF0aC5hYnMoZSkpIDogZTtcbiAgfSxcbiAgICAgIGEgPSBNYXRoLnBvdygyLCA1MykgLSAxLFxuICAgICAgbyA9IGZ1bmN0aW9uIG8ocikge1xuICAgIHZhciBlID0gbihyKTtyZXR1cm4gTWF0aC5taW4oTWF0aC5tYXgoZSwgMCksIGEpO1xuICB9LFxuICAgICAgdSA9IGZ1bmN0aW9uIHUoZSkge1xuICAgIHZhciBuID0gdGhpcztpZiAobnVsbCA9PSBlKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiYEFycmF5LmZyb21gIHJlcXVpcmVzIGFuIGFycmF5LWxpa2Ugb2JqZWN0LCBub3QgYG51bGxgIG9yIGB1bmRlZmluZWRgXCIpO3tcbiAgICAgIHZhciBhLFxuICAgICAgICAgIHUsXG4gICAgICAgICAgaSA9IE9iamVjdChlKTthcmd1bWVudHMubGVuZ3RoID4gMTtcbiAgICB9aWYgKGFyZ3VtZW50cy5sZW5ndGggPiAxKSB7XG4gICAgICBpZiAoKGEgPSBhcmd1bWVudHNbMV0sICF0KGEpKSkgdGhyb3cgbmV3IFR5cGVFcnJvcihcIldoZW4gcHJvdmlkZWQsIHRoZSBzZWNvbmQgYXJndW1lbnQgdG8gYEFycmF5LmZyb21gIG11c3QgYmUgYSBmdW5jdGlvblwiKTthcmd1bWVudHMubGVuZ3RoID4gMiAmJiAodSA9IGFyZ3VtZW50c1syXSk7XG4gICAgfWZvciAodmFyIGYsIGMsIGwgPSBvKGkubGVuZ3RoKSwgaCA9IHQobikgPyBPYmplY3QobmV3IG4obCkpIDogbmV3IEFycmF5KGwpLCBtID0gMDsgbCA+IG07KSBmID0gaVttXSwgYyA9IGEgPyBcInVuZGVmaW5lZFwiID09IHR5cGVvZiB1ID8gYShmLCBtKSA6IGEuY2FsbCh1LCBmLCBtKSA6IGYsIHIoaCwgbSwgeyB2YWx1ZTogYywgY29uZmlndXJhYmxlOiAhMCwgZW51bWVyYWJsZTogITAsIHdyaXRhYmxlOiAhMCB9KSwgKyttO3JldHVybiBoLmxlbmd0aCA9IGwsIGg7XG4gIH07cihBcnJheSwgXCJmcm9tXCIsIHsgdmFsdWU6IHUsIGNvbmZpZ3VyYWJsZTogITAsIHdyaXRhYmxlOiAhMCB9KTtcbn0pKCk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1BcnJheS5mcm9tLmpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbnZhciBfY3JlYXRlQ2xhc3MgPSAoZnVuY3Rpb24gKCkgeyBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0aWVzKHRhcmdldCwgcHJvcHMpIHsgZm9yICh2YXIgaSA9IDA7IGkgPCBwcm9wcy5sZW5ndGg7IGkrKykgeyB2YXIgZGVzY3JpcHRvciA9IHByb3BzW2ldOyBkZXNjcmlwdG9yLmVudW1lcmFibGUgPSBkZXNjcmlwdG9yLmVudW1lcmFibGUgfHwgZmFsc2U7IGRlc2NyaXB0b3IuY29uZmlndXJhYmxlID0gdHJ1ZTsgaWYgKFwidmFsdWVcIiBpbiBkZXNjcmlwdG9yKSBkZXNjcmlwdG9yLndyaXRhYmxlID0gdHJ1ZTsgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgZGVzY3JpcHRvci5rZXksIGRlc2NyaXB0b3IpOyB9IH0gcmV0dXJuIGZ1bmN0aW9uIChDb25zdHJ1Y3RvciwgcHJvdG9Qcm9wcywgc3RhdGljUHJvcHMpIHsgaWYgKHByb3RvUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IucHJvdG90eXBlLCBwcm90b1Byb3BzKTsgaWYgKHN0YXRpY1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLCBzdGF0aWNQcm9wcyk7IHJldHVybiBDb25zdHJ1Y3RvcjsgfTsgfSkoKTtcblxuZnVuY3Rpb24gX2NsYXNzQ2FsbENoZWNrKGluc3RhbmNlLCBDb25zdHJ1Y3RvcikgeyBpZiAoIShpbnN0YW5jZSBpbnN0YW5jZW9mIENvbnN0cnVjdG9yKSkgeyB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IGNhbGwgYSBjbGFzcyBhcyBhIGZ1bmN0aW9uXCIpOyB9IH1cblxudmFyIFV0aWxzID0gKGZ1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gVXRpbHMoKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIFV0aWxzKTtcbiAgfVxuXG4gIF9jcmVhdGVDbGFzcyhVdGlscywgW3tcbiAgICBrZXk6IFwicmVxdWVzdFwiLFxuICAgIHZhbHVlOiBmdW5jdGlvbiByZXF1ZXN0KHR5cGUsIHVybCwgb3B0cykge1xuICAgICAgLy8gUmV0dXJuIGEgbmV3IHByb21pc2UuXG4gICAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAvLyBEbyB0aGUgdXN1YWwgWEhSIHN0dWZmXG4gICAgICAgIHZhciByZXEgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgICAgcmVxLndpdGhDcmVkZW50aWFscyA9IHRydWU7XG4gICAgICAgIHJlcS5vcGVuKHR5cGUsIHVybCk7XG4gICAgICAgIGlmICh0eXBlID09ICdQT1NUJykge1xuICAgICAgICAgIHJlcS5zZXRSZXF1ZXN0SGVhZGVyKFwiQ29udGVudC1UeXBlXCIsIFwiYXBwbGljYXRpb24vanNvblwiKTtcbiAgICAgICAgfVxuICAgICAgICByZXEub25sb2FkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIC8vIFRoaXMgaXMgY2FsbGVkIGV2ZW4gb24gNDA0IGV0Y1xuICAgICAgICAgIC8vIHNvIGNoZWNrIHRoZSBzdGF0dXNcbiAgICAgICAgICBpZiAocmVxLnN0YXR1cyA9PSAyMDApIHtcbiAgICAgICAgICAgIC8vIFJlc29sdmUgdGhlIHByb21pc2Ugd2l0aCB0aGUgcmVzcG9uc2UgdGV4dFxuICAgICAgICAgICAgcmVzb2x2ZShyZXEucmVzcG9uc2UpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBPdGhlcndpc2UgcmVqZWN0IHdpdGggdGhlIHN0YXR1cyB0ZXh0XG4gICAgICAgICAgICAvLyB3aGljaCB3aWxsIGhvcGVmdWxseSBiZSBhIG1lYW5pbmdmdWwgZXJyb3JcbiAgICAgICAgICAgIHJlamVjdChFcnJvcihyZXEuc3RhdHVzVGV4dCkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICAvLyBIYW5kbGUgbmV0d29yayBlcnJvcnNcbiAgICAgICAgcmVxLm9uZXJyb3IgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmVqZWN0KEVycm9yKFwiTmV0d29yayBFcnJvclwiKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gU2V0IGhlYWRlcnNcbiAgICAgICAgaWYgKG9wdHMuaGVhZGVycykge1xuICAgICAgICAgIHZhciBfaXRlcmF0b3JOb3JtYWxDb21wbGV0aW9uID0gdHJ1ZTtcbiAgICAgICAgICB2YXIgX2RpZEl0ZXJhdG9yRXJyb3IgPSBmYWxzZTtcbiAgICAgICAgICB2YXIgX2l0ZXJhdG9yRXJyb3IgPSB1bmRlZmluZWQ7XG5cbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgZm9yICh2YXIgX2l0ZXJhdG9yID0gT2JqZWN0LmtleXMob3B0cy5oZWFkZXJzKVtTeW1ib2wuaXRlcmF0b3JdKCksIF9zdGVwOyAhKF9pdGVyYXRvck5vcm1hbENvbXBsZXRpb24gPSAoX3N0ZXAgPSBfaXRlcmF0b3IubmV4dCgpKS5kb25lKTsgX2l0ZXJhdG9yTm9ybWFsQ29tcGxldGlvbiA9IHRydWUpIHtcbiAgICAgICAgICAgICAgdmFyIGtleSA9IF9zdGVwLnZhbHVlO1xuXG4gICAgICAgICAgICAgIHJlcS5zZXRSZXF1ZXN0SGVhZGVyKGtleSwgb3B0cy5oZWFkZXJzW2tleV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgX2RpZEl0ZXJhdG9yRXJyb3IgPSB0cnVlO1xuICAgICAgICAgICAgX2l0ZXJhdG9yRXJyb3IgPSBlcnI7XG4gICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIGlmICghX2l0ZXJhdG9yTm9ybWFsQ29tcGxldGlvbiAmJiBfaXRlcmF0b3JbXCJyZXR1cm5cIl0pIHtcbiAgICAgICAgICAgICAgICBfaXRlcmF0b3JbXCJyZXR1cm5cIl0oKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgaWYgKF9kaWRJdGVyYXRvckVycm9yKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgX2l0ZXJhdG9yRXJyb3I7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gTWFrZSB0aGUgcmVxdWVzdFxuICAgICAgICByZXEuc2VuZChKU09OLnN0cmluZ2lmeShvcHRzLmRhdGEpKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogXCJnZXRcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gZ2V0KHVybCkge1xuICAgICAgdmFyIG9wdHMgPSBhcmd1bWVudHMubGVuZ3RoIDw9IDEgfHwgYXJndW1lbnRzWzFdID09PSB1bmRlZmluZWQgPyB7IGRhdGE6ICcnIH0gOiBhcmd1bWVudHNbMV07XG5cbiAgICAgIHJldHVybiB0aGlzLnJlcXVlc3QoJ0dFVCcsIHVybCwgb3B0cyk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiBcInBvc3RcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gcG9zdCh1cmwpIHtcbiAgICAgIHZhciBvcHRzID0gYXJndW1lbnRzLmxlbmd0aCA8PSAxIHx8IGFyZ3VtZW50c1sxXSA9PT0gdW5kZWZpbmVkID8geyBkYXRhOiAnJyB9IDogYXJndW1lbnRzWzFdO1xuXG4gICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KCdQT1NUJywgdXJsLCBvcHRzKTtcbiAgICB9XG4gIH1dKTtcblxuICByZXR1cm4gVXRpbHM7XG59KSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBVdGlscygpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXRpbHMuanMubWFwXG4iXX0=
