(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
var CHAR_CODES = {
  // turkishdictionary codings
  '%C4%B1': '%FD', //ı (Lowercase i-dotless)  actually it is &#305; but turkishdictionary need it this way 
  '%C5%9F': '%FE', //ş
  '%C4%9F': '%F0', //ğ  (silent character)
  '%C3%A7': '%E7', //ç
  '%C3%B6': '%F6', //ö
  '%C3%BC': '%FC' //ü
}

module.exports = CHAR_CODES;
},{}],2:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/var CHAR_CODES = {  '%C3%80': '&#192;', // À  '%C3%81': '&#193;', // Á  '%C3%82': '&#194;', // Â  '%C3%83': '&#195;', // Ã  '%C3%84': '&#196;', // Ä  '%C3%85': '&#197;', // Å  '%C3%86': '&#198;', // Æ  '%C3%87': '&#199;', // Ç  '%C3%88': '&#200;', // È  '%C3%89': '&#201;', // É  '%C3%8A': '&#202;', // Ê  '%C3%8B': '&#203;', // Ë  '%C3%8C': '&#204;', // Ì  '%C3%8D': '&#205;', // Í  '%C3%8E': '&#206;', // Î  '%C3%8F': '&#207;', // Ï  '%C3%91': '&#209;', // Ñ  '%C3%92': '&#210;', // Ò  '%C3%93': '&#211;', // Ó  '%C3%94': '&#212;', // Ô  '%C3%95': '&#213;', // Õ  '%C3%96': '&#214;', // Ö  '%C3%99': '&#217;', // Ù  '%C3%9A': '&#218;', // Ú  '%C3%9B': '&#219;', // Û  '%C3%9C': '&#220;', // Ü  '%C3%A0': '&#224;', // à  '%C3%A1': '&#225;', // á  '%C3%A2': '&#226;', // â  '%C3%A3': '&#227;', // ã  '%C3%A4': '&#228;', // ä  '%C3%A5': '&#229;', // å  '%C3%A6': '&#230;', // æ  '%C3%A7': '&#231;', // ç  '%C3%A8': '&#232;', // è  '%C3%A9': '&#233;', // é  '%C3%AA': '&#234;', // ê  '%C3%AB': '&#235;', // ë  '%C3%AC': '&#236;', // ì  '%C3%AD': '&#237;', // í  '%C3%AE': '&#238;', // î  '%C3%AF': '&#239;', // ï  '%C3%B0': '&#240;', // ð  '%C3%B1': '&#241;', // ñ  '%C3%B2': '&#242;', // ò  '%C3%B3': '&#243;', // ó  '%C3%B4': '&#244;', // ô  '%C3%B5': '&#245;', // õ  '%C3%B6': '&#246;', // ö  '%C3%B9': '&#249;', // ù  '%C3%BA': '&#250;', // ú  '%C3%BB': '&#251;', // û  '%C3%BC': '&#252;', // ü  '%C3%BF': '&#255;', // ÿ  '%C5%B8': '&#376;', // Ÿ  '%C3%9F': '&#223;', // ß  '%C2%BF': '&#191;', // ¿  '%C2%A1': '&#161;', // ¡};module.exports = CHAR_CODES;
},{}],3:[function(require,module,exports){

/*
  Dropdown language menu
  @param opts takes element and onSelect handler
  example:
  new Dropdown({
   el: document.getElementById('#menu');
   onSelect: function () {}
  })
 */
var DICT_CODE, Dropdown, LANG_CODE;

LANG_CODE = {
  '1': 'Eng',
  '2': 'Rus',
  '3': 'Ger',
  '4': 'Fre',
  '5': 'Spa',
  '23': 'Ita',
  '24': 'Dut',
  '26': 'Est',
  '27': 'Lav',
  '31': 'Afr',
  '34': 'Epo',
  '35': 'Xal',
  '1000': 'Tur'
};

DICT_CODE = {
  '1': 'multitran',
  '1000': 'turkish'
};

Dropdown = (function() {
  function Dropdown(opts) {
    this.el = opts.el || document.createElement('div');
    this.onSelect = opts.onSelect;
    this.menu = this.el.querySelector('.dropdown-menu');
    if (this.menu) {
      this.menu.style.display = 'none';
      this.items = this.menu.getElementsByClassName('language-type');
      this.button = this.el.querySelector('.dropdown-toggle');
      this.addListeners();
      this.initLanguage();
    }
  }

  Dropdown.prototype.addListeners = function() {
    this.button.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.toggle(e);
      };
    })(this));
    document.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.hide(e);
      };
    })(this));
    return this.menu.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.choose(e);
      };
    })(this));
  };

  Dropdown.prototype.initLanguage = function() {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(store) {
        return _this.setTitle(store.language);
      };
    })(this));
  };

  Dropdown.prototype.toggle = function(e) {
    e.stopPropagation();
    this.setActiveItem();
    if (this.menu && this.menu.style.display === 'none') {
      return this.show();
    } else {
      return this.hide();
    }
  };

  Dropdown.prototype.setActiveItem = function() {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(store) {
        var item, _i, _len, _ref, _results;
        _ref = _this.items;
        _results = [];
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          item = _ref[_i];
          if (item.getAttribute('data-val') === store.language) {
            _results.push(item.classList.add('active'));
          } else {
            _results.push(item.classList.remove('active'));
          }
        }
        return _results;
      };
    })(this));
  };

  Dropdown.prototype.hide = function() {
    return this.menu.style.display = 'none';
  };

  Dropdown.prototype.show = function() {
    return this.menu.style.display = 'block';
  };

  Dropdown.prototype.choose = function(e) {
    var dictionary, language;
    e.stopPropagation();
    e.preventDefault();
    language = e.target.getAttribute('data-val');
    dictionary = this.getDictionary(language);
    chrome.storage.sync.set({
      language: language,
      dictionary: dictionary
    }, this.onSelect);
    this.setTitle(language);
    return this.hide();
  };

  Dropdown.prototype.getDictionary = function(lang) {
    var dict;
    console.log('choose dict: for', lang);
    dict = DICT_CODE[lang] || 'multitran';
    console.log('dict', dict);
    return dict;
  };

  Dropdown.prototype.setTitle = function(language) {
    var html;
    html = LANG_CODE[language] + ' <span class="caret"></span>';
    return this.button.innerHTML = html;
  };

  return Dropdown;

})();

module.exports = Dropdown;


},{}],4:[function(require,module,exports){

/*
  Extension popup window
  Shows search form and dropdown menu with languages
 */
var SearchForm;

SearchForm = require('./search_form.coffee');

document.addEventListener("DOMContentLoaded", function() {
  var form, link;
  form = new SearchForm(document.getElementById('tran-form'));
  link = document.getElementById('header-link');
  if (link) {
    return link.addEventListener('click', function(e) {
      var href;
      e.preventDefault();
      href = e.target.getAttribute('href') + form.getValue();
      return chrome.tabs.create({
        url: href
      });
    });
  }
});


},{"./search_form.coffee":5}],5:[function(require,module,exports){

/*
  Serves search input and form

  @param form DOM elemnt
  @constructor
 */
var Dropdown, SearchForm, TRANSLATE_ENGINES, tran, turkishdictionary,
  __indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

Dropdown = require('./dropdown.coffee');

tran = require('../tran.coffee');

turkishdictionary = require('../turkishdictionary.js');

TRANSLATE_ENGINES = {
  'multitran': tran,
  'turkish': turkishdictionary
};

SearchForm = (function() {
  function SearchForm(form) {
    this.form = form;
    this.input = document.getElementById('translate-txt');
    this.input.focus();
    this.result = document.getElementById('result');
    this.addListeners();
    this.dropdown = new Dropdown({
      el: document.querySelector('.dropdown-el'),
      onSelect: (function(_this) {
        return function() {
          return _this.search();
        };
      })(this)
    });
  }

  SearchForm.prototype.addListeners = function() {
    if (this.form && this.result) {
      this.form.addEventListener('submit', (function(_this) {
        return function(e) {
          return _this.search(e);
        };
      })(this));
      return this.result.addEventListener('click', (function(_this) {
        return function(e) {
          return _this.resultClickHandler(e);
        };
      })(this));
    }
  };

  SearchForm.prototype.search = function(e) {
    e && e.preventDefault && e.preventDefault();
    if (this.input.value.length > 0) {
      return chrome.storage.sync.get({
        language: '1',
        dictionary: 'multitran'
      }, (function(_this) {
        return function(items) {
          console.log('ITEMS:', items);
          return TRANSLATE_ENGINES[items.dictionary].search({
            value: _this.input.value,
            success: _this.successHandler.bind(_this)
          });
        };
      })(this));
    }
  };

  SearchForm.prototype.successHandler = function(response) {
    this.clean(this.result);
    return this.result.appendChild(response);
  };

  SearchForm.prototype.clean = function(el) {
    var _results;
    _results = [];
    while (el.lastChild) {
      _results.push(el.removeChild(el.lastChild));
    }
    return _results;
  };

  SearchForm.prototype.resultClickHandler = function(e) {
    var linkTags, _ref;
    e.preventDefault();
    linkTags = ['A', 'a'];
    if (_ref = e.target.tagName, __indexOf.call(linkTags, _ref) >= 0) {
      this.input.value = e.target.innerText;
      return this.search(e);
    }
  };

  SearchForm.prototype.getValue = function() {
    return this.input.value;
  };

  return SearchForm;

})();

module.exports = SearchForm;


},{"../tran.coffee":6,"../turkishdictionary.js":7,"./dropdown.coffee":3}],6:[function(require,module,exports){

/*global chrome */

/*
  Multitran.ru translate engine
  Provides program interface for making translate queries to multitran and get clean response

  All engines must follow common interface and provide methods:
    - search (languange, successHandler)  clean translation must be passed into successHandler
    - click

  Translation-module that makes requests to language-engine,
  parses results and sends plugin-global message with translation data
 */
var CHAR_CODES, Tran;

CHAR_CODES = require('./char-codes.js');

Tran = (function() {
  function Tran() {
    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1';
    this.xhr = {};
  }


  /*
    Context menu click handler
   */

  Tran.prototype.click = function(data) {
    var selectionText;
    if (typeof data.silent === void 0 || data.silent === null) {
      data.silent = true;
    }
    selectionText = this.removeHyphenation(data.selectionText);
    return this.search({
      value: selectionText,
      success: this.successtHandler.bind(this),
      silent: data.silent
    });
  };


  /*
    Discard soft hyphen character (U+00AD, &shy;) from the input
   */

  Tran.prototype.removeHyphenation = function(text) {
    return text.replace(/\xad/g, '');
  };


  /*
    Initiate translation search
   */

  Tran.prototype.search = function(params) {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(items) {
        var language, origSuccess, url;
        if (language === '') {
          language = '1';
        }
        _this.setLanguage(items.language);
        url = _this.makeUrl(params.value);
        origSuccess = params.success;
        params.success = function(response) {
          var translated;
          translated = _this.parse(response, params.silent);
          return origSuccess(translated);
        };
        return _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      };
    })(this));
  };

  Tran.prototype.setLanguage = function(language) {
    this.currentLanguage = language;
    return this.lang = '?l1=2&l2=' + language;
  };


  /*
    Request translation and run callback function
    passing translated result or error to callback
   */

  Tran.prototype.request = function(opts) {
    var xhr;
    xhr = this.xhr = new XMLHttpRequest();
    xhr.onreadystatechange = (function(_this) {
      return function(e) {
        xhr = _this.xhr;
        if (xhr.readyState < 4) {

        } else if (xhr.status !== 200) {
          _this.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error();
          }
        } else if (xhr.readyState === 4) {
          return opts.success(e.target.response);
        }
      };
    })(this);
    xhr.open("GET", opts.url, true);
    return xhr.send();
  };

  Tran.prototype.makeUrl = function(value) {
    var url;
    url = [this.protocol, '://', this.host, this.path, this.lang, this.query, this.getEncodedValue(value)].join('');
    return url;
  };

  Tran.prototype.getEncodedValue = function(value) {
    var char, code, val;
    val = encodeURIComponent(value);
    for (char in CHAR_CODES) {
      code = CHAR_CODES[char];
      val = val.replace(char, encodeURIComponent(code));
    }
    return val;
  };

  Tran.prototype.errorHandler = function(xhr) {
    return console.log('error', xhr);
  };


  /*
   Receiving data from translation-engine and send ready message with data
   */

  Tran.prototype.successtHandler = function(translated) {
    if (translated) {
      return chrome.tabs.getSelected(null, (function(_this) {
        return function(tab) {
          return chrome.tabs.sendMessage(tab.id, {
            action: _this.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        };
      })(this));
    }
  };

  Tran.prototype.messageType = function(translated) {
    var _ref;
    if ((translated != null ? (_ref = translated.rows) != null ? _ref.length : void 0 : void 0) === 1) {
      return 'similar_words';
    } else {
      return 'open_tooltip';
    }
  };


  /*
    Parse response from translation engine
   */

  Tran.prototype.parse = function(response, silent, translate) {
    var doc, fragment;
    if (translate == null) {
      translate = null;
    }
    doc = this.stripScripts(response);
    fragment = this.makeFragment(doc);
    if (fragment) {
      translate = fragment.querySelector('#translation ~ table');
      if (translate) {
        translate.className = this.TABLE_CLASS;
        translate.setAttribute("cellpadding", "5");
        this.fixImages(translate);
        this.fixLinks(translate);
      } else if (!silent) {
        translate = document.createElement('div');
        translate.className = 'failTranslate';
        translate.innerText = "Unfortunately, could not translate";
      }
    }
    return translate;
  };


  /*
    Strip script tags from response html
   */

  Tran.prototype.stripScripts = function(s) {
    var div, i, scripts;
    div = document.createElement('div');
    div.innerHTML = s;
    scripts = div.getElementsByTagName('script');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
    return div.innerHTML;
  };

  Tran.prototype.makeFragment = function(doc, fragment) {
    var div;
    if (fragment == null) {
      fragment = null;
    }
    div = document.createElement("div");
    div.innerHTML = doc;
    fragment = document.createDocumentFragment();
    while (div.firstChild) {
      fragment.appendChild(div.firstChild);
    }
    return fragment;
  };

  Tran.prototype.fixImages = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'img', 'src');
    return fragment;
  };

  Tran.prototype.fixLinks = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'a', 'href');
    return fragment;
  };

  Tran.prototype.fixUrl = function(fragment, tag, attr) {
    var parser, tags, _i, _len, _results;
    if (fragment == null) {
      fragment = null;
    }
    if (fragment) {
      tags = fragment.querySelectorAll(tag);
      parser = document.createElement('a');
      _results = [];
      for (_i = 0, _len = tags.length; _i < _len; _i++) {
        tag = tags[_i];
        parser.href = tag[attr];
        parser.host = this.host;
        parser.protocol = this.protocol;
        if (tag.tagName === 'A') {
          tag.classList.add('mtt_link');
          if (parser.pathname.indexOf('m.exe') !== -1) {
            parser.pathname = '/c' + parser.pathname;
            tag.setAttribute('target', '_blank');
          }
        } else if (tag.tagName === 'IMG') {
          tag.classList.add('mtt_img');
        }
        _results.push(tag.setAttribute(attr, parser.href));
      }
      return _results;
    }
  };

  return Tran;

})();

module.exports = new Tran;


},{"./char-codes.js":2}],7:[function(require,module,exports){
"use strict";

var _prototypeProperties = function (child, staticProps, instanceProps) {
  if (staticProps) Object.defineProperties(child, staticProps);
  if (instanceProps) Object.defineProperties(child.prototype, instanceProps);
};

/*
  Translation engine: http://www.turkishdictionary.net
  For translating turkish-russian and vice versa
*/
var CHAR_CODES = require("./char-codes-turk.js");

var TurkishDictionary = (function () {
  function TurkishDictionary() {
    this.host = "http://www.turkishdictionary.net/?word=%FC";
    this.path = "";
    this.protocol = "http";
    this.query = "&s=";
    this.TABLE_CLASS = "___mtt_translate_table";
    this.need_publish = true;
  }

  _prototypeProperties(TurkishDictionary, null, {
    search: {
      value: function search(data) {
        data.url = this.makeUrl(data.value);
        this.need_publish = false;
        return this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    translate: {
      value: function translate(data) {
        console.log("request data:", data);
        data.url = this.makeUrl(data.selectionText);
        this.need_publish = true;
        this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeUrl: {
      value: function makeUrl(text) {
        return ["http://www.turkishdictionary.net/?word=", text].join("");
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    request: {

      /*
        Request translation and run callback function
        passing translated result or error to callback
      */
      value: function request(opts) {
        console.log("start request");
        this.xhr = new XMLHttpRequest();
        this.xhr.onreadystatechange = this.onReadyStateChange.bind(this, opts);
        this.xhr.open("GET", opts.url, true);
        this.xhr.send();
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    onReadyStateChange: {
      value: function onReadyStateChange(opts, e) {
        var xhr = this.xhr;
        if (xhr.readyState < 4) {
          return;
        } else if (xhr.status != 200) {
          this.errorHandler(xhr);
          return opts.error && opts.error();
        } else if (xhr.readyState == 4) {
          var translation = this.successHandler(e.target.response);
          console.log("success turkish translate", translation);
          console.log("call", opts.success);
          return opts.success && opts.success(translation);
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    successHandler: {
      value: function successHandler(response) {
        var data = this.parse(response);
        if (this.need_publish) {
          chrome.tabs.getSelected(null, this.publishTranslation.bind(this, data));
        }
        return data;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    publishTranslation: {

      /* publish successfuly translated text all over extension */
      value: function publishTranslation(translation, tab) {
        console.log("publish translation");
        chrome.tabs.sendMessage(tab.id, {
          action: "open_tooltip",
          data: translation.outerHTML,
          success: !translation.classList.contains("failTranslate")
        });
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    errorHandler: {
      value: function errorHandler(response) {
        console.log("error ajax", response);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parse: {

      /* Parse response from translation engine */
      value: function parse(response, silent, translate) {
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);
        if (fragment) {
          translate = fragment.querySelector("#meaning_div > table");
          if (translate) {
            translate.className = this.TABLE_CLASS;
            translate.setAttribute("cellpadding", "5");
            // @fixImages(translate)
            // @fixLinks(translate)
          } else if (!silent) {
            translate = document.createElement("div");
            translate.className = "failTranslate";
            translate.innerText = "Unfortunately, could not translate";
          }
        }
        return translate;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    stripScripts: {

      //TODO extract to base engine class
      /* removes <script> tags from html code */
      value: function stripScripts(html) {
        var div = document.createElement("div");
        div.innerHTML = html;
        var scripts = div.getElementsByTagName("script");
        var i = scripts.length;
        while (i--) scripts[i].parentNode.removeChild(scripts[i]);
        return div.innerHTML;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeFragment: {

      //TODO extract to base engine class
      /* creates temp object to parse translation from page 
        (since it's not a friendly api) 
      */
      value: function makeFragment(html) {
        var fragment,
            div = document.createElement("div");
        div.innerHTML = html;
        fragment = document.createDocumentFragment();
        while (div.firstChild) {
          fragment.appendChild(div.firstChild);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    }
  });

  return TurkishDictionary;
})();

// Singletone
module.exports = new TurkishDictionary();
},{"./char-codes-turk.js":1}]},{},[4])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvY2hhci1jb2Rlcy10dXJrLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy9jaGFyLWNvZGVzLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy9wb3B1cC9kcm9wZG93bi5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXZlbG9wbWVudC90cmFuL2pzL3BvcHVwL3BvcHVwLmNvZmZlZSIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvcG9wdXAvc2VhcmNoX2Zvcm0uY29mZmVlIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy90cmFuLmNvZmZlZSIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvdHVya2lzaGRpY3Rpb25hcnkuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1ZBOztBQ0FBO0FBQUE7Ozs7Ozs7O0dBQUE7QUFBQSxJQUFBLDhCQUFBOztBQUFBLFNBU0EsR0FDRTtBQUFBLEVBQUEsR0FBQSxFQUFLLEtBQUw7QUFBQSxFQUNBLEdBQUEsRUFBSyxLQURMO0FBQUEsRUFFQSxHQUFBLEVBQUssS0FGTDtBQUFBLEVBR0EsR0FBQSxFQUFLLEtBSEw7QUFBQSxFQUlBLEdBQUEsRUFBSyxLQUpMO0FBQUEsRUFLQSxJQUFBLEVBQU0sS0FMTjtBQUFBLEVBTUEsSUFBQSxFQUFNLEtBTk47QUFBQSxFQU9BLElBQUEsRUFBTSxLQVBOO0FBQUEsRUFRQSxJQUFBLEVBQU0sS0FSTjtBQUFBLEVBU0EsSUFBQSxFQUFNLEtBVE47QUFBQSxFQVVBLElBQUEsRUFBTSxLQVZOO0FBQUEsRUFXQSxJQUFBLEVBQU0sS0FYTjtBQUFBLEVBWUEsTUFBQSxFQUFRLEtBWlI7Q0FWRixDQUFBOztBQUFBLFNBd0JBLEdBQ0U7QUFBQSxFQUFBLEdBQUEsRUFBSyxXQUFMO0FBQUEsRUFDQSxNQUFBLEVBQVEsU0FEUjtDQXpCRixDQUFBOztBQUFBO0FBNkJlLEVBQUEsa0JBQUMsSUFBRCxHQUFBO0FBQ1gsSUFBQSxJQUFDLENBQUEsRUFBRCxHQUFNLElBQUksQ0FBQyxFQUFMLElBQVcsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBakIsQ0FBQTtBQUFBLElBRUEsSUFBQyxDQUFBLFFBQUQsR0FBWSxJQUFJLENBQUMsUUFGakIsQ0FBQTtBQUFBLElBSUEsSUFBQyxDQUFBLElBQUQsR0FBUSxJQUFDLENBQUEsRUFBRSxDQUFDLGFBQUosQ0FBa0IsZ0JBQWxCLENBSlIsQ0FBQTtBQUtBLElBQUEsSUFBRyxJQUFDLENBQUEsSUFBSjtBQUNFLE1BQUEsSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWixHQUFzQixNQUF0QixDQUFBO0FBQUEsTUFDQSxJQUFDLENBQUEsS0FBRCxHQUFTLElBQUMsQ0FBQSxJQUFJLENBQUMsc0JBQU4sQ0FBNkIsZUFBN0IsQ0FEVCxDQUFBO0FBQUEsTUFFQSxJQUFDLENBQUEsTUFBRCxHQUFVLElBQUMsQ0FBQSxFQUFFLENBQUMsYUFBSixDQUFrQixrQkFBbEIsQ0FGVixDQUFBO0FBQUEsTUFHQSxJQUFDLENBQUEsWUFBRCxDQUFBLENBSEEsQ0FBQTtBQUFBLE1BSUEsSUFBQyxDQUFBLFlBQUQsQ0FBQSxDQUpBLENBREY7S0FOVztFQUFBLENBQWI7O0FBQUEscUJBYUEsWUFBQSxHQUFjLFNBQUEsR0FBQTtBQUNaLElBQUEsSUFBQyxDQUFBLE1BQU0sQ0FBQyxnQkFBUixDQUF5QixPQUF6QixFQUFrQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7ZUFBTyxLQUFDLENBQUEsTUFBRCxDQUFRLENBQVIsRUFBUDtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxDLENBQUEsQ0FBQTtBQUFBLElBQ0EsUUFBUSxDQUFDLGdCQUFULENBQTBCLE9BQTFCLEVBQW1DLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLENBQUQsR0FBQTtlQUFPLEtBQUMsQ0FBQSxJQUFELENBQU0sQ0FBTixFQUFQO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbkMsQ0FEQSxDQUFBO1dBRUEsSUFBQyxDQUFBLElBQUksQ0FBQyxnQkFBTixDQUF1QixPQUF2QixFQUFnQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7ZUFBTyxLQUFDLENBQUEsTUFBRCxDQUFRLENBQVIsRUFBUDtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWhDLEVBSFk7RUFBQSxDQWJkLENBQUE7O0FBQUEscUJBbUJBLFlBQUEsR0FBYyxTQUFBLEdBQUE7V0FDWixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUUsUUFBQSxFQUFVLEdBQVo7S0FBeEIsRUFBMEMsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsS0FBRCxHQUFBO2VBQ3hDLEtBQUMsQ0FBQSxRQUFELENBQVUsS0FBSyxDQUFDLFFBQWhCLEVBRHdDO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBMUMsRUFEWTtFQUFBLENBbkJkLENBQUE7O0FBQUEscUJBd0JBLE1BQUEsR0FBUSxTQUFDLENBQUQsR0FBQTtBQUNOLElBQUEsQ0FBQyxDQUFDLGVBQUYsQ0FBQSxDQUFBLENBQUE7QUFBQSxJQUNBLElBQUMsQ0FBQSxhQUFELENBQUEsQ0FEQSxDQUFBO0FBRUEsSUFBQSxJQUFHLElBQUMsQ0FBQSxJQUFELElBQVUsSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWixLQUF1QixNQUFwQzthQUNFLElBQUMsQ0FBQSxJQUFELENBQUEsRUFERjtLQUFBLE1BQUE7YUFHRSxJQUFDLENBQUEsSUFBRCxDQUFBLEVBSEY7S0FITTtFQUFBLENBeEJSLENBQUE7O0FBQUEscUJBaUNBLGFBQUEsR0FBZSxTQUFBLEdBQUE7V0FDYixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUMsUUFBQSxFQUFVLEdBQVg7S0FBeEIsRUFBeUMsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsS0FBRCxHQUFBO0FBQ3ZDLFlBQUEsOEJBQUE7QUFBQTtBQUFBO2FBQUEsMkNBQUE7MEJBQUE7QUFDRSxVQUFBLElBQUcsSUFBSSxDQUFDLFlBQUwsQ0FBa0IsVUFBbEIsQ0FBQSxLQUFpQyxLQUFLLENBQUMsUUFBMUM7MEJBQ0UsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFmLENBQW1CLFFBQW5CLEdBREY7V0FBQSxNQUFBOzBCQUdFLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBZixDQUFzQixRQUF0QixHQUhGO1dBREY7QUFBQTt3QkFEdUM7TUFBQSxFQUFBO0lBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUF6QyxFQURhO0VBQUEsQ0FqQ2YsQ0FBQTs7QUFBQSxxQkF5Q0EsSUFBQSxHQUFNLFNBQUEsR0FBQTtXQUNKLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQVosR0FBc0IsT0FEbEI7RUFBQSxDQXpDTixDQUFBOztBQUFBLHFCQTRDQSxJQUFBLEdBQU0sU0FBQSxHQUFBO1dBQ0osSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWixHQUFzQixRQURsQjtFQUFBLENBNUNOLENBQUE7O0FBQUEscUJBaURBLE1BQUEsR0FBUSxTQUFDLENBQUQsR0FBQTtBQUNOLFFBQUEsb0JBQUE7QUFBQSxJQUFBLENBQUMsQ0FBQyxlQUFGLENBQUEsQ0FBQSxDQUFBO0FBQUEsSUFDQSxDQUFDLENBQUMsY0FBRixDQUFBLENBREEsQ0FBQTtBQUFBLElBRUEsUUFBQSxHQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBVCxDQUFzQixVQUF0QixDQUZYLENBQUE7QUFBQSxJQUdBLFVBQUEsR0FBYSxJQUFDLENBQUEsYUFBRCxDQUFlLFFBQWYsQ0FIYixDQUFBO0FBQUEsSUFJQSxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUMsUUFBQSxFQUFVLFFBQVg7QUFBQSxNQUFxQixVQUFBLEVBQVksVUFBakM7S0FBeEIsRUFBc0UsSUFBQyxDQUFBLFFBQXZFLENBSkEsQ0FBQTtBQUFBLElBS0EsSUFBQyxDQUFBLFFBQUQsQ0FBVSxRQUFWLENBTEEsQ0FBQTtXQU1BLElBQUMsQ0FBQSxJQUFELENBQUEsRUFQTTtFQUFBLENBakRSLENBQUE7O0FBQUEscUJBNERBLGFBQUEsR0FBZSxTQUFDLElBQUQsR0FBQTtBQUNiLFFBQUEsSUFBQTtBQUFBLElBQUEsT0FBTyxDQUFDLEdBQVIsQ0FBWSxrQkFBWixFQUErQixJQUEvQixDQUFBLENBQUE7QUFBQSxJQUNBLElBQUEsR0FBTyxTQUFVLENBQUEsSUFBQSxDQUFWLElBQW1CLFdBRDFCLENBQUE7QUFBQSxJQUVBLE9BQU8sQ0FBQyxHQUFSLENBQVksTUFBWixFQUFtQixJQUFuQixDQUZBLENBQUE7QUFHQSxXQUFPLElBQVAsQ0FKYTtFQUFBLENBNURmLENBQUE7O0FBQUEscUJBbUVBLFFBQUEsR0FBVSxTQUFDLFFBQUQsR0FBQTtBQUNSLFFBQUEsSUFBQTtBQUFBLElBQUEsSUFBQSxHQUFPLFNBQVUsQ0FBQSxRQUFBLENBQVYsR0FBc0IsOEJBQTdCLENBQUE7V0FDQSxJQUFDLENBQUEsTUFBTSxDQUFDLFNBQVIsR0FBb0IsS0FGWjtFQUFBLENBbkVWLENBQUE7O2tCQUFBOztJQTdCRixDQUFBOztBQUFBLE1BcUdNLENBQUMsT0FBUCxHQUFpQixRQXJHakIsQ0FBQTs7OztBQ0FBO0FBQUE7OztHQUFBO0FBQUEsSUFBQSxVQUFBOztBQUFBLFVBSUEsR0FBYSxPQUFBLENBQVEsc0JBQVIsQ0FKYixDQUFBOztBQUFBLFFBTVEsQ0FBQyxnQkFBVCxDQUEwQixrQkFBMUIsRUFBOEMsU0FBQSxHQUFBO0FBQzVDLE1BQUEsVUFBQTtBQUFBLEVBQUEsSUFBQSxHQUFXLElBQUEsVUFBQSxDQUFXLFFBQVEsQ0FBQyxjQUFULENBQXdCLFdBQXhCLENBQVgsQ0FBWCxDQUFBO0FBQUEsRUFDQSxJQUFBLEdBQU8sUUFBUSxDQUFDLGNBQVQsQ0FBd0IsYUFBeEIsQ0FEUCxDQUFBO0FBRUEsRUFBQSxJQUFHLElBQUg7V0FDRSxJQUFJLENBQUMsZ0JBQUwsQ0FBc0IsT0FBdEIsRUFBK0IsU0FBQyxDQUFELEdBQUE7QUFDN0IsVUFBQSxJQUFBO0FBQUEsTUFBQSxDQUFDLENBQUMsY0FBRixDQUFBLENBQUEsQ0FBQTtBQUFBLE1BQ0EsSUFBQSxHQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBVCxDQUFzQixNQUF0QixDQUFBLEdBQWdDLElBQUksQ0FBQyxRQUFMLENBQUEsQ0FEdkMsQ0FBQTthQUVBLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBWixDQUFtQjtBQUFBLFFBQUUsR0FBQSxFQUFLLElBQVA7T0FBbkIsRUFINkI7SUFBQSxDQUEvQixFQURGO0dBSDRDO0FBQUEsQ0FBOUMsQ0FOQSxDQUFBOzs7O0FDQUE7QUFBQTs7Ozs7R0FBQTtBQUFBLElBQUEsZ0VBQUE7RUFBQSxxSkFBQTs7QUFBQSxRQU1BLEdBQVcsT0FBQSxDQUFRLG1CQUFSLENBTlgsQ0FBQTs7QUFBQSxJQVNBLEdBQU8sT0FBQSxDQUFRLGdCQUFSLENBVFAsQ0FBQTs7QUFBQSxpQkFVQSxHQUFvQixPQUFBLENBQVEseUJBQVIsQ0FWcEIsQ0FBQTs7QUFBQSxpQkFjQSxHQUNFO0FBQUEsRUFBQSxXQUFBLEVBQWEsSUFBYjtBQUFBLEVBQ0EsU0FBQSxFQUFXLGlCQURYO0NBZkYsQ0FBQTs7QUFBQTtBQW1CZSxFQUFBLG9CQUFFLElBQUYsR0FBQTtBQUNYLElBRFksSUFBQyxDQUFBLE9BQUEsSUFDYixDQUFBO0FBQUEsSUFBQSxJQUFDLENBQUEsS0FBRCxHQUFTLFFBQVEsQ0FBQyxjQUFULENBQXdCLGVBQXhCLENBQVQsQ0FBQTtBQUFBLElBQ0EsSUFBQyxDQUFBLEtBQUssQ0FBQyxLQUFQLENBQUEsQ0FEQSxDQUFBO0FBQUEsSUFHQSxJQUFDLENBQUEsTUFBRCxHQUFVLFFBQVEsQ0FBQyxjQUFULENBQXdCLFFBQXhCLENBSFYsQ0FBQTtBQUFBLElBSUEsSUFBQyxDQUFBLFlBQUQsQ0FBQSxDQUpBLENBQUE7QUFBQSxJQUtBLElBQUMsQ0FBQSxRQUFELEdBQWdCLElBQUEsUUFBQSxDQUFTO0FBQUEsTUFDdkIsRUFBQSxFQUFJLFFBQVEsQ0FBQyxhQUFULENBQXVCLGNBQXZCLENBRG1CO0FBQUEsTUFFdkIsUUFBQSxFQUFVLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFBLEdBQUE7aUJBQUcsS0FBQyxDQUFBLE1BQUQsQ0FBQSxFQUFIO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FGYTtLQUFULENBTGhCLENBRFc7RUFBQSxDQUFiOztBQUFBLHVCQVdBLFlBQUEsR0FBYyxTQUFBLEdBQUE7QUFDWixJQUFBLElBQUcsSUFBQyxDQUFBLElBQUQsSUFBVSxJQUFDLENBQUEsTUFBZDtBQUNFLE1BQUEsSUFBQyxDQUFBLElBQUksQ0FBQyxnQkFBTixDQUF1QixRQUF2QixFQUFpQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxDQUFELEdBQUE7aUJBQU8sS0FBQyxDQUFBLE1BQUQsQ0FBUSxDQUFSLEVBQVA7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFqQyxDQUFBLENBQUE7YUFDQSxJQUFDLENBQUEsTUFBTSxDQUFDLGdCQUFSLENBQXlCLE9BQXpCLEVBQWtDLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLENBQUQsR0FBQTtpQkFBTyxLQUFDLENBQUEsa0JBQUQsQ0FBb0IsQ0FBcEIsRUFBUDtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxDLEVBRkY7S0FEWTtFQUFBLENBWGQsQ0FBQTs7QUFBQSx1QkFnQkEsTUFBQSxHQUFRLFNBQUMsQ0FBRCxHQUFBO0FBQ04sSUFBQSxDQUFBLElBQUssQ0FBQyxDQUFDLGNBQVAsSUFBeUIsQ0FBQyxDQUFDLGNBQUYsQ0FBQSxDQUF6QixDQUFBO0FBQ0EsSUFBQSxJQUFHLElBQUMsQ0FBQSxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQWIsR0FBc0IsQ0FBekI7YUFFRSxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLFFBQUMsUUFBQSxFQUFVLEdBQVg7QUFBQSxRQUFnQixVQUFBLEVBQVksV0FBNUI7T0FBeEIsRUFBa0UsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsS0FBRCxHQUFBO0FBQ2hFLFVBQUEsT0FBTyxDQUFDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCLEtBQXRCLENBQUEsQ0FBQTtpQkFDQSxpQkFBa0IsQ0FBQSxLQUFLLENBQUMsVUFBTixDQUFpQixDQUFDLE1BQXBDLENBQ0U7QUFBQSxZQUFBLEtBQUEsRUFBTyxLQUFDLENBQUEsS0FBSyxDQUFDLEtBQWQ7QUFBQSxZQUNBLE9BQUEsRUFBUyxLQUFDLENBQUEsY0FBYyxDQUFDLElBQWhCLENBQXFCLEtBQXJCLENBRFQ7V0FERixFQUZnRTtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxFLEVBRkY7S0FGTTtFQUFBLENBaEJSLENBQUE7O0FBQUEsdUJBMkJBLGNBQUEsR0FBZ0IsU0FBQyxRQUFELEdBQUE7QUFDWixJQUFBLElBQUMsQ0FBQSxLQUFELENBQU8sSUFBQyxDQUFBLE1BQVIsQ0FBQSxDQUFBO1dBQ0EsSUFBQyxDQUFBLE1BQU0sQ0FBQyxXQUFSLENBQW9CLFFBQXBCLEVBRlk7RUFBQSxDQTNCaEIsQ0FBQTs7QUFBQSx1QkErQkEsS0FBQSxHQUFPLFNBQUMsRUFBRCxHQUFBO0FBQ0wsUUFBQSxRQUFBO0FBQUE7V0FBTyxFQUFFLENBQUMsU0FBVixHQUFBO0FBQ0Usb0JBQUEsRUFBRSxDQUFDLFdBQUgsQ0FBZSxFQUFFLENBQUMsU0FBbEIsRUFBQSxDQURGO0lBQUEsQ0FBQTtvQkFESztFQUFBLENBL0JQLENBQUE7O0FBQUEsdUJBbUNBLGtCQUFBLEdBQW9CLFNBQUMsQ0FBRCxHQUFBO0FBQ2xCLFFBQUEsY0FBQTtBQUFBLElBQUEsQ0FBQyxDQUFDLGNBQUYsQ0FBQSxDQUFBLENBQUE7QUFBQSxJQUNBLFFBQUEsR0FBVyxDQUFDLEdBQUQsRUFBTSxHQUFOLENBRFgsQ0FBQTtBQUVBLElBQUEsV0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQVQsRUFBQSxlQUFvQixRQUFwQixFQUFBLElBQUEsTUFBSDtBQUNFLE1BQUEsSUFBQyxDQUFBLEtBQUssQ0FBQyxLQUFQLEdBQWUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUF4QixDQUFBO2FBQ0EsSUFBQyxDQUFBLE1BQUQsQ0FBUSxDQUFSLEVBRkY7S0FIa0I7RUFBQSxDQW5DcEIsQ0FBQTs7QUFBQSx1QkEwQ0EsUUFBQSxHQUFVLFNBQUEsR0FBQTtBQUNSLFdBQU8sSUFBQyxDQUFBLEtBQUssQ0FBQyxLQUFkLENBRFE7RUFBQSxDQTFDVixDQUFBOztvQkFBQTs7SUFuQkYsQ0FBQTs7QUFBQSxNQWdGTSxDQUFDLE9BQVAsR0FBaUIsVUFoRmpCLENBQUE7Ozs7QUNBQTtBQUFBLGtCQUFBO0FBQ0E7QUFBQTs7Ozs7Ozs7OztHQURBO0FBQUEsSUFBQSxnQkFBQTs7QUFBQSxVQWFBLEdBQWEsT0FBQSxDQUFRLGlCQUFSLENBYmIsQ0FBQTs7QUFBQTtBQWdCZSxFQUFBLGNBQUEsR0FBQTtBQUNYLElBQUEsSUFBQyxDQUFBLFdBQUQsR0FBZSx3QkFBZixDQUFBO0FBQUEsSUFDQSxJQUFDLENBQUEsUUFBRCxHQUFZLE1BRFosQ0FBQTtBQUFBLElBRUEsSUFBQyxDQUFBLElBQUQsR0FBUSxrQkFGUixDQUFBO0FBQUEsSUFHQSxJQUFDLENBQUEsSUFBRCxHQUFRLFVBSFIsQ0FBQTtBQUFBLElBSUEsSUFBQyxDQUFBLEtBQUQsR0FBUyxLQUpULENBQUE7QUFBQSxJQUtBLElBQUMsQ0FBQSxJQUFELEdBQVEsWUFMUixDQUFBO0FBQUEsSUFNQSxJQUFDLENBQUEsR0FBRCxHQUFPLEVBTlAsQ0FEVztFQUFBLENBQWI7O0FBU0E7QUFBQTs7S0FUQTs7QUFBQSxpQkFZQSxLQUFBLEdBQU8sU0FBQyxJQUFELEdBQUE7QUFDTCxRQUFBLGFBQUE7QUFBQSxJQUFBLElBQUcsTUFBQSxDQUFBLElBQVcsQ0FBQyxNQUFaLEtBQXNCLE1BQXRCLElBQW1DLElBQUksQ0FBQyxNQUFMLEtBQWUsSUFBckQ7QUFDRSxNQUFBLElBQUksQ0FBQyxNQUFMLEdBQWMsSUFBZCxDQURGO0tBQUE7QUFBQSxJQUVBLGFBQUEsR0FBZ0IsSUFBQyxDQUFBLGlCQUFELENBQW1CLElBQUksQ0FBQyxhQUF4QixDQUZoQixDQUFBO1dBR0EsSUFBQyxDQUFBLE1BQUQsQ0FDSTtBQUFBLE1BQUEsS0FBQSxFQUFPLGFBQVA7QUFBQSxNQUNBLE9BQUEsRUFBUyxJQUFDLENBQUEsZUFBZSxDQUFDLElBQWpCLENBQXNCLElBQXRCLENBRFQ7QUFBQSxNQUVBLE1BQUEsRUFBUSxJQUFJLENBQUMsTUFGYjtLQURKLEVBSks7RUFBQSxDQVpQLENBQUE7O0FBcUJBO0FBQUE7O0tBckJBOztBQUFBLGlCQXdCQSxpQkFBQSxHQUFtQixTQUFDLElBQUQsR0FBQTtXQUNqQixJQUFJLENBQUMsT0FBTCxDQUFhLE9BQWIsRUFBc0IsRUFBdEIsRUFEaUI7RUFBQSxDQXhCbkIsQ0FBQTs7QUEyQkE7QUFBQTs7S0EzQkE7O0FBQUEsaUJBOEJBLE1BQUEsR0FBUSxTQUFDLE1BQUQsR0FBQTtXQUVOLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsTUFBQyxRQUFBLEVBQVUsR0FBWDtLQUF4QixFQUF5QyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxLQUFELEdBQUE7QUFDdkMsWUFBQSwwQkFBQTtBQUFBLFFBQUEsSUFBRyxRQUFBLEtBQVksRUFBZjtBQUNFLFVBQUEsUUFBQSxHQUFXLEdBQVgsQ0FERjtTQUFBO0FBQUEsUUFFQSxLQUFDLENBQUEsV0FBRCxDQUFhLEtBQUssQ0FBQyxRQUFuQixDQUZBLENBQUE7QUFBQSxRQUdBLEdBQUEsR0FBTSxLQUFDLENBQUEsT0FBRCxDQUFTLE1BQU0sQ0FBQyxLQUFoQixDQUhOLENBQUE7QUFBQSxRQUtBLFdBQUEsR0FBYyxNQUFNLENBQUMsT0FMckIsQ0FBQTtBQUFBLFFBTUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsU0FBQyxRQUFELEdBQUE7QUFDZixjQUFBLFVBQUE7QUFBQSxVQUFBLFVBQUEsR0FBYSxLQUFDLENBQUEsS0FBRCxDQUFPLFFBQVAsRUFBaUIsTUFBTSxDQUFDLE1BQXhCLENBQWIsQ0FBQTtpQkFDQSxXQUFBLENBQVksVUFBWixFQUZlO1FBQUEsQ0FOakIsQ0FBQTtlQVdBLEtBQUMsQ0FBQSxPQUFELENBQ0U7QUFBQSxVQUFBLEdBQUEsRUFBSyxHQUFMO0FBQUEsVUFDQSxPQUFBLEVBQVMsTUFBTSxDQUFDLE9BRGhCO0FBQUEsVUFFQSxLQUFBLEVBQU8sTUFBTSxDQUFDLEtBRmQ7U0FERixFQVp1QztNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpDLEVBRk07RUFBQSxDQTlCUixDQUFBOztBQUFBLGlCQW1EQSxXQUFBLEdBQWEsU0FBQyxRQUFELEdBQUE7QUFDWCxJQUFBLElBQUMsQ0FBQSxlQUFELEdBQW1CLFFBQW5CLENBQUE7V0FDQSxJQUFDLENBQUEsSUFBRCxHQUFRLFdBQUEsR0FBYyxTQUZYO0VBQUEsQ0FuRGIsQ0FBQTs7QUF1REE7QUFBQTs7O0tBdkRBOztBQUFBLGlCQTJEQSxPQUFBLEdBQVMsU0FBQyxJQUFELEdBQUE7QUFDUCxRQUFBLEdBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxJQUFDLENBQUEsR0FBRCxHQUFXLElBQUEsY0FBQSxDQUFBLENBQWpCLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxrQkFBSixHQUF5QixDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7QUFDdkIsUUFBQSxHQUFBLEdBQU0sS0FBQyxDQUFBLEdBQVAsQ0FBQTtBQUNBLFFBQUEsSUFBRyxHQUFHLENBQUMsVUFBSixHQUFpQixDQUFwQjtBQUFBO1NBQUEsTUFFSyxJQUFHLEdBQUcsQ0FBQyxNQUFKLEtBQWMsR0FBakI7QUFDSCxVQUFBLEtBQUMsQ0FBQSxZQUFELENBQWMsR0FBZCxDQUFBLENBQUE7QUFDQSxVQUFBLElBQUksTUFBQSxDQUFBLElBQVcsQ0FBQyxLQUFaLEtBQXFCLFVBQXpCO0FBQ0UsWUFBQSxJQUFJLENBQUMsS0FBTCxDQUFBLENBQUEsQ0FERjtXQUZHO1NBQUEsTUFLQSxJQUFHLEdBQUcsQ0FBQyxVQUFKLEtBQWtCLENBQXJCO0FBQ0QsaUJBQU8sSUFBSSxDQUFDLE9BQUwsQ0FBYSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQXRCLENBQVAsQ0FEQztTQVRrQjtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRHpCLENBQUE7QUFBQSxJQWFBLEdBQUcsQ0FBQyxJQUFKLENBQVMsS0FBVCxFQUFnQixJQUFJLENBQUMsR0FBckIsRUFBMEIsSUFBMUIsQ0FiQSxDQUFBO1dBY0EsR0FBRyxDQUFDLElBQUosQ0FBQSxFQWZPO0VBQUEsQ0EzRFQsQ0FBQTs7QUFBQSxpQkE2RUEsT0FBQSxHQUFTLFNBQUMsS0FBRCxHQUFBO0FBQ1AsUUFBQSxHQUFBO0FBQUEsSUFBQSxHQUFBLEdBQU0sQ0FBQyxJQUFDLENBQUEsUUFBRixFQUFZLEtBQVosRUFDSSxJQUFDLENBQUEsSUFETCxFQUVJLElBQUMsQ0FBQSxJQUZMLEVBR0ksSUFBQyxDQUFBLElBSEwsRUFJSSxJQUFDLENBQUEsS0FKTCxFQUtJLElBQUMsQ0FBQSxlQUFELENBQWlCLEtBQWpCLENBTEosQ0FNQyxDQUFDLElBTkYsQ0FNTyxFQU5QLENBQU4sQ0FBQTtBQVFBLFdBQU8sR0FBUCxDQVRPO0VBQUEsQ0E3RVQsQ0FBQTs7QUFBQSxpQkF5RkEsZUFBQSxHQUFpQixTQUFDLEtBQUQsR0FBQTtBQUVmLFFBQUEsZUFBQTtBQUFBLElBQUEsR0FBQSxHQUFNLGtCQUFBLENBQW1CLEtBQW5CLENBQU4sQ0FBQTtBQUNBLFNBQUEsa0JBQUE7OEJBQUE7QUFDRSxNQUFBLEdBQUEsR0FBTSxHQUFHLENBQUMsT0FBSixDQUFZLElBQVosRUFBa0Isa0JBQUEsQ0FBbUIsSUFBbkIsQ0FBbEIsQ0FBTixDQURGO0FBQUEsS0FEQTtBQUdBLFdBQU8sR0FBUCxDQUxlO0VBQUEsQ0F6RmpCLENBQUE7O0FBQUEsaUJBZ0dBLFlBQUEsR0FBYyxTQUFDLEdBQUQsR0FBQTtXQUNaLE9BQU8sQ0FBQyxHQUFSLENBQVksT0FBWixFQUFxQixHQUFyQixFQURZO0VBQUEsQ0FoR2QsQ0FBQTs7QUFtR0E7QUFBQTs7S0FuR0E7O0FBQUEsaUJBc0dBLGVBQUEsR0FBaUIsU0FBQyxVQUFELEdBQUE7QUFDZixJQUFBLElBQUcsVUFBSDthQUNFLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBWixDQUF3QixJQUF4QixFQUE4QixDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxHQUFELEdBQUE7aUJBQzVCLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBWixDQUF3QixHQUFHLENBQUMsRUFBNUIsRUFBZ0M7QUFBQSxZQUM5QixNQUFBLEVBQVEsS0FBQyxDQUFBLFdBQUQsQ0FBYSxVQUFiLENBRHNCO0FBQUEsWUFFOUIsSUFBQSxFQUFNLFVBQVUsQ0FBQyxTQUZhO0FBQUEsWUFHOUIsT0FBQSxFQUFTLENBQUEsVUFBVyxDQUFDLFNBQVMsQ0FBQyxRQUFyQixDQUE4QixlQUE5QixDQUhvQjtXQUFoQyxFQUQ0QjtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQTlCLEVBREY7S0FEZTtFQUFBLENBdEdqQixDQUFBOztBQUFBLGlCQWdIQSxXQUFBLEdBQWEsU0FBQyxVQUFELEdBQUE7QUFDWCxRQUFBLElBQUE7QUFBQSxJQUFBLGlFQUFtQixDQUFFLHlCQUFsQixLQUE0QixDQUEvQjthQUNFLGdCQURGO0tBQUEsTUFBQTthQUdFLGVBSEY7S0FEVztFQUFBLENBaEhiLENBQUE7O0FBc0hBO0FBQUE7O0tBdEhBOztBQUFBLGlCQXlIQSxLQUFBLEdBQU8sU0FBQyxRQUFELEVBQVcsTUFBWCxFQUFtQixTQUFuQixHQUFBO0FBQ0gsUUFBQSxhQUFBOztNQURzQixZQUFZO0tBQ2xDO0FBQUEsSUFBQSxHQUFBLEdBQU0sSUFBQyxDQUFBLFlBQUQsQ0FBYyxRQUFkLENBQU4sQ0FBQTtBQUFBLElBQ0EsUUFBQSxHQUFXLElBQUMsQ0FBQSxZQUFELENBQWMsR0FBZCxDQURYLENBQUE7QUFFQSxJQUFBLElBQUcsUUFBSDtBQUNFLE1BQUEsU0FBQSxHQUFZLFFBQVEsQ0FBQyxhQUFULENBQXVCLHNCQUF2QixDQUFaLENBQUE7QUFDQSxNQUFBLElBQUcsU0FBSDtBQUNFLFFBQUEsU0FBUyxDQUFDLFNBQVYsR0FBc0IsSUFBQyxDQUFBLFdBQXZCLENBQUE7QUFBQSxRQUNBLFNBQVMsQ0FBQyxZQUFWLENBQXVCLGFBQXZCLEVBQXNDLEdBQXRDLENBREEsQ0FBQTtBQUFBLFFBRUEsSUFBQyxDQUFBLFNBQUQsQ0FBVyxTQUFYLENBRkEsQ0FBQTtBQUFBLFFBR0EsSUFBQyxDQUFBLFFBQUQsQ0FBVSxTQUFWLENBSEEsQ0FERjtPQUFBLE1BS0ssSUFBRyxDQUFBLE1BQUg7QUFDSCxRQUFBLFNBQUEsR0FBWSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFaLENBQUE7QUFBQSxRQUNBLFNBQVMsQ0FBQyxTQUFWLEdBQXNCLGVBRHRCLENBQUE7QUFBQSxRQUVBLFNBQVMsQ0FBQyxTQUFWLEdBQXNCLG9DQUZ0QixDQURHO09BUFA7S0FGQTtBQWNBLFdBQU8sU0FBUCxDQWZHO0VBQUEsQ0F6SFAsQ0FBQTs7QUEwSUE7QUFBQTs7S0ExSUE7O0FBQUEsaUJBNklBLFlBQUEsR0FBYyxTQUFDLENBQUQsR0FBQTtBQUNaLFFBQUEsZUFBQTtBQUFBLElBQUEsR0FBQSxHQUFNLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCLENBQU4sQ0FBQTtBQUFBLElBQ0EsR0FBRyxDQUFDLFNBQUosR0FBZ0IsQ0FEaEIsQ0FBQTtBQUFBLElBRUEsT0FBQSxHQUFVLEdBQUcsQ0FBQyxvQkFBSixDQUF5QixRQUF6QixDQUZWLENBQUE7QUFBQSxJQUdBLENBQUEsR0FBSSxPQUFPLENBQUMsTUFIWixDQUFBO0FBSUEsV0FBTSxDQUFBLEVBQU4sR0FBQTtBQUNFLE1BQUEsT0FBUSxDQUFBLENBQUEsQ0FBRSxDQUFDLFVBQVUsQ0FBQyxXQUF0QixDQUFrQyxPQUFRLENBQUEsQ0FBQSxDQUExQyxDQUFBLENBREY7SUFBQSxDQUpBO0FBTUEsV0FBTyxHQUFHLENBQUMsU0FBWCxDQVBZO0VBQUEsQ0E3SWQsQ0FBQTs7QUFBQSxpQkFzSkEsWUFBQSxHQUFjLFNBQUMsR0FBRCxFQUFNLFFBQU4sR0FBQTtBQUNaLFFBQUEsR0FBQTs7TUFEa0IsV0FBVztLQUM3QjtBQUFBLElBQUEsR0FBQSxHQUFNLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCLENBQU4sQ0FBQTtBQUFBLElBQ0EsR0FBRyxDQUFDLFNBQUosR0FBZ0IsR0FEaEIsQ0FBQTtBQUFBLElBRUEsUUFBQSxHQUFXLFFBQVEsQ0FBQyxzQkFBVCxDQUFBLENBRlgsQ0FBQTtBQUdBLFdBQVEsR0FBRyxDQUFDLFVBQVosR0FBQTtBQUNFLE1BQUEsUUFBUSxDQUFDLFdBQVQsQ0FBc0IsR0FBRyxDQUFDLFVBQTFCLENBQUEsQ0FERjtJQUFBLENBSEE7QUFLQSxXQUFPLFFBQVAsQ0FOWTtFQUFBLENBdEpkLENBQUE7O0FBQUEsaUJBOEpBLFNBQUEsR0FBVyxTQUFDLFFBQUQsR0FBQTs7TUFBQyxXQUFTO0tBQ25CO0FBQUEsSUFBQSxJQUFJLENBQUMsTUFBTCxDQUFZLFFBQVosRUFBc0IsS0FBdEIsRUFBNkIsS0FBN0IsQ0FBQSxDQUFBO0FBQ0EsV0FBTyxRQUFQLENBRlM7RUFBQSxDQTlKWCxDQUFBOztBQUFBLGlCQWtLQSxRQUFBLEdBQVUsU0FBQyxRQUFELEdBQUE7O01BQUMsV0FBUztLQUNsQjtBQUFBLElBQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxRQUFaLEVBQXNCLEdBQXRCLEVBQTJCLE1BQTNCLENBQUEsQ0FBQTtBQUNBLFdBQU8sUUFBUCxDQUZRO0VBQUEsQ0FsS1YsQ0FBQTs7QUFBQSxpQkFzS0EsTUFBQSxHQUFRLFNBQUMsUUFBRCxFQUFnQixHQUFoQixFQUFxQixJQUFyQixHQUFBO0FBQ04sUUFBQSxnQ0FBQTs7TUFETyxXQUFTO0tBQ2hCO0FBQUEsSUFBQSxJQUFHLFFBQUg7QUFDRSxNQUFBLElBQUEsR0FBUSxRQUFRLENBQUMsZ0JBQVQsQ0FBMEIsR0FBMUIsQ0FBUixDQUFBO0FBQUEsTUFDQSxNQUFBLEdBQVMsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsR0FBdkIsQ0FEVCxDQUFBO0FBRUE7V0FBQSwyQ0FBQTt1QkFBQTtBQUNFLFFBQUEsTUFBTSxDQUFDLElBQVAsR0FBYyxHQUFJLENBQUEsSUFBQSxDQUFsQixDQUFBO0FBQUEsUUFDQSxNQUFNLENBQUMsSUFBUCxHQUFjLElBQUMsQ0FBQSxJQURmLENBQUE7QUFBQSxRQUVBLE1BQU0sQ0FBQyxRQUFQLEdBQWtCLElBQUMsQ0FBQSxRQUZuQixDQUFBO0FBSUEsUUFBQSxJQUFHLEdBQUcsQ0FBQyxPQUFKLEtBQWUsR0FBbEI7QUFDRSxVQUFBLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBZCxDQUFrQixVQUFsQixDQUFBLENBQUE7QUFDQSxVQUFBLElBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFoQixDQUF3QixPQUF4QixDQUFBLEtBQXNDLENBQUEsQ0FBekM7QUFDRSxZQUFBLE1BQU0sQ0FBQyxRQUFQLEdBQWtCLElBQUEsR0FBTyxNQUFNLENBQUMsUUFBaEMsQ0FBQTtBQUFBLFlBQ0EsR0FBRyxDQUFDLFlBQUosQ0FBaUIsUUFBakIsRUFBMkIsUUFBM0IsQ0FEQSxDQURGO1dBRkY7U0FBQSxNQUtLLElBQUcsR0FBRyxDQUFDLE9BQUosS0FBZSxLQUFsQjtBQUNILFVBQUEsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFkLENBQWtCLFNBQWxCLENBQUEsQ0FERztTQVRMO0FBQUEsc0JBWUEsR0FBRyxDQUFDLFlBQUosQ0FBaUIsSUFBakIsRUFBdUIsTUFBTSxDQUFDLElBQTlCLEVBWkEsQ0FERjtBQUFBO3NCQUhGO0tBRE07RUFBQSxDQXRLUixDQUFBOztjQUFBOztJQWhCRixDQUFBOztBQUFBLE1BMk1NLENBQUMsT0FBUCxHQUFpQixHQUFBLENBQUEsSUEzTWpCLENBQUE7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKX12YXIgZj1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwoZi5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxmLGYuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwidmFyIENIQVJfQ09ERVMgPSB7XG4gIC8vIHR1cmtpc2hkaWN0aW9uYXJ5IGNvZGluZ3NcbiAgJyVDNCVCMSc6ICclRkQnLCAvL8SxIChMb3dlcmNhc2UgaS1kb3RsZXNzKSAgYWN0dWFsbHkgaXQgaXMgJiMzMDU7IGJ1dCB0dXJraXNoZGljdGlvbmFyeSBuZWVkIGl0IHRoaXMgd2F5IFxuICAnJUM1JTlGJzogJyVGRScsIC8vxZ9cbiAgJyVDNCU5Ric6ICclRjAnLCAvL8SfICAoc2lsZW50IGNoYXJhY3RlcilcbiAgJyVDMyVBNyc6ICclRTcnLCAvL8OnXG4gICclQzMlQjYnOiAnJUY2JywgLy/DtlxuICAnJUMzJUJDJzogJyVGQycgLy/DvFxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IENIQVJfQ09ERVM7IiwiLypcciAgTXVsdGl0cmFuIGRlcGVuZHMgb24gaHRtbC1lc2NhcGluZyAobm90IFVURi04KSBydWxlcyBmb3Igc3BlY2lhbCBzeW1ib2xzXHIgIMOgLCDDqCwgw6wsIMOyLCDDuSAtIMOALCDDiCwgw4wsIMOSLCDDmVxyICDDoSwgw6ksIMOtLCDDsywgw7osIMO9IC0gw4EsIMOJLCDDjSwgw5MsIMOaLCDDnVxyICDDoiwgw6osIMOuLCDDtCwgw7sgw4IsIMOKLCDDjiwgw5QsIMObXHIgIMOjLCDDsSwgw7Ugw4MsIMORLCDDlVxyICDDpCwgw6ssIMOvLCDDtiwgw7wsIMO/IMOELCDDiywgw48sIMOWLCDDnCxcciAgw6UsIMOFXHIgIMOmLCDDhlxyICDDpywgw4dcciAgw7AsIMOQXHIgIMO4LCDDmFxyICDCvyDCoSDDn1xyKi9ccnZhciBDSEFSX0NPREVTID0ge1xyICAnJUMzJTgwJzogJyYjMTkyOycsIC8vIMOAXHIgICclQzMlODEnOiAnJiMxOTM7JywgLy8gw4FcciAgJyVDMyU4Mic6ICcmIzE5NDsnLCAvLyDDglxyICAnJUMzJTgzJzogJyYjMTk1OycsIC8vIMODXHIgICclQzMlODQnOiAnJiMxOTY7JywgLy8gw4RcciAgJyVDMyU4NSc6ICcmIzE5NzsnLCAvLyDDhVxyICAnJUMzJTg2JzogJyYjMTk4OycsIC8vIMOGXHJcciAgJyVDMyU4Nyc6ICcmIzE5OTsnLCAvLyDDh1xyICAnJUMzJTg4JzogJyYjMjAwOycsIC8vIMOIXHIgICclQzMlODknOiAnJiMyMDE7JywgLy8gw4lcciAgJyVDMyU4QSc6ICcmIzIwMjsnLCAvLyDDilxyICAnJUMzJThCJzogJyYjMjAzOycsIC8vIMOLXHJcciAgJyVDMyU4Qyc6ICcmIzIwNDsnLCAvLyDDjFxyICAnJUMzJThEJzogJyYjMjA1OycsIC8vIMONXHIgICclQzMlOEUnOiAnJiMyMDY7JywgLy8gw45cciAgJyVDMyU4Ric6ICcmIzIwNzsnLCAvLyDDj1xyXHIgICclQzMlOTEnOiAnJiMyMDk7JywgLy8gw5FcciAgJyVDMyU5Mic6ICcmIzIxMDsnLCAvLyDDklxyICAnJUMzJTkzJzogJyYjMjExOycsIC8vIMOTXHIgICclQzMlOTQnOiAnJiMyMTI7JywgLy8gw5RcciAgJyVDMyU5NSc6ICcmIzIxMzsnLCAvLyDDlVxyICAnJUMzJTk2JzogJyYjMjE0OycsIC8vIMOWXHJcciAgJyVDMyU5OSc6ICcmIzIxNzsnLCAvLyDDmVxyICAnJUMzJTlBJzogJyYjMjE4OycsIC8vIMOaXHIgICclQzMlOUInOiAnJiMyMTk7JywgLy8gw5tcciAgJyVDMyU5Qyc6ICcmIzIyMDsnLCAvLyDDnFxyXHJcciAgJyVDMyVBMCc6ICcmIzIyNDsnLCAvLyDDoFxyICAnJUMzJUExJzogJyYjMjI1OycsIC8vIMOhXHIgICclQzMlQTInOiAnJiMyMjY7JywgLy8gw6JcciAgJyVDMyVBMyc6ICcmIzIyNzsnLCAvLyDDo1xyICAnJUMzJUE0JzogJyYjMjI4OycsIC8vIMOkXHIgICclQzMlQTUnOiAnJiMyMjk7JywgLy8gw6VcciAgJyVDMyVBNic6ICcmIzIzMDsnLCAvLyDDplxyICAnJUMzJUE3JzogJyYjMjMxOycsIC8vIMOnXHJcclxyICAnJUMzJUE4JzogJyYjMjMyOycsIC8vIMOoXHIgICclQzMlQTknOiAnJiMyMzM7JywgLy8gw6lcciAgJyVDMyVBQSc6ICcmIzIzNDsnLCAvLyDDqlxyICAnJUMzJUFCJzogJyYjMjM1OycsIC8vIMOrXHJcciAgJyVDMyVBQyc6ICcmIzIzNjsnLCAvLyDDrFxyICAnJUMzJUFEJzogJyYjMjM3OycsIC8vIMOtXHIgICclQzMlQUUnOiAnJiMyMzg7JywgLy8gw65cciAgJyVDMyVBRic6ICcmIzIzOTsnLCAvLyDDr1xyXHIgICclQzMlQjAnOiAnJiMyNDA7JywgLy8gw7BcciAgJyVDMyVCMSc6ICcmIzI0MTsnLCAvLyDDsVxyXHIgICclQzMlQjInOiAnJiMyNDI7JywgLy8gw7JcciAgJyVDMyVCMyc6ICcmIzI0MzsnLCAvLyDDs1xyICAnJUMzJUI0JzogJyYjMjQ0OycsIC8vIMO0XHIgICclQzMlQjUnOiAnJiMyNDU7JywgLy8gw7VcciAgJyVDMyVCNic6ICcmIzI0NjsnLCAvLyDDtlxyXHIgICclQzMlQjknOiAnJiMyNDk7JywgLy8gw7lcciAgJyVDMyVCQSc6ICcmIzI1MDsnLCAvLyDDulxyICAnJUMzJUJCJzogJyYjMjUxOycsIC8vIMO7XHIgICclQzMlQkMnOiAnJiMyNTI7JywgLy8gw7xcciAgJyVDMyVCRic6ICcmIzI1NTsnLCAvLyDDv1xyICAnJUM1JUI4JzogJyYjMzc2OycsIC8vIMW4XHJcciAgJyVDMyU5Ric6ICcmIzIyMzsnLCAvLyDDn1xyXHIgICclQzIlQkYnOiAnJiMxOTE7JywgLy8gwr9cciAgJyVDMiVBMSc6ICcmIzE2MTsnLCAvLyDCoVxyfTtcclxybW9kdWxlLmV4cG9ydHMgPSBDSEFSX0NPREVTO1xyIiwiIyMjXG4gIERyb3Bkb3duIGxhbmd1YWdlIG1lbnVcbiAgQHBhcmFtIG9wdHMgdGFrZXMgZWxlbWVudCBhbmQgb25TZWxlY3QgaGFuZGxlclxuICBleGFtcGxlOlxuICBuZXcgRHJvcGRvd24oe1xuICAgZWw6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCcjbWVudScpO1xuICAgb25TZWxlY3Q6IGZ1bmN0aW9uICgpIHt9XG4gIH0pXG4jIyNcbkxBTkdfQ09ERSA9XG4gICcxJzogJ0VuZydcbiAgJzInOiAnUnVzJ1xuICAnMyc6ICdHZXInXG4gICc0JzogJ0ZyZSdcbiAgJzUnOiAnU3BhJ1xuICAnMjMnOiAnSXRhJ1xuICAnMjQnOiAnRHV0J1xuICAnMjYnOiAnRXN0J1xuICAnMjcnOiAnTGF2J1xuICAnMzEnOiAnQWZyJ1xuICAnMzQnOiAnRXBvJ1xuICAnMzUnOiAnWGFsJyxcbiAgJzEwMDAnOiAnVHVyJ1xuXG5ESUNUX0NPREUgPVxuICAnMSc6ICdtdWx0aXRyYW4nXG4gICcxMDAwJzogJ3R1cmtpc2gnXG5cbmNsYXNzIERyb3Bkb3duXG4gIGNvbnN0cnVjdG9yOiAob3B0cykgLT5cbiAgICBAZWwgPSBvcHRzLmVsIG9yIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgIyBvblNlbGVjdCBoYW5kbGVyIHNldCBieSBhZ2dyZWdhdGUgY2xhc3NcbiAgICBAb25TZWxlY3QgPSBvcHRzLm9uU2VsZWN0XG5cbiAgICBAbWVudSA9IEBlbC5xdWVyeVNlbGVjdG9yKCcuZHJvcGRvd24tbWVudScpXG4gICAgaWYgQG1lbnVcbiAgICAgIEBtZW51LnN0eWxlLmRpc3BsYXkgPSAnbm9uZSdcbiAgICAgIEBpdGVtcyA9IEBtZW51LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoJ2xhbmd1YWdlLXR5cGUnKVxuICAgICAgQGJ1dHRvbiA9IEBlbC5xdWVyeVNlbGVjdG9yKCcuZHJvcGRvd24tdG9nZ2xlJylcbiAgICAgIEBhZGRMaXN0ZW5lcnMoKVxuICAgICAgQGluaXRMYW5ndWFnZSgpXG5cbiAgYWRkTGlzdGVuZXJzOiAtPlxuICAgIEBidXR0b24uYWRkRXZlbnRMaXN0ZW5lciAnY2xpY2snLCAoZSkgPT4gQHRvZ2dsZShlKVxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIgJ2NsaWNrJywgKGUpID0+IEBoaWRlKGUpXG4gICAgQG1lbnUuYWRkRXZlbnRMaXN0ZW5lciAnY2xpY2snLCAoZSkgPT4gQGNob29zZShlKVxuXG4gICMgT24gaW5pdCB0cnlpbmcgdG8gZ2V0IGN1cnJlbnQgbGFuZ3VhZ2UgZnJvbSBzdG9yYWdlIG9yIHVzaW5nIGRlZmF1bHQoIDE6ZW5nbGlzaClcbiAgaW5pdExhbmd1YWdlOiAtPlxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHsgbGFuZ3VhZ2U6ICcxJ30sIChzdG9yZSkgPT5cbiAgICAgIEBzZXRUaXRsZShzdG9yZS5sYW5ndWFnZSk7XG4gICAgKVxuXG4gIHRvZ2dsZTogKGUpIC0+XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKVxuICAgIEBzZXRBY3RpdmVJdGVtKClcbiAgICBpZiBAbWVudSBhbmQgQG1lbnUuc3R5bGUuZGlzcGxheSBpcyAnbm9uZSdcbiAgICAgIEBzaG93KClcbiAgICBlbHNlXG4gICAgICBAaGlkZSgpXG5cbiAgIyBSZWFkIGN1cnJlbnQgbGFuZ3VhZ2UgZnJvbSBDaHJvbWUgU3RvcmFnZSBhbmQgY29sb3IgYWN0aXZlIGxpbmVcbiAgc2V0QWN0aXZlSXRlbTogLT5cbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCB7bGFuZ3VhZ2U6ICcxJ30sIChzdG9yZSkgPT5cbiAgICAgIGZvciBpdGVtIGluIEBpdGVtc1xuICAgICAgICBpZiBpdGVtLmdldEF0dHJpYnV0ZSgnZGF0YS12YWwnKSA9PSBzdG9yZS5sYW5ndWFnZVxuICAgICAgICAgIGl0ZW0uY2xhc3NMaXN0LmFkZCgnYWN0aXZlJylcbiAgICAgICAgZWxzZVxuICAgICAgICAgIGl0ZW0uY2xhc3NMaXN0LnJlbW92ZSgnYWN0aXZlJylcblxuICBoaWRlOiAtPlxuICAgIEBtZW51LnN0eWxlLmRpc3BsYXkgPSAnbm9uZSdcblxuICBzaG93OiAtPlxuICAgIEBtZW51LnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snXG5cbiAgIyBTYXZlcyBjaG9zZW4gbGFuZ3VhZ2UgdG8gY2hyb21lLnN0b3JhZ2UgYW5kIGRlY2lkZSB3aGljaCBkaWN0aW9uYXJ5IHRvIHVzZVxuICAjIFRoZW4gY2FsbGVkIG9uU2VsZWN0IGhhbmRsZXIgb2YgdGhlIGNvbnRhaW5lciBjbGFzc1xuICBjaG9vc2U6IChlKSAtPlxuICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBsYW5ndWFnZSA9IGUudGFyZ2V0LmdldEF0dHJpYnV0ZSgnZGF0YS12YWwnKVxuICAgIGRpY3Rpb25hcnkgPSBAZ2V0RGljdGlvbmFyeShsYW5ndWFnZSlcbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLnNldCh7bGFuZ3VhZ2U6IGxhbmd1YWdlLCBkaWN0aW9uYXJ5OiBkaWN0aW9uYXJ5fSwgQG9uU2VsZWN0KVxuICAgIEBzZXRUaXRsZShsYW5ndWFnZSlcbiAgICBAaGlkZSgpXG5cbiAgIyBTb21lIGxhbmd1YWdlcyBhcmUgbm90IHByZXNlbnQgaW4gbXVsdGl0cmFuIChlLmcuIHR1cmtpc2gpXG4gICMgc28gd2UgY2hvb3NlIGFub3RoZXIgc2VydmljZVxuICBnZXREaWN0aW9uYXJ5OiAobGFuZykgLT5cbiAgICBjb25zb2xlLmxvZygnY2hvb3NlIGRpY3Q6IGZvcicsbGFuZyk7XG4gICAgZGljdCA9IERJQ1RfQ09ERVtsYW5nXSB8fCAnbXVsdGl0cmFuJ1xuICAgIGNvbnNvbGUubG9nKCdkaWN0JyxkaWN0KVxuICAgIHJldHVybiBkaWN0XG5cbiAgI1NldCBjdXJyZW50IGxhbmd1YWdlIGxhYmVsXG4gIHNldFRpdGxlOiAobGFuZ3VhZ2UpIC0+XG4gICAgaHRtbCA9IExBTkdfQ09ERVtsYW5ndWFnZV0gKyAnIDxzcGFuIGNsYXNzPVwiY2FyZXRcIj48L3NwYW4+J1xuICAgIEBidXR0b24uaW5uZXJIVE1MID0gaHRtbFxuXG5cbm1vZHVsZS5leHBvcnRzID0gRHJvcGRvd24iLCIjIyNcbiAgRXh0ZW5zaW9uIHBvcHVwIHdpbmRvd1xuICBTaG93cyBzZWFyY2ggZm9ybSBhbmQgZHJvcGRvd24gbWVudSB3aXRoIGxhbmd1YWdlc1xuIyMjXG5TZWFyY2hGb3JtID0gcmVxdWlyZSgnLi9zZWFyY2hfZm9ybS5jb2ZmZWUnKVxuXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyIFwiRE9NQ29udGVudExvYWRlZFwiLCAtPlxuICBmb3JtID0gbmV3IFNlYXJjaEZvcm0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RyYW4tZm9ybScpXG4gIGxpbmsgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnaGVhZGVyLWxpbmsnKVxuICBpZiBsaW5rXG4gICAgbGluay5hZGRFdmVudExpc3RlbmVyICdjbGljaycsIChlKSAtPlxuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgaHJlZiA9IGUudGFyZ2V0LmdldEF0dHJpYnV0ZSgnaHJlZicpICsgZm9ybS5nZXRWYWx1ZSgpXG4gICAgICBjaHJvbWUudGFicy5jcmVhdGUoeyB1cmw6IGhyZWYgfSlcbiIsIiMjI1xuICBTZXJ2ZXMgc2VhcmNoIGlucHV0IGFuZCBmb3JtXG5cbiAgQHBhcmFtIGZvcm0gRE9NIGVsZW1udFxuICBAY29uc3RydWN0b3JcbiMjI1xuRHJvcGRvd24gPSByZXF1aXJlKCcuL2Ryb3Bkb3duLmNvZmZlZScpXG5cbiN0cmFuc2xhdGUgZW5naW5lc1xudHJhbiA9IHJlcXVpcmUoJy4uL3RyYW4uY29mZmVlJylcbnR1cmtpc2hkaWN0aW9uYXJ5ID0gcmVxdWlyZSgnLi4vdHVya2lzaGRpY3Rpb25hcnkuanMnKVxuXG5cbiNUcmFuc2xhdGUgZW5naW5lc1xuVFJBTlNMQVRFX0VOR0lORVMgPVxuICAnbXVsdGl0cmFuJzogdHJhblxuICAndHVya2lzaCc6IHR1cmtpc2hkaWN0aW9uYXJ5XG5cbmNsYXNzIFNlYXJjaEZvcm1cbiAgY29uc3RydWN0b3I6IChAZm9ybSkgLT5cbiAgICBAaW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndHJhbnNsYXRlLXR4dCcpXG4gICAgQGlucHV0LmZvY3VzKClcblxuICAgIEByZXN1bHQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncmVzdWx0JylcbiAgICBAYWRkTGlzdGVuZXJzKCk7XG4gICAgQGRyb3Bkb3duID0gbmV3IERyb3Bkb3duKHtcbiAgICAgIGVsOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuZHJvcGRvd24tZWwnKSxcbiAgICAgIG9uU2VsZWN0OiA9PiBAc2VhcmNoKClcbiAgICB9KTtcblxuICBhZGRMaXN0ZW5lcnM6IC0+XG4gICAgaWYgQGZvcm0gYW5kIEByZXN1bHRcbiAgICAgIEBmb3JtLmFkZEV2ZW50TGlzdGVuZXIgJ3N1Ym1pdCcsIChlKSA9PiBAc2VhcmNoKGUpXG4gICAgICBAcmVzdWx0LmFkZEV2ZW50TGlzdGVuZXIgJ2NsaWNrJywgKGUpID0+IEByZXN1bHRDbGlja0hhbmRsZXIoZSlcblxuICBzZWFyY2g6IChlKSAtPlxuICAgIGUgJiYgZS5wcmV2ZW50RGVmYXVsdCAmJiBlLnByZXZlbnREZWZhdWx0KClcbiAgICBpZiBAaW5wdXQudmFsdWUubGVuZ3RoID4gMFxuICAgICAgI2Nob29zZSBlbmdpbmUgYW5kIHNlYXJjaCBmb3IgdHJhbnNsYXRpb24gKGJ5IGRlZmF1bHQgZW5nbGlzaC1tdWx0aXRyYW4pXG4gICAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7bGFuZ3VhZ2U6ICcxJywgZGljdGlvbmFyeTogJ211bHRpdHJhbid9LCAoaXRlbXMpID0+XG4gICAgICAgIGNvbnNvbGUubG9nKCdJVEVNUzonLCBpdGVtcyk7XG4gICAgICAgIFRSQU5TTEFURV9FTkdJTkVTW2l0ZW1zLmRpY3Rpb25hcnldLnNlYXJjaFxuICAgICAgICAgIHZhbHVlOiBAaW5wdXQudmFsdWVcbiAgICAgICAgICBzdWNjZXNzOiBAc3VjY2Vzc0hhbmRsZXIuYmluZChAKVxuICAgICAgKVxuXG4gIHN1Y2Nlc3NIYW5kbGVyOiAocmVzcG9uc2UpIC0+XG4gICAgICBAY2xlYW4oQHJlc3VsdClcbiAgICAgIEByZXN1bHQuYXBwZW5kQ2hpbGQocmVzcG9uc2UpXG5cbiAgY2xlYW46IChlbCkgLT5cbiAgICB3aGlsZSAoZWwubGFzdENoaWxkKVxuICAgICAgZWwucmVtb3ZlQ2hpbGQoZWwubGFzdENoaWxkKVxuXG4gIHJlc3VsdENsaWNrSGFuZGxlcjogKGUpIC0+XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGxpbmtUYWdzID0gWydBJywgJ2EnXVxuICAgIGlmIGUudGFyZ2V0LnRhZ05hbWUgaW4gbGlua1RhZ3NcbiAgICAgIEBpbnB1dC52YWx1ZSA9IGUudGFyZ2V0LmlubmVyVGV4dDtcbiAgICAgIEBzZWFyY2goZSlcblxuICBnZXRWYWx1ZTogLT5cbiAgICByZXR1cm4gQGlucHV0LnZhbHVlXG5cbiAgIyBpbnB1dEhhbmRsZXI6IChlKSAtPlxuICAjICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoe2xhbmd1YWdlOiAnMScsIGRpY3Rpb25hcnk6ICdtdWx0aXRyYW4nfSwgKGl0ZW1zKSA9PlxuICAjICAgICBUUkFOU0xBVEVfRU5HSU5FU1tpdGVtcy5kaWN0aW9uYXJ5XS5yZXF1ZXN0XG4gICMgICAgICAgdmFsdWU6IEBpbnB1dC52YWx1ZVxuICAjICAgICAgIHN1Y2Nlc3M6IEBzdWNjZXNzSGFuZGxlci5iaW5kKEApXG4gICMgICAgICAgZXJyb3I6IHBhcmFtcy5lcnJvclxuICAjICAgKVxuICAgICMgdmFsdWUgPSBAaW5wdXQudmFsdWVcbiAgICAjIHRyYW4ucmVxdWVzdChcbiAgICAjICAgdXJsOiB1cmwsXG4gICAgIyAgIHN1Y2Nlc3M6IHBhcmFtcy5zdWNjZXNzLFxuICAgICMgICBlcnJvcjogcGFyYW1zLmVycm9yXG4gICAgIyApXG5cblxuXG5tb2R1bGUuZXhwb3J0cyA9IFNlYXJjaEZvcm1cbiIsIiMjI2dsb2JhbCBjaHJvbWUjIyNcbiMjI1xuICBNdWx0aXRyYW4ucnUgdHJhbnNsYXRlIGVuZ2luZVxuICBQcm92aWRlcyBwcm9ncmFtIGludGVyZmFjZSBmb3IgbWFraW5nIHRyYW5zbGF0ZSBxdWVyaWVzIHRvIG11bHRpdHJhbiBhbmQgZ2V0IGNsZWFuIHJlc3BvbnNlXG5cbiAgQWxsIGVuZ2luZXMgbXVzdCBmb2xsb3cgY29tbW9uIGludGVyZmFjZSBhbmQgcHJvdmlkZSBtZXRob2RzOlxuICAgIC0gc2VhcmNoIChsYW5ndWFuZ2UsIHN1Y2Nlc3NIYW5kbGVyKSAgY2xlYW4gdHJhbnNsYXRpb24gbXVzdCBiZSBwYXNzZWQgaW50byBzdWNjZXNzSGFuZGxlclxuICAgIC0gY2xpY2tcblxuICBUcmFuc2xhdGlvbi1tb2R1bGUgdGhhdCBtYWtlcyByZXF1ZXN0cyB0byBsYW5ndWFnZS1lbmdpbmUsXG4gIHBhcnNlcyByZXN1bHRzIGFuZCBzZW5kcyBwbHVnaW4tZ2xvYmFsIG1lc3NhZ2Ugd2l0aCB0cmFuc2xhdGlvbiBkYXRhXG4jIyNcblxuQ0hBUl9DT0RFUyA9IHJlcXVpcmUoJy4vY2hhci1jb2Rlcy5qcycpO1xuXG5jbGFzcyBUcmFuXG4gIGNvbnN0cnVjdG9yOiAtPlxuICAgIEBUQUJMRV9DTEFTUyA9IFwiX19fbXR0X3RyYW5zbGF0ZV90YWJsZVwiXG4gICAgQHByb3RvY29sID0gJ2h0dHAnXG4gICAgQGhvc3QgPSAnd3d3Lm11bHRpdHJhbi5ydSdcbiAgICBAcGF0aCA9ICcvYy9tLmV4ZSdcbiAgICBAcXVlcnkgPSAnJnM9J1xuICAgIEBsYW5nID0gJz9sMT0yJmwyPTEnICNmcm9tIHJ1c3NpYW4gdG8gZW5nbGlzaCBieSBkZWZhdWx0XG4gICAgQHhociA9IHt9XG5cbiAgIyMjXG4gICAgQ29udGV4dCBtZW51IGNsaWNrIGhhbmRsZXJcbiAgIyMjXG4gIGNsaWNrOiAoZGF0YSkgLT5cbiAgICBpZiB0eXBlb2YgZGF0YS5zaWxlbnQgPT0gdW5kZWZpbmVkIHx8IGRhdGEuc2lsZW50ID09IG51bGxcbiAgICAgIGRhdGEuc2lsZW50ID0gdHJ1ZSAjIHRydWUgYnkgZGVmYXVsdFxuICAgIHNlbGVjdGlvblRleHQgPSBAcmVtb3ZlSHlwaGVuYXRpb24gZGF0YS5zZWxlY3Rpb25UZXh0XG4gICAgQHNlYXJjaFxuICAgICAgICB2YWx1ZTogc2VsZWN0aW9uVGV4dFxuICAgICAgICBzdWNjZXNzOiBAc3VjY2Vzc3RIYW5kbGVyLmJpbmQodGhpcylcbiAgICAgICAgc2lsZW50OiBkYXRhLnNpbGVudCAgIyBpZiB0cmFuc2xhdGlvbiBmYWlsZWQgZG8gbm90IHNob3cgZGlhbG9nXG5cbiAgIyMjXG4gICAgRGlzY2FyZCBzb2Z0IGh5cGhlbiBjaGFyYWN0ZXIgKFUrMDBBRCwgJnNoeTspIGZyb20gdGhlIGlucHV0XG4gICMjI1xuICByZW1vdmVIeXBoZW5hdGlvbjogKHRleHQpIC0+XG4gICAgdGV4dC5yZXBsYWNlIC9cXHhhZC9nLCAnJ1xuXG4gICMjI1xuICAgIEluaXRpYXRlIHRyYW5zbGF0aW9uIHNlYXJjaFxuICAjIyNcbiAgc2VhcmNoOiAocGFyYW1zKSAtPlxuICAgICN2YWx1ZSwgY2FsbGJhY2ssIGVyclxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHtsYW5ndWFnZTogJzEnfSwgKGl0ZW1zKSA9PlxuICAgICAgaWYgbGFuZ3VhZ2UgaXMgJydcbiAgICAgICAgbGFuZ3VhZ2UgPSAnMSdcbiAgICAgIEBzZXRMYW5ndWFnZShpdGVtcy5sYW5ndWFnZSlcbiAgICAgIHVybCA9IEBtYWtlVXJsKHBhcmFtcy52YWx1ZSk7XG4gICAgICAjIGRlY29yYXRlIHN1Y2Nlc3MgdG8gbWFrZSBwcmVsaW1pbmFyeSBwYXJzaW5nXG4gICAgICBvcmlnU3VjY2VzcyA9IHBhcmFtcy5zdWNjZXNzXG4gICAgICBwYXJhbXMuc3VjY2VzcyA9IChyZXNwb25zZSkgPT5cbiAgICAgICAgdHJhbnNsYXRlZCA9IEBwYXJzZShyZXNwb25zZSwgcGFyYW1zLnNpbGVudClcbiAgICAgICAgb3JpZ1N1Y2Nlc3ModHJhbnNsYXRlZClcblxuICAgICAgIyBtYWtlIHJlcXVlc3QgKEdFVCByZXF1ZXN0IHdpdGggcXVlcnkgcGFyYW1ldGVycyBpbiB1cmwpXG4gICAgICBAcmVxdWVzdChcbiAgICAgICAgdXJsOiB1cmwsXG4gICAgICAgIHN1Y2Nlc3M6IHBhcmFtcy5zdWNjZXNzLFxuICAgICAgICBlcnJvcjogcGFyYW1zLmVycm9yXG4gICAgICApXG4gICAgKVxuXG4gIHNldExhbmd1YWdlOiAobGFuZ3VhZ2UpIC0+XG4gICAgQGN1cnJlbnRMYW5ndWFnZSA9IGxhbmd1YWdlXG4gICAgQGxhbmcgPSAnP2wxPTImbDI9JyArIGxhbmd1YWdlXG5cbiAgIyMjXG4gICAgUmVxdWVzdCB0cmFuc2xhdGlvbiBhbmQgcnVuIGNhbGxiYWNrIGZ1bmN0aW9uXG4gICAgcGFzc2luZyB0cmFuc2xhdGVkIHJlc3VsdCBvciBlcnJvciB0byBjYWxsYmFja1xuICAjIyNcbiAgcmVxdWVzdDogKG9wdHMpIC0+XG4gICAgeGhyID0gQHhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpXG4gICAgeGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IChlKSA9PlxuICAgICAgeGhyID0gQHhoclxuICAgICAgaWYgeGhyLnJlYWR5U3RhdGUgPCA0XG4gICAgICAgIHJldHVyblxuICAgICAgZWxzZSBpZiB4aHIuc3RhdHVzICE9IDIwMFxuICAgICAgICBAZXJyb3JIYW5kbGVyKHhocilcbiAgICAgICAgaWYgKHR5cGVvZiBvcHRzLmVycm9yID09ICdmdW5jdGlvbicpXG4gICAgICAgICAgb3B0cy5lcnJvcigpXG4gICAgICAgIHJldHVyblxuICAgICAgZWxzZSBpZiB4aHIucmVhZHlTdGF0ZSA9PSA0XG4gICAgICAgICAgcmV0dXJuIG9wdHMuc3VjY2VzcyhlLnRhcmdldC5yZXNwb25zZSlcblxuICAgIHhoci5vcGVuKFwiR0VUXCIsIG9wdHMudXJsLCB0cnVlKTtcbiAgICB4aHIuc2VuZCgpO1xuXG5cbiAgbWFrZVVybDogKHZhbHVlKSAtPlxuICAgIHVybCA9IFtAcHJvdG9jb2wsICc6Ly8nLFxuICAgICAgICAgICAgICBAaG9zdCxcbiAgICAgICAgICAgICAgQHBhdGgsXG4gICAgICAgICAgICAgIEBsYW5nLFxuICAgICAgICAgICAgICBAcXVlcnksXG4gICAgICAgICAgICAgIEBnZXRFbmNvZGVkVmFsdWUodmFsdWUpXG4gICAgICAgICAgXS5qb2luKCcnKVxuXG4gICAgcmV0dXJuIHVybDtcblxuICAjIFJlcGxhY2Ugc3BlY2lhbCBsYW5ndWFnZSBjaGFyYWN0ZXJzIHRvIGh0bWwgY29kZXNcbiAgZ2V0RW5jb2RlZFZhbHVlOiAodmFsdWUpIC0+XG4gICAgIyB0byBmaW5kIHNwZWMgc3ltYm9scyB3ZSBmaXJzdCBlbmNvZGUgdGhlbSAocmF3IHNlYXJjaCBmb3IgdGhhdCBzeW1ib2wgZG9lc24ndCB3b3IpXG4gICAgdmFsID0gZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKVxuICAgIGZvciBjaGFyLCBjb2RlIG9mIENIQVJfQ09ERVNcbiAgICAgIHZhbCA9IHZhbC5yZXBsYWNlKGNoYXIsIGVuY29kZVVSSUNvbXBvbmVudChjb2RlKSlcbiAgICByZXR1cm4gdmFsXG5cbiAgZXJyb3JIYW5kbGVyOiAoeGhyKSAtPlxuICAgIGNvbnNvbGUubG9nKCdlcnJvcicsIHhocilcblxuICAjIyNcbiAgIFJlY2VpdmluZyBkYXRhIGZyb20gdHJhbnNsYXRpb24tZW5naW5lIGFuZCBzZW5kIHJlYWR5IG1lc3NhZ2Ugd2l0aCBkYXRhXG4gICMjI1xuICBzdWNjZXNzdEhhbmRsZXI6ICh0cmFuc2xhdGVkKSAtPlxuICAgIGlmIHRyYW5zbGF0ZWRcbiAgICAgIGNocm9tZS50YWJzLmdldFNlbGVjdGVkKG51bGwsICh0YWIpID0+XG4gICAgICAgIGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhYi5pZCwge1xuICAgICAgICAgIGFjdGlvbjogQG1lc3NhZ2VUeXBlIHRyYW5zbGF0ZWRcbiAgICAgICAgICBkYXRhOiB0cmFuc2xhdGVkLm91dGVySFRNTCxcbiAgICAgICAgICBzdWNjZXNzOiAhdHJhbnNsYXRlZC5jbGFzc0xpc3QuY29udGFpbnMoJ2ZhaWxUcmFuc2xhdGUnKVxuICAgICAgICB9KVxuICAgICAgKVxuXG4gIG1lc3NhZ2VUeXBlOiAodHJhbnNsYXRlZCkgLT5cbiAgICBpZiB0cmFuc2xhdGVkPy5yb3dzPy5sZW5ndGggPT0gMVxuICAgICAgJ3NpbWlsYXJfd29yZHMnXG4gICAgZWxzZVxuICAgICAgJ29wZW5fdG9vbHRpcCdcblxuICAjIyNcbiAgICBQYXJzZSByZXNwb25zZSBmcm9tIHRyYW5zbGF0aW9uIGVuZ2luZVxuICAjIyNcbiAgcGFyc2U6IChyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUgPSBudWxsKSAtPlxuICAgICAgZG9jID0gQHN0cmlwU2NyaXB0cyhyZXNwb25zZSlcbiAgICAgIGZyYWdtZW50ID0gQG1ha2VGcmFnbWVudChkb2MpXG4gICAgICBpZiBmcmFnbWVudFxuICAgICAgICB0cmFuc2xhdGUgPSBmcmFnbWVudC5xdWVyeVNlbGVjdG9yKCcjdHJhbnNsYXRpb24gfiB0YWJsZScpXG4gICAgICAgIGlmIHRyYW5zbGF0ZVxuICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSBAVEFCTEVfQ0xBU1M7XG4gICAgICAgICAgdHJhbnNsYXRlLnNldEF0dHJpYnV0ZShcImNlbGxwYWRkaW5nXCIsIFwiNVwiKVxuICAgICAgICAgIEBmaXhJbWFnZXModHJhbnNsYXRlKVxuICAgICAgICAgIEBmaXhMaW5rcyh0cmFuc2xhdGUpXG4gICAgICAgIGVsc2UgaWYgbm90IHNpbGVudFxuICAgICAgICAgIHRyYW5zbGF0ZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9ICdmYWlsVHJhbnNsYXRlJ1xuICAgICAgICAgIHRyYW5zbGF0ZS5pbm5lclRleHQgPSBcIlVuZm9ydHVuYXRlbHksIGNvdWxkIG5vdCB0cmFuc2xhdGVcIlxuXG4gICAgICByZXR1cm4gdHJhbnNsYXRlO1xuXG4gICMjI1xuICAgIFN0cmlwIHNjcmlwdCB0YWdzIGZyb20gcmVzcG9uc2UgaHRtbFxuICAjIyNcbiAgc3RyaXBTY3JpcHRzOiAocykgLT5cbiAgICBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICAgIGRpdi5pbm5lckhUTUwgPSBzXG4gICAgc2NyaXB0cyA9IGRpdi5nZXRFbGVtZW50c0J5VGFnTmFtZSgnc2NyaXB0JylcbiAgICBpID0gc2NyaXB0cy5sZW5ndGhcbiAgICB3aGlsZSBpLS1cbiAgICAgIHNjcmlwdHNbaV0ucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChzY3JpcHRzW2ldKVxuICAgIHJldHVybiBkaXYuaW5uZXJIVE1MO1xuXG4gIG1ha2VGcmFnbWVudDogKGRvYywgZnJhZ21lbnQgPSBudWxsKSAtPlxuICAgIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIilcbiAgICBkaXYuaW5uZXJIVE1MID0gZG9jXG4gICAgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KClcbiAgICB3aGlsZSAoIGRpdi5maXJzdENoaWxkIClcbiAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKCBkaXYuZmlyc3RDaGlsZCApXG4gICAgcmV0dXJuIGZyYWdtZW50XG5cbiAgZml4SW1hZ2VzOiAoZnJhZ21lbnQ9bnVsbCkgLT5cbiAgICB0aGlzLmZpeFVybChmcmFnbWVudCwgJ2ltZycsICdzcmMnKTtcbiAgICByZXR1cm4gZnJhZ21lbnQ7XG5cbiAgZml4TGlua3M6IChmcmFnbWVudD1udWxsKSAtPlxuICAgIHRoaXMuZml4VXJsKGZyYWdtZW50LCAnYScsICdocmVmJylcbiAgICByZXR1cm4gZnJhZ21lbnRcblxuICBmaXhVcmw6IChmcmFnbWVudD1udWxsLCB0YWcsIGF0dHIpIC0+XG4gICAgaWYgZnJhZ21lbnRcbiAgICAgIHRhZ3MgPSAgZnJhZ21lbnQucXVlcnlTZWxlY3RvckFsbCh0YWcpXG4gICAgICBwYXJzZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJylcbiAgICAgIGZvciB0YWcgaW4gdGFnc1xuICAgICAgICBwYXJzZXIuaHJlZiA9IHRhZ1thdHRyXVxuICAgICAgICBwYXJzZXIuaG9zdCA9IEBob3N0XG4gICAgICAgIHBhcnNlci5wcm90b2NvbCA9IEBwcm90b2NvbFxuICAgICAgICAjZml4IHJlbGF0aXZlIGxpbmtzXG4gICAgICAgIGlmIHRhZy50YWdOYW1lID09ICdBJ1xuICAgICAgICAgIHRhZy5jbGFzc0xpc3QuYWRkICdtdHRfbGluaydcbiAgICAgICAgICBpZiBwYXJzZXIucGF0aG5hbWUuaW5kZXhPZignbS5leGUnKSBpc250IC0xXG4gICAgICAgICAgICBwYXJzZXIucGF0aG5hbWUgPSAnL2MnICsgcGFyc2VyLnBhdGhuYW1lXG4gICAgICAgICAgICB0YWcuc2V0QXR0cmlidXRlKCd0YXJnZXQnLCAnX2JsYW5rJylcbiAgICAgICAgZWxzZSBpZiB0YWcudGFnTmFtZSA9PSAnSU1HJ1xuICAgICAgICAgIHRhZy5jbGFzc0xpc3QuYWRkICdtdHRfaW1nJ1xuXG4gICAgICAgIHRhZy5zZXRBdHRyaWJ1dGUoYXR0ciwgcGFyc2VyLmhyZWYpXG5cblxuXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBUcmFuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbnZhciBfcHJvdG90eXBlUHJvcGVydGllcyA9IGZ1bmN0aW9uIChjaGlsZCwgc3RhdGljUHJvcHMsIGluc3RhbmNlUHJvcHMpIHtcbiAgaWYgKHN0YXRpY1Byb3BzKSBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhjaGlsZCwgc3RhdGljUHJvcHMpO1xuICBpZiAoaW5zdGFuY2VQcm9wcykgT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoY2hpbGQucHJvdG90eXBlLCBpbnN0YW5jZVByb3BzKTtcbn07XG5cbi8qXG4gIFRyYW5zbGF0aW9uIGVuZ2luZTogaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXRcbiAgRm9yIHRyYW5zbGF0aW5nIHR1cmtpc2gtcnVzc2lhbiBhbmQgdmljZSB2ZXJzYVxuKi9cbnZhciBDSEFSX0NPREVTID0gcmVxdWlyZShcIi4vY2hhci1jb2Rlcy10dXJrLmpzXCIpO1xuXG52YXIgVHVya2lzaERpY3Rpb25hcnkgPSAoZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBUdXJraXNoRGljdGlvbmFyeSgpIHtcbiAgICB0aGlzLmhvc3QgPSBcImh0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0Lz93b3JkPSVGQ1wiO1xuICAgIHRoaXMucGF0aCA9IFwiXCI7XG4gICAgdGhpcy5wcm90b2NvbCA9IFwiaHR0cFwiO1xuICAgIHRoaXMucXVlcnkgPSBcIiZzPVwiO1xuICAgIHRoaXMuVEFCTEVfQ0xBU1MgPSBcIl9fX210dF90cmFuc2xhdGVfdGFibGVcIjtcbiAgICB0aGlzLm5lZWRfcHVibGlzaCA9IHRydWU7XG4gIH1cblxuICBfcHJvdG90eXBlUHJvcGVydGllcyhUdXJraXNoRGljdGlvbmFyeSwgbnVsbCwge1xuICAgIHNlYXJjaDoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHNlYXJjaChkYXRhKSB7XG4gICAgICAgIGRhdGEudXJsID0gdGhpcy5tYWtlVXJsKGRhdGEudmFsdWUpO1xuICAgICAgICB0aGlzLm5lZWRfcHVibGlzaCA9IGZhbHNlO1xuICAgICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KGRhdGEpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgdHJhbnNsYXRlOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gdHJhbnNsYXRlKGRhdGEpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJyZXF1ZXN0IGRhdGE6XCIsIGRhdGEpO1xuICAgICAgICBkYXRhLnVybCA9IHRoaXMubWFrZVVybChkYXRhLnNlbGVjdGlvblRleHQpO1xuICAgICAgICB0aGlzLm5lZWRfcHVibGlzaCA9IHRydWU7XG4gICAgICAgIHRoaXMucmVxdWVzdChkYXRhKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIG1ha2VVcmw6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlVXJsKHRleHQpIHtcbiAgICAgICAgcmV0dXJuIFtcImh0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0Lz93b3JkPVwiLCB0ZXh0XS5qb2luKFwiXCIpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcmVxdWVzdDoge1xuXG4gICAgICAvKlxuICAgICAgICBSZXF1ZXN0IHRyYW5zbGF0aW9uIGFuZCBydW4gY2FsbGJhY2sgZnVuY3Rpb25cbiAgICAgICAgcGFzc2luZyB0cmFuc2xhdGVkIHJlc3VsdCBvciBlcnJvciB0byBjYWxsYmFja1xuICAgICAgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiByZXF1ZXN0KG9wdHMpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJzdGFydCByZXF1ZXN0XCIpO1xuICAgICAgICB0aGlzLnhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgICB0aGlzLnhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSB0aGlzLm9uUmVhZHlTdGF0ZUNoYW5nZS5iaW5kKHRoaXMsIG9wdHMpO1xuICAgICAgICB0aGlzLnhoci5vcGVuKFwiR0VUXCIsIG9wdHMudXJsLCB0cnVlKTtcbiAgICAgICAgdGhpcy54aHIuc2VuZCgpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgb25SZWFkeVN0YXRlQ2hhbmdlOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gb25SZWFkeVN0YXRlQ2hhbmdlKG9wdHMsIGUpIHtcbiAgICAgICAgdmFyIHhociA9IHRoaXMueGhyO1xuICAgICAgICBpZiAoeGhyLnJlYWR5U3RhdGUgPCA0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9IGVsc2UgaWYgKHhoci5zdGF0dXMgIT0gMjAwKSB7XG4gICAgICAgICAgdGhpcy5lcnJvckhhbmRsZXIoeGhyKTtcbiAgICAgICAgICByZXR1cm4gb3B0cy5lcnJvciAmJiBvcHRzLmVycm9yKCk7XG4gICAgICAgIH0gZWxzZSBpZiAoeGhyLnJlYWR5U3RhdGUgPT0gNCkge1xuICAgICAgICAgIHZhciB0cmFuc2xhdGlvbiA9IHRoaXMuc3VjY2Vzc0hhbmRsZXIoZS50YXJnZXQucmVzcG9uc2UpO1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwic3VjY2VzcyB0dXJraXNoIHRyYW5zbGF0ZVwiLCB0cmFuc2xhdGlvbik7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJjYWxsXCIsIG9wdHMuc3VjY2Vzcyk7XG4gICAgICAgICAgcmV0dXJuIG9wdHMuc3VjY2VzcyAmJiBvcHRzLnN1Y2Nlc3ModHJhbnNsYXRpb24pO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBzdWNjZXNzSGFuZGxlcjoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHN1Y2Nlc3NIYW5kbGVyKHJlc3BvbnNlKSB7XG4gICAgICAgIHZhciBkYXRhID0gdGhpcy5wYXJzZShyZXNwb25zZSk7XG4gICAgICAgIGlmICh0aGlzLm5lZWRfcHVibGlzaCkge1xuICAgICAgICAgIGNocm9tZS50YWJzLmdldFNlbGVjdGVkKG51bGwsIHRoaXMucHVibGlzaFRyYW5zbGF0aW9uLmJpbmQodGhpcywgZGF0YSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcHVibGlzaFRyYW5zbGF0aW9uOiB7XG5cbiAgICAgIC8qIHB1Ymxpc2ggc3VjY2Vzc2Z1bHkgdHJhbnNsYXRlZCB0ZXh0IGFsbCBvdmVyIGV4dGVuc2lvbiAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHB1Ymxpc2hUcmFuc2xhdGlvbih0cmFuc2xhdGlvbiwgdGFiKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwicHVibGlzaCB0cmFuc2xhdGlvblwiKTtcbiAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgYWN0aW9uOiBcIm9wZW5fdG9vbHRpcFwiLFxuICAgICAgICAgIGRhdGE6IHRyYW5zbGF0aW9uLm91dGVySFRNTCxcbiAgICAgICAgICBzdWNjZXNzOiAhdHJhbnNsYXRpb24uY2xhc3NMaXN0LmNvbnRhaW5zKFwiZmFpbFRyYW5zbGF0ZVwiKVxuICAgICAgICB9KTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIGVycm9ySGFuZGxlcjoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIGVycm9ySGFuZGxlcihyZXNwb25zZSkge1xuICAgICAgICBjb25zb2xlLmxvZyhcImVycm9yIGFqYXhcIiwgcmVzcG9uc2UpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcGFyc2U6IHtcblxuICAgICAgLyogUGFyc2UgcmVzcG9uc2UgZnJvbSB0cmFuc2xhdGlvbiBlbmdpbmUgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBwYXJzZShyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUpIHtcbiAgICAgICAgdmFyIGRvYyA9IHRoaXMuc3RyaXBTY3JpcHRzKHJlc3BvbnNlKSxcbiAgICAgICAgICAgIGZyYWdtZW50ID0gdGhpcy5tYWtlRnJhZ21lbnQoZG9jKTtcbiAgICAgICAgaWYgKGZyYWdtZW50KSB7XG4gICAgICAgICAgdHJhbnNsYXRlID0gZnJhZ21lbnQucXVlcnlTZWxlY3RvcihcIiNtZWFuaW5nX2RpdiA+IHRhYmxlXCIpO1xuICAgICAgICAgIGlmICh0cmFuc2xhdGUpIHtcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSB0aGlzLlRBQkxFX0NMQVNTO1xuICAgICAgICAgICAgdHJhbnNsYXRlLnNldEF0dHJpYnV0ZShcImNlbGxwYWRkaW5nXCIsIFwiNVwiKTtcbiAgICAgICAgICAgIC8vIEBmaXhJbWFnZXModHJhbnNsYXRlKVxuICAgICAgICAgICAgLy8gQGZpeExpbmtzKHRyYW5zbGF0ZSlcbiAgICAgICAgICB9IGVsc2UgaWYgKCFzaWxlbnQpIHtcbiAgICAgICAgICAgIHRyYW5zbGF0ZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gXCJmYWlsVHJhbnNsYXRlXCI7XG4gICAgICAgICAgICB0cmFuc2xhdGUuaW5uZXJUZXh0ID0gXCJVbmZvcnR1bmF0ZWx5LCBjb3VsZCBub3QgdHJhbnNsYXRlXCI7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cmFuc2xhdGU7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBzdHJpcFNjcmlwdHM6IHtcblxuICAgICAgLy9UT0RPIGV4dHJhY3QgdG8gYmFzZSBlbmdpbmUgY2xhc3NcbiAgICAgIC8qIHJlbW92ZXMgPHNjcmlwdD4gdGFncyBmcm9tIGh0bWwgY29kZSAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHN0cmlwU2NyaXB0cyhodG1sKSB7XG4gICAgICAgIHZhciBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcbiAgICAgICAgdmFyIHNjcmlwdHMgPSBkaXYuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJzY3JpcHRcIik7XG4gICAgICAgIHZhciBpID0gc2NyaXB0cy5sZW5ndGg7XG4gICAgICAgIHdoaWxlIChpLS0pIHNjcmlwdHNbaV0ucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChzY3JpcHRzW2ldKTtcbiAgICAgICAgcmV0dXJuIGRpdi5pbm5lckhUTUw7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBtYWtlRnJhZ21lbnQ6IHtcblxuICAgICAgLy9UT0RPIGV4dHJhY3QgdG8gYmFzZSBlbmdpbmUgY2xhc3NcbiAgICAgIC8qIGNyZWF0ZXMgdGVtcCBvYmplY3QgdG8gcGFyc2UgdHJhbnNsYXRpb24gZnJvbSBwYWdlIFxuICAgICAgICAoc2luY2UgaXQncyBub3QgYSBmcmllbmRseSBhcGkpIFxuICAgICAgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlRnJhZ21lbnQoaHRtbCkge1xuICAgICAgICB2YXIgZnJhZ21lbnQsXG4gICAgICAgICAgICBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcbiAgICAgICAgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG4gICAgICAgIHdoaWxlIChkaXYuZmlyc3RDaGlsZCkge1xuICAgICAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKGRpdi5maXJzdENoaWxkKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfVxuICB9KTtcblxuICByZXR1cm4gVHVya2lzaERpY3Rpb25hcnk7XG59KSgpO1xuXG4vLyBTaW5nbGV0b25lXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBUdXJraXNoRGljdGlvbmFyeSgpOyJdfQ==
