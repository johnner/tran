(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
// turkishdictionary codings
var DICT = {
    350: '%DE', //Ş
    286: '%D0', //Ğ
    287: '%F0', //ğ
    351: '%FE', //ş
    305: '%FD', //ı
    304: '%DD', //İ
    252: '%FC', //ü
    220: '%DC', //Ü
    231: '%E7', //ç
    199: '%C7', //Ç
    246: '%F6', //ö
    244: '%F4', //ô
    214: '%D6', //Ö
    212: '%D4', //Ô
    251: '%FB', //û
    219: '%DB', //Û
    194: '%C2', //Â
    226: '%E2', //â
    39: '',  //'
};

module.exports = DICT;
},{}],2:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/var CHAR_CODES = {  //russian  '%D1%8A': {val:'%FA', lang:'ru'}, // ъ  '%D0%AA': {val:'%DA', lang:'ru'},// Ъ  '%C3%80': '&#192;', // À  '%C3%81': '&#193;', // Á  '%C3%82': '&#194;', // Â  '%C3%83': '&#195;', // Ã  '%C3%84': '&#196;', // Ä  '%C3%85': '&#197;', // Å  '%C3%86': '&#198;', // Æ  '%C3%87': '&#199;', // Ç  '%C3%88': '&#200;', // È  '%C3%89': '&#201;', // É  '%C3%8A': '&#202;', // Ê  '%C3%8B': '&#203;', // Ë  '%C3%8C': '&#204;', // Ì  '%C3%8D': '&#205;', // Í  '%C3%8E': '&#206;', // Î  '%C3%8F': '&#207;', // Ï  '%C3%91': '&#209;', // Ñ  '%C3%92': '&#210;', // Ò  '%C3%93': '&#211;', // Ó  '%C3%94': '&#212;', // Ô  '%C3%95': '&#213;', // Õ  '%C3%96': '&#214;', // Ö  '%C3%99': '&#217;', // Ù  '%C3%9A': '&#218;', // Ú  '%C3%9B': '&#219;', // Û  '%C3%9C': '&#220;', // Ü  '%C3%A0': '&#224;', // à  '%C3%A1': '&#225;', // á  '%C3%A2': '&#226;', // â  '%C3%A3': '&#227;', // ã  '%C3%A4': '&#228;', // ä  '%C3%A5': '&#229;', // å  '%C3%A6': '&#230;', // æ  '%C3%A7': '&#231;', // ç  '%C3%A8': '&#232;', // è  '%C3%A9': '&#233;', // é  '%C3%AA': '&#234;', // ê  '%C3%AB': '&#235;', // ë  '%C3%AC': '&#236;', // ì  '%C3%AD': '&#237;', // í  '%C3%AE': '&#238;', // î  '%C3%AF': '&#239;', // ï  '%C3%B0': '&#240;', // ð  '%C3%B1': '&#241;', // ñ  '%C3%B2': '&#242;', // ò  '%C3%B3': '&#243;', // ó  '%C3%B4': '&#244;', // ô  '%C3%B5': '&#245;', // õ  '%C3%B6': '&#246;', // ö  '%C3%B9': '&#249;', // ù  '%C3%BA': '&#250;', // ú  '%C3%BB': '&#251;', // û  '%C3%BC': '&#252;', // ü  '%C3%BF': '&#255;', // ÿ  '%C5%B8': '&#376;', // Ÿ  '%C3%9F': '&#223;', // ß  '%C2%BF': '&#191;', // ¿  '%C2%A1': '&#161;', // ¡};module.exports = CHAR_CODES;
},{}],3:[function(require,module,exports){

/*
  Dropdown language menu
  @param opts takes element and onSelect handler
  example:
  new Dropdown({
   el: document.getElementById('#menu');
   onSelect: function () {}
  })
 */
var DICT_CODE, Dropdown, LANG_CODE;

LANG_CODE = {
  '1': 'Eng',
  '2': 'Rus',
  '3': 'Ger',
  '4': 'Fre',
  '5': 'Spa',
  '23': 'Ita',
  '24': 'Dut',
  '26': 'Est',
  '27': 'Lav',
  '31': 'Afr',
  '34': 'Epo',
  '35': 'Xal',
  '1000': 'Tur'
};

DICT_CODE = {
  '1': 'multitran',
  '1000': 'turkish'
};

Dropdown = (function() {
  function Dropdown(opts) {
    this.el = opts.el || document.createElement('div');
    this.onSelect = opts.onSelect;
    this.menu = this.el.querySelector('.dropdown-menu');
    if (this.menu) {
      this.menu.style.display = 'none';
      this.items = this.menu.getElementsByClassName('language-type');
      this.button = this.el.querySelector('.dropdown-toggle');
      this.addListeners();
      this.initLanguage();
    }
  }

  Dropdown.prototype.addListeners = function() {
    this.button.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.toggle(e);
      };
    })(this));
    document.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.hide(e);
      };
    })(this));
    return this.menu.addEventListener('click', (function(_this) {
      return function(e) {
        return _this.choose(e);
      };
    })(this));
  };

  Dropdown.prototype.initLanguage = function() {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(store) {
        return _this.setTitle(store.language);
      };
    })(this));
  };

  Dropdown.prototype.toggle = function(e) {
    e.stopPropagation();
    this.setActiveItem();
    if (this.menu && this.menu.style.display === 'none') {
      return this.show();
    } else {
      return this.hide();
    }
  };

  Dropdown.prototype.setActiveItem = function() {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(store) {
        var item, _i, _len, _ref, _results;
        _ref = _this.items;
        _results = [];
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          item = _ref[_i];
          if (item.getAttribute('data-val') === store.language) {
            _results.push(item.classList.add('active'));
          } else {
            _results.push(item.classList.remove('active'));
          }
        }
        return _results;
      };
    })(this));
  };

  Dropdown.prototype.hide = function() {
    return this.menu.style.display = 'none';
  };

  Dropdown.prototype.show = function() {
    return this.menu.style.display = 'block';
  };

  Dropdown.prototype.choose = function(e) {
    var dictionary, language;
    e.stopPropagation();
    e.preventDefault();
    language = e.target.getAttribute('data-val');
    dictionary = this.getDictionary(language);
    chrome.storage.sync.set({
      language: language,
      dictionary: dictionary
    }, this.onSelect);
    this.setTitle(language);
    return this.hide();
  };

  Dropdown.prototype.getDictionary = function(lang) {
    var dict;
    console.log('choose dict: for', lang);
    dict = DICT_CODE[lang] || 'multitran';
    console.log('dict', dict);
    return dict;
  };

  Dropdown.prototype.setTitle = function(language) {
    var html;
    html = LANG_CODE[language] + ' <span class="caret"></span>';
    return this.button.innerHTML = html;
  };

  return Dropdown;

})();

module.exports = Dropdown;


},{}],4:[function(require,module,exports){

/*
  Extension popup window
  Shows search form and dropdown menu with languages
 */
var SearchForm;

SearchForm = require('./search_form.coffee');

document.addEventListener("DOMContentLoaded", function() {
  var form, link;
  form = new SearchForm(document.getElementById('tran-form'));
  link = document.getElementById('header-link');
  if (link) {
    return link.addEventListener('click', function(e) {
      var href;
      e.preventDefault();
      href = e.target.getAttribute('href') + form.getValue();
      return chrome.tabs.create({
        url: href
      });
    });
  }
});


},{"./search_form.coffee":5}],5:[function(require,module,exports){

/*
  Serves search input and form

  @param form DOM elemnt
  @constructor
 */
var Dropdown, SearchForm, TRANSLATE_ENGINES, tran, turkishdictionary,
  __indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

Dropdown = require('./dropdown.coffee');

tran = require('../tran.coffee');

turkishdictionary = require('../turkishdictionary.js');

TRANSLATE_ENGINES = {
  'multitran': tran,
  'turkish': turkishdictionary
};

SearchForm = (function() {
  function SearchForm(form) {
    this.form = form;
    this.input = document.getElementById('translate-txt');
    this.input.focus();
    this.result = document.getElementById('result');
    this.addListeners();
    this.dropdown = new Dropdown({
      el: document.querySelector('.dropdown-el'),
      onSelect: (function(_this) {
        return function() {
          return _this.search();
        };
      })(this)
    });
  }

  SearchForm.prototype.addListeners = function() {
    if (this.form && this.result) {
      this.form.addEventListener('submit', (function(_this) {
        return function(e) {
          return _this.search(e);
        };
      })(this));
      return this.result.addEventListener('click', (function(_this) {
        return function(e) {
          return _this.resultClickHandler(e);
        };
      })(this));
    }
  };

  SearchForm.prototype.search = function(e) {
    e && e.preventDefault && e.preventDefault();
    if (this.input.value.length > 0) {
      return chrome.storage.sync.get({
        language: '1',
        dictionary: 'multitran'
      }, (function(_this) {
        return function(items) {
          console.log('ITEMS:', items);
          return TRANSLATE_ENGINES[items.dictionary].search({
            value: _this.input.value,
            success: _this.successHandler.bind(_this)
          });
        };
      })(this));
    }
  };

  SearchForm.prototype.successHandler = function(response) {
    this.clean(this.result);
    return this.result.appendChild(response);
  };

  SearchForm.prototype.clean = function(el) {
    var _results;
    _results = [];
    while (el.lastChild) {
      _results.push(el.removeChild(el.lastChild));
    }
    return _results;
  };

  SearchForm.prototype.resultClickHandler = function(e) {
    var linkTags, _ref;
    e.preventDefault();
    linkTags = ['A', 'a'];
    if (_ref = e.target.tagName, __indexOf.call(linkTags, _ref) >= 0) {
      this.input.value = e.target.innerText;
      return this.search(e);
    }
  };

  SearchForm.prototype.getValue = function() {
    return this.input.value;
  };

  return SearchForm;

})();

module.exports = SearchForm;


},{"../tran.coffee":6,"../turkishdictionary.js":7,"./dropdown.coffee":3}],6:[function(require,module,exports){

/*global chrome */

/*
  Multitran.ru translate engine
  Provides program interface for making translate queries to multitran and get clean response

  All engines must follow common interface and provide methods:
    - search (languange, successHandler)  clean translation must be passed into successHandler
    - click

  Translation-module that makes requests to language-engine,
  parses results and sends plugin-global message with translation data
 */
var CHAR_CODES, Tran;

CHAR_CODES = require('./char-codes.js');

Tran = (function() {
  function Tran() {
    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1';
    this.xhr = {};
  }


  /*
    Context menu click handler
   */

  Tran.prototype.click = function(data) {
    var selectionText;
    if (typeof data.silent === void 0 || data.silent === null) {
      data.silent = true;
    }
    selectionText = this.removeHyphenation(data.selectionText);
    return this.search({
      value: selectionText,
      success: this.successtHandler.bind(this),
      silent: data.silent
    });
  };


  /*
    Discard soft hyphen character (U+00AD, &shy;) from the input
   */

  Tran.prototype.removeHyphenation = function(text) {
    return text.replace(/\xad/g, '');
  };


  /*
    Initiate translation search
   */

  Tran.prototype.search = function(params) {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(items) {
        var language, origSuccess, url;
        if (language === '') {
          language = '1';
        }
        _this.setLanguage(items.language);
        url = _this.makeUrl(params.value);
        origSuccess = params.success;
        params.success = function(response) {
          var translated;
          translated = _this.parse(response, params.silent);
          return origSuccess(translated);
        };
        return _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      };
    })(this));
  };

  Tran.prototype.setLanguage = function(language) {
    this.currentLanguage = language;
    return this.lang = '?l1=2&l2=' + language;
  };


  /*
    Request translation and run callback function
    passing translated result or error to callback
   */

  Tran.prototype.request = function(opts) {
    var xhr;
    xhr = this.xhr = new XMLHttpRequest();
    xhr.onreadystatechange = (function(_this) {
      return function(e) {
        xhr = _this.xhr;
        if (xhr.readyState < 4) {

        } else if (xhr.status !== 200) {
          _this.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error();
          }
        } else if (xhr.readyState === 4) {
          return opts.success(e.target.response);
        }
      };
    })(this);
    xhr.open("GET", opts.url, true);
    return xhr.send();
  };

  Tran.prototype.makeUrl = function(value) {
    var url;
    url = [this.protocol, '://', this.host, this.path, this.lang, this.query, this.getEncodedValue(value)].join('');
    return url;
  };

  Tran.prototype.getEncodedValue = function(value) {
    var cc, char, code, val;
    val = encodeURIComponent(value);
    for (char in CHAR_CODES) {
      code = CHAR_CODES[char];
      if (typeof code === 'object') {
        cc = code.val;
      } else {
        cc = encodeURIComponent(code);
      }
      val = val.replace(char, cc);
    }
    return val;
  };

  Tran.prototype.errorHandler = function(xhr) {
    return console.log('error', xhr);
  };


  /*
   Receiving data from translation-engine and send ready message with data
   */

  Tran.prototype.successtHandler = function(translated) {
    if (translated) {
      return chrome.tabs.getSelected(null, (function(_this) {
        return function(tab) {
          return chrome.tabs.sendMessage(tab.id, {
            action: _this.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        };
      })(this));
    }
  };

  Tran.prototype.messageType = function(translated) {
    var _ref;
    if ((translated != null ? (_ref = translated.rows) != null ? _ref.length : void 0 : void 0) === 1) {
      return 'similar_words';
    } else {
      return 'open_tooltip';
    }
  };


  /*
    Parse response from translation engine
   */

  Tran.prototype.parse = function(response, silent, translate) {
    var doc, fragment;
    if (translate == null) {
      translate = null;
    }
    doc = this.stripScripts(response);
    fragment = this.makeFragment(doc);
    if (fragment) {
      translate = fragment.querySelector('#translation ~ table');
      if (translate) {
        translate.className = this.TABLE_CLASS;
        translate.setAttribute("cellpadding", "5");
        this.fixImages(translate);
        this.fixLinks(translate);
      } else if (!silent) {
        translate = document.createElement('div');
        translate.className = 'failTranslate';
        translate.innerText = "Unfortunately, could not translate";
      }
    }
    return translate;
  };


  /*
    Strip script tags from response html
   */

  Tran.prototype.stripScripts = function(s) {
    var div, i, scripts;
    div = document.createElement('div');
    div.innerHTML = s;
    scripts = div.getElementsByTagName('script');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
    return div.innerHTML;
  };

  Tran.prototype.makeFragment = function(doc, fragment) {
    var div;
    if (fragment == null) {
      fragment = null;
    }
    div = document.createElement("div");
    div.innerHTML = doc;
    fragment = document.createDocumentFragment();
    while (div.firstChild) {
      fragment.appendChild(div.firstChild);
    }
    return fragment;
  };

  Tran.prototype.fixImages = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'img', 'src');
    return fragment;
  };

  Tran.prototype.fixLinks = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'a', 'href');
    return fragment;
  };

  Tran.prototype.fixUrl = function(fragment, tag, attr) {
    var parser, tags, _i, _len, _results;
    if (fragment == null) {
      fragment = null;
    }
    if (fragment) {
      tags = fragment.querySelectorAll(tag);
      parser = document.createElement('a');
      _results = [];
      for (_i = 0, _len = tags.length; _i < _len; _i++) {
        tag = tags[_i];
        parser.href = tag[attr];
        parser.host = this.host;
        parser.protocol = this.protocol;
        if (tag.tagName === 'A') {
          tag.classList.add('mtt_link');
          if (parser.pathname.indexOf('m.exe') !== -1) {
            parser.pathname = '/c' + parser.pathname;
            tag.setAttribute('target', '_blank');
          }
        } else if (tag.tagName === 'IMG') {
          tag.classList.add('mtt_img');
        }
        _results.push(tag.setAttribute(attr, parser.href));
      }
      return _results;
    }
  };

  return Tran;

})();

module.exports = new Tran;


},{"./char-codes.js":2}],7:[function(require,module,exports){
"use strict";

var _prototypeProperties = function (child, staticProps, instanceProps) {
  if (staticProps) Object.defineProperties(child, staticProps);
  if (instanceProps) Object.defineProperties(child.prototype, instanceProps);
};

/*
  Translation engine: http://www.turkishdictionary.net
  For translating turkish-russian and vice versa
*/
var CHAR_CODES = require("./char-codes-turk.js");

var TurkishDictionary = (function () {
  function TurkishDictionary() {
    this.host = "http://www.turkishdictionary.net/?word=%FC";
    this.path = "";
    this.protocol = "http";
    this.query = "&s=";
    this.TABLE_CLASS = "___mtt_translate_table";
    // this flag indicates that if translation was successful then publish it all over extension
    this.need_publish = true;
  }

  _prototypeProperties(TurkishDictionary, null, {
    search: {
      value: function search(data) {
        data.url = this.makeUrl(data.value);
        this.need_publish = false;
        return this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    translate: {
      value: function translate(data) {
        data.url = this.makeUrl(data.selectionText);
        this.need_publish = true;
        this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeUrl: {
      value: function makeUrl(text) {
        var text = this.getEncodedValue(text);
        return ["http://www.turkishdictionary.net/?word=", text].join("");
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    getEncodedValue: {


      // Replace special language characters to html codes
      value: function getEncodedValue(value) {
        // to find spec symbols we first encode them (raw search for that symbol doesn't wor)
        return encodeURIComponent(value);
        //return this.makeStringTransferable(value);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeStringTransferable: {

      /** converting script from the turkishdict */
      value: function makeStringTransferable(inputText) {
        var text = "";
        if (inputText.length > 0) {
          text = inputText;
          for (var i = 0; i < text.length; i++) {
            if (CHAR_CODES[text.charCodeAt(i)]) {
              text = text.substring(0, i) + CHAR_CODES[text.charCodeAt(i)] + text.substring(i + 1, text.length);
            } else if (text.charAt(i) == " ") {
              // replace spaces
              text = text.substring(0, i) + "___" + text.substring(i + 1, text.length);
            }
          }
        }
        return text;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    request: {

      /*
        Request translation and run callback function
        passing translated result or error to callback
      */
      value: function request(opts) {
        console.log("start request");
        this.xhr = new XMLHttpRequest();
        this.xhr.onreadystatechange = this.onReadyStateChange.bind(this, opts);
        this.xhr.open("GET", opts.url, true);
        this.xhr.send();
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    onReadyStateChange: {
      value: function onReadyStateChange(opts, e) {
        var xhr = this.xhr;
        if (xhr.readyState < 4) {
          return;
        } else if (xhr.status != 200) {
          this.errorHandler(xhr);
          return opts.error && opts.error();
        } else if (xhr.readyState == 4) {
          var translation = this.successHandler(e.target.response);
          console.log("success turkish translate", translation);
          console.log("call", opts.success);
          return opts.success && opts.success(translation);
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    successHandler: {
      value: function successHandler(response) {
        var data = this.parse(response);
        if (this.need_publish) {
          chrome.tabs.getSelected(null, this.publishTranslation.bind(this, data));
        }
        return data;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    publishTranslation: {

      /* publish successfuly translated text all over extension */
      value: function publishTranslation(translation, tab) {
        console.log("publish translation");
        chrome.tabs.sendMessage(tab.id, {
          action: this.tooltipAction(translation),
          data: translation.outerHTML,
          success: !translation.classList.contains("failTranslate")
        });
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    tooltipAction: {
      value: function tooltipAction(translation) {
        if (translation.textContent.trim().indexOf("was not found in our dictionary") != -1) {
          console.log("similar words");
          return "similar_words";
        } else {
          console.log("open tooltip");
          return "open_tooltip";
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    errorHandler: {
      value: function errorHandler(response) {
        console.log("error ajax", response);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parse: {

      /* Parse response from translation engine */
      value: function parse(response, silent, translate) {
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);
        if (fragment) {
          translate = fragment.querySelector("#meaning_div > table");
          if (translate) {
            translate.className = this.TABLE_CLASS;
            translate.setAttribute("cellpadding", "5");
            // @fixImages(translate)
            // @fixLinks(translate)
          } else if (!silent) {
            translate = document.createElement("div");
            translate.className = "failTranslate";
            translate.innerText = "Unfortunately, could not translate";
          }
        }
        return translate;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parseText: {

      /** parsing of terrible html markup */
      value: function parseText(response, silent, translate) {
        var _this = this;
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);

        if (fragment) {
          var i;
          var _ret = (function () {
            var stopIndex = null;
            var tr = fragment.querySelectorAll("#meaning_div>table>tbody>tr");
            tr = Array.prototype.slice.call(tr);

            var trans = tr.filter(function (tr, index) {
              if (!isNaN(parseInt(stopIndex, 10)) && index >= stopIndex) {
                return;
              } else {
                tr = $(tr);
                // take every row before next section (which is English->English)
                if (tr.attr("bgcolor") == "e0e6ff") {
                  stopIndex = index;return;
                } else {
                  return $.trim(tr.find("td").text()).length;
                }
              }
            });
            trans = trans.slice(1, trans.length - 1);
            trans = trans.filter(function (el, indx) {
              return indx % 2;
            });
            var frag = _this.fragmentFromList(trans);
            var fonts = frag.querySelectorAll("font");
            var text = "";
            for (i = 0; i < fonts.length; i++) {
              text += " " + fonts[i].textContent.trim();
            }
            return {
              v: text
            };
          })();

          if (typeof _ret === "object") return _ret.v;
        } else {
          throw "HTML fragment could not be parsed";
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    stripScripts: {

      //TODO extract to base engine class
      /* removes <script> tags from html code */
      value: function stripScripts(html) {
        var div = document.createElement("div");
        div.innerHTML = html;
        var scripts = div.getElementsByTagName("script");
        var i = scripts.length;
        while (i--) scripts[i].parentNode.removeChild(scripts[i]);
        return div.innerHTML;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeFragment: {

      //TODO extract to base engine class
      /* creates temp object to parse translation from page 
        (since it's not a friendly api) 
      */
      value: function makeFragment(html) {
        var fragment = document.createDocumentFragment(),
            div = document.createElement("div");
        div.innerHTML = html;
        while (div.firstChild) {
          fragment.appendChild(div.firstChild);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    fragmentFromList: {

      /** create fragment from list of DOM elements */
      value: function fragmentFromList(list) {
        var fragment = document.createDocumentFragment(),
            len = list.length;
        while (len--) {
          fragment.appendChild(list[len]);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    }
  });

  return TurkishDictionary;
})();

// Singletone
module.exports = new TurkishDictionary();
},{"./char-codes-turk.js":1}]},{},[4])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvY2hhci1jb2Rlcy10dXJrLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy9jaGFyLWNvZGVzLmpzIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy9wb3B1cC9kcm9wZG93bi5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXZlbG9wbWVudC90cmFuL2pzL3BvcHVwL3BvcHVwLmNvZmZlZSIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvcG9wdXAvc2VhcmNoX2Zvcm0uY29mZmVlIiwiL1VzZXJzL2FudGhvbnkvRGV2ZWxvcG1lbnQvdHJhbi9qcy90cmFuLmNvZmZlZSIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvdHVya2lzaGRpY3Rpb25hcnkuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdkJBOztBQ0FBO0FBQUE7Ozs7Ozs7O0dBQUE7QUFBQSxJQUFBLDhCQUFBOztBQUFBLFNBU0EsR0FDRTtBQUFBLEVBQUEsR0FBQSxFQUFLLEtBQUw7QUFBQSxFQUNBLEdBQUEsRUFBSyxLQURMO0FBQUEsRUFFQSxHQUFBLEVBQUssS0FGTDtBQUFBLEVBR0EsR0FBQSxFQUFLLEtBSEw7QUFBQSxFQUlBLEdBQUEsRUFBSyxLQUpMO0FBQUEsRUFLQSxJQUFBLEVBQU0sS0FMTjtBQUFBLEVBTUEsSUFBQSxFQUFNLEtBTk47QUFBQSxFQU9BLElBQUEsRUFBTSxLQVBOO0FBQUEsRUFRQSxJQUFBLEVBQU0sS0FSTjtBQUFBLEVBU0EsSUFBQSxFQUFNLEtBVE47QUFBQSxFQVVBLElBQUEsRUFBTSxLQVZOO0FBQUEsRUFXQSxJQUFBLEVBQU0sS0FYTjtBQUFBLEVBWUEsTUFBQSxFQUFRLEtBWlI7Q0FWRixDQUFBOztBQUFBLFNBd0JBLEdBQ0U7QUFBQSxFQUFBLEdBQUEsRUFBSyxXQUFMO0FBQUEsRUFDQSxNQUFBLEVBQVEsU0FEUjtDQXpCRixDQUFBOztBQUFBO0FBNkJlLEVBQUEsa0JBQUMsSUFBRCxHQUFBO0FBQ1gsSUFBQSxJQUFDLENBQUEsRUFBRCxHQUFNLElBQUksQ0FBQyxFQUFMLElBQVcsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBakIsQ0FBQTtBQUFBLElBRUEsSUFBQyxDQUFBLFFBQUQsR0FBWSxJQUFJLENBQUMsUUFGakIsQ0FBQTtBQUFBLElBSUEsSUFBQyxDQUFBLElBQUQsR0FBUSxJQUFDLENBQUEsRUFBRSxDQUFDLGFBQUosQ0FBa0IsZ0JBQWxCLENBSlIsQ0FBQTtBQUtBLElBQUEsSUFBRyxJQUFDLENBQUEsSUFBSjtBQUNFLE1BQUEsSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWixHQUFzQixNQUF0QixDQUFBO0FBQUEsTUFDQSxJQUFDLENBQUEsS0FBRCxHQUFTLElBQUMsQ0FBQSxJQUFJLENBQUMsc0JBQU4sQ0FBNkIsZUFBN0IsQ0FEVCxDQUFBO0FBQUEsTUFFQSxJQUFDLENBQUEsTUFBRCxHQUFVLElBQUMsQ0FBQSxFQUFFLENBQUMsYUFBSixDQUFrQixrQkFBbEIsQ0FGVixDQUFBO0FBQUEsTUFHQSxJQUFDLENBQUEsWUFBRCxDQUFBLENBSEEsQ0FBQTtBQUFBLE1BSUEsSUFBQyxDQUFBLFlBQUQsQ0FBQSxDQUpBLENBREY7S0FOVztFQUFBLENBQWI7O0FBQUEscUJBYUEsWUFBQSxHQUFjLFNBQUEsR0FBQTtBQUNaLElBQUEsSUFBQyxDQUFBLE1BQU0sQ0FBQyxnQkFBUixDQUF5QixPQUF6QixFQUFrQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7ZUFBTyxLQUFDLENBQUEsTUFBRCxDQUFRLENBQVIsRUFBUDtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxDLENBQUEsQ0FBQTtBQUFBLElBQ0EsUUFBUSxDQUFDLGdCQUFULENBQTBCLE9BQTFCLEVBQW1DLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLENBQUQsR0FBQTtlQUFPLEtBQUMsQ0FBQSxJQUFELENBQU0sQ0FBTixFQUFQO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbkMsQ0FEQSxDQUFBO1dBRUEsSUFBQyxDQUFBLElBQUksQ0FBQyxnQkFBTixDQUF1QixPQUF2QixFQUFnQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7ZUFBTyxLQUFDLENBQUEsTUFBRCxDQUFRLENBQVIsRUFBUDtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWhDLEVBSFk7RUFBQSxDQWJkLENBQUE7O0FBQUEscUJBbUJBLFlBQUEsR0FBYyxTQUFBLEdBQUE7V0FDWixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUUsUUFBQSxFQUFVLEdBQVo7S0FBeEIsRUFBMEMsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsS0FBRCxHQUFBO2VBQ3hDLEtBQUMsQ0FBQSxRQUFELENBQVUsS0FBSyxDQUFDLFFBQWhCLEVBRHdDO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBMUMsRUFEWTtFQUFBLENBbkJkLENBQUE7O0FBQUEscUJBd0JBLE1BQUEsR0FBUSxTQUFDLENBQUQsR0FBQTtBQUNOLElBQUEsQ0FBQyxDQUFDLGVBQUYsQ0FBQSxDQUFBLENBQUE7QUFBQSxJQUNBLElBQUMsQ0FBQSxhQUFELENBQUEsQ0FEQSxDQUFBO0FBRUEsSUFBQSxJQUFHLElBQUMsQ0FBQSxJQUFELElBQVUsSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWixLQUF1QixNQUFwQzthQUNFLElBQUMsQ0FBQSxJQUFELENBQUEsRUFERjtLQUFBLE1BQUE7YUFHRSxJQUFDLENBQUEsSUFBRCxDQUFBLEVBSEY7S0FITTtFQUFBLENBeEJSLENBQUE7O0FBQUEscUJBaUNBLGFBQUEsR0FBZSxTQUFBLEdBQUE7V0FDYixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUMsUUFBQSxFQUFVLEdBQVg7S0FBeEIsRUFBeUMsQ0FBQSxTQUFBLEtBQUEsR0FBQTthQUFBLFNBQUMsS0FBRCxHQUFBO0FBQ3ZDLFlBQUEsOEJBQUE7QUFBQTtBQUFBO2FBQUEsMkNBQUE7MEJBQUE7QUFDRSxVQUFBLElBQUcsSUFBSSxDQUFDLFlBQUwsQ0FBa0IsVUFBbEIsQ0FBQSxLQUFpQyxLQUFLLENBQUMsUUFBMUM7MEJBQ0UsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFmLENBQW1CLFFBQW5CLEdBREY7V0FBQSxNQUFBOzBCQUdFLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBZixDQUFzQixRQUF0QixHQUhGO1dBREY7QUFBQTt3QkFEdUM7TUFBQSxFQUFBO0lBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUF6QyxFQURhO0VBQUEsQ0FqQ2YsQ0FBQTs7QUFBQSxxQkF5Q0EsSUFBQSxHQUFNLFNBQUEsR0FBQTtXQUNKLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQVosR0FBc0IsT0FEbEI7RUFBQSxDQXpDTixDQUFBOztBQUFBLHFCQTRDQSxJQUFBLEdBQU0sU0FBQSxHQUFBO1dBQ0osSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWixHQUFzQixRQURsQjtFQUFBLENBNUNOLENBQUE7O0FBQUEscUJBaURBLE1BQUEsR0FBUSxTQUFDLENBQUQsR0FBQTtBQUNOLFFBQUEsb0JBQUE7QUFBQSxJQUFBLENBQUMsQ0FBQyxlQUFGLENBQUEsQ0FBQSxDQUFBO0FBQUEsSUFDQSxDQUFDLENBQUMsY0FBRixDQUFBLENBREEsQ0FBQTtBQUFBLElBRUEsUUFBQSxHQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBVCxDQUFzQixVQUF0QixDQUZYLENBQUE7QUFBQSxJQUdBLFVBQUEsR0FBYSxJQUFDLENBQUEsYUFBRCxDQUFlLFFBQWYsQ0FIYixDQUFBO0FBQUEsSUFJQSxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUMsUUFBQSxFQUFVLFFBQVg7QUFBQSxNQUFxQixVQUFBLEVBQVksVUFBakM7S0FBeEIsRUFBc0UsSUFBQyxDQUFBLFFBQXZFLENBSkEsQ0FBQTtBQUFBLElBS0EsSUFBQyxDQUFBLFFBQUQsQ0FBVSxRQUFWLENBTEEsQ0FBQTtXQU1BLElBQUMsQ0FBQSxJQUFELENBQUEsRUFQTTtFQUFBLENBakRSLENBQUE7O0FBQUEscUJBNERBLGFBQUEsR0FBZSxTQUFDLElBQUQsR0FBQTtBQUNiLFFBQUEsSUFBQTtBQUFBLElBQUEsT0FBTyxDQUFDLEdBQVIsQ0FBWSxrQkFBWixFQUErQixJQUEvQixDQUFBLENBQUE7QUFBQSxJQUNBLElBQUEsR0FBTyxTQUFVLENBQUEsSUFBQSxDQUFWLElBQW1CLFdBRDFCLENBQUE7QUFBQSxJQUVBLE9BQU8sQ0FBQyxHQUFSLENBQVksTUFBWixFQUFtQixJQUFuQixDQUZBLENBQUE7QUFHQSxXQUFPLElBQVAsQ0FKYTtFQUFBLENBNURmLENBQUE7O0FBQUEscUJBbUVBLFFBQUEsR0FBVSxTQUFDLFFBQUQsR0FBQTtBQUNSLFFBQUEsSUFBQTtBQUFBLElBQUEsSUFBQSxHQUFPLFNBQVUsQ0FBQSxRQUFBLENBQVYsR0FBc0IsOEJBQTdCLENBQUE7V0FDQSxJQUFDLENBQUEsTUFBTSxDQUFDLFNBQVIsR0FBb0IsS0FGWjtFQUFBLENBbkVWLENBQUE7O2tCQUFBOztJQTdCRixDQUFBOztBQUFBLE1BcUdNLENBQUMsT0FBUCxHQUFpQixRQXJHakIsQ0FBQTs7OztBQ0FBO0FBQUE7OztHQUFBO0FBQUEsSUFBQSxVQUFBOztBQUFBLFVBSUEsR0FBYSxPQUFBLENBQVEsc0JBQVIsQ0FKYixDQUFBOztBQUFBLFFBTVEsQ0FBQyxnQkFBVCxDQUEwQixrQkFBMUIsRUFBOEMsU0FBQSxHQUFBO0FBQzVDLE1BQUEsVUFBQTtBQUFBLEVBQUEsSUFBQSxHQUFXLElBQUEsVUFBQSxDQUFXLFFBQVEsQ0FBQyxjQUFULENBQXdCLFdBQXhCLENBQVgsQ0FBWCxDQUFBO0FBQUEsRUFDQSxJQUFBLEdBQU8sUUFBUSxDQUFDLGNBQVQsQ0FBd0IsYUFBeEIsQ0FEUCxDQUFBO0FBRUEsRUFBQSxJQUFHLElBQUg7V0FDRSxJQUFJLENBQUMsZ0JBQUwsQ0FBc0IsT0FBdEIsRUFBK0IsU0FBQyxDQUFELEdBQUE7QUFDN0IsVUFBQSxJQUFBO0FBQUEsTUFBQSxDQUFDLENBQUMsY0FBRixDQUFBLENBQUEsQ0FBQTtBQUFBLE1BQ0EsSUFBQSxHQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBVCxDQUFzQixNQUF0QixDQUFBLEdBQWdDLElBQUksQ0FBQyxRQUFMLENBQUEsQ0FEdkMsQ0FBQTthQUVBLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBWixDQUFtQjtBQUFBLFFBQUUsR0FBQSxFQUFLLElBQVA7T0FBbkIsRUFINkI7SUFBQSxDQUEvQixFQURGO0dBSDRDO0FBQUEsQ0FBOUMsQ0FOQSxDQUFBOzs7O0FDQUE7QUFBQTs7Ozs7R0FBQTtBQUFBLElBQUEsZ0VBQUE7RUFBQSxxSkFBQTs7QUFBQSxRQU1BLEdBQVcsT0FBQSxDQUFRLG1CQUFSLENBTlgsQ0FBQTs7QUFBQSxJQVNBLEdBQU8sT0FBQSxDQUFRLGdCQUFSLENBVFAsQ0FBQTs7QUFBQSxpQkFVQSxHQUFvQixPQUFBLENBQVEseUJBQVIsQ0FWcEIsQ0FBQTs7QUFBQSxpQkFjQSxHQUNFO0FBQUEsRUFBQSxXQUFBLEVBQWEsSUFBYjtBQUFBLEVBQ0EsU0FBQSxFQUFXLGlCQURYO0NBZkYsQ0FBQTs7QUFBQTtBQW1CZSxFQUFBLG9CQUFFLElBQUYsR0FBQTtBQUNYLElBRFksSUFBQyxDQUFBLE9BQUEsSUFDYixDQUFBO0FBQUEsSUFBQSxJQUFDLENBQUEsS0FBRCxHQUFTLFFBQVEsQ0FBQyxjQUFULENBQXdCLGVBQXhCLENBQVQsQ0FBQTtBQUFBLElBQ0EsSUFBQyxDQUFBLEtBQUssQ0FBQyxLQUFQLENBQUEsQ0FEQSxDQUFBO0FBQUEsSUFHQSxJQUFDLENBQUEsTUFBRCxHQUFVLFFBQVEsQ0FBQyxjQUFULENBQXdCLFFBQXhCLENBSFYsQ0FBQTtBQUFBLElBSUEsSUFBQyxDQUFBLFlBQUQsQ0FBQSxDQUpBLENBQUE7QUFBQSxJQUtBLElBQUMsQ0FBQSxRQUFELEdBQWdCLElBQUEsUUFBQSxDQUFTO0FBQUEsTUFDdkIsRUFBQSxFQUFJLFFBQVEsQ0FBQyxhQUFULENBQXVCLGNBQXZCLENBRG1CO0FBQUEsTUFFdkIsUUFBQSxFQUFVLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFBLEdBQUE7aUJBQUcsS0FBQyxDQUFBLE1BQUQsQ0FBQSxFQUFIO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FGYTtLQUFULENBTGhCLENBRFc7RUFBQSxDQUFiOztBQUFBLHVCQVdBLFlBQUEsR0FBYyxTQUFBLEdBQUE7QUFDWixJQUFBLElBQUcsSUFBQyxDQUFBLElBQUQsSUFBVSxJQUFDLENBQUEsTUFBZDtBQUNFLE1BQUEsSUFBQyxDQUFBLElBQUksQ0FBQyxnQkFBTixDQUF1QixRQUF2QixFQUFpQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxDQUFELEdBQUE7aUJBQU8sS0FBQyxDQUFBLE1BQUQsQ0FBUSxDQUFSLEVBQVA7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFqQyxDQUFBLENBQUE7YUFDQSxJQUFDLENBQUEsTUFBTSxDQUFDLGdCQUFSLENBQXlCLE9BQXpCLEVBQWtDLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLENBQUQsR0FBQTtpQkFBTyxLQUFDLENBQUEsa0JBQUQsQ0FBb0IsQ0FBcEIsRUFBUDtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxDLEVBRkY7S0FEWTtFQUFBLENBWGQsQ0FBQTs7QUFBQSx1QkFnQkEsTUFBQSxHQUFRLFNBQUMsQ0FBRCxHQUFBO0FBQ04sSUFBQSxDQUFBLElBQUssQ0FBQyxDQUFDLGNBQVAsSUFBeUIsQ0FBQyxDQUFDLGNBQUYsQ0FBQSxDQUF6QixDQUFBO0FBQ0EsSUFBQSxJQUFHLElBQUMsQ0FBQSxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQWIsR0FBc0IsQ0FBekI7YUFFRSxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLFFBQUMsUUFBQSxFQUFVLEdBQVg7QUFBQSxRQUFnQixVQUFBLEVBQVksV0FBNUI7T0FBeEIsRUFBa0UsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsS0FBRCxHQUFBO0FBQ2hFLFVBQUEsT0FBTyxDQUFDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCLEtBQXRCLENBQUEsQ0FBQTtpQkFDQSxpQkFBa0IsQ0FBQSxLQUFLLENBQUMsVUFBTixDQUFpQixDQUFDLE1BQXBDLENBQ0U7QUFBQSxZQUFBLEtBQUEsRUFBTyxLQUFDLENBQUEsS0FBSyxDQUFDLEtBQWQ7QUFBQSxZQUNBLE9BQUEsRUFBUyxLQUFDLENBQUEsY0FBYyxDQUFDLElBQWhCLENBQXFCLEtBQXJCLENBRFQ7V0FERixFQUZnRTtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxFLEVBRkY7S0FGTTtFQUFBLENBaEJSLENBQUE7O0FBQUEsdUJBMkJBLGNBQUEsR0FBZ0IsU0FBQyxRQUFELEdBQUE7QUFDWixJQUFBLElBQUMsQ0FBQSxLQUFELENBQU8sSUFBQyxDQUFBLE1BQVIsQ0FBQSxDQUFBO1dBQ0EsSUFBQyxDQUFBLE1BQU0sQ0FBQyxXQUFSLENBQW9CLFFBQXBCLEVBRlk7RUFBQSxDQTNCaEIsQ0FBQTs7QUFBQSx1QkErQkEsS0FBQSxHQUFPLFNBQUMsRUFBRCxHQUFBO0FBQ0wsUUFBQSxRQUFBO0FBQUE7V0FBTyxFQUFFLENBQUMsU0FBVixHQUFBO0FBQ0Usb0JBQUEsRUFBRSxDQUFDLFdBQUgsQ0FBZSxFQUFFLENBQUMsU0FBbEIsRUFBQSxDQURGO0lBQUEsQ0FBQTtvQkFESztFQUFBLENBL0JQLENBQUE7O0FBQUEsdUJBbUNBLGtCQUFBLEdBQW9CLFNBQUMsQ0FBRCxHQUFBO0FBQ2xCLFFBQUEsY0FBQTtBQUFBLElBQUEsQ0FBQyxDQUFDLGNBQUYsQ0FBQSxDQUFBLENBQUE7QUFBQSxJQUNBLFFBQUEsR0FBVyxDQUFDLEdBQUQsRUFBTSxHQUFOLENBRFgsQ0FBQTtBQUVBLElBQUEsV0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQVQsRUFBQSxlQUFvQixRQUFwQixFQUFBLElBQUEsTUFBSDtBQUNFLE1BQUEsSUFBQyxDQUFBLEtBQUssQ0FBQyxLQUFQLEdBQWUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUF4QixDQUFBO2FBQ0EsSUFBQyxDQUFBLE1BQUQsQ0FBUSxDQUFSLEVBRkY7S0FIa0I7RUFBQSxDQW5DcEIsQ0FBQTs7QUFBQSx1QkEwQ0EsUUFBQSxHQUFVLFNBQUEsR0FBQTtBQUNSLFdBQU8sSUFBQyxDQUFBLEtBQUssQ0FBQyxLQUFkLENBRFE7RUFBQSxDQTFDVixDQUFBOztvQkFBQTs7SUFuQkYsQ0FBQTs7QUFBQSxNQWlFTSxDQUFDLE9BQVAsR0FBaUIsVUFqRWpCLENBQUE7Ozs7QUNBQTtBQUFBLGtCQUFBO0FBQ0E7QUFBQTs7Ozs7Ozs7OztHQURBO0FBQUEsSUFBQSxnQkFBQTs7QUFBQSxVQWFBLEdBQWEsT0FBQSxDQUFRLGlCQUFSLENBYmIsQ0FBQTs7QUFBQTtBQWdCZSxFQUFBLGNBQUEsR0FBQTtBQUNYLElBQUEsSUFBQyxDQUFBLFdBQUQsR0FBZSx3QkFBZixDQUFBO0FBQUEsSUFDQSxJQUFDLENBQUEsUUFBRCxHQUFZLE1BRFosQ0FBQTtBQUFBLElBRUEsSUFBQyxDQUFBLElBQUQsR0FBUSxrQkFGUixDQUFBO0FBQUEsSUFHQSxJQUFDLENBQUEsSUFBRCxHQUFRLFVBSFIsQ0FBQTtBQUFBLElBSUEsSUFBQyxDQUFBLEtBQUQsR0FBUyxLQUpULENBQUE7QUFBQSxJQUtBLElBQUMsQ0FBQSxJQUFELEdBQVEsWUFMUixDQUFBO0FBQUEsSUFNQSxJQUFDLENBQUEsR0FBRCxHQUFPLEVBTlAsQ0FEVztFQUFBLENBQWI7O0FBU0E7QUFBQTs7S0FUQTs7QUFBQSxpQkFZQSxLQUFBLEdBQU8sU0FBQyxJQUFELEdBQUE7QUFDTCxRQUFBLGFBQUE7QUFBQSxJQUFBLElBQUcsTUFBQSxDQUFBLElBQVcsQ0FBQyxNQUFaLEtBQXNCLE1BQXRCLElBQW1DLElBQUksQ0FBQyxNQUFMLEtBQWUsSUFBckQ7QUFDRSxNQUFBLElBQUksQ0FBQyxNQUFMLEdBQWMsSUFBZCxDQURGO0tBQUE7QUFBQSxJQUVBLGFBQUEsR0FBZ0IsSUFBQyxDQUFBLGlCQUFELENBQW1CLElBQUksQ0FBQyxhQUF4QixDQUZoQixDQUFBO1dBR0EsSUFBQyxDQUFBLE1BQUQsQ0FDSTtBQUFBLE1BQUEsS0FBQSxFQUFPLGFBQVA7QUFBQSxNQUNBLE9BQUEsRUFBUyxJQUFDLENBQUEsZUFBZSxDQUFDLElBQWpCLENBQXNCLElBQXRCLENBRFQ7QUFBQSxNQUVBLE1BQUEsRUFBUSxJQUFJLENBQUMsTUFGYjtLQURKLEVBSks7RUFBQSxDQVpQLENBQUE7O0FBcUJBO0FBQUE7O0tBckJBOztBQUFBLGlCQXdCQSxpQkFBQSxHQUFtQixTQUFDLElBQUQsR0FBQTtXQUNqQixJQUFJLENBQUMsT0FBTCxDQUFhLE9BQWIsRUFBc0IsRUFBdEIsRUFEaUI7RUFBQSxDQXhCbkIsQ0FBQTs7QUEyQkE7QUFBQTs7S0EzQkE7O0FBQUEsaUJBOEJBLE1BQUEsR0FBUSxTQUFDLE1BQUQsR0FBQTtXQUVOLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsTUFBQyxRQUFBLEVBQVUsR0FBWDtLQUF4QixFQUF5QyxDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxLQUFELEdBQUE7QUFDdkMsWUFBQSwwQkFBQTtBQUFBLFFBQUEsSUFBRyxRQUFBLEtBQVksRUFBZjtBQUNFLFVBQUEsUUFBQSxHQUFXLEdBQVgsQ0FERjtTQUFBO0FBQUEsUUFFQSxLQUFDLENBQUEsV0FBRCxDQUFhLEtBQUssQ0FBQyxRQUFuQixDQUZBLENBQUE7QUFBQSxRQUdBLEdBQUEsR0FBTSxLQUFDLENBQUEsT0FBRCxDQUFTLE1BQU0sQ0FBQyxLQUFoQixDQUhOLENBQUE7QUFBQSxRQUtBLFdBQUEsR0FBYyxNQUFNLENBQUMsT0FMckIsQ0FBQTtBQUFBLFFBTUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsU0FBQyxRQUFELEdBQUE7QUFDZixjQUFBLFVBQUE7QUFBQSxVQUFBLFVBQUEsR0FBYSxLQUFDLENBQUEsS0FBRCxDQUFPLFFBQVAsRUFBaUIsTUFBTSxDQUFDLE1BQXhCLENBQWIsQ0FBQTtpQkFDQSxXQUFBLENBQVksVUFBWixFQUZlO1FBQUEsQ0FOakIsQ0FBQTtlQVdBLEtBQUMsQ0FBQSxPQUFELENBQ0U7QUFBQSxVQUFBLEdBQUEsRUFBSyxHQUFMO0FBQUEsVUFDQSxPQUFBLEVBQVMsTUFBTSxDQUFDLE9BRGhCO0FBQUEsVUFFQSxLQUFBLEVBQU8sTUFBTSxDQUFDLEtBRmQ7U0FERixFQVp1QztNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpDLEVBRk07RUFBQSxDQTlCUixDQUFBOztBQUFBLGlCQW1EQSxXQUFBLEdBQWEsU0FBQyxRQUFELEdBQUE7QUFDWCxJQUFBLElBQUMsQ0FBQSxlQUFELEdBQW1CLFFBQW5CLENBQUE7V0FDQSxJQUFDLENBQUEsSUFBRCxHQUFRLFdBQUEsR0FBYyxTQUZYO0VBQUEsQ0FuRGIsQ0FBQTs7QUF1REE7QUFBQTs7O0tBdkRBOztBQUFBLGlCQTJEQSxPQUFBLEdBQVMsU0FBQyxJQUFELEdBQUE7QUFDUCxRQUFBLEdBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxJQUFDLENBQUEsR0FBRCxHQUFXLElBQUEsY0FBQSxDQUFBLENBQWpCLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxrQkFBSixHQUF5QixDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQyxDQUFELEdBQUE7QUFDdkIsUUFBQSxHQUFBLEdBQU0sS0FBQyxDQUFBLEdBQVAsQ0FBQTtBQUNBLFFBQUEsSUFBRyxHQUFHLENBQUMsVUFBSixHQUFpQixDQUFwQjtBQUFBO1NBQUEsTUFFSyxJQUFHLEdBQUcsQ0FBQyxNQUFKLEtBQWMsR0FBakI7QUFDSCxVQUFBLEtBQUMsQ0FBQSxZQUFELENBQWMsR0FBZCxDQUFBLENBQUE7QUFDQSxVQUFBLElBQUksTUFBQSxDQUFBLElBQVcsQ0FBQyxLQUFaLEtBQXFCLFVBQXpCO0FBQ0UsWUFBQSxJQUFJLENBQUMsS0FBTCxDQUFBLENBQUEsQ0FERjtXQUZHO1NBQUEsTUFLQSxJQUFHLEdBQUcsQ0FBQyxVQUFKLEtBQWtCLENBQXJCO0FBQ0QsaUJBQU8sSUFBSSxDQUFDLE9BQUwsQ0FBYSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQXRCLENBQVAsQ0FEQztTQVRrQjtNQUFBLEVBQUE7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRHpCLENBQUE7QUFBQSxJQWFBLEdBQUcsQ0FBQyxJQUFKLENBQVMsS0FBVCxFQUFnQixJQUFJLENBQUMsR0FBckIsRUFBMEIsSUFBMUIsQ0FiQSxDQUFBO1dBY0EsR0FBRyxDQUFDLElBQUosQ0FBQSxFQWZPO0VBQUEsQ0EzRFQsQ0FBQTs7QUFBQSxpQkE2RUEsT0FBQSxHQUFTLFNBQUMsS0FBRCxHQUFBO0FBQ1AsUUFBQSxHQUFBO0FBQUEsSUFBQSxHQUFBLEdBQU0sQ0FBQyxJQUFDLENBQUEsUUFBRixFQUFZLEtBQVosRUFDSSxJQUFDLENBQUEsSUFETCxFQUVJLElBQUMsQ0FBQSxJQUZMLEVBR0ksSUFBQyxDQUFBLElBSEwsRUFJSSxJQUFDLENBQUEsS0FKTCxFQUtJLElBQUMsQ0FBQSxlQUFELENBQWlCLEtBQWpCLENBTEosQ0FNQyxDQUFDLElBTkYsQ0FNTyxFQU5QLENBQU4sQ0FBQTtBQVFBLFdBQU8sR0FBUCxDQVRPO0VBQUEsQ0E3RVQsQ0FBQTs7QUFBQSxpQkF5RkEsZUFBQSxHQUFpQixTQUFDLEtBQUQsR0FBQTtBQUVmLFFBQUEsbUJBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxrQkFBQSxDQUFtQixLQUFuQixDQUFOLENBQUE7QUFDQSxTQUFBLGtCQUFBOzhCQUFBO0FBQ0UsTUFBQSxJQUFHLE1BQUEsQ0FBQSxJQUFBLEtBQWUsUUFBbEI7QUFFRSxRQUFBLEVBQUEsR0FBSyxJQUFJLENBQUMsR0FBVixDQUZGO09BQUEsTUFBQTtBQU1FLFFBQUEsRUFBQSxHQUFLLGtCQUFBLENBQW1CLElBQW5CLENBQUwsQ0FORjtPQUFBO0FBQUEsTUFPQSxHQUFBLEdBQU0sR0FBRyxDQUFDLE9BQUosQ0FBWSxJQUFaLEVBQWtCLEVBQWxCLENBUE4sQ0FERjtBQUFBLEtBREE7QUFVQSxXQUFPLEdBQVAsQ0FaZTtFQUFBLENBekZqQixDQUFBOztBQUFBLGlCQXVHQSxZQUFBLEdBQWMsU0FBQyxHQUFELEdBQUE7V0FDWixPQUFPLENBQUMsR0FBUixDQUFZLE9BQVosRUFBcUIsR0FBckIsRUFEWTtFQUFBLENBdkdkLENBQUE7O0FBMEdBO0FBQUE7O0tBMUdBOztBQUFBLGlCQTZHQSxlQUFBLEdBQWlCLFNBQUMsVUFBRCxHQUFBO0FBQ2YsSUFBQSxJQUFHLFVBQUg7YUFDRSxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVosQ0FBd0IsSUFBeEIsRUFBOEIsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsR0FBRCxHQUFBO2lCQUM1QixNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVosQ0FBd0IsR0FBRyxDQUFDLEVBQTVCLEVBQWdDO0FBQUEsWUFDOUIsTUFBQSxFQUFRLEtBQUMsQ0FBQSxXQUFELENBQWEsVUFBYixDQURzQjtBQUFBLFlBRTlCLElBQUEsRUFBTSxVQUFVLENBQUMsU0FGYTtBQUFBLFlBRzlCLE9BQUEsRUFBUyxDQUFBLFVBQVcsQ0FBQyxTQUFTLENBQUMsUUFBckIsQ0FBOEIsZUFBOUIsQ0FIb0I7V0FBaEMsRUFENEI7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUE5QixFQURGO0tBRGU7RUFBQSxDQTdHakIsQ0FBQTs7QUFBQSxpQkF1SEEsV0FBQSxHQUFhLFNBQUMsVUFBRCxHQUFBO0FBQ1gsUUFBQSxJQUFBO0FBQUEsSUFBQSxpRUFBbUIsQ0FBRSx5QkFBbEIsS0FBNEIsQ0FBL0I7YUFDRSxnQkFERjtLQUFBLE1BQUE7YUFHRSxlQUhGO0tBRFc7RUFBQSxDQXZIYixDQUFBOztBQTZIQTtBQUFBOztLQTdIQTs7QUFBQSxpQkFnSUEsS0FBQSxHQUFPLFNBQUMsUUFBRCxFQUFXLE1BQVgsRUFBbUIsU0FBbkIsR0FBQTtBQUNILFFBQUEsYUFBQTs7TUFEc0IsWUFBWTtLQUNsQztBQUFBLElBQUEsR0FBQSxHQUFNLElBQUMsQ0FBQSxZQUFELENBQWMsUUFBZCxDQUFOLENBQUE7QUFBQSxJQUNBLFFBQUEsR0FBVyxJQUFDLENBQUEsWUFBRCxDQUFjLEdBQWQsQ0FEWCxDQUFBO0FBRUEsSUFBQSxJQUFHLFFBQUg7QUFDRSxNQUFBLFNBQUEsR0FBWSxRQUFRLENBQUMsYUFBVCxDQUF1QixzQkFBdkIsQ0FBWixDQUFBO0FBQ0EsTUFBQSxJQUFHLFNBQUg7QUFDRSxRQUFBLFNBQVMsQ0FBQyxTQUFWLEdBQXNCLElBQUMsQ0FBQSxXQUF2QixDQUFBO0FBQUEsUUFDQSxTQUFTLENBQUMsWUFBVixDQUF1QixhQUF2QixFQUFzQyxHQUF0QyxDQURBLENBQUE7QUFBQSxRQUVBLElBQUMsQ0FBQSxTQUFELENBQVcsU0FBWCxDQUZBLENBQUE7QUFBQSxRQUdBLElBQUMsQ0FBQSxRQUFELENBQVUsU0FBVixDQUhBLENBREY7T0FBQSxNQUtLLElBQUcsQ0FBQSxNQUFIO0FBQ0gsUUFBQSxTQUFBLEdBQVksUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBWixDQUFBO0FBQUEsUUFDQSxTQUFTLENBQUMsU0FBVixHQUFzQixlQUR0QixDQUFBO0FBQUEsUUFFQSxTQUFTLENBQUMsU0FBVixHQUFzQixvQ0FGdEIsQ0FERztPQVBQO0tBRkE7QUFjQSxXQUFPLFNBQVAsQ0FmRztFQUFBLENBaElQLENBQUE7O0FBaUpBO0FBQUE7O0tBakpBOztBQUFBLGlCQW9KQSxZQUFBLEdBQWMsU0FBQyxDQUFELEdBQUE7QUFDWixRQUFBLGVBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFOLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxTQUFKLEdBQWdCLENBRGhCLENBQUE7QUFBQSxJQUVBLE9BQUEsR0FBVSxHQUFHLENBQUMsb0JBQUosQ0FBeUIsUUFBekIsQ0FGVixDQUFBO0FBQUEsSUFHQSxDQUFBLEdBQUksT0FBTyxDQUFDLE1BSFosQ0FBQTtBQUlBLFdBQU0sQ0FBQSxFQUFOLEdBQUE7QUFDRSxNQUFBLE9BQVEsQ0FBQSxDQUFBLENBQUUsQ0FBQyxVQUFVLENBQUMsV0FBdEIsQ0FBa0MsT0FBUSxDQUFBLENBQUEsQ0FBMUMsQ0FBQSxDQURGO0lBQUEsQ0FKQTtBQU1BLFdBQU8sR0FBRyxDQUFDLFNBQVgsQ0FQWTtFQUFBLENBcEpkLENBQUE7O0FBQUEsaUJBNkpBLFlBQUEsR0FBYyxTQUFDLEdBQUQsRUFBTSxRQUFOLEdBQUE7QUFDWixRQUFBLEdBQUE7O01BRGtCLFdBQVc7S0FDN0I7QUFBQSxJQUFBLEdBQUEsR0FBTSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFOLENBQUE7QUFBQSxJQUNBLEdBQUcsQ0FBQyxTQUFKLEdBQWdCLEdBRGhCLENBQUE7QUFBQSxJQUVBLFFBQUEsR0FBVyxRQUFRLENBQUMsc0JBQVQsQ0FBQSxDQUZYLENBQUE7QUFHQSxXQUFRLEdBQUcsQ0FBQyxVQUFaLEdBQUE7QUFDRSxNQUFBLFFBQVEsQ0FBQyxXQUFULENBQXNCLEdBQUcsQ0FBQyxVQUExQixDQUFBLENBREY7SUFBQSxDQUhBO0FBS0EsV0FBTyxRQUFQLENBTlk7RUFBQSxDQTdKZCxDQUFBOztBQUFBLGlCQXFLQSxTQUFBLEdBQVcsU0FBQyxRQUFELEdBQUE7O01BQUMsV0FBUztLQUNuQjtBQUFBLElBQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxRQUFaLEVBQXNCLEtBQXRCLEVBQTZCLEtBQTdCLENBQUEsQ0FBQTtBQUNBLFdBQU8sUUFBUCxDQUZTO0VBQUEsQ0FyS1gsQ0FBQTs7QUFBQSxpQkF5S0EsUUFBQSxHQUFVLFNBQUMsUUFBRCxHQUFBOztNQUFDLFdBQVM7S0FDbEI7QUFBQSxJQUFBLElBQUksQ0FBQyxNQUFMLENBQVksUUFBWixFQUFzQixHQUF0QixFQUEyQixNQUEzQixDQUFBLENBQUE7QUFDQSxXQUFPLFFBQVAsQ0FGUTtFQUFBLENBektWLENBQUE7O0FBQUEsaUJBNktBLE1BQUEsR0FBUSxTQUFDLFFBQUQsRUFBZ0IsR0FBaEIsRUFBcUIsSUFBckIsR0FBQTtBQUNOLFFBQUEsZ0NBQUE7O01BRE8sV0FBUztLQUNoQjtBQUFBLElBQUEsSUFBRyxRQUFIO0FBQ0UsTUFBQSxJQUFBLEdBQVEsUUFBUSxDQUFDLGdCQUFULENBQTBCLEdBQTFCLENBQVIsQ0FBQTtBQUFBLE1BQ0EsTUFBQSxHQUFTLFFBQVEsQ0FBQyxhQUFULENBQXVCLEdBQXZCLENBRFQsQ0FBQTtBQUVBO1dBQUEsMkNBQUE7dUJBQUE7QUFDRSxRQUFBLE1BQU0sQ0FBQyxJQUFQLEdBQWMsR0FBSSxDQUFBLElBQUEsQ0FBbEIsQ0FBQTtBQUFBLFFBQ0EsTUFBTSxDQUFDLElBQVAsR0FBYyxJQUFDLENBQUEsSUFEZixDQUFBO0FBQUEsUUFFQSxNQUFNLENBQUMsUUFBUCxHQUFrQixJQUFDLENBQUEsUUFGbkIsQ0FBQTtBQUlBLFFBQUEsSUFBRyxHQUFHLENBQUMsT0FBSixLQUFlLEdBQWxCO0FBQ0UsVUFBQSxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQWQsQ0FBa0IsVUFBbEIsQ0FBQSxDQUFBO0FBQ0EsVUFBQSxJQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBaEIsQ0FBd0IsT0FBeEIsQ0FBQSxLQUFzQyxDQUFBLENBQXpDO0FBQ0UsWUFBQSxNQUFNLENBQUMsUUFBUCxHQUFrQixJQUFBLEdBQU8sTUFBTSxDQUFDLFFBQWhDLENBQUE7QUFBQSxZQUNBLEdBQUcsQ0FBQyxZQUFKLENBQWlCLFFBQWpCLEVBQTJCLFFBQTNCLENBREEsQ0FERjtXQUZGO1NBQUEsTUFLSyxJQUFHLEdBQUcsQ0FBQyxPQUFKLEtBQWUsS0FBbEI7QUFDSCxVQUFBLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBZCxDQUFrQixTQUFsQixDQUFBLENBREc7U0FUTDtBQUFBLHNCQVlBLEdBQUcsQ0FBQyxZQUFKLENBQWlCLElBQWpCLEVBQXVCLE1BQU0sQ0FBQyxJQUE5QixFQVpBLENBREY7QUFBQTtzQkFIRjtLQURNO0VBQUEsQ0E3S1IsQ0FBQTs7Y0FBQTs7SUFoQkYsQ0FBQTs7QUFBQSxNQWtOTSxDQUFDLE9BQVAsR0FBaUIsR0FBQSxDQUFBLElBbE5qQixDQUFBOzs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpfXZhciBmPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChmLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGYsZi5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCIvLyB0dXJraXNoZGljdGlvbmFyeSBjb2RpbmdzXG52YXIgRElDVCA9IHtcbiAgICAzNTA6ICclREUnLCAvL8WeXG4gICAgMjg2OiAnJUQwJywgLy/EnlxuICAgIDI4NzogJyVGMCcsIC8vxJ9cbiAgICAzNTE6ICclRkUnLCAvL8WfXG4gICAgMzA1OiAnJUZEJywgLy/EsVxuICAgIDMwNDogJyVERCcsIC8vxLBcbiAgICAyNTI6ICclRkMnLCAvL8O8XG4gICAgMjIwOiAnJURDJywgLy/DnFxuICAgIDIzMTogJyVFNycsIC8vw6dcbiAgICAxOTk6ICclQzcnLCAvL8OHXG4gICAgMjQ2OiAnJUY2JywgLy/DtlxuICAgIDI0NDogJyVGNCcsIC8vw7RcbiAgICAyMTQ6ICclRDYnLCAvL8OWXG4gICAgMjEyOiAnJUQ0JywgLy/DlFxuICAgIDI1MTogJyVGQicsIC8vw7tcbiAgICAyMTk6ICclREInLCAvL8ObXG4gICAgMTk0OiAnJUMyJywgLy/DglxuICAgIDIyNjogJyVFMicsIC8vw6JcbiAgICAzOTogJycsICAvLydcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gRElDVDsiLCIvKlxyICBNdWx0aXRyYW4gZGVwZW5kcyBvbiBodG1sLWVzY2FwaW5nIChub3QgVVRGLTgpIHJ1bGVzIGZvciBzcGVjaWFsIHN5bWJvbHNcciAgw6AsIMOoLCDDrCwgw7IsIMO5IC0gw4AsIMOILCDDjCwgw5IsIMOZXHIgIMOhLCDDqSwgw60sIMOzLCDDuiwgw70gLSDDgSwgw4ksIMONLCDDkywgw5osIMOdXHIgIMOiLCDDqiwgw64sIMO0LCDDuyDDgiwgw4osIMOOLCDDlCwgw5tcciAgw6MsIMOxLCDDtSDDgywgw5EsIMOVXHIgIMOkLCDDqywgw68sIMO2LCDDvCwgw78gw4QsIMOLLCDDjywgw5YsIMOcLFxyICDDpSwgw4VcciAgw6YsIMOGXHIgIMOnLCDDh1xyICDDsCwgw5BcciAgw7gsIMOYXHIgIMK/IMKhIMOfXHIqL1xydmFyIENIQVJfQ09ERVMgPSB7XHIgIC8vcnVzc2lhblxyICAnJUQxJThBJzoge3ZhbDonJUZBJywgbGFuZzoncnUnfSwgLy8g0YpcciAgJyVEMCVBQSc6IHt2YWw6JyVEQScsIGxhbmc6J3J1J30sLy8g0KpcclxyICAnJUMzJTgwJzogJyYjMTkyOycsIC8vIMOAXHIgICclQzMlODEnOiAnJiMxOTM7JywgLy8gw4FcciAgJyVDMyU4Mic6ICcmIzE5NDsnLCAvLyDDglxyICAnJUMzJTgzJzogJyYjMTk1OycsIC8vIMODXHIgICclQzMlODQnOiAnJiMxOTY7JywgLy8gw4RcciAgJyVDMyU4NSc6ICcmIzE5NzsnLCAvLyDDhVxyICAnJUMzJTg2JzogJyYjMTk4OycsIC8vIMOGXHJcciAgJyVDMyU4Nyc6ICcmIzE5OTsnLCAvLyDDh1xyICAnJUMzJTg4JzogJyYjMjAwOycsIC8vIMOIXHIgICclQzMlODknOiAnJiMyMDE7JywgLy8gw4lcciAgJyVDMyU4QSc6ICcmIzIwMjsnLCAvLyDDilxyICAnJUMzJThCJzogJyYjMjAzOycsIC8vIMOLXHJcciAgJyVDMyU4Qyc6ICcmIzIwNDsnLCAvLyDDjFxyICAnJUMzJThEJzogJyYjMjA1OycsIC8vIMONXHIgICclQzMlOEUnOiAnJiMyMDY7JywgLy8gw45cciAgJyVDMyU4Ric6ICcmIzIwNzsnLCAvLyDDj1xyXHIgICclQzMlOTEnOiAnJiMyMDk7JywgLy8gw5FcciAgJyVDMyU5Mic6ICcmIzIxMDsnLCAvLyDDklxyICAnJUMzJTkzJzogJyYjMjExOycsIC8vIMOTXHIgICclQzMlOTQnOiAnJiMyMTI7JywgLy8gw5RcciAgJyVDMyU5NSc6ICcmIzIxMzsnLCAvLyDDlVxyICAnJUMzJTk2JzogJyYjMjE0OycsIC8vIMOWXHJcciAgJyVDMyU5OSc6ICcmIzIxNzsnLCAvLyDDmVxyICAnJUMzJTlBJzogJyYjMjE4OycsIC8vIMOaXHIgICclQzMlOUInOiAnJiMyMTk7JywgLy8gw5tcciAgJyVDMyU5Qyc6ICcmIzIyMDsnLCAvLyDDnFxyXHJcciAgJyVDMyVBMCc6ICcmIzIyNDsnLCAvLyDDoFxyICAnJUMzJUExJzogJyYjMjI1OycsIC8vIMOhXHIgICclQzMlQTInOiAnJiMyMjY7JywgLy8gw6JcciAgJyVDMyVBMyc6ICcmIzIyNzsnLCAvLyDDo1xyICAnJUMzJUE0JzogJyYjMjI4OycsIC8vIMOkXHIgICclQzMlQTUnOiAnJiMyMjk7JywgLy8gw6VcciAgJyVDMyVBNic6ICcmIzIzMDsnLCAvLyDDplxyICAnJUMzJUE3JzogJyYjMjMxOycsIC8vIMOnXHJcclxyICAnJUMzJUE4JzogJyYjMjMyOycsIC8vIMOoXHIgICclQzMlQTknOiAnJiMyMzM7JywgLy8gw6lcciAgJyVDMyVBQSc6ICcmIzIzNDsnLCAvLyDDqlxyICAnJUMzJUFCJzogJyYjMjM1OycsIC8vIMOrXHJcciAgJyVDMyVBQyc6ICcmIzIzNjsnLCAvLyDDrFxyICAnJUMzJUFEJzogJyYjMjM3OycsIC8vIMOtXHIgICclQzMlQUUnOiAnJiMyMzg7JywgLy8gw65cciAgJyVDMyVBRic6ICcmIzIzOTsnLCAvLyDDr1xyXHIgICclQzMlQjAnOiAnJiMyNDA7JywgLy8gw7BcciAgJyVDMyVCMSc6ICcmIzI0MTsnLCAvLyDDsVxyXHIgICclQzMlQjInOiAnJiMyNDI7JywgLy8gw7JcciAgJyVDMyVCMyc6ICcmIzI0MzsnLCAvLyDDs1xyICAnJUMzJUI0JzogJyYjMjQ0OycsIC8vIMO0XHIgICclQzMlQjUnOiAnJiMyNDU7JywgLy8gw7VcciAgJyVDMyVCNic6ICcmIzI0NjsnLCAvLyDDtlxyXHIgICclQzMlQjknOiAnJiMyNDk7JywgLy8gw7lcciAgJyVDMyVCQSc6ICcmIzI1MDsnLCAvLyDDulxyICAnJUMzJUJCJzogJyYjMjUxOycsIC8vIMO7XHIgICclQzMlQkMnOiAnJiMyNTI7JywgLy8gw7xcciAgJyVDMyVCRic6ICcmIzI1NTsnLCAvLyDDv1xyICAnJUM1JUI4JzogJyYjMzc2OycsIC8vIMW4XHJcciAgJyVDMyU5Ric6ICcmIzIyMzsnLCAvLyDDn1xyXHIgICclQzIlQkYnOiAnJiMxOTE7JywgLy8gwr9cciAgJyVDMiVBMSc6ICcmIzE2MTsnLCAvLyDCoVxyfTtcclxybW9kdWxlLmV4cG9ydHMgPSBDSEFSX0NPREVTO1xyIiwiIyMjXG4gIERyb3Bkb3duIGxhbmd1YWdlIG1lbnVcbiAgQHBhcmFtIG9wdHMgdGFrZXMgZWxlbWVudCBhbmQgb25TZWxlY3QgaGFuZGxlclxuICBleGFtcGxlOlxuICBuZXcgRHJvcGRvd24oe1xuICAgZWw6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCcjbWVudScpO1xuICAgb25TZWxlY3Q6IGZ1bmN0aW9uICgpIHt9XG4gIH0pXG4jIyNcbkxBTkdfQ09ERSA9XG4gICcxJzogJ0VuZydcbiAgJzInOiAnUnVzJ1xuICAnMyc6ICdHZXInXG4gICc0JzogJ0ZyZSdcbiAgJzUnOiAnU3BhJ1xuICAnMjMnOiAnSXRhJ1xuICAnMjQnOiAnRHV0J1xuICAnMjYnOiAnRXN0J1xuICAnMjcnOiAnTGF2J1xuICAnMzEnOiAnQWZyJ1xuICAnMzQnOiAnRXBvJ1xuICAnMzUnOiAnWGFsJyxcbiAgJzEwMDAnOiAnVHVyJ1xuXG5ESUNUX0NPREUgPVxuICAnMSc6ICdtdWx0aXRyYW4nXG4gICcxMDAwJzogJ3R1cmtpc2gnXG5cbmNsYXNzIERyb3Bkb3duXG4gIGNvbnN0cnVjdG9yOiAob3B0cykgLT5cbiAgICBAZWwgPSBvcHRzLmVsIG9yIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgIyBvblNlbGVjdCBoYW5kbGVyIHNldCBieSBhZ2dyZWdhdGUgY2xhc3NcbiAgICBAb25TZWxlY3QgPSBvcHRzLm9uU2VsZWN0XG5cbiAgICBAbWVudSA9IEBlbC5xdWVyeVNlbGVjdG9yKCcuZHJvcGRvd24tbWVudScpXG4gICAgaWYgQG1lbnVcbiAgICAgIEBtZW51LnN0eWxlLmRpc3BsYXkgPSAnbm9uZSdcbiAgICAgIEBpdGVtcyA9IEBtZW51LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoJ2xhbmd1YWdlLXR5cGUnKVxuICAgICAgQGJ1dHRvbiA9IEBlbC5xdWVyeVNlbGVjdG9yKCcuZHJvcGRvd24tdG9nZ2xlJylcbiAgICAgIEBhZGRMaXN0ZW5lcnMoKVxuICAgICAgQGluaXRMYW5ndWFnZSgpXG5cbiAgYWRkTGlzdGVuZXJzOiAtPlxuICAgIEBidXR0b24uYWRkRXZlbnRMaXN0ZW5lciAnY2xpY2snLCAoZSkgPT4gQHRvZ2dsZShlKVxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIgJ2NsaWNrJywgKGUpID0+IEBoaWRlKGUpXG4gICAgQG1lbnUuYWRkRXZlbnRMaXN0ZW5lciAnY2xpY2snLCAoZSkgPT4gQGNob29zZShlKVxuXG4gICMgT24gaW5pdCB0cnlpbmcgdG8gZ2V0IGN1cnJlbnQgbGFuZ3VhZ2UgZnJvbSBzdG9yYWdlIG9yIHVzaW5nIGRlZmF1bHQoIDE6ZW5nbGlzaClcbiAgaW5pdExhbmd1YWdlOiAtPlxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHsgbGFuZ3VhZ2U6ICcxJ30sIChzdG9yZSkgPT5cbiAgICAgIEBzZXRUaXRsZShzdG9yZS5sYW5ndWFnZSk7XG4gICAgKVxuXG4gIHRvZ2dsZTogKGUpIC0+XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKVxuICAgIEBzZXRBY3RpdmVJdGVtKClcbiAgICBpZiBAbWVudSBhbmQgQG1lbnUuc3R5bGUuZGlzcGxheSBpcyAnbm9uZSdcbiAgICAgIEBzaG93KClcbiAgICBlbHNlXG4gICAgICBAaGlkZSgpXG5cbiAgIyBSZWFkIGN1cnJlbnQgbGFuZ3VhZ2UgZnJvbSBDaHJvbWUgU3RvcmFnZSBhbmQgY29sb3IgYWN0aXZlIGxpbmVcbiAgc2V0QWN0aXZlSXRlbTogLT5cbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCB7bGFuZ3VhZ2U6ICcxJ30sIChzdG9yZSkgPT5cbiAgICAgIGZvciBpdGVtIGluIEBpdGVtc1xuICAgICAgICBpZiBpdGVtLmdldEF0dHJpYnV0ZSgnZGF0YS12YWwnKSA9PSBzdG9yZS5sYW5ndWFnZVxuICAgICAgICAgIGl0ZW0uY2xhc3NMaXN0LmFkZCgnYWN0aXZlJylcbiAgICAgICAgZWxzZVxuICAgICAgICAgIGl0ZW0uY2xhc3NMaXN0LnJlbW92ZSgnYWN0aXZlJylcblxuICBoaWRlOiAtPlxuICAgIEBtZW51LnN0eWxlLmRpc3BsYXkgPSAnbm9uZSdcblxuICBzaG93OiAtPlxuICAgIEBtZW51LnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snXG5cbiAgIyBTYXZlcyBjaG9zZW4gbGFuZ3VhZ2UgdG8gY2hyb21lLnN0b3JhZ2UgYW5kIGRlY2lkZSB3aGljaCBkaWN0aW9uYXJ5IHRvIHVzZVxuICAjIFRoZW4gY2FsbGVkIG9uU2VsZWN0IGhhbmRsZXIgb2YgdGhlIGNvbnRhaW5lciBjbGFzc1xuICBjaG9vc2U6IChlKSAtPlxuICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBsYW5ndWFnZSA9IGUudGFyZ2V0LmdldEF0dHJpYnV0ZSgnZGF0YS12YWwnKVxuICAgIGRpY3Rpb25hcnkgPSBAZ2V0RGljdGlvbmFyeShsYW5ndWFnZSlcbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLnNldCh7bGFuZ3VhZ2U6IGxhbmd1YWdlLCBkaWN0aW9uYXJ5OiBkaWN0aW9uYXJ5fSwgQG9uU2VsZWN0KVxuICAgIEBzZXRUaXRsZShsYW5ndWFnZSlcbiAgICBAaGlkZSgpXG5cbiAgIyBTb21lIGxhbmd1YWdlcyBhcmUgbm90IHByZXNlbnQgaW4gbXVsdGl0cmFuIChlLmcuIHR1cmtpc2gpXG4gICMgc28gd2UgY2hvb3NlIGFub3RoZXIgc2VydmljZVxuICBnZXREaWN0aW9uYXJ5OiAobGFuZykgLT5cbiAgICBjb25zb2xlLmxvZygnY2hvb3NlIGRpY3Q6IGZvcicsbGFuZyk7XG4gICAgZGljdCA9IERJQ1RfQ09ERVtsYW5nXSB8fCAnbXVsdGl0cmFuJ1xuICAgIGNvbnNvbGUubG9nKCdkaWN0JyxkaWN0KVxuICAgIHJldHVybiBkaWN0XG5cbiAgI1NldCBjdXJyZW50IGxhbmd1YWdlIGxhYmVsXG4gIHNldFRpdGxlOiAobGFuZ3VhZ2UpIC0+XG4gICAgaHRtbCA9IExBTkdfQ09ERVtsYW5ndWFnZV0gKyAnIDxzcGFuIGNsYXNzPVwiY2FyZXRcIj48L3NwYW4+J1xuICAgIEBidXR0b24uaW5uZXJIVE1MID0gaHRtbFxuXG5cbm1vZHVsZS5leHBvcnRzID0gRHJvcGRvd24iLCIjIyNcbiAgRXh0ZW5zaW9uIHBvcHVwIHdpbmRvd1xuICBTaG93cyBzZWFyY2ggZm9ybSBhbmQgZHJvcGRvd24gbWVudSB3aXRoIGxhbmd1YWdlc1xuIyMjXG5TZWFyY2hGb3JtID0gcmVxdWlyZSgnLi9zZWFyY2hfZm9ybS5jb2ZmZWUnKVxuXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyIFwiRE9NQ29udGVudExvYWRlZFwiLCAtPlxuICBmb3JtID0gbmV3IFNlYXJjaEZvcm0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RyYW4tZm9ybScpXG4gIGxpbmsgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnaGVhZGVyLWxpbmsnKVxuICBpZiBsaW5rXG4gICAgbGluay5hZGRFdmVudExpc3RlbmVyICdjbGljaycsIChlKSAtPlxuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgaHJlZiA9IGUudGFyZ2V0LmdldEF0dHJpYnV0ZSgnaHJlZicpICsgZm9ybS5nZXRWYWx1ZSgpXG4gICAgICBjaHJvbWUudGFicy5jcmVhdGUoeyB1cmw6IGhyZWYgfSlcbiIsIiMjI1xuICBTZXJ2ZXMgc2VhcmNoIGlucHV0IGFuZCBmb3JtXG5cbiAgQHBhcmFtIGZvcm0gRE9NIGVsZW1udFxuICBAY29uc3RydWN0b3JcbiMjI1xuRHJvcGRvd24gPSByZXF1aXJlKCcuL2Ryb3Bkb3duLmNvZmZlZScpXG5cbiN0cmFuc2xhdGUgZW5naW5lc1xudHJhbiA9IHJlcXVpcmUoJy4uL3RyYW4uY29mZmVlJylcbnR1cmtpc2hkaWN0aW9uYXJ5ID0gcmVxdWlyZSgnLi4vdHVya2lzaGRpY3Rpb25hcnkuanMnKVxuXG5cbiNUcmFuc2xhdGUgZW5naW5lc1xuVFJBTlNMQVRFX0VOR0lORVMgPVxuICAnbXVsdGl0cmFuJzogdHJhblxuICAndHVya2lzaCc6IHR1cmtpc2hkaWN0aW9uYXJ5XG5cbmNsYXNzIFNlYXJjaEZvcm1cbiAgY29uc3RydWN0b3I6IChAZm9ybSkgLT5cbiAgICBAaW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndHJhbnNsYXRlLXR4dCcpXG4gICAgQGlucHV0LmZvY3VzKClcblxuICAgIEByZXN1bHQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncmVzdWx0JylcbiAgICBAYWRkTGlzdGVuZXJzKCk7XG4gICAgQGRyb3Bkb3duID0gbmV3IERyb3Bkb3duKHtcbiAgICAgIGVsOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuZHJvcGRvd24tZWwnKSxcbiAgICAgIG9uU2VsZWN0OiA9PiBAc2VhcmNoKClcbiAgICB9KTtcblxuICBhZGRMaXN0ZW5lcnM6IC0+XG4gICAgaWYgQGZvcm0gYW5kIEByZXN1bHRcbiAgICAgIEBmb3JtLmFkZEV2ZW50TGlzdGVuZXIgJ3N1Ym1pdCcsIChlKSA9PiBAc2VhcmNoKGUpXG4gICAgICBAcmVzdWx0LmFkZEV2ZW50TGlzdGVuZXIgJ2NsaWNrJywgKGUpID0+IEByZXN1bHRDbGlja0hhbmRsZXIoZSlcblxuICBzZWFyY2g6IChlKSAtPlxuICAgIGUgJiYgZS5wcmV2ZW50RGVmYXVsdCAmJiBlLnByZXZlbnREZWZhdWx0KClcbiAgICBpZiBAaW5wdXQudmFsdWUubGVuZ3RoID4gMFxuICAgICAgI2Nob29zZSBlbmdpbmUgYW5kIHNlYXJjaCBmb3IgdHJhbnNsYXRpb24gKGJ5IGRlZmF1bHQgZW5nbGlzaC1tdWx0aXRyYW4pXG4gICAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7bGFuZ3VhZ2U6ICcxJywgZGljdGlvbmFyeTogJ211bHRpdHJhbid9LCAoaXRlbXMpID0+XG4gICAgICAgIGNvbnNvbGUubG9nKCdJVEVNUzonLCBpdGVtcyk7XG4gICAgICAgIFRSQU5TTEFURV9FTkdJTkVTW2l0ZW1zLmRpY3Rpb25hcnldLnNlYXJjaFxuICAgICAgICAgIHZhbHVlOiBAaW5wdXQudmFsdWVcbiAgICAgICAgICBzdWNjZXNzOiBAc3VjY2Vzc0hhbmRsZXIuYmluZChAKVxuICAgICAgKVxuXG4gIHN1Y2Nlc3NIYW5kbGVyOiAocmVzcG9uc2UpIC0+XG4gICAgICBAY2xlYW4oQHJlc3VsdClcbiAgICAgIEByZXN1bHQuYXBwZW5kQ2hpbGQocmVzcG9uc2UpXG5cbiAgY2xlYW46IChlbCkgLT5cbiAgICB3aGlsZSAoZWwubGFzdENoaWxkKVxuICAgICAgZWwucmVtb3ZlQ2hpbGQoZWwubGFzdENoaWxkKVxuXG4gIHJlc3VsdENsaWNrSGFuZGxlcjogKGUpIC0+XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGxpbmtUYWdzID0gWydBJywgJ2EnXVxuICAgIGlmIGUudGFyZ2V0LnRhZ05hbWUgaW4gbGlua1RhZ3NcbiAgICAgIEBpbnB1dC52YWx1ZSA9IGUudGFyZ2V0LmlubmVyVGV4dDtcbiAgICAgIEBzZWFyY2goZSlcblxuICBnZXRWYWx1ZTogLT5cbiAgICByZXR1cm4gQGlucHV0LnZhbHVlXG5cblxubW9kdWxlLmV4cG9ydHMgPSBTZWFyY2hGb3JtXG4iLCIjIyNnbG9iYWwgY2hyb21lIyMjXG4jIyNcbiAgTXVsdGl0cmFuLnJ1IHRyYW5zbGF0ZSBlbmdpbmVcbiAgUHJvdmlkZXMgcHJvZ3JhbSBpbnRlcmZhY2UgZm9yIG1ha2luZyB0cmFuc2xhdGUgcXVlcmllcyB0byBtdWx0aXRyYW4gYW5kIGdldCBjbGVhbiByZXNwb25zZVxuXG4gIEFsbCBlbmdpbmVzIG11c3QgZm9sbG93IGNvbW1vbiBpbnRlcmZhY2UgYW5kIHByb3ZpZGUgbWV0aG9kczpcbiAgICAtIHNlYXJjaCAobGFuZ3VhbmdlLCBzdWNjZXNzSGFuZGxlcikgIGNsZWFuIHRyYW5zbGF0aW9uIG11c3QgYmUgcGFzc2VkIGludG8gc3VjY2Vzc0hhbmRsZXJcbiAgICAtIGNsaWNrXG5cbiAgVHJhbnNsYXRpb24tbW9kdWxlIHRoYXQgbWFrZXMgcmVxdWVzdHMgdG8gbGFuZ3VhZ2UtZW5naW5lLFxuICBwYXJzZXMgcmVzdWx0cyBhbmQgc2VuZHMgcGx1Z2luLWdsb2JhbCBtZXNzYWdlIHdpdGggdHJhbnNsYXRpb24gZGF0YVxuIyMjXG5cbkNIQVJfQ09ERVMgPSByZXF1aXJlKCcuL2NoYXItY29kZXMuanMnKTtcblxuY2xhc3MgVHJhblxuICBjb25zdHJ1Y3RvcjogLT5cbiAgICBAVEFCTEVfQ0xBU1MgPSBcIl9fX210dF90cmFuc2xhdGVfdGFibGVcIlxuICAgIEBwcm90b2NvbCA9ICdodHRwJ1xuICAgIEBob3N0ID0gJ3d3dy5tdWx0aXRyYW4ucnUnXG4gICAgQHBhdGggPSAnL2MvbS5leGUnXG4gICAgQHF1ZXJ5ID0gJyZzPSdcbiAgICBAbGFuZyA9ICc/bDE9MiZsMj0xJyAjZnJvbSBydXNzaWFuIHRvIGVuZ2xpc2ggYnkgZGVmYXVsdFxuICAgIEB4aHIgPSB7fVxuXG4gICMjI1xuICAgIENvbnRleHQgbWVudSBjbGljayBoYW5kbGVyXG4gICMjI1xuICBjbGljazogKGRhdGEpIC0+XG4gICAgaWYgdHlwZW9mIGRhdGEuc2lsZW50ID09IHVuZGVmaW5lZCB8fCBkYXRhLnNpbGVudCA9PSBudWxsXG4gICAgICBkYXRhLnNpbGVudCA9IHRydWUgIyB0cnVlIGJ5IGRlZmF1bHRcbiAgICBzZWxlY3Rpb25UZXh0ID0gQHJlbW92ZUh5cGhlbmF0aW9uIGRhdGEuc2VsZWN0aW9uVGV4dFxuICAgIEBzZWFyY2hcbiAgICAgICAgdmFsdWU6IHNlbGVjdGlvblRleHRcbiAgICAgICAgc3VjY2VzczogQHN1Y2Nlc3N0SGFuZGxlci5iaW5kKHRoaXMpXG4gICAgICAgIHNpbGVudDogZGF0YS5zaWxlbnQgICMgaWYgdHJhbnNsYXRpb24gZmFpbGVkIGRvIG5vdCBzaG93IGRpYWxvZ1xuXG4gICMjI1xuICAgIERpc2NhcmQgc29mdCBoeXBoZW4gY2hhcmFjdGVyIChVKzAwQUQsICZzaHk7KSBmcm9tIHRoZSBpbnB1dFxuICAjIyNcbiAgcmVtb3ZlSHlwaGVuYXRpb246ICh0ZXh0KSAtPlxuICAgIHRleHQucmVwbGFjZSAvXFx4YWQvZywgJydcblxuICAjIyNcbiAgICBJbml0aWF0ZSB0cmFuc2xhdGlvbiBzZWFyY2hcbiAgIyMjXG4gIHNlYXJjaDogKHBhcmFtcykgLT5cbiAgICAjdmFsdWUsIGNhbGxiYWNrLCBlcnJcbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7bGFuZ3VhZ2U6ICcxJ30sIChpdGVtcykgPT5cbiAgICAgIGlmIGxhbmd1YWdlIGlzICcnXG4gICAgICAgIGxhbmd1YWdlID0gJzEnXG4gICAgICBAc2V0TGFuZ3VhZ2UoaXRlbXMubGFuZ3VhZ2UpXG4gICAgICB1cmwgPSBAbWFrZVVybChwYXJhbXMudmFsdWUpO1xuICAgICAgIyBkZWNvcmF0ZSBzdWNjZXNzIHRvIG1ha2UgcHJlbGltaW5hcnkgcGFyc2luZ1xuICAgICAgb3JpZ1N1Y2Nlc3MgPSBwYXJhbXMuc3VjY2Vzc1xuICAgICAgcGFyYW1zLnN1Y2Nlc3MgPSAocmVzcG9uc2UpID0+XG4gICAgICAgIHRyYW5zbGF0ZWQgPSBAcGFyc2UocmVzcG9uc2UsIHBhcmFtcy5zaWxlbnQpXG4gICAgICAgIG9yaWdTdWNjZXNzKHRyYW5zbGF0ZWQpXG5cbiAgICAgICMgbWFrZSByZXF1ZXN0IChHRVQgcmVxdWVzdCB3aXRoIHF1ZXJ5IHBhcmFtZXRlcnMgaW4gdXJsKVxuICAgICAgQHJlcXVlc3QoXG4gICAgICAgIHVybDogdXJsLFxuICAgICAgICBzdWNjZXNzOiBwYXJhbXMuc3VjY2VzcyxcbiAgICAgICAgZXJyb3I6IHBhcmFtcy5lcnJvclxuICAgICAgKVxuICAgIClcblxuICBzZXRMYW5ndWFnZTogKGxhbmd1YWdlKSAtPlxuICAgIEBjdXJyZW50TGFuZ3VhZ2UgPSBsYW5ndWFnZVxuICAgIEBsYW5nID0gJz9sMT0yJmwyPScgKyBsYW5ndWFnZVxuXG4gICMjI1xuICAgIFJlcXVlc3QgdHJhbnNsYXRpb24gYW5kIHJ1biBjYWxsYmFjayBmdW5jdGlvblxuICAgIHBhc3NpbmcgdHJhbnNsYXRlZCByZXN1bHQgb3IgZXJyb3IgdG8gY2FsbGJhY2tcbiAgIyMjXG4gIHJlcXVlc3Q6IChvcHRzKSAtPlxuICAgIHhociA9IEB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKVxuICAgIHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSAoZSkgPT5cbiAgICAgIHhociA9IEB4aHJcbiAgICAgIGlmIHhoci5yZWFkeVN0YXRlIDwgNFxuICAgICAgICByZXR1cm5cbiAgICAgIGVsc2UgaWYgeGhyLnN0YXR1cyAhPSAyMDBcbiAgICAgICAgQGVycm9ySGFuZGxlcih4aHIpXG4gICAgICAgIGlmICh0eXBlb2Ygb3B0cy5lcnJvciA9PSAnZnVuY3Rpb24nKVxuICAgICAgICAgIG9wdHMuZXJyb3IoKVxuICAgICAgICByZXR1cm5cbiAgICAgIGVsc2UgaWYgeGhyLnJlYWR5U3RhdGUgPT0gNFxuICAgICAgICAgIHJldHVybiBvcHRzLnN1Y2Nlc3MoZS50YXJnZXQucmVzcG9uc2UpXG5cbiAgICB4aHIub3BlbihcIkdFVFwiLCBvcHRzLnVybCwgdHJ1ZSk7XG4gICAgeGhyLnNlbmQoKTtcblxuXG4gIG1ha2VVcmw6ICh2YWx1ZSkgLT5cbiAgICB1cmwgPSBbQHByb3RvY29sLCAnOi8vJyxcbiAgICAgICAgICAgICAgQGhvc3QsXG4gICAgICAgICAgICAgIEBwYXRoLFxuICAgICAgICAgICAgICBAbGFuZyxcbiAgICAgICAgICAgICAgQHF1ZXJ5LFxuICAgICAgICAgICAgICBAZ2V0RW5jb2RlZFZhbHVlKHZhbHVlKVxuICAgICAgICAgIF0uam9pbignJylcblxuICAgIHJldHVybiB1cmw7XG5cbiAgIyBSZXBsYWNlIHNwZWNpYWwgbGFuZ3VhZ2UgY2hhcmFjdGVycyB0byBodG1sIGNvZGVzXG4gIGdldEVuY29kZWRWYWx1ZTogKHZhbHVlKSAtPlxuICAgICMgdG8gZmluZCBzcGVjIHN5bWJvbHMgd2UgZmlyc3QgZW5jb2RlIHRoZW0gKHJhdyBzZWFyY2ggZm9yIHRoYXQgc3ltYm9sIGRvZXNuJ3Qgd29yKVxuICAgIHZhbCA9IGVuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSlcbiAgICBmb3IgY2hhciwgY29kZSBvZiBDSEFSX0NPREVTXG4gICAgICBpZiB0eXBlb2YgY29kZSA9PSAnb2JqZWN0J1xuICAgICAgICAjIHJ1c3NpYW4gaGFzIHNwZWNpYWwgY29kZXNcbiAgICAgICAgY2MgPSBjb2RlLnZhbFxuICAgICAgZWxzZVxuICAgICAgICAjIGZvciBhbGwgbGFuZ3MgZXhjZXB0IHJ1c3NpYW4gZW5jb2RlIGh0bWwtY29kZXMgbmVlZGVkXG4gICAgICAgICMg0LTQu9GPINCy0YHQtdGFINC+0YHRgtCw0LvRjNC90YvRhSDRj9C30YvQutC+0LJcbiAgICAgICAgY2MgPSBlbmNvZGVVUklDb21wb25lbnQoY29kZSlcbiAgICAgIHZhbCA9IHZhbC5yZXBsYWNlKGNoYXIsIGNjKVxuICAgIHJldHVybiB2YWxcblxuICBlcnJvckhhbmRsZXI6ICh4aHIpIC0+XG4gICAgY29uc29sZS5sb2coJ2Vycm9yJywgeGhyKVxuXG4gICMjI1xuICAgUmVjZWl2aW5nIGRhdGEgZnJvbSB0cmFuc2xhdGlvbi1lbmdpbmUgYW5kIHNlbmQgcmVhZHkgbWVzc2FnZSB3aXRoIGRhdGFcbiAgIyMjXG4gIHN1Y2Nlc3N0SGFuZGxlcjogKHRyYW5zbGF0ZWQpIC0+XG4gICAgaWYgdHJhbnNsYXRlZFxuICAgICAgY2hyb21lLnRhYnMuZ2V0U2VsZWN0ZWQobnVsbCwgKHRhYikgPT5cbiAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgYWN0aW9uOiBAbWVzc2FnZVR5cGUgdHJhbnNsYXRlZFxuICAgICAgICAgIGRhdGE6IHRyYW5zbGF0ZWQub3V0ZXJIVE1MLFxuICAgICAgICAgIHN1Y2Nlc3M6ICF0cmFuc2xhdGVkLmNsYXNzTGlzdC5jb250YWlucygnZmFpbFRyYW5zbGF0ZScpXG4gICAgICAgIH0pXG4gICAgICApXG5cbiAgbWVzc2FnZVR5cGU6ICh0cmFuc2xhdGVkKSAtPlxuICAgIGlmIHRyYW5zbGF0ZWQ/LnJvd3M/Lmxlbmd0aCA9PSAxXG4gICAgICAnc2ltaWxhcl93b3JkcydcbiAgICBlbHNlXG4gICAgICAnb3Blbl90b29sdGlwJ1xuXG4gICMjI1xuICAgIFBhcnNlIHJlc3BvbnNlIGZyb20gdHJhbnNsYXRpb24gZW5naW5lXG4gICMjI1xuICBwYXJzZTogKHJlc3BvbnNlLCBzaWxlbnQsIHRyYW5zbGF0ZSA9IG51bGwpIC0+XG4gICAgICBkb2MgPSBAc3RyaXBTY3JpcHRzKHJlc3BvbnNlKVxuICAgICAgZnJhZ21lbnQgPSBAbWFrZUZyYWdtZW50KGRvYylcbiAgICAgIGlmIGZyYWdtZW50XG4gICAgICAgIHRyYW5zbGF0ZSA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3IoJyN0cmFuc2xhdGlvbiB+IHRhYmxlJylcbiAgICAgICAgaWYgdHJhbnNsYXRlXG4gICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9IEBUQUJMRV9DTEFTUztcbiAgICAgICAgICB0cmFuc2xhdGUuc2V0QXR0cmlidXRlKFwiY2VsbHBhZGRpbmdcIiwgXCI1XCIpXG4gICAgICAgICAgQGZpeEltYWdlcyh0cmFuc2xhdGUpXG4gICAgICAgICAgQGZpeExpbmtzKHRyYW5zbGF0ZSlcbiAgICAgICAgZWxzZSBpZiBub3Qgc2lsZW50XG4gICAgICAgICAgdHJhbnNsYXRlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gJ2ZhaWxUcmFuc2xhdGUnXG4gICAgICAgICAgdHJhbnNsYXRlLmlubmVyVGV4dCA9IFwiVW5mb3J0dW5hdGVseSwgY291bGQgbm90IHRyYW5zbGF0ZVwiXG5cbiAgICAgIHJldHVybiB0cmFuc2xhdGU7XG5cbiAgIyMjXG4gICAgU3RyaXAgc2NyaXB0IHRhZ3MgZnJvbSByZXNwb25zZSBodG1sXG4gICMjI1xuICBzdHJpcFNjcmlwdHM6IChzKSAtPlxuICAgIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgZGl2LmlubmVySFRNTCA9IHNcbiAgICBzY3JpcHRzID0gZGl2LmdldEVsZW1lbnRzQnlUYWdOYW1lKCdzY3JpcHQnKVxuICAgIGkgPSBzY3JpcHRzLmxlbmd0aFxuICAgIHdoaWxlIGktLVxuICAgICAgc2NyaXB0c1tpXS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHNjcmlwdHNbaV0pXG4gICAgcmV0dXJuIGRpdi5pbm5lckhUTUw7XG5cbiAgbWFrZUZyYWdtZW50OiAoZG9jLCBmcmFnbWVudCA9IG51bGwpIC0+XG4gICAgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKVxuICAgIGRpdi5pbm5lckhUTUwgPSBkb2NcbiAgICBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKVxuICAgIHdoaWxlICggZGl2LmZpcnN0Q2hpbGQgKVxuICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoIGRpdi5maXJzdENoaWxkIClcbiAgICByZXR1cm4gZnJhZ21lbnRcblxuICBmaXhJbWFnZXM6IChmcmFnbWVudD1udWxsKSAtPlxuICAgIHRoaXMuZml4VXJsKGZyYWdtZW50LCAnaW1nJywgJ3NyYycpO1xuICAgIHJldHVybiBmcmFnbWVudDtcblxuICBmaXhMaW5rczogKGZyYWdtZW50PW51bGwpIC0+XG4gICAgdGhpcy5maXhVcmwoZnJhZ21lbnQsICdhJywgJ2hyZWYnKVxuICAgIHJldHVybiBmcmFnbWVudFxuXG4gIGZpeFVybDogKGZyYWdtZW50PW51bGwsIHRhZywgYXR0cikgLT5cbiAgICBpZiBmcmFnbWVudFxuICAgICAgdGFncyA9ICBmcmFnbWVudC5xdWVyeVNlbGVjdG9yQWxsKHRhZylcbiAgICAgIHBhcnNlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKVxuICAgICAgZm9yIHRhZyBpbiB0YWdzXG4gICAgICAgIHBhcnNlci5ocmVmID0gdGFnW2F0dHJdXG4gICAgICAgIHBhcnNlci5ob3N0ID0gQGhvc3RcbiAgICAgICAgcGFyc2VyLnByb3RvY29sID0gQHByb3RvY29sXG4gICAgICAgICNmaXggcmVsYXRpdmUgbGlua3NcbiAgICAgICAgaWYgdGFnLnRhZ05hbWUgPT0gJ0EnXG4gICAgICAgICAgdGFnLmNsYXNzTGlzdC5hZGQgJ210dF9saW5rJ1xuICAgICAgICAgIGlmIHBhcnNlci5wYXRobmFtZS5pbmRleE9mKCdtLmV4ZScpIGlzbnQgLTFcbiAgICAgICAgICAgIHBhcnNlci5wYXRobmFtZSA9ICcvYycgKyBwYXJzZXIucGF0aG5hbWVcbiAgICAgICAgICAgIHRhZy5zZXRBdHRyaWJ1dGUoJ3RhcmdldCcsICdfYmxhbmsnKVxuICAgICAgICBlbHNlIGlmIHRhZy50YWdOYW1lID09ICdJTUcnXG4gICAgICAgICAgdGFnLmNsYXNzTGlzdC5hZGQgJ210dF9pbWcnXG5cbiAgICAgICAgdGFnLnNldEF0dHJpYnV0ZShhdHRyLCBwYXJzZXIuaHJlZilcblxuXG5cbm1vZHVsZS5leHBvcnRzID0gbmV3IFRyYW4iLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIF9wcm90b3R5cGVQcm9wZXJ0aWVzID0gZnVuY3Rpb24gKGNoaWxkLCBzdGF0aWNQcm9wcywgaW5zdGFuY2VQcm9wcykge1xuICBpZiAoc3RhdGljUHJvcHMpIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGNoaWxkLCBzdGF0aWNQcm9wcyk7XG4gIGlmIChpbnN0YW5jZVByb3BzKSBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhjaGlsZC5wcm90b3R5cGUsIGluc3RhbmNlUHJvcHMpO1xufTtcblxuLypcbiAgVHJhbnNsYXRpb24gZW5naW5lOiBodHRwOi8vd3d3LnR1cmtpc2hkaWN0aW9uYXJ5Lm5ldFxuICBGb3IgdHJhbnNsYXRpbmcgdHVya2lzaC1ydXNzaWFuIGFuZCB2aWNlIHZlcnNhXG4qL1xudmFyIENIQVJfQ09ERVMgPSByZXF1aXJlKFwiLi9jaGFyLWNvZGVzLXR1cmsuanNcIik7XG5cbnZhciBUdXJraXNoRGljdGlvbmFyeSA9IChmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIFR1cmtpc2hEaWN0aW9uYXJ5KCkge1xuICAgIHRoaXMuaG9zdCA9IFwiaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXQvP3dvcmQ9JUZDXCI7XG4gICAgdGhpcy5wYXRoID0gXCJcIjtcbiAgICB0aGlzLnByb3RvY29sID0gXCJodHRwXCI7XG4gICAgdGhpcy5xdWVyeSA9IFwiJnM9XCI7XG4gICAgdGhpcy5UQUJMRV9DTEFTUyA9IFwiX19fbXR0X3RyYW5zbGF0ZV90YWJsZVwiO1xuICAgIC8vIHRoaXMgZmxhZyBpbmRpY2F0ZXMgdGhhdCBpZiB0cmFuc2xhdGlvbiB3YXMgc3VjY2Vzc2Z1bCB0aGVuIHB1Ymxpc2ggaXQgYWxsIG92ZXIgZXh0ZW5zaW9uXG4gICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSB0cnVlO1xuICB9XG5cbiAgX3Byb3RvdHlwZVByb3BlcnRpZXMoVHVya2lzaERpY3Rpb25hcnksIG51bGwsIHtcbiAgICBzZWFyY2g6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBzZWFyY2goZGF0YSkge1xuICAgICAgICBkYXRhLnVybCA9IHRoaXMubWFrZVVybChkYXRhLnZhbHVlKTtcbiAgICAgICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSBmYWxzZTtcbiAgICAgICAgcmV0dXJuIHRoaXMucmVxdWVzdChkYXRhKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHRyYW5zbGF0ZToge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHRyYW5zbGF0ZShkYXRhKSB7XG4gICAgICAgIGRhdGEudXJsID0gdGhpcy5tYWtlVXJsKGRhdGEuc2VsZWN0aW9uVGV4dCk7XG4gICAgICAgIHRoaXMubmVlZF9wdWJsaXNoID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5yZXF1ZXN0KGRhdGEpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgbWFrZVVybDoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIG1ha2VVcmwodGV4dCkge1xuICAgICAgICB2YXIgdGV4dCA9IHRoaXMuZ2V0RW5jb2RlZFZhbHVlKHRleHQpO1xuICAgICAgICByZXR1cm4gW1wiaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXQvP3dvcmQ9XCIsIHRleHRdLmpvaW4oXCJcIik7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBnZXRFbmNvZGVkVmFsdWU6IHtcblxuXG4gICAgICAvLyBSZXBsYWNlIHNwZWNpYWwgbGFuZ3VhZ2UgY2hhcmFjdGVycyB0byBodG1sIGNvZGVzXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gZ2V0RW5jb2RlZFZhbHVlKHZhbHVlKSB7XG4gICAgICAgIC8vIHRvIGZpbmQgc3BlYyBzeW1ib2xzIHdlIGZpcnN0IGVuY29kZSB0aGVtIChyYXcgc2VhcmNoIGZvciB0aGF0IHN5bWJvbCBkb2Vzbid0IHdvcilcbiAgICAgICAgcmV0dXJuIGVuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSk7XG4gICAgICAgIC8vcmV0dXJuIHRoaXMubWFrZVN0cmluZ1RyYW5zZmVyYWJsZSh2YWx1ZSk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBtYWtlU3RyaW5nVHJhbnNmZXJhYmxlOiB7XG5cbiAgICAgIC8qKiBjb252ZXJ0aW5nIHNjcmlwdCBmcm9tIHRoZSB0dXJraXNoZGljdCAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIG1ha2VTdHJpbmdUcmFuc2ZlcmFibGUoaW5wdXRUZXh0KSB7XG4gICAgICAgIHZhciB0ZXh0ID0gXCJcIjtcbiAgICAgICAgaWYgKGlucHV0VGV4dC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgdGV4dCA9IGlucHV0VGV4dDtcbiAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRleHQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChDSEFSX0NPREVTW3RleHQuY2hhckNvZGVBdChpKV0pIHtcbiAgICAgICAgICAgICAgdGV4dCA9IHRleHQuc3Vic3RyaW5nKDAsIGkpICsgQ0hBUl9DT0RFU1t0ZXh0LmNoYXJDb2RlQXQoaSldICsgdGV4dC5zdWJzdHJpbmcoaSArIDEsIHRleHQubGVuZ3RoKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodGV4dC5jaGFyQXQoaSkgPT0gXCIgXCIpIHtcbiAgICAgICAgICAgICAgLy8gcmVwbGFjZSBzcGFjZXNcbiAgICAgICAgICAgICAgdGV4dCA9IHRleHQuc3Vic3RyaW5nKDAsIGkpICsgXCJfX19cIiArIHRleHQuc3Vic3RyaW5nKGkgKyAxLCB0ZXh0Lmxlbmd0aCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0ZXh0O1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcmVxdWVzdDoge1xuXG4gICAgICAvKlxuICAgICAgICBSZXF1ZXN0IHRyYW5zbGF0aW9uIGFuZCBydW4gY2FsbGJhY2sgZnVuY3Rpb25cbiAgICAgICAgcGFzc2luZyB0cmFuc2xhdGVkIHJlc3VsdCBvciBlcnJvciB0byBjYWxsYmFja1xuICAgICAgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiByZXF1ZXN0KG9wdHMpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJzdGFydCByZXF1ZXN0XCIpO1xuICAgICAgICB0aGlzLnhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgICB0aGlzLnhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSB0aGlzLm9uUmVhZHlTdGF0ZUNoYW5nZS5iaW5kKHRoaXMsIG9wdHMpO1xuICAgICAgICB0aGlzLnhoci5vcGVuKFwiR0VUXCIsIG9wdHMudXJsLCB0cnVlKTtcbiAgICAgICAgdGhpcy54aHIuc2VuZCgpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgb25SZWFkeVN0YXRlQ2hhbmdlOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gb25SZWFkeVN0YXRlQ2hhbmdlKG9wdHMsIGUpIHtcbiAgICAgICAgdmFyIHhociA9IHRoaXMueGhyO1xuICAgICAgICBpZiAoeGhyLnJlYWR5U3RhdGUgPCA0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9IGVsc2UgaWYgKHhoci5zdGF0dXMgIT0gMjAwKSB7XG4gICAgICAgICAgdGhpcy5lcnJvckhhbmRsZXIoeGhyKTtcbiAgICAgICAgICByZXR1cm4gb3B0cy5lcnJvciAmJiBvcHRzLmVycm9yKCk7XG4gICAgICAgIH0gZWxzZSBpZiAoeGhyLnJlYWR5U3RhdGUgPT0gNCkge1xuICAgICAgICAgIHZhciB0cmFuc2xhdGlvbiA9IHRoaXMuc3VjY2Vzc0hhbmRsZXIoZS50YXJnZXQucmVzcG9uc2UpO1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwic3VjY2VzcyB0dXJraXNoIHRyYW5zbGF0ZVwiLCB0cmFuc2xhdGlvbik7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJjYWxsXCIsIG9wdHMuc3VjY2Vzcyk7XG4gICAgICAgICAgcmV0dXJuIG9wdHMuc3VjY2VzcyAmJiBvcHRzLnN1Y2Nlc3ModHJhbnNsYXRpb24pO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBzdWNjZXNzSGFuZGxlcjoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHN1Y2Nlc3NIYW5kbGVyKHJlc3BvbnNlKSB7XG4gICAgICAgIHZhciBkYXRhID0gdGhpcy5wYXJzZShyZXNwb25zZSk7XG4gICAgICAgIGlmICh0aGlzLm5lZWRfcHVibGlzaCkge1xuICAgICAgICAgIGNocm9tZS50YWJzLmdldFNlbGVjdGVkKG51bGwsIHRoaXMucHVibGlzaFRyYW5zbGF0aW9uLmJpbmQodGhpcywgZGF0YSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcHVibGlzaFRyYW5zbGF0aW9uOiB7XG5cbiAgICAgIC8qIHB1Ymxpc2ggc3VjY2Vzc2Z1bHkgdHJhbnNsYXRlZCB0ZXh0IGFsbCBvdmVyIGV4dGVuc2lvbiAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHB1Ymxpc2hUcmFuc2xhdGlvbih0cmFuc2xhdGlvbiwgdGFiKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwicHVibGlzaCB0cmFuc2xhdGlvblwiKTtcbiAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgYWN0aW9uOiB0aGlzLnRvb2x0aXBBY3Rpb24odHJhbnNsYXRpb24pLFxuICAgICAgICAgIGRhdGE6IHRyYW5zbGF0aW9uLm91dGVySFRNTCxcbiAgICAgICAgICBzdWNjZXNzOiAhdHJhbnNsYXRpb24uY2xhc3NMaXN0LmNvbnRhaW5zKFwiZmFpbFRyYW5zbGF0ZVwiKVxuICAgICAgICB9KTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHRvb2x0aXBBY3Rpb246IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiB0b29sdGlwQWN0aW9uKHRyYW5zbGF0aW9uKSB7XG4gICAgICAgIGlmICh0cmFuc2xhdGlvbi50ZXh0Q29udGVudC50cmltKCkuaW5kZXhPZihcIndhcyBub3QgZm91bmQgaW4gb3VyIGRpY3Rpb25hcnlcIikgIT0gLTEpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhcInNpbWlsYXIgd29yZHNcIik7XG4gICAgICAgICAgcmV0dXJuIFwic2ltaWxhcl93b3Jkc1wiO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwib3BlbiB0b29sdGlwXCIpO1xuICAgICAgICAgIHJldHVybiBcIm9wZW5fdG9vbHRpcFwiO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBlcnJvckhhbmRsZXI6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBlcnJvckhhbmRsZXIocmVzcG9uc2UpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJlcnJvciBhamF4XCIsIHJlc3BvbnNlKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHBhcnNlOiB7XG5cbiAgICAgIC8qIFBhcnNlIHJlc3BvbnNlIGZyb20gdHJhbnNsYXRpb24gZW5naW5lICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gcGFyc2UocmVzcG9uc2UsIHNpbGVudCwgdHJhbnNsYXRlKSB7XG4gICAgICAgIHZhciBkb2MgPSB0aGlzLnN0cmlwU2NyaXB0cyhyZXNwb25zZSksXG4gICAgICAgICAgICBmcmFnbWVudCA9IHRoaXMubWFrZUZyYWdtZW50KGRvYyk7XG4gICAgICAgIGlmIChmcmFnbWVudCkge1xuICAgICAgICAgIHRyYW5zbGF0ZSA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjbWVhbmluZ19kaXYgPiB0YWJsZVwiKTtcbiAgICAgICAgICBpZiAodHJhbnNsYXRlKSB7XG4gICAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gdGhpcy5UQUJMRV9DTEFTUztcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5zZXRBdHRyaWJ1dGUoXCJjZWxscGFkZGluZ1wiLCBcIjVcIik7XG4gICAgICAgICAgICAvLyBAZml4SW1hZ2VzKHRyYW5zbGF0ZSlcbiAgICAgICAgICAgIC8vIEBmaXhMaW5rcyh0cmFuc2xhdGUpXG4gICAgICAgICAgfSBlbHNlIGlmICghc2lsZW50KSB7XG4gICAgICAgICAgICB0cmFuc2xhdGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9IFwiZmFpbFRyYW5zbGF0ZVwiO1xuICAgICAgICAgICAgdHJhbnNsYXRlLmlubmVyVGV4dCA9IFwiVW5mb3J0dW5hdGVseSwgY291bGQgbm90IHRyYW5zbGF0ZVwiO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJhbnNsYXRlO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcGFyc2VUZXh0OiB7XG5cbiAgICAgIC8qKiBwYXJzaW5nIG9mIHRlcnJpYmxlIGh0bWwgbWFya3VwICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gcGFyc2VUZXh0KHJlc3BvbnNlLCBzaWxlbnQsIHRyYW5zbGF0ZSkge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICB2YXIgZG9jID0gdGhpcy5zdHJpcFNjcmlwdHMocmVzcG9uc2UpLFxuICAgICAgICAgICAgZnJhZ21lbnQgPSB0aGlzLm1ha2VGcmFnbWVudChkb2MpO1xuXG4gICAgICAgIGlmIChmcmFnbWVudCkge1xuICAgICAgICAgIHZhciBpO1xuICAgICAgICAgIHZhciBfcmV0ID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBzdG9wSW5kZXggPSBudWxsO1xuICAgICAgICAgICAgdmFyIHRyID0gZnJhZ21lbnQucXVlcnlTZWxlY3RvckFsbChcIiNtZWFuaW5nX2Rpdj50YWJsZT50Ym9keT50clwiKTtcbiAgICAgICAgICAgIHRyID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwodHIpO1xuXG4gICAgICAgICAgICB2YXIgdHJhbnMgPSB0ci5maWx0ZXIoZnVuY3Rpb24gKHRyLCBpbmRleCkge1xuICAgICAgICAgICAgICBpZiAoIWlzTmFOKHBhcnNlSW50KHN0b3BJbmRleCwgMTApKSAmJiBpbmRleCA+PSBzdG9wSW5kZXgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdHIgPSAkKHRyKTtcbiAgICAgICAgICAgICAgICAvLyB0YWtlIGV2ZXJ5IHJvdyBiZWZvcmUgbmV4dCBzZWN0aW9uICh3aGljaCBpcyBFbmdsaXNoLT5FbmdsaXNoKVxuICAgICAgICAgICAgICAgIGlmICh0ci5hdHRyKFwiYmdjb2xvclwiKSA9PSBcImUwZTZmZlwiKSB7XG4gICAgICAgICAgICAgICAgICBzdG9wSW5kZXggPSBpbmRleDtyZXR1cm47XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiAkLnRyaW0odHIuZmluZChcInRkXCIpLnRleHQoKSkubGVuZ3RoO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0cmFucyA9IHRyYW5zLnNsaWNlKDEsIHRyYW5zLmxlbmd0aCAtIDEpO1xuICAgICAgICAgICAgdHJhbnMgPSB0cmFucy5maWx0ZXIoZnVuY3Rpb24gKGVsLCBpbmR4KSB7XG4gICAgICAgICAgICAgIHJldHVybiBpbmR4ICUgMjtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdmFyIGZyYWcgPSBfdGhpcy5mcmFnbWVudEZyb21MaXN0KHRyYW5zKTtcbiAgICAgICAgICAgIHZhciBmb250cyA9IGZyYWcucXVlcnlTZWxlY3RvckFsbChcImZvbnRcIik7XG4gICAgICAgICAgICB2YXIgdGV4dCA9IFwiXCI7XG4gICAgICAgICAgICBmb3IgKGkgPSAwOyBpIDwgZm9udHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgdGV4dCArPSBcIiBcIiArIGZvbnRzW2ldLnRleHRDb250ZW50LnRyaW0oKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIHY6IHRleHRcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSkoKTtcblxuICAgICAgICAgIGlmICh0eXBlb2YgX3JldCA9PT0gXCJvYmplY3RcIikgcmV0dXJuIF9yZXQudjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyBcIkhUTUwgZnJhZ21lbnQgY291bGQgbm90IGJlIHBhcnNlZFwiO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBzdHJpcFNjcmlwdHM6IHtcblxuICAgICAgLy9UT0RPIGV4dHJhY3QgdG8gYmFzZSBlbmdpbmUgY2xhc3NcbiAgICAgIC8qIHJlbW92ZXMgPHNjcmlwdD4gdGFncyBmcm9tIGh0bWwgY29kZSAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHN0cmlwU2NyaXB0cyhodG1sKSB7XG4gICAgICAgIHZhciBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcbiAgICAgICAgdmFyIHNjcmlwdHMgPSBkaXYuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJzY3JpcHRcIik7XG4gICAgICAgIHZhciBpID0gc2NyaXB0cy5sZW5ndGg7XG4gICAgICAgIHdoaWxlIChpLS0pIHNjcmlwdHNbaV0ucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChzY3JpcHRzW2ldKTtcbiAgICAgICAgcmV0dXJuIGRpdi5pbm5lckhUTUw7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBtYWtlRnJhZ21lbnQ6IHtcblxuICAgICAgLy9UT0RPIGV4dHJhY3QgdG8gYmFzZSBlbmdpbmUgY2xhc3NcbiAgICAgIC8qIGNyZWF0ZXMgdGVtcCBvYmplY3QgdG8gcGFyc2UgdHJhbnNsYXRpb24gZnJvbSBwYWdlIFxuICAgICAgICAoc2luY2UgaXQncyBub3QgYSBmcmllbmRseSBhcGkpIFxuICAgICAgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlRnJhZ21lbnQoaHRtbCkge1xuICAgICAgICB2YXIgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCksXG4gICAgICAgICAgICBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcbiAgICAgICAgd2hpbGUgKGRpdi5maXJzdENoaWxkKSB7XG4gICAgICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoZGl2LmZpcnN0Q2hpbGQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmcmFnbWVudDtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIGZyYWdtZW50RnJvbUxpc3Q6IHtcblxuICAgICAgLyoqIGNyZWF0ZSBmcmFnbWVudCBmcm9tIGxpc3Qgb2YgRE9NIGVsZW1lbnRzICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gZnJhZ21lbnRGcm9tTGlzdChsaXN0KSB7XG4gICAgICAgIHZhciBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKSxcbiAgICAgICAgICAgIGxlbiA9IGxpc3QubGVuZ3RoO1xuICAgICAgICB3aGlsZSAobGVuLS0pIHtcbiAgICAgICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZChsaXN0W2xlbl0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmcmFnbWVudDtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9XG4gIH0pO1xuXG4gIHJldHVybiBUdXJraXNoRGljdGlvbmFyeTtcbn0pKCk7XG5cbi8vIFNpbmdsZXRvbmVcbm1vZHVsZS5leHBvcnRzID0gbmV3IFR1cmtpc2hEaWN0aW9uYXJ5KCk7Il19
