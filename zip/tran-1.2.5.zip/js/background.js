(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){

/*global tran, chrome */
var CHAR_CODES, tran, turkishDictionary;

CHAR_CODES = require('./char-codes.js');

tran = require('./tran.coffee');

turkishDictionary = require('./turkishdictionary.js');

chrome.contextMenus.create({
  title: 'Multitran: "%s"',
  contexts: ["editable", "selection"],
  onclick: function(data) {
    data.silent = false;
    return tran.click(data);
  }
});


/*
 Can't get chrome.storage directly from content_script
 so content_script sends request message and then background script
 responds with storage value
 */

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.method === "get_fast_option") {
    chrome.storage.sync.get({
      fast: true
    }, function(items) {
      return sendResponse({
        fast: items.fast
      });
    });
  } else if (request.method === 'request_search') {
    chrome.storage.sync.get({
      language: '1',
      fast: true
    }, function(items) {
      request.data.silent = true;
      if (parseInt(items.language, 10) === 1000) {
        turkishDictionary.translate(request.data);
      } else {
        tran.click(request.data);
      }
      return true;
    });
  }
  return true;
});


},{"./char-codes.js":3,"./tran.coffee":4,"./turkishdictionary.js":5}],2:[function(require,module,exports){
// turkishdictionary codings
var DICT = {
    350: '%DE', //Ş
    286: '%D0', //Ğ
    287: '%F0', //ğ
    351: '%FE', //ş
    305: '%FD', //ı
    304: '%DD', //İ
    252: '%FC', //ü
    220: '%DC', //Ü
    231: '%E7', //ç
    199: '%C7', //Ç
    246: '%F6', //ö
    244: '%F4', //ô
    214: '%D6', //Ö
    212: '%D4', //Ô
    251: '%FB', //û
    219: '%DB', //Û
    194: '%C2', //Â
    226: '%E2', //â
    39: '',  //'
};

module.exports = DICT;
},{}],3:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/var CHAR_CODES = {  //russian  '%D1%8A': {val:'%FA', lang:'ru'}, // ъ  '%D0%AA': {val:'%DA', lang:'ru'},// Ъ  '%C3%80': '&#192;', // À  '%C3%81': '&#193;', // Á  '%C3%82': '&#194;', // Â  '%C3%83': '&#195;', // Ã  '%C3%84': '&#196;', // Ä  '%C3%85': '&#197;', // Å  '%C3%86': '&#198;', // Æ  '%C3%87': '&#199;', // Ç  '%C3%88': '&#200;', // È  '%C3%89': '&#201;', // É  '%C3%8A': '&#202;', // Ê  '%C3%8B': '&#203;', // Ë  '%C3%8C': '&#204;', // Ì  '%C3%8D': '&#205;', // Í  '%C3%8E': '&#206;', // Î  '%C3%8F': '&#207;', // Ï  '%C3%91': '&#209;', // Ñ  '%C3%92': '&#210;', // Ò  '%C3%93': '&#211;', // Ó  '%C3%94': '&#212;', // Ô  '%C3%95': '&#213;', // Õ  '%C3%96': '&#214;', // Ö  '%C3%99': '&#217;', // Ù  '%C3%9A': '&#218;', // Ú  '%C3%9B': '&#219;', // Û  '%C3%9C': '&#220;', // Ü  '%C3%A0': '&#224;', // à  '%C3%A1': '&#225;', // á  '%C3%A2': '&#226;', // â  '%C3%A3': '&#227;', // ã  '%C3%A4': '&#228;', // ä  '%C3%A5': '&#229;', // å  '%C3%A6': '&#230;', // æ  '%C3%A7': '&#231;', // ç  '%C3%A8': '&#232;', // è  '%C3%A9': '&#233;', // é  '%C3%AA': '&#234;', // ê  '%C3%AB': '&#235;', // ë  '%C3%AC': '&#236;', // ì  '%C3%AD': '&#237;', // í  '%C3%AE': '&#238;', // î  '%C3%AF': '&#239;', // ï  '%C3%B0': '&#240;', // ð  '%C3%B1': '&#241;', // ñ  '%C3%B2': '&#242;', // ò  '%C3%B3': '&#243;', // ó  '%C3%B4': '&#244;', // ô  '%C3%B5': '&#245;', // õ  '%C3%B6': '&#246;', // ö  '%C3%B9': '&#249;', // ù  '%C3%BA': '&#250;', // ú  '%C3%BB': '&#251;', // û  '%C3%BC': '&#252;', // ü  '%C3%BF': '&#255;', // ÿ  '%C5%B8': '&#376;', // Ÿ  '%C3%9F': '&#223;', // ß  '%C2%BF': '&#191;', // ¿  '%C2%A1': '&#161;', // ¡};module.exports = CHAR_CODES;
},{}],4:[function(require,module,exports){

/*global chrome */

/*
  Multitran.ru translate engine
  Provides program interface for making translate queries to multitran and get clean response

  All engines must follow common interface and provide methods:
    - search (languange, successHandler)  clean translation must be passed into successHandler
    - click

  Translation-module that makes requests to language-engine,
  parses results and sends plugin-global message with translation data
 */
var CHAR_CODES, Tran;

CHAR_CODES = require('./char-codes.js');

Tran = (function() {
  function Tran() {
    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1';
    this.xhr = {};
  }


  /*
    Context menu click handler
   */

  Tran.prototype.click = function(data) {
    var selectionText;
    if (typeof data.silent === void 0 || data.silent === null) {
      data.silent = true;
    }
    selectionText = this.removeHyphenation(data.selectionText);
    return this.search({
      value: selectionText,
      success: this.successtHandler.bind(this),
      silent: data.silent
    });
  };


  /*
    Discard soft hyphen character (U+00AD, &shy;) from the input
   */

  Tran.prototype.removeHyphenation = function(text) {
    return text.replace(/\xad/g, '');
  };


  /*
    Initiate translation search
   */

  Tran.prototype.search = function(params) {
    return chrome.storage.sync.get({
      language: '1'
    }, (function(_this) {
      return function(items) {
        var language, origSuccess, url;
        if (language === '') {
          language = '1';
        }
        _this.setLanguage(items.language);
        url = _this.makeUrl(params.value);
        origSuccess = params.success;
        params.success = function(response) {
          var translated;
          translated = _this.parse(response, params.silent);
          return origSuccess(translated);
        };
        return _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      };
    })(this));
  };

  Tran.prototype.setLanguage = function(language) {
    this.currentLanguage = language;
    return this.lang = '?l1=2&l2=' + language;
  };


  /*
    Request translation and run callback function
    passing translated result or error to callback
   */

  Tran.prototype.request = function(opts) {
    var xhr;
    xhr = this.xhr = new XMLHttpRequest();
    xhr.onreadystatechange = (function(_this) {
      return function(e) {
        xhr = _this.xhr;
        if (xhr.readyState < 4) {

        } else if (xhr.status !== 200) {
          _this.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error();
          }
        } else if (xhr.readyState === 4) {
          return opts.success(e.target.response);
        }
      };
    })(this);
    xhr.open("GET", opts.url, true);
    return xhr.send();
  };

  Tran.prototype.makeUrl = function(value) {
    var url;
    url = [this.protocol, '://', this.host, this.path, this.lang, this.query, this.getEncodedValue(value)].join('');
    return url;
  };

  Tran.prototype.getEncodedValue = function(value) {
    var cc, char, code, val;
    val = encodeURIComponent(value);
    for (char in CHAR_CODES) {
      code = CHAR_CODES[char];
      if (typeof code === 'object') {
        cc = code.val;
      } else {
        cc = encodeURIComponent(code);
      }
      val = val.replace(char, cc);
    }
    return val;
  };

  Tran.prototype.errorHandler = function(xhr) {
    return console.log('error', xhr);
  };


  /*
   Receiving data from translation-engine and send ready message with data
   */

  Tran.prototype.successtHandler = function(translated) {
    if (translated) {
      return chrome.tabs.getSelected(null, (function(_this) {
        return function(tab) {
          return chrome.tabs.sendMessage(tab.id, {
            action: _this.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        };
      })(this));
    }
  };

  Tran.prototype.messageType = function(translated) {
    var _ref;
    if ((translated != null ? (_ref = translated.rows) != null ? _ref.length : void 0 : void 0) === 1) {
      return 'similar_words';
    } else {
      return 'open_tooltip';
    }
  };


  /*
    Parse response from translation engine
   */

  Tran.prototype.parse = function(response, silent, translate) {
    var doc, fragment;
    if (translate == null) {
      translate = null;
    }
    doc = this.stripScripts(response);
    fragment = this.makeFragment(doc);
    if (fragment) {
      translate = fragment.querySelector('#translation ~ table');
      if (translate) {
        translate.className = this.TABLE_CLASS;
        translate.setAttribute("cellpadding", "5");
        this.fixImages(translate);
        this.fixLinks(translate);
      } else if (!silent) {
        translate = document.createElement('div');
        translate.className = 'failTranslate';
        translate.innerText = "Unfortunately, could not translate";
      }
    }
    return translate;
  };


  /*
    Strip script tags from response html
   */

  Tran.prototype.stripScripts = function(s) {
    var div, i, scripts;
    div = document.createElement('div');
    div.innerHTML = s;
    scripts = div.getElementsByTagName('script');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
    return div.innerHTML;
  };

  Tran.prototype.makeFragment = function(doc, fragment) {
    var div;
    if (fragment == null) {
      fragment = null;
    }
    div = document.createElement("div");
    div.innerHTML = doc;
    fragment = document.createDocumentFragment();
    while (div.firstChild) {
      fragment.appendChild(div.firstChild);
    }
    return fragment;
  };

  Tran.prototype.fixImages = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'img', 'src');
    return fragment;
  };

  Tran.prototype.fixLinks = function(fragment) {
    if (fragment == null) {
      fragment = null;
    }
    this.fixUrl(fragment, 'a', 'href');
    return fragment;
  };

  Tran.prototype.fixUrl = function(fragment, tag, attr) {
    var parser, tags, _i, _len, _results;
    if (fragment == null) {
      fragment = null;
    }
    if (fragment) {
      tags = fragment.querySelectorAll(tag);
      parser = document.createElement('a');
      _results = [];
      for (_i = 0, _len = tags.length; _i < _len; _i++) {
        tag = tags[_i];
        parser.href = tag[attr];
        parser.host = this.host;
        parser.protocol = this.protocol;
        if (tag.tagName === 'A') {
          tag.classList.add('mtt_link');
          if (parser.pathname.indexOf('m.exe') !== -1) {
            parser.pathname = '/c' + parser.pathname;
            tag.setAttribute('target', '_blank');
          }
        } else if (tag.tagName === 'IMG') {
          tag.classList.add('mtt_img');
        }
        _results.push(tag.setAttribute(attr, parser.href));
      }
      return _results;
    }
  };

  return Tran;

})();

module.exports = new Tran;


},{"./char-codes.js":3}],5:[function(require,module,exports){
"use strict";

var _prototypeProperties = function (child, staticProps, instanceProps) {
  if (staticProps) Object.defineProperties(child, staticProps);
  if (instanceProps) Object.defineProperties(child.prototype, instanceProps);
};

/*
  Translation engine: http://www.turkishdictionary.net
  For translating turkish-russian and vice versa
*/
var CHAR_CODES = require("./char-codes-turk.js");

var TurkishDictionary = (function () {
  function TurkishDictionary() {
    this.host = "http://www.turkishdictionary.net/?word=%FC";
    this.path = "";
    this.protocol = "http";
    this.query = "&s=";
    this.TABLE_CLASS = "___mtt_translate_table";
    // this flag indicates that if translation was successful then publish it all over extension
    this.need_publish = true;
  }

  _prototypeProperties(TurkishDictionary, null, {
    search: {
      value: function search(data) {
        data.url = this.makeUrl(data.value);
        this.need_publish = false;
        return this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    translate: {
      value: function translate(data) {
        data.url = this.makeUrl(data.selectionText);
        this.need_publish = true;
        this.request(data);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeUrl: {
      value: function makeUrl(text) {
        var text = this.getEncodedValue(text);
        return ["http://www.turkishdictionary.net/?word=", text].join("");
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    getEncodedValue: {


      // Replace special language characters to html codes
      value: function getEncodedValue(value) {
        // to find spec symbols we first encode them (raw search for that symbol doesn't wor)
        return encodeURIComponent(value);
        //return this.makeStringTransferable(value);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeStringTransferable: {

      /** converting script from the turkishdict */
      value: function makeStringTransferable(inputText) {
        var text = "";
        if (inputText.length > 0) {
          text = inputText;
          for (var i = 0; i < text.length; i++) {
            if (CHAR_CODES[text.charCodeAt(i)]) {
              text = text.substring(0, i) + CHAR_CODES[text.charCodeAt(i)] + text.substring(i + 1, text.length);
            } else if (text.charAt(i) == " ") {
              // replace spaces
              text = text.substring(0, i) + "___" + text.substring(i + 1, text.length);
            }
          }
        }
        return text;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    request: {

      /*
        Request translation and run callback function
        passing translated result or error to callback
      */
      value: function request(opts) {
        console.log("start request");
        this.xhr = new XMLHttpRequest();
        this.xhr.onreadystatechange = this.onReadyStateChange.bind(this, opts);
        this.xhr.open("GET", opts.url, true);
        this.xhr.send();
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    onReadyStateChange: {
      value: function onReadyStateChange(opts, e) {
        var xhr = this.xhr;
        if (xhr.readyState < 4) {
          return;
        } else if (xhr.status != 200) {
          this.errorHandler(xhr);
          return opts.error && opts.error();
        } else if (xhr.readyState == 4) {
          var translation = this.successHandler(e.target.response);
          console.log("success turkish translate", translation);
          console.log("call", opts.success);
          return opts.success && opts.success(translation);
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    successHandler: {
      value: function successHandler(response) {
        var data = this.parse(response);
        if (this.need_publish) {
          chrome.tabs.getSelected(null, this.publishTranslation.bind(this, data));
        }
        return data;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    publishTranslation: {

      /* publish successfuly translated text all over extension */
      value: function publishTranslation(translation, tab) {
        console.log("publish translation");
        chrome.tabs.sendMessage(tab.id, {
          action: this.tooltipAction(translation),
          data: translation.outerHTML,
          success: !translation.classList.contains("failTranslate")
        });
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    tooltipAction: {
      value: function tooltipAction(translation) {
        if (translation.textContent.trim().indexOf("was not found in our dictionary") != -1) {
          console.log("similar words");
          return "similar_words";
        } else {
          console.log("open tooltip");
          return "open_tooltip";
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    errorHandler: {
      value: function errorHandler(response) {
        console.log("error ajax", response);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parse: {

      /* Parse response from translation engine */
      value: function parse(response, silent, translate) {
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);
        if (fragment) {
          translate = fragment.querySelector("#meaning_div > table");
          if (translate) {
            translate.className = this.TABLE_CLASS;
            translate.setAttribute("cellpadding", "5");
            // @fixImages(translate)
            // @fixLinks(translate)
          } else if (!silent) {
            translate = document.createElement("div");
            translate.className = "failTranslate";
            translate.innerText = "Unfortunately, could not translate";
          }
        }
        return translate;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    parseText: {

      /** parsing of terrible html markup */
      value: function parseText(response, silent, translate) {
        var _this = this;
        var doc = this.stripScripts(response),
            fragment = this.makeFragment(doc);

        if (fragment) {
          var i;
          var _ret = (function () {
            var stopIndex = null;
            var tr = fragment.querySelectorAll("#meaning_div>table>tbody>tr");
            tr = Array.prototype.slice.call(tr);

            var trans = tr.filter(function (tr, index) {
              if (!isNaN(parseInt(stopIndex, 10)) && index >= stopIndex) {
                return;
              } else {
                tr = $(tr);
                // take every row before next section (which is English->English)
                if (tr.attr("bgcolor") == "e0e6ff") {
                  stopIndex = index;return;
                } else {
                  return $.trim(tr.find("td").text()).length;
                }
              }
            });
            trans = trans.slice(1, trans.length - 1);
            trans = trans.filter(function (el, indx) {
              return indx % 2;
            });
            var frag = _this.fragmentFromList(trans);
            var fonts = frag.querySelectorAll("font");
            var text = "";
            for (i = 0; i < fonts.length; i++) {
              text += " " + fonts[i].textContent.trim();
            }
            return {
              v: text
            };
          })();

          if (typeof _ret === "object") return _ret.v;
        } else {
          throw "HTML fragment could not be parsed";
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    stripScripts: {

      //TODO extract to base engine class
      /* removes <script> tags from html code */
      value: function stripScripts(html) {
        var div = document.createElement("div");
        div.innerHTML = html;
        var scripts = div.getElementsByTagName("script");
        var i = scripts.length;
        while (i--) scripts[i].parentNode.removeChild(scripts[i]);
        return div.innerHTML;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    makeFragment: {

      //TODO extract to base engine class
      /* creates temp object to parse translation from page 
        (since it's not a friendly api) 
      */
      value: function makeFragment(html) {
        var fragment = document.createDocumentFragment(),
            div = document.createElement("div");
        div.innerHTML = html;
        while (div.firstChild) {
          fragment.appendChild(div.firstChild);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    fragmentFromList: {

      /** create fragment from list of DOM elements */
      value: function fragmentFromList(list) {
        var fragment = document.createDocumentFragment(),
            len = list.length;
        while (len--) {
          fragment.appendChild(list[len]);
        }
        return fragment;
      },
      writable: true,
      enumerable: true,
      configurable: true
    }
  });

  return TurkishDictionary;
})();

// Singletone
module.exports = new TurkishDictionary();
},{"./char-codes-turk.js":2}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vbm9kZV9tb2R1bGVzL2dydW50LWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvYmFja2dyb3VuZC5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXZlbG9wbWVudC90cmFuL2pzL2NoYXItY29kZXMtdHVyay5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvY2hhci1jb2Rlcy5qcyIsIi9Vc2Vycy9hbnRob255L0RldmVsb3BtZW50L3RyYW4vanMvdHJhbi5jb2ZmZWUiLCIvVXNlcnMvYW50aG9ueS9EZXZlbG9wbWVudC90cmFuL2pzL3R1cmtpc2hkaWN0aW9uYXJ5LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFBQSx3QkFBQTtBQUFBLElBQUEsbUNBQUE7O0FBQUEsVUFHQSxHQUFhLE9BQUEsQ0FBUSxpQkFBUixDQUhiLENBQUE7O0FBQUEsSUFLQSxHQUFPLE9BQUEsQ0FBUSxlQUFSLENBTFAsQ0FBQTs7QUFBQSxpQkFNQSxHQUFvQixPQUFBLENBQVEsd0JBQVIsQ0FOcEIsQ0FBQTs7QUFBQSxNQVNNLENBQUMsWUFBWSxDQUFDLE1BQXBCLENBQ0U7QUFBQSxFQUFBLEtBQUEsRUFBUSxpQkFBUjtBQUFBLEVBQ0EsUUFBQSxFQUFVLENBQUMsVUFBRCxFQUFhLFdBQWIsQ0FEVjtBQUFBLEVBRUEsT0FBQSxFQUFVLFNBQUMsSUFBRCxHQUFBO0FBQ1IsSUFBQSxJQUFJLENBQUMsTUFBTCxHQUFjLEtBQWQsQ0FBQTtXQUNBLElBQUksQ0FBQyxLQUFMLENBQVcsSUFBWCxFQUZRO0VBQUEsQ0FGVjtDQURGLENBVEEsQ0FBQTs7QUFpQkE7QUFBQTs7OztHQWpCQTs7QUFBQSxNQXNCTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsV0FBekIsQ0FBcUMsU0FBQyxPQUFELEVBQVUsTUFBVixFQUFrQixZQUFsQixHQUFBO0FBQ25DLEVBQUEsSUFBRyxPQUFPLENBQUMsTUFBUixLQUFrQixpQkFBckI7QUFDRSxJQUFBLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQXBCLENBQXdCO0FBQUEsTUFBQSxJQUFBLEVBQU0sSUFBTjtLQUF4QixFQUFvQyxTQUFDLEtBQUQsR0FBQTthQUNoQyxZQUFBLENBQWE7QUFBQSxRQUFBLElBQUEsRUFBTSxLQUFLLENBQUMsSUFBWjtPQUFiLEVBRGdDO0lBQUEsQ0FBcEMsQ0FBQSxDQURGO0dBQUEsTUFPSyxJQUFHLE9BQU8sQ0FBQyxNQUFSLEtBQWtCLGdCQUFyQjtBQUNILElBQUEsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBcEIsQ0FBd0I7QUFBQSxNQUFFLFFBQUEsRUFBVSxHQUFaO0FBQUEsTUFBaUIsSUFBQSxFQUFNLElBQXZCO0tBQXhCLEVBQXNELFNBQUMsS0FBRCxHQUFBO0FBQ3BELE1BQUEsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFiLEdBQXNCLElBQXRCLENBQUE7QUFDQSxNQUFBLElBQUcsUUFBQSxDQUFTLEtBQUssQ0FBQyxRQUFmLEVBQXdCLEVBQXhCLENBQUEsS0FBK0IsSUFBbEM7QUFDRSxRQUFBLGlCQUFpQixDQUFDLFNBQWxCLENBQTRCLE9BQU8sQ0FBQyxJQUFwQyxDQUFBLENBREY7T0FBQSxNQUFBO0FBR0UsUUFBQSxJQUFJLENBQUMsS0FBTCxDQUFXLE9BQU8sQ0FBQyxJQUFuQixDQUFBLENBSEY7T0FEQTtBQUtBLGFBQU8sSUFBUCxDQU5vRDtJQUFBLENBQXRELENBQUEsQ0FERztHQVBMO1NBZ0JBLEtBakJtQztBQUFBLENBQXJDLENBdEJBLENBQUE7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdkJBOztBQ0FBO0FBQUEsa0JBQUE7QUFDQTtBQUFBOzs7Ozs7Ozs7O0dBREE7QUFBQSxJQUFBLGdCQUFBOztBQUFBLFVBYUEsR0FBYSxPQUFBLENBQVEsaUJBQVIsQ0FiYixDQUFBOztBQUFBO0FBZ0JlLEVBQUEsY0FBQSxHQUFBO0FBQ1gsSUFBQSxJQUFDLENBQUEsV0FBRCxHQUFlLHdCQUFmLENBQUE7QUFBQSxJQUNBLElBQUMsQ0FBQSxRQUFELEdBQVksTUFEWixDQUFBO0FBQUEsSUFFQSxJQUFDLENBQUEsSUFBRCxHQUFRLGtCQUZSLENBQUE7QUFBQSxJQUdBLElBQUMsQ0FBQSxJQUFELEdBQVEsVUFIUixDQUFBO0FBQUEsSUFJQSxJQUFDLENBQUEsS0FBRCxHQUFTLEtBSlQsQ0FBQTtBQUFBLElBS0EsSUFBQyxDQUFBLElBQUQsR0FBUSxZQUxSLENBQUE7QUFBQSxJQU1BLElBQUMsQ0FBQSxHQUFELEdBQU8sRUFOUCxDQURXO0VBQUEsQ0FBYjs7QUFTQTtBQUFBOztLQVRBOztBQUFBLGlCQVlBLEtBQUEsR0FBTyxTQUFDLElBQUQsR0FBQTtBQUNMLFFBQUEsYUFBQTtBQUFBLElBQUEsSUFBRyxNQUFBLENBQUEsSUFBVyxDQUFDLE1BQVosS0FBc0IsTUFBdEIsSUFBbUMsSUFBSSxDQUFDLE1BQUwsS0FBZSxJQUFyRDtBQUNFLE1BQUEsSUFBSSxDQUFDLE1BQUwsR0FBYyxJQUFkLENBREY7S0FBQTtBQUFBLElBRUEsYUFBQSxHQUFnQixJQUFDLENBQUEsaUJBQUQsQ0FBbUIsSUFBSSxDQUFDLGFBQXhCLENBRmhCLENBQUE7V0FHQSxJQUFDLENBQUEsTUFBRCxDQUNJO0FBQUEsTUFBQSxLQUFBLEVBQU8sYUFBUDtBQUFBLE1BQ0EsT0FBQSxFQUFTLElBQUMsQ0FBQSxlQUFlLENBQUMsSUFBakIsQ0FBc0IsSUFBdEIsQ0FEVDtBQUFBLE1BRUEsTUFBQSxFQUFRLElBQUksQ0FBQyxNQUZiO0tBREosRUFKSztFQUFBLENBWlAsQ0FBQTs7QUFxQkE7QUFBQTs7S0FyQkE7O0FBQUEsaUJBd0JBLGlCQUFBLEdBQW1CLFNBQUMsSUFBRCxHQUFBO1dBQ2pCLElBQUksQ0FBQyxPQUFMLENBQWEsT0FBYixFQUFzQixFQUF0QixFQURpQjtFQUFBLENBeEJuQixDQUFBOztBQTJCQTtBQUFBOztLQTNCQTs7QUFBQSxpQkE4QkEsTUFBQSxHQUFRLFNBQUMsTUFBRCxHQUFBO1dBRU4sTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBcEIsQ0FBd0I7QUFBQSxNQUFDLFFBQUEsRUFBVSxHQUFYO0tBQXhCLEVBQXlDLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLEtBQUQsR0FBQTtBQUN2QyxZQUFBLDBCQUFBO0FBQUEsUUFBQSxJQUFHLFFBQUEsS0FBWSxFQUFmO0FBQ0UsVUFBQSxRQUFBLEdBQVcsR0FBWCxDQURGO1NBQUE7QUFBQSxRQUVBLEtBQUMsQ0FBQSxXQUFELENBQWEsS0FBSyxDQUFDLFFBQW5CLENBRkEsQ0FBQTtBQUFBLFFBR0EsR0FBQSxHQUFNLEtBQUMsQ0FBQSxPQUFELENBQVMsTUFBTSxDQUFDLEtBQWhCLENBSE4sQ0FBQTtBQUFBLFFBS0EsV0FBQSxHQUFjLE1BQU0sQ0FBQyxPQUxyQixDQUFBO0FBQUEsUUFNQSxNQUFNLENBQUMsT0FBUCxHQUFpQixTQUFDLFFBQUQsR0FBQTtBQUNmLGNBQUEsVUFBQTtBQUFBLFVBQUEsVUFBQSxHQUFhLEtBQUMsQ0FBQSxLQUFELENBQU8sUUFBUCxFQUFpQixNQUFNLENBQUMsTUFBeEIsQ0FBYixDQUFBO2lCQUNBLFdBQUEsQ0FBWSxVQUFaLEVBRmU7UUFBQSxDQU5qQixDQUFBO2VBV0EsS0FBQyxDQUFBLE9BQUQsQ0FDRTtBQUFBLFVBQUEsR0FBQSxFQUFLLEdBQUw7QUFBQSxVQUNBLE9BQUEsRUFBUyxNQUFNLENBQUMsT0FEaEI7QUFBQSxVQUVBLEtBQUEsRUFBTyxNQUFNLENBQUMsS0FGZDtTQURGLEVBWnVDO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBekMsRUFGTTtFQUFBLENBOUJSLENBQUE7O0FBQUEsaUJBbURBLFdBQUEsR0FBYSxTQUFDLFFBQUQsR0FBQTtBQUNYLElBQUEsSUFBQyxDQUFBLGVBQUQsR0FBbUIsUUFBbkIsQ0FBQTtXQUNBLElBQUMsQ0FBQSxJQUFELEdBQVEsV0FBQSxHQUFjLFNBRlg7RUFBQSxDQW5EYixDQUFBOztBQXVEQTtBQUFBOzs7S0F2REE7O0FBQUEsaUJBMkRBLE9BQUEsR0FBUyxTQUFDLElBQUQsR0FBQTtBQUNQLFFBQUEsR0FBQTtBQUFBLElBQUEsR0FBQSxHQUFNLElBQUMsQ0FBQSxHQUFELEdBQVcsSUFBQSxjQUFBLENBQUEsQ0FBakIsQ0FBQTtBQUFBLElBQ0EsR0FBRyxDQUFDLGtCQUFKLEdBQXlCLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLENBQUQsR0FBQTtBQUN2QixRQUFBLEdBQUEsR0FBTSxLQUFDLENBQUEsR0FBUCxDQUFBO0FBQ0EsUUFBQSxJQUFHLEdBQUcsQ0FBQyxVQUFKLEdBQWlCLENBQXBCO0FBQUE7U0FBQSxNQUVLLElBQUcsR0FBRyxDQUFDLE1BQUosS0FBYyxHQUFqQjtBQUNILFVBQUEsS0FBQyxDQUFBLFlBQUQsQ0FBYyxHQUFkLENBQUEsQ0FBQTtBQUNBLFVBQUEsSUFBSSxNQUFBLENBQUEsSUFBVyxDQUFDLEtBQVosS0FBcUIsVUFBekI7QUFDRSxZQUFBLElBQUksQ0FBQyxLQUFMLENBQUEsQ0FBQSxDQURGO1dBRkc7U0FBQSxNQUtBLElBQUcsR0FBRyxDQUFDLFVBQUosS0FBa0IsQ0FBckI7QUFDRCxpQkFBTyxJQUFJLENBQUMsT0FBTCxDQUFhLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBdEIsQ0FBUCxDQURDO1NBVGtCO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FEekIsQ0FBQTtBQUFBLElBYUEsR0FBRyxDQUFDLElBQUosQ0FBUyxLQUFULEVBQWdCLElBQUksQ0FBQyxHQUFyQixFQUEwQixJQUExQixDQWJBLENBQUE7V0FjQSxHQUFHLENBQUMsSUFBSixDQUFBLEVBZk87RUFBQSxDQTNEVCxDQUFBOztBQUFBLGlCQTZFQSxPQUFBLEdBQVMsU0FBQyxLQUFELEdBQUE7QUFDUCxRQUFBLEdBQUE7QUFBQSxJQUFBLEdBQUEsR0FBTSxDQUFDLElBQUMsQ0FBQSxRQUFGLEVBQVksS0FBWixFQUNJLElBQUMsQ0FBQSxJQURMLEVBRUksSUFBQyxDQUFBLElBRkwsRUFHSSxJQUFDLENBQUEsSUFITCxFQUlJLElBQUMsQ0FBQSxLQUpMLEVBS0ksSUFBQyxDQUFBLGVBQUQsQ0FBaUIsS0FBakIsQ0FMSixDQU1DLENBQUMsSUFORixDQU1PLEVBTlAsQ0FBTixDQUFBO0FBUUEsV0FBTyxHQUFQLENBVE87RUFBQSxDQTdFVCxDQUFBOztBQUFBLGlCQXlGQSxlQUFBLEdBQWlCLFNBQUMsS0FBRCxHQUFBO0FBRWYsUUFBQSxtQkFBQTtBQUFBLElBQUEsR0FBQSxHQUFNLGtCQUFBLENBQW1CLEtBQW5CLENBQU4sQ0FBQTtBQUNBLFNBQUEsa0JBQUE7OEJBQUE7QUFDRSxNQUFBLElBQUcsTUFBQSxDQUFBLElBQUEsS0FBZSxRQUFsQjtBQUVFLFFBQUEsRUFBQSxHQUFLLElBQUksQ0FBQyxHQUFWLENBRkY7T0FBQSxNQUFBO0FBTUUsUUFBQSxFQUFBLEdBQUssa0JBQUEsQ0FBbUIsSUFBbkIsQ0FBTCxDQU5GO09BQUE7QUFBQSxNQU9BLEdBQUEsR0FBTSxHQUFHLENBQUMsT0FBSixDQUFZLElBQVosRUFBa0IsRUFBbEIsQ0FQTixDQURGO0FBQUEsS0FEQTtBQVVBLFdBQU8sR0FBUCxDQVplO0VBQUEsQ0F6RmpCLENBQUE7O0FBQUEsaUJBdUdBLFlBQUEsR0FBYyxTQUFDLEdBQUQsR0FBQTtXQUNaLE9BQU8sQ0FBQyxHQUFSLENBQVksT0FBWixFQUFxQixHQUFyQixFQURZO0VBQUEsQ0F2R2QsQ0FBQTs7QUEwR0E7QUFBQTs7S0ExR0E7O0FBQUEsaUJBNkdBLGVBQUEsR0FBaUIsU0FBQyxVQUFELEdBQUE7QUFDZixJQUFBLElBQUcsVUFBSDthQUNFLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBWixDQUF3QixJQUF4QixFQUE4QixDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxHQUFELEdBQUE7aUJBQzVCLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBWixDQUF3QixHQUFHLENBQUMsRUFBNUIsRUFBZ0M7QUFBQSxZQUM5QixNQUFBLEVBQVEsS0FBQyxDQUFBLFdBQUQsQ0FBYSxVQUFiLENBRHNCO0FBQUEsWUFFOUIsSUFBQSxFQUFNLFVBQVUsQ0FBQyxTQUZhO0FBQUEsWUFHOUIsT0FBQSxFQUFTLENBQUEsVUFBVyxDQUFDLFNBQVMsQ0FBQyxRQUFyQixDQUE4QixlQUE5QixDQUhvQjtXQUFoQyxFQUQ0QjtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQTlCLEVBREY7S0FEZTtFQUFBLENBN0dqQixDQUFBOztBQUFBLGlCQXVIQSxXQUFBLEdBQWEsU0FBQyxVQUFELEdBQUE7QUFDWCxRQUFBLElBQUE7QUFBQSxJQUFBLGlFQUFtQixDQUFFLHlCQUFsQixLQUE0QixDQUEvQjthQUNFLGdCQURGO0tBQUEsTUFBQTthQUdFLGVBSEY7S0FEVztFQUFBLENBdkhiLENBQUE7O0FBNkhBO0FBQUE7O0tBN0hBOztBQUFBLGlCQWdJQSxLQUFBLEdBQU8sU0FBQyxRQUFELEVBQVcsTUFBWCxFQUFtQixTQUFuQixHQUFBO0FBQ0gsUUFBQSxhQUFBOztNQURzQixZQUFZO0tBQ2xDO0FBQUEsSUFBQSxHQUFBLEdBQU0sSUFBQyxDQUFBLFlBQUQsQ0FBYyxRQUFkLENBQU4sQ0FBQTtBQUFBLElBQ0EsUUFBQSxHQUFXLElBQUMsQ0FBQSxZQUFELENBQWMsR0FBZCxDQURYLENBQUE7QUFFQSxJQUFBLElBQUcsUUFBSDtBQUNFLE1BQUEsU0FBQSxHQUFZLFFBQVEsQ0FBQyxhQUFULENBQXVCLHNCQUF2QixDQUFaLENBQUE7QUFDQSxNQUFBLElBQUcsU0FBSDtBQUNFLFFBQUEsU0FBUyxDQUFDLFNBQVYsR0FBc0IsSUFBQyxDQUFBLFdBQXZCLENBQUE7QUFBQSxRQUNBLFNBQVMsQ0FBQyxZQUFWLENBQXVCLGFBQXZCLEVBQXNDLEdBQXRDLENBREEsQ0FBQTtBQUFBLFFBRUEsSUFBQyxDQUFBLFNBQUQsQ0FBVyxTQUFYLENBRkEsQ0FBQTtBQUFBLFFBR0EsSUFBQyxDQUFBLFFBQUQsQ0FBVSxTQUFWLENBSEEsQ0FERjtPQUFBLE1BS0ssSUFBRyxDQUFBLE1BQUg7QUFDSCxRQUFBLFNBQUEsR0FBWSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QixDQUFaLENBQUE7QUFBQSxRQUNBLFNBQVMsQ0FBQyxTQUFWLEdBQXNCLGVBRHRCLENBQUE7QUFBQSxRQUVBLFNBQVMsQ0FBQyxTQUFWLEdBQXNCLG9DQUZ0QixDQURHO09BUFA7S0FGQTtBQWNBLFdBQU8sU0FBUCxDQWZHO0VBQUEsQ0FoSVAsQ0FBQTs7QUFpSkE7QUFBQTs7S0FqSkE7O0FBQUEsaUJBb0pBLFlBQUEsR0FBYyxTQUFDLENBQUQsR0FBQTtBQUNaLFFBQUEsZUFBQTtBQUFBLElBQUEsR0FBQSxHQUFNLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCLENBQU4sQ0FBQTtBQUFBLElBQ0EsR0FBRyxDQUFDLFNBQUosR0FBZ0IsQ0FEaEIsQ0FBQTtBQUFBLElBRUEsT0FBQSxHQUFVLEdBQUcsQ0FBQyxvQkFBSixDQUF5QixRQUF6QixDQUZWLENBQUE7QUFBQSxJQUdBLENBQUEsR0FBSSxPQUFPLENBQUMsTUFIWixDQUFBO0FBSUEsV0FBTSxDQUFBLEVBQU4sR0FBQTtBQUNFLE1BQUEsT0FBUSxDQUFBLENBQUEsQ0FBRSxDQUFDLFVBQVUsQ0FBQyxXQUF0QixDQUFrQyxPQUFRLENBQUEsQ0FBQSxDQUExQyxDQUFBLENBREY7SUFBQSxDQUpBO0FBTUEsV0FBTyxHQUFHLENBQUMsU0FBWCxDQVBZO0VBQUEsQ0FwSmQsQ0FBQTs7QUFBQSxpQkE2SkEsWUFBQSxHQUFjLFNBQUMsR0FBRCxFQUFNLFFBQU4sR0FBQTtBQUNaLFFBQUEsR0FBQTs7TUFEa0IsV0FBVztLQUM3QjtBQUFBLElBQUEsR0FBQSxHQUFNLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCLENBQU4sQ0FBQTtBQUFBLElBQ0EsR0FBRyxDQUFDLFNBQUosR0FBZ0IsR0FEaEIsQ0FBQTtBQUFBLElBRUEsUUFBQSxHQUFXLFFBQVEsQ0FBQyxzQkFBVCxDQUFBLENBRlgsQ0FBQTtBQUdBLFdBQVEsR0FBRyxDQUFDLFVBQVosR0FBQTtBQUNFLE1BQUEsUUFBUSxDQUFDLFdBQVQsQ0FBc0IsR0FBRyxDQUFDLFVBQTFCLENBQUEsQ0FERjtJQUFBLENBSEE7QUFLQSxXQUFPLFFBQVAsQ0FOWTtFQUFBLENBN0pkLENBQUE7O0FBQUEsaUJBcUtBLFNBQUEsR0FBVyxTQUFDLFFBQUQsR0FBQTs7TUFBQyxXQUFTO0tBQ25CO0FBQUEsSUFBQSxJQUFJLENBQUMsTUFBTCxDQUFZLFFBQVosRUFBc0IsS0FBdEIsRUFBNkIsS0FBN0IsQ0FBQSxDQUFBO0FBQ0EsV0FBTyxRQUFQLENBRlM7RUFBQSxDQXJLWCxDQUFBOztBQUFBLGlCQXlLQSxRQUFBLEdBQVUsU0FBQyxRQUFELEdBQUE7O01BQUMsV0FBUztLQUNsQjtBQUFBLElBQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxRQUFaLEVBQXNCLEdBQXRCLEVBQTJCLE1BQTNCLENBQUEsQ0FBQTtBQUNBLFdBQU8sUUFBUCxDQUZRO0VBQUEsQ0F6S1YsQ0FBQTs7QUFBQSxpQkE2S0EsTUFBQSxHQUFRLFNBQUMsUUFBRCxFQUFnQixHQUFoQixFQUFxQixJQUFyQixHQUFBO0FBQ04sUUFBQSxnQ0FBQTs7TUFETyxXQUFTO0tBQ2hCO0FBQUEsSUFBQSxJQUFHLFFBQUg7QUFDRSxNQUFBLElBQUEsR0FBUSxRQUFRLENBQUMsZ0JBQVQsQ0FBMEIsR0FBMUIsQ0FBUixDQUFBO0FBQUEsTUFDQSxNQUFBLEdBQVMsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsR0FBdkIsQ0FEVCxDQUFBO0FBRUE7V0FBQSwyQ0FBQTt1QkFBQTtBQUNFLFFBQUEsTUFBTSxDQUFDLElBQVAsR0FBYyxHQUFJLENBQUEsSUFBQSxDQUFsQixDQUFBO0FBQUEsUUFDQSxNQUFNLENBQUMsSUFBUCxHQUFjLElBQUMsQ0FBQSxJQURmLENBQUE7QUFBQSxRQUVBLE1BQU0sQ0FBQyxRQUFQLEdBQWtCLElBQUMsQ0FBQSxRQUZuQixDQUFBO0FBSUEsUUFBQSxJQUFHLEdBQUcsQ0FBQyxPQUFKLEtBQWUsR0FBbEI7QUFDRSxVQUFBLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBZCxDQUFrQixVQUFsQixDQUFBLENBQUE7QUFDQSxVQUFBLElBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFoQixDQUF3QixPQUF4QixDQUFBLEtBQXNDLENBQUEsQ0FBekM7QUFDRSxZQUFBLE1BQU0sQ0FBQyxRQUFQLEdBQWtCLElBQUEsR0FBTyxNQUFNLENBQUMsUUFBaEMsQ0FBQTtBQUFBLFlBQ0EsR0FBRyxDQUFDLFlBQUosQ0FBaUIsUUFBakIsRUFBMkIsUUFBM0IsQ0FEQSxDQURGO1dBRkY7U0FBQSxNQUtLLElBQUcsR0FBRyxDQUFDLE9BQUosS0FBZSxLQUFsQjtBQUNILFVBQUEsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFkLENBQWtCLFNBQWxCLENBQUEsQ0FERztTQVRMO0FBQUEsc0JBWUEsR0FBRyxDQUFDLFlBQUosQ0FBaUIsSUFBakIsRUFBdUIsTUFBTSxDQUFDLElBQTlCLEVBWkEsQ0FERjtBQUFBO3NCQUhGO0tBRE07RUFBQSxDQTdLUixDQUFBOztjQUFBOztJQWhCRixDQUFBOztBQUFBLE1Ba05NLENBQUMsT0FBUCxHQUFpQixHQUFBLENBQUEsSUFsTmpCLENBQUE7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3Rocm93IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIil9dmFyIGY9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGYuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sZixmLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIiMjI2dsb2JhbCB0cmFuLCBjaHJvbWUjIyNcblxuI2xvYWQgZW5naW5lc1xuQ0hBUl9DT0RFUyA9IHJlcXVpcmUoJy4vY2hhci1jb2Rlcy5qcycpO1xuXG50cmFuID0gcmVxdWlyZSgnLi90cmFuLmNvZmZlZScpICAgICAgICAgICAgICAgICAgICAgICAgICAgICAjIG11bHRpdHJhbi5ydVxudHVya2lzaERpY3Rpb25hcnkgPSByZXF1aXJlKCcuL3R1cmtpc2hkaWN0aW9uYXJ5LmpzJykgICAjIHR1cmtpc2hkaWN0aW9uYXJ5Lm5ldFxuXG4jZ2VuZXJhdGVzIGEgY29udGV4dCBtZW51XG5jaHJvbWUuY29udGV4dE1lbnVzLmNyZWF0ZShcbiAgdGl0bGU6ICAnTXVsdGl0cmFuOiBcIiVzXCInXG4gIGNvbnRleHRzOiBbXCJlZGl0YWJsZVwiLCBcInNlbGVjdGlvblwiXVxuICBvbmNsaWNrOiAgKGRhdGEpIC0+XG4gICAgZGF0YS5zaWxlbnQgPSBmYWxzZVxuICAgIHRyYW4uY2xpY2soZGF0YSlcbilcblxuIyMjXG4gQ2FuJ3QgZ2V0IGNocm9tZS5zdG9yYWdlIGRpcmVjdGx5IGZyb20gY29udGVudF9zY3JpcHRcbiBzbyBjb250ZW50X3NjcmlwdCBzZW5kcyByZXF1ZXN0IG1lc3NhZ2UgYW5kIHRoZW4gYmFja2dyb3VuZCBzY3JpcHRcbiByZXNwb25kcyB3aXRoIHN0b3JhZ2UgdmFsdWVcbiMjI1xuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyIChyZXF1ZXN0LCBzZW5kZXIsIHNlbmRSZXNwb25zZSkgLT5cbiAgaWYgcmVxdWVzdC5tZXRob2QgPT0gXCJnZXRfZmFzdF9vcHRpb25cIlxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KGZhc3Q6IHRydWUsIChpdGVtcykgLT5cbiAgICAgICAgc2VuZFJlc3BvbnNlKGZhc3Q6IGl0ZW1zLmZhc3QpXG4gICAgICAgICNyZXR1cm4gdHJ1ZVxuICAgIClcbiAgI0Zhc3QgdHJhbnNsYXRpb24gaW5pdGlhdGUgc2VhcmNoIHdpdGggJ3JlcXVlc3Rfc2VhcmNoJyBtZXNzYWdlIGZyb21cbiAgI2NvbnRlbnRfc2NyaXB0XG4gIGVsc2UgaWYgcmVxdWVzdC5tZXRob2QgPT0gJ3JlcXVlc3Rfc2VhcmNoJ1xuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHsgbGFuZ3VhZ2U6ICcxJywgZmFzdDogdHJ1ZX0sIChpdGVtcykgLT5cbiAgICAgIHJlcXVlc3QuZGF0YS5zaWxlbnQgPSB0cnVlXG4gICAgICBpZiBwYXJzZUludChpdGVtcy5sYW5ndWFnZSwxMCkgPT0gMTAwMFxuICAgICAgICB0dXJraXNoRGljdGlvbmFyeS50cmFuc2xhdGUocmVxdWVzdC5kYXRhKVxuICAgICAgZWxzZVxuICAgICAgICB0cmFuLmNsaWNrKHJlcXVlc3QuZGF0YSlcbiAgICAgIHJldHVybiB0cnVlXG4gICAgKVxuICB0cnVlXG5cbiIsIi8vIHR1cmtpc2hkaWN0aW9uYXJ5IGNvZGluZ3NcbnZhciBESUNUID0ge1xuICAgIDM1MDogJyVERScsIC8vxZ5cbiAgICAyODY6ICclRDAnLCAvL8SeXG4gICAgMjg3OiAnJUYwJywgLy/En1xuICAgIDM1MTogJyVGRScsIC8vxZ9cbiAgICAzMDU6ICclRkQnLCAvL8SxXG4gICAgMzA0OiAnJUREJywgLy/EsFxuICAgIDI1MjogJyVGQycsIC8vw7xcbiAgICAyMjA6ICclREMnLCAvL8OcXG4gICAgMjMxOiAnJUU3JywgLy/Dp1xuICAgIDE5OTogJyVDNycsIC8vw4dcbiAgICAyNDY6ICclRjYnLCAvL8O2XG4gICAgMjQ0OiAnJUY0JywgLy/DtFxuICAgIDIxNDogJyVENicsIC8vw5ZcbiAgICAyMTI6ICclRDQnLCAvL8OUXG4gICAgMjUxOiAnJUZCJywgLy/Du1xuICAgIDIxOTogJyVEQicsIC8vw5tcbiAgICAxOTQ6ICclQzInLCAvL8OCXG4gICAgMjI2OiAnJUUyJywgLy/DolxuICAgIDM5OiAnJywgIC8vJ1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBESUNUOyIsIi8qXHIgIE11bHRpdHJhbiBkZXBlbmRzIG9uIGh0bWwtZXNjYXBpbmcgKG5vdCBVVEYtOCkgcnVsZXMgZm9yIHNwZWNpYWwgc3ltYm9sc1xyICDDoCwgw6gsIMOsLCDDsiwgw7kgLSDDgCwgw4gsIMOMLCDDkiwgw5lcciAgw6EsIMOpLCDDrSwgw7MsIMO6LCDDvSAtIMOBLCDDiSwgw40sIMOTLCDDmiwgw51cciAgw6IsIMOqLCDDriwgw7QsIMO7IMOCLCDDiiwgw44sIMOULCDDm1xyICDDoywgw7EsIMO1IMODLCDDkSwgw5VcciAgw6QsIMOrLCDDrywgw7YsIMO8LCDDvyDDhCwgw4ssIMOPLCDDliwgw5wsXHIgIMOlLCDDhVxyICDDpiwgw4ZcciAgw6csIMOHXHIgIMOwLCDDkFxyICDDuCwgw5hcciAgwr8gwqEgw59cciovXHJ2YXIgQ0hBUl9DT0RFUyA9IHtcciAgLy9ydXNzaWFuXHIgICclRDElOEEnOiB7dmFsOiclRkEnLCBsYW5nOidydSd9LCAvLyDRilxyICAnJUQwJUFBJzoge3ZhbDonJURBJywgbGFuZzoncnUnfSwvLyDQqlxyXHIgICclQzMlODAnOiAnJiMxOTI7JywgLy8gw4BcciAgJyVDMyU4MSc6ICcmIzE5MzsnLCAvLyDDgVxyICAnJUMzJTgyJzogJyYjMTk0OycsIC8vIMOCXHIgICclQzMlODMnOiAnJiMxOTU7JywgLy8gw4NcciAgJyVDMyU4NCc6ICcmIzE5NjsnLCAvLyDDhFxyICAnJUMzJTg1JzogJyYjMTk3OycsIC8vIMOFXHIgICclQzMlODYnOiAnJiMxOTg7JywgLy8gw4ZcclxyICAnJUMzJTg3JzogJyYjMTk5OycsIC8vIMOHXHIgICclQzMlODgnOiAnJiMyMDA7JywgLy8gw4hcciAgJyVDMyU4OSc6ICcmIzIwMTsnLCAvLyDDiVxyICAnJUMzJThBJzogJyYjMjAyOycsIC8vIMOKXHIgICclQzMlOEInOiAnJiMyMDM7JywgLy8gw4tcclxyICAnJUMzJThDJzogJyYjMjA0OycsIC8vIMOMXHIgICclQzMlOEQnOiAnJiMyMDU7JywgLy8gw41cciAgJyVDMyU4RSc6ICcmIzIwNjsnLCAvLyDDjlxyICAnJUMzJThGJzogJyYjMjA3OycsIC8vIMOPXHJcciAgJyVDMyU5MSc6ICcmIzIwOTsnLCAvLyDDkVxyICAnJUMzJTkyJzogJyYjMjEwOycsIC8vIMOSXHIgICclQzMlOTMnOiAnJiMyMTE7JywgLy8gw5NcciAgJyVDMyU5NCc6ICcmIzIxMjsnLCAvLyDDlFxyICAnJUMzJTk1JzogJyYjMjEzOycsIC8vIMOVXHIgICclQzMlOTYnOiAnJiMyMTQ7JywgLy8gw5ZcclxyICAnJUMzJTk5JzogJyYjMjE3OycsIC8vIMOZXHIgICclQzMlOUEnOiAnJiMyMTg7JywgLy8gw5pcciAgJyVDMyU5Qic6ICcmIzIxOTsnLCAvLyDDm1xyICAnJUMzJTlDJzogJyYjMjIwOycsIC8vIMOcXHJcclxyICAnJUMzJUEwJzogJyYjMjI0OycsIC8vIMOgXHIgICclQzMlQTEnOiAnJiMyMjU7JywgLy8gw6FcciAgJyVDMyVBMic6ICcmIzIyNjsnLCAvLyDDolxyICAnJUMzJUEzJzogJyYjMjI3OycsIC8vIMOjXHIgICclQzMlQTQnOiAnJiMyMjg7JywgLy8gw6RcciAgJyVDMyVBNSc6ICcmIzIyOTsnLCAvLyDDpVxyICAnJUMzJUE2JzogJyYjMjMwOycsIC8vIMOmXHIgICclQzMlQTcnOiAnJiMyMzE7JywgLy8gw6dcclxyXHIgICclQzMlQTgnOiAnJiMyMzI7JywgLy8gw6hcciAgJyVDMyVBOSc6ICcmIzIzMzsnLCAvLyDDqVxyICAnJUMzJUFBJzogJyYjMjM0OycsIC8vIMOqXHIgICclQzMlQUInOiAnJiMyMzU7JywgLy8gw6tcclxyICAnJUMzJUFDJzogJyYjMjM2OycsIC8vIMOsXHIgICclQzMlQUQnOiAnJiMyMzc7JywgLy8gw61cciAgJyVDMyVBRSc6ICcmIzIzODsnLCAvLyDDrlxyICAnJUMzJUFGJzogJyYjMjM5OycsIC8vIMOvXHJcciAgJyVDMyVCMCc6ICcmIzI0MDsnLCAvLyDDsFxyICAnJUMzJUIxJzogJyYjMjQxOycsIC8vIMOxXHJcciAgJyVDMyVCMic6ICcmIzI0MjsnLCAvLyDDslxyICAnJUMzJUIzJzogJyYjMjQzOycsIC8vIMOzXHIgICclQzMlQjQnOiAnJiMyNDQ7JywgLy8gw7RcciAgJyVDMyVCNSc6ICcmIzI0NTsnLCAvLyDDtVxyICAnJUMzJUI2JzogJyYjMjQ2OycsIC8vIMO2XHJcciAgJyVDMyVCOSc6ICcmIzI0OTsnLCAvLyDDuVxyICAnJUMzJUJBJzogJyYjMjUwOycsIC8vIMO6XHIgICclQzMlQkInOiAnJiMyNTE7JywgLy8gw7tcciAgJyVDMyVCQyc6ICcmIzI1MjsnLCAvLyDDvFxyICAnJUMzJUJGJzogJyYjMjU1OycsIC8vIMO/XHIgICclQzUlQjgnOiAnJiMzNzY7JywgLy8gxbhcclxyICAnJUMzJTlGJzogJyYjMjIzOycsIC8vIMOfXHJcciAgJyVDMiVCRic6ICcmIzE5MTsnLCAvLyDCv1xyICAnJUMyJUExJzogJyYjMTYxOycsIC8vIMKhXHJ9O1xyXHJtb2R1bGUuZXhwb3J0cyA9IENIQVJfQ09ERVM7XHIiLCIjIyNnbG9iYWwgY2hyb21lIyMjXG4jIyNcbiAgTXVsdGl0cmFuLnJ1IHRyYW5zbGF0ZSBlbmdpbmVcbiAgUHJvdmlkZXMgcHJvZ3JhbSBpbnRlcmZhY2UgZm9yIG1ha2luZyB0cmFuc2xhdGUgcXVlcmllcyB0byBtdWx0aXRyYW4gYW5kIGdldCBjbGVhbiByZXNwb25zZVxuXG4gIEFsbCBlbmdpbmVzIG11c3QgZm9sbG93IGNvbW1vbiBpbnRlcmZhY2UgYW5kIHByb3ZpZGUgbWV0aG9kczpcbiAgICAtIHNlYXJjaCAobGFuZ3VhbmdlLCBzdWNjZXNzSGFuZGxlcikgIGNsZWFuIHRyYW5zbGF0aW9uIG11c3QgYmUgcGFzc2VkIGludG8gc3VjY2Vzc0hhbmRsZXJcbiAgICAtIGNsaWNrXG5cbiAgVHJhbnNsYXRpb24tbW9kdWxlIHRoYXQgbWFrZXMgcmVxdWVzdHMgdG8gbGFuZ3VhZ2UtZW5naW5lLFxuICBwYXJzZXMgcmVzdWx0cyBhbmQgc2VuZHMgcGx1Z2luLWdsb2JhbCBtZXNzYWdlIHdpdGggdHJhbnNsYXRpb24gZGF0YVxuIyMjXG5cbkNIQVJfQ09ERVMgPSByZXF1aXJlKCcuL2NoYXItY29kZXMuanMnKTtcblxuY2xhc3MgVHJhblxuICBjb25zdHJ1Y3RvcjogLT5cbiAgICBAVEFCTEVfQ0xBU1MgPSBcIl9fX210dF90cmFuc2xhdGVfdGFibGVcIlxuICAgIEBwcm90b2NvbCA9ICdodHRwJ1xuICAgIEBob3N0ID0gJ3d3dy5tdWx0aXRyYW4ucnUnXG4gICAgQHBhdGggPSAnL2MvbS5leGUnXG4gICAgQHF1ZXJ5ID0gJyZzPSdcbiAgICBAbGFuZyA9ICc/bDE9MiZsMj0xJyAjZnJvbSBydXNzaWFuIHRvIGVuZ2xpc2ggYnkgZGVmYXVsdFxuICAgIEB4aHIgPSB7fVxuXG4gICMjI1xuICAgIENvbnRleHQgbWVudSBjbGljayBoYW5kbGVyXG4gICMjI1xuICBjbGljazogKGRhdGEpIC0+XG4gICAgaWYgdHlwZW9mIGRhdGEuc2lsZW50ID09IHVuZGVmaW5lZCB8fCBkYXRhLnNpbGVudCA9PSBudWxsXG4gICAgICBkYXRhLnNpbGVudCA9IHRydWUgIyB0cnVlIGJ5IGRlZmF1bHRcbiAgICBzZWxlY3Rpb25UZXh0ID0gQHJlbW92ZUh5cGhlbmF0aW9uIGRhdGEuc2VsZWN0aW9uVGV4dFxuICAgIEBzZWFyY2hcbiAgICAgICAgdmFsdWU6IHNlbGVjdGlvblRleHRcbiAgICAgICAgc3VjY2VzczogQHN1Y2Nlc3N0SGFuZGxlci5iaW5kKHRoaXMpXG4gICAgICAgIHNpbGVudDogZGF0YS5zaWxlbnQgICMgaWYgdHJhbnNsYXRpb24gZmFpbGVkIGRvIG5vdCBzaG93IGRpYWxvZ1xuXG4gICMjI1xuICAgIERpc2NhcmQgc29mdCBoeXBoZW4gY2hhcmFjdGVyIChVKzAwQUQsICZzaHk7KSBmcm9tIHRoZSBpbnB1dFxuICAjIyNcbiAgcmVtb3ZlSHlwaGVuYXRpb246ICh0ZXh0KSAtPlxuICAgIHRleHQucmVwbGFjZSAvXFx4YWQvZywgJydcblxuICAjIyNcbiAgICBJbml0aWF0ZSB0cmFuc2xhdGlvbiBzZWFyY2hcbiAgIyMjXG4gIHNlYXJjaDogKHBhcmFtcykgLT5cbiAgICAjdmFsdWUsIGNhbGxiYWNrLCBlcnJcbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7bGFuZ3VhZ2U6ICcxJ30sIChpdGVtcykgPT5cbiAgICAgIGlmIGxhbmd1YWdlIGlzICcnXG4gICAgICAgIGxhbmd1YWdlID0gJzEnXG4gICAgICBAc2V0TGFuZ3VhZ2UoaXRlbXMubGFuZ3VhZ2UpXG4gICAgICB1cmwgPSBAbWFrZVVybChwYXJhbXMudmFsdWUpO1xuICAgICAgIyBkZWNvcmF0ZSBzdWNjZXNzIHRvIG1ha2UgcHJlbGltaW5hcnkgcGFyc2luZ1xuICAgICAgb3JpZ1N1Y2Nlc3MgPSBwYXJhbXMuc3VjY2Vzc1xuICAgICAgcGFyYW1zLnN1Y2Nlc3MgPSAocmVzcG9uc2UpID0+XG4gICAgICAgIHRyYW5zbGF0ZWQgPSBAcGFyc2UocmVzcG9uc2UsIHBhcmFtcy5zaWxlbnQpXG4gICAgICAgIG9yaWdTdWNjZXNzKHRyYW5zbGF0ZWQpXG5cbiAgICAgICMgbWFrZSByZXF1ZXN0IChHRVQgcmVxdWVzdCB3aXRoIHF1ZXJ5IHBhcmFtZXRlcnMgaW4gdXJsKVxuICAgICAgQHJlcXVlc3QoXG4gICAgICAgIHVybDogdXJsLFxuICAgICAgICBzdWNjZXNzOiBwYXJhbXMuc3VjY2VzcyxcbiAgICAgICAgZXJyb3I6IHBhcmFtcy5lcnJvclxuICAgICAgKVxuICAgIClcblxuICBzZXRMYW5ndWFnZTogKGxhbmd1YWdlKSAtPlxuICAgIEBjdXJyZW50TGFuZ3VhZ2UgPSBsYW5ndWFnZVxuICAgIEBsYW5nID0gJz9sMT0yJmwyPScgKyBsYW5ndWFnZVxuXG4gICMjI1xuICAgIFJlcXVlc3QgdHJhbnNsYXRpb24gYW5kIHJ1biBjYWxsYmFjayBmdW5jdGlvblxuICAgIHBhc3NpbmcgdHJhbnNsYXRlZCByZXN1bHQgb3IgZXJyb3IgdG8gY2FsbGJhY2tcbiAgIyMjXG4gIHJlcXVlc3Q6IChvcHRzKSAtPlxuICAgIHhociA9IEB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKVxuICAgIHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSAoZSkgPT5cbiAgICAgIHhociA9IEB4aHJcbiAgICAgIGlmIHhoci5yZWFkeVN0YXRlIDwgNFxuICAgICAgICByZXR1cm5cbiAgICAgIGVsc2UgaWYgeGhyLnN0YXR1cyAhPSAyMDBcbiAgICAgICAgQGVycm9ySGFuZGxlcih4aHIpXG4gICAgICAgIGlmICh0eXBlb2Ygb3B0cy5lcnJvciA9PSAnZnVuY3Rpb24nKVxuICAgICAgICAgIG9wdHMuZXJyb3IoKVxuICAgICAgICByZXR1cm5cbiAgICAgIGVsc2UgaWYgeGhyLnJlYWR5U3RhdGUgPT0gNFxuICAgICAgICAgIHJldHVybiBvcHRzLnN1Y2Nlc3MoZS50YXJnZXQucmVzcG9uc2UpXG5cbiAgICB4aHIub3BlbihcIkdFVFwiLCBvcHRzLnVybCwgdHJ1ZSk7XG4gICAgeGhyLnNlbmQoKTtcblxuXG4gIG1ha2VVcmw6ICh2YWx1ZSkgLT5cbiAgICB1cmwgPSBbQHByb3RvY29sLCAnOi8vJyxcbiAgICAgICAgICAgICAgQGhvc3QsXG4gICAgICAgICAgICAgIEBwYXRoLFxuICAgICAgICAgICAgICBAbGFuZyxcbiAgICAgICAgICAgICAgQHF1ZXJ5LFxuICAgICAgICAgICAgICBAZ2V0RW5jb2RlZFZhbHVlKHZhbHVlKVxuICAgICAgICAgIF0uam9pbignJylcblxuICAgIHJldHVybiB1cmw7XG5cbiAgIyBSZXBsYWNlIHNwZWNpYWwgbGFuZ3VhZ2UgY2hhcmFjdGVycyB0byBodG1sIGNvZGVzXG4gIGdldEVuY29kZWRWYWx1ZTogKHZhbHVlKSAtPlxuICAgICMgdG8gZmluZCBzcGVjIHN5bWJvbHMgd2UgZmlyc3QgZW5jb2RlIHRoZW0gKHJhdyBzZWFyY2ggZm9yIHRoYXQgc3ltYm9sIGRvZXNuJ3Qgd29yKVxuICAgIHZhbCA9IGVuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSlcbiAgICBmb3IgY2hhciwgY29kZSBvZiBDSEFSX0NPREVTXG4gICAgICBpZiB0eXBlb2YgY29kZSA9PSAnb2JqZWN0J1xuICAgICAgICAjIHJ1c3NpYW4gaGFzIHNwZWNpYWwgY29kZXNcbiAgICAgICAgY2MgPSBjb2RlLnZhbFxuICAgICAgZWxzZVxuICAgICAgICAjIGZvciBhbGwgbGFuZ3MgZXhjZXB0IHJ1c3NpYW4gZW5jb2RlIGh0bWwtY29kZXMgbmVlZGVkXG4gICAgICAgICMg0LTQu9GPINCy0YHQtdGFINC+0YHRgtCw0LvRjNC90YvRhSDRj9C30YvQutC+0LJcbiAgICAgICAgY2MgPSBlbmNvZGVVUklDb21wb25lbnQoY29kZSlcbiAgICAgIHZhbCA9IHZhbC5yZXBsYWNlKGNoYXIsIGNjKVxuICAgIHJldHVybiB2YWxcblxuICBlcnJvckhhbmRsZXI6ICh4aHIpIC0+XG4gICAgY29uc29sZS5sb2coJ2Vycm9yJywgeGhyKVxuXG4gICMjI1xuICAgUmVjZWl2aW5nIGRhdGEgZnJvbSB0cmFuc2xhdGlvbi1lbmdpbmUgYW5kIHNlbmQgcmVhZHkgbWVzc2FnZSB3aXRoIGRhdGFcbiAgIyMjXG4gIHN1Y2Nlc3N0SGFuZGxlcjogKHRyYW5zbGF0ZWQpIC0+XG4gICAgaWYgdHJhbnNsYXRlZFxuICAgICAgY2hyb21lLnRhYnMuZ2V0U2VsZWN0ZWQobnVsbCwgKHRhYikgPT5cbiAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgYWN0aW9uOiBAbWVzc2FnZVR5cGUgdHJhbnNsYXRlZFxuICAgICAgICAgIGRhdGE6IHRyYW5zbGF0ZWQub3V0ZXJIVE1MLFxuICAgICAgICAgIHN1Y2Nlc3M6ICF0cmFuc2xhdGVkLmNsYXNzTGlzdC5jb250YWlucygnZmFpbFRyYW5zbGF0ZScpXG4gICAgICAgIH0pXG4gICAgICApXG5cbiAgbWVzc2FnZVR5cGU6ICh0cmFuc2xhdGVkKSAtPlxuICAgIGlmIHRyYW5zbGF0ZWQ/LnJvd3M/Lmxlbmd0aCA9PSAxXG4gICAgICAnc2ltaWxhcl93b3JkcydcbiAgICBlbHNlXG4gICAgICAnb3Blbl90b29sdGlwJ1xuXG4gICMjI1xuICAgIFBhcnNlIHJlc3BvbnNlIGZyb20gdHJhbnNsYXRpb24gZW5naW5lXG4gICMjI1xuICBwYXJzZTogKHJlc3BvbnNlLCBzaWxlbnQsIHRyYW5zbGF0ZSA9IG51bGwpIC0+XG4gICAgICBkb2MgPSBAc3RyaXBTY3JpcHRzKHJlc3BvbnNlKVxuICAgICAgZnJhZ21lbnQgPSBAbWFrZUZyYWdtZW50KGRvYylcbiAgICAgIGlmIGZyYWdtZW50XG4gICAgICAgIHRyYW5zbGF0ZSA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3IoJyN0cmFuc2xhdGlvbiB+IHRhYmxlJylcbiAgICAgICAgaWYgdHJhbnNsYXRlXG4gICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9IEBUQUJMRV9DTEFTUztcbiAgICAgICAgICB0cmFuc2xhdGUuc2V0QXR0cmlidXRlKFwiY2VsbHBhZGRpbmdcIiwgXCI1XCIpXG4gICAgICAgICAgQGZpeEltYWdlcyh0cmFuc2xhdGUpXG4gICAgICAgICAgQGZpeExpbmtzKHRyYW5zbGF0ZSlcbiAgICAgICAgZWxzZSBpZiBub3Qgc2lsZW50XG4gICAgICAgICAgdHJhbnNsYXRlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gJ2ZhaWxUcmFuc2xhdGUnXG4gICAgICAgICAgdHJhbnNsYXRlLmlubmVyVGV4dCA9IFwiVW5mb3J0dW5hdGVseSwgY291bGQgbm90IHRyYW5zbGF0ZVwiXG5cbiAgICAgIHJldHVybiB0cmFuc2xhdGU7XG5cbiAgIyMjXG4gICAgU3RyaXAgc2NyaXB0IHRhZ3MgZnJvbSByZXNwb25zZSBodG1sXG4gICMjI1xuICBzdHJpcFNjcmlwdHM6IChzKSAtPlxuICAgIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgZGl2LmlubmVySFRNTCA9IHNcbiAgICBzY3JpcHRzID0gZGl2LmdldEVsZW1lbnRzQnlUYWdOYW1lKCdzY3JpcHQnKVxuICAgIGkgPSBzY3JpcHRzLmxlbmd0aFxuICAgIHdoaWxlIGktLVxuICAgICAgc2NyaXB0c1tpXS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHNjcmlwdHNbaV0pXG4gICAgcmV0dXJuIGRpdi5pbm5lckhUTUw7XG5cbiAgbWFrZUZyYWdtZW50OiAoZG9jLCBmcmFnbWVudCA9IG51bGwpIC0+XG4gICAgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKVxuICAgIGRpdi5pbm5lckhUTUwgPSBkb2NcbiAgICBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKVxuICAgIHdoaWxlICggZGl2LmZpcnN0Q2hpbGQgKVxuICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoIGRpdi5maXJzdENoaWxkIClcbiAgICByZXR1cm4gZnJhZ21lbnRcblxuICBmaXhJbWFnZXM6IChmcmFnbWVudD1udWxsKSAtPlxuICAgIHRoaXMuZml4VXJsKGZyYWdtZW50LCAnaW1nJywgJ3NyYycpO1xuICAgIHJldHVybiBmcmFnbWVudDtcblxuICBmaXhMaW5rczogKGZyYWdtZW50PW51bGwpIC0+XG4gICAgdGhpcy5maXhVcmwoZnJhZ21lbnQsICdhJywgJ2hyZWYnKVxuICAgIHJldHVybiBmcmFnbWVudFxuXG4gIGZpeFVybDogKGZyYWdtZW50PW51bGwsIHRhZywgYXR0cikgLT5cbiAgICBpZiBmcmFnbWVudFxuICAgICAgdGFncyA9ICBmcmFnbWVudC5xdWVyeVNlbGVjdG9yQWxsKHRhZylcbiAgICAgIHBhcnNlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKVxuICAgICAgZm9yIHRhZyBpbiB0YWdzXG4gICAgICAgIHBhcnNlci5ocmVmID0gdGFnW2F0dHJdXG4gICAgICAgIHBhcnNlci5ob3N0ID0gQGhvc3RcbiAgICAgICAgcGFyc2VyLnByb3RvY29sID0gQHByb3RvY29sXG4gICAgICAgICNmaXggcmVsYXRpdmUgbGlua3NcbiAgICAgICAgaWYgdGFnLnRhZ05hbWUgPT0gJ0EnXG4gICAgICAgICAgdGFnLmNsYXNzTGlzdC5hZGQgJ210dF9saW5rJ1xuICAgICAgICAgIGlmIHBhcnNlci5wYXRobmFtZS5pbmRleE9mKCdtLmV4ZScpIGlzbnQgLTFcbiAgICAgICAgICAgIHBhcnNlci5wYXRobmFtZSA9ICcvYycgKyBwYXJzZXIucGF0aG5hbWVcbiAgICAgICAgICAgIHRhZy5zZXRBdHRyaWJ1dGUoJ3RhcmdldCcsICdfYmxhbmsnKVxuICAgICAgICBlbHNlIGlmIHRhZy50YWdOYW1lID09ICdJTUcnXG4gICAgICAgICAgdGFnLmNsYXNzTGlzdC5hZGQgJ210dF9pbWcnXG5cbiAgICAgICAgdGFnLnNldEF0dHJpYnV0ZShhdHRyLCBwYXJzZXIuaHJlZilcblxuXG5cbm1vZHVsZS5leHBvcnRzID0gbmV3IFRyYW4iLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIF9wcm90b3R5cGVQcm9wZXJ0aWVzID0gZnVuY3Rpb24gKGNoaWxkLCBzdGF0aWNQcm9wcywgaW5zdGFuY2VQcm9wcykge1xuICBpZiAoc3RhdGljUHJvcHMpIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGNoaWxkLCBzdGF0aWNQcm9wcyk7XG4gIGlmIChpbnN0YW5jZVByb3BzKSBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhjaGlsZC5wcm90b3R5cGUsIGluc3RhbmNlUHJvcHMpO1xufTtcblxuLypcbiAgVHJhbnNsYXRpb24gZW5naW5lOiBodHRwOi8vd3d3LnR1cmtpc2hkaWN0aW9uYXJ5Lm5ldFxuICBGb3IgdHJhbnNsYXRpbmcgdHVya2lzaC1ydXNzaWFuIGFuZCB2aWNlIHZlcnNhXG4qL1xudmFyIENIQVJfQ09ERVMgPSByZXF1aXJlKFwiLi9jaGFyLWNvZGVzLXR1cmsuanNcIik7XG5cbnZhciBUdXJraXNoRGljdGlvbmFyeSA9IChmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIFR1cmtpc2hEaWN0aW9uYXJ5KCkge1xuICAgIHRoaXMuaG9zdCA9IFwiaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXQvP3dvcmQ9JUZDXCI7XG4gICAgdGhpcy5wYXRoID0gXCJcIjtcbiAgICB0aGlzLnByb3RvY29sID0gXCJodHRwXCI7XG4gICAgdGhpcy5xdWVyeSA9IFwiJnM9XCI7XG4gICAgdGhpcy5UQUJMRV9DTEFTUyA9IFwiX19fbXR0X3RyYW5zbGF0ZV90YWJsZVwiO1xuICAgIC8vIHRoaXMgZmxhZyBpbmRpY2F0ZXMgdGhhdCBpZiB0cmFuc2xhdGlvbiB3YXMgc3VjY2Vzc2Z1bCB0aGVuIHB1Ymxpc2ggaXQgYWxsIG92ZXIgZXh0ZW5zaW9uXG4gICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSB0cnVlO1xuICB9XG5cbiAgX3Byb3RvdHlwZVByb3BlcnRpZXMoVHVya2lzaERpY3Rpb25hcnksIG51bGwsIHtcbiAgICBzZWFyY2g6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBzZWFyY2goZGF0YSkge1xuICAgICAgICBkYXRhLnVybCA9IHRoaXMubWFrZVVybChkYXRhLnZhbHVlKTtcbiAgICAgICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSBmYWxzZTtcbiAgICAgICAgcmV0dXJuIHRoaXMucmVxdWVzdChkYXRhKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHRyYW5zbGF0ZToge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHRyYW5zbGF0ZShkYXRhKSB7XG4gICAgICAgIGRhdGEudXJsID0gdGhpcy5tYWtlVXJsKGRhdGEuc2VsZWN0aW9uVGV4dCk7XG4gICAgICAgIHRoaXMubmVlZF9wdWJsaXNoID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5yZXF1ZXN0KGRhdGEpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgbWFrZVVybDoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIG1ha2VVcmwodGV4dCkge1xuICAgICAgICB2YXIgdGV4dCA9IHRoaXMuZ2V0RW5jb2RlZFZhbHVlKHRleHQpO1xuICAgICAgICByZXR1cm4gW1wiaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXQvP3dvcmQ9XCIsIHRleHRdLmpvaW4oXCJcIik7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBnZXRFbmNvZGVkVmFsdWU6IHtcblxuXG4gICAgICAvLyBSZXBsYWNlIHNwZWNpYWwgbGFuZ3VhZ2UgY2hhcmFjdGVycyB0byBodG1sIGNvZGVzXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gZ2V0RW5jb2RlZFZhbHVlKHZhbHVlKSB7XG4gICAgICAgIC8vIHRvIGZpbmQgc3BlYyBzeW1ib2xzIHdlIGZpcnN0IGVuY29kZSB0aGVtIChyYXcgc2VhcmNoIGZvciB0aGF0IHN5bWJvbCBkb2Vzbid0IHdvcilcbiAgICAgICAgcmV0dXJuIGVuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSk7XG4gICAgICAgIC8vcmV0dXJuIHRoaXMubWFrZVN0cmluZ1RyYW5zZmVyYWJsZSh2YWx1ZSk7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBtYWtlU3RyaW5nVHJhbnNmZXJhYmxlOiB7XG5cbiAgICAgIC8qKiBjb252ZXJ0aW5nIHNjcmlwdCBmcm9tIHRoZSB0dXJraXNoZGljdCAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIG1ha2VTdHJpbmdUcmFuc2ZlcmFibGUoaW5wdXRUZXh0KSB7XG4gICAgICAgIHZhciB0ZXh0ID0gXCJcIjtcbiAgICAgICAgaWYgKGlucHV0VGV4dC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgdGV4dCA9IGlucHV0VGV4dDtcbiAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRleHQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChDSEFSX0NPREVTW3RleHQuY2hhckNvZGVBdChpKV0pIHtcbiAgICAgICAgICAgICAgdGV4dCA9IHRleHQuc3Vic3RyaW5nKDAsIGkpICsgQ0hBUl9DT0RFU1t0ZXh0LmNoYXJDb2RlQXQoaSldICsgdGV4dC5zdWJzdHJpbmcoaSArIDEsIHRleHQubGVuZ3RoKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodGV4dC5jaGFyQXQoaSkgPT0gXCIgXCIpIHtcbiAgICAgICAgICAgICAgLy8gcmVwbGFjZSBzcGFjZXNcbiAgICAgICAgICAgICAgdGV4dCA9IHRleHQuc3Vic3RyaW5nKDAsIGkpICsgXCJfX19cIiArIHRleHQuc3Vic3RyaW5nKGkgKyAxLCB0ZXh0Lmxlbmd0aCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0ZXh0O1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcmVxdWVzdDoge1xuXG4gICAgICAvKlxuICAgICAgICBSZXF1ZXN0IHRyYW5zbGF0aW9uIGFuZCBydW4gY2FsbGJhY2sgZnVuY3Rpb25cbiAgICAgICAgcGFzc2luZyB0cmFuc2xhdGVkIHJlc3VsdCBvciBlcnJvciB0byBjYWxsYmFja1xuICAgICAgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiByZXF1ZXN0KG9wdHMpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJzdGFydCByZXF1ZXN0XCIpO1xuICAgICAgICB0aGlzLnhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgICB0aGlzLnhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSB0aGlzLm9uUmVhZHlTdGF0ZUNoYW5nZS5iaW5kKHRoaXMsIG9wdHMpO1xuICAgICAgICB0aGlzLnhoci5vcGVuKFwiR0VUXCIsIG9wdHMudXJsLCB0cnVlKTtcbiAgICAgICAgdGhpcy54aHIuc2VuZCgpO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgb25SZWFkeVN0YXRlQ2hhbmdlOiB7XG4gICAgICB2YWx1ZTogZnVuY3Rpb24gb25SZWFkeVN0YXRlQ2hhbmdlKG9wdHMsIGUpIHtcbiAgICAgICAgdmFyIHhociA9IHRoaXMueGhyO1xuICAgICAgICBpZiAoeGhyLnJlYWR5U3RhdGUgPCA0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9IGVsc2UgaWYgKHhoci5zdGF0dXMgIT0gMjAwKSB7XG4gICAgICAgICAgdGhpcy5lcnJvckhhbmRsZXIoeGhyKTtcbiAgICAgICAgICByZXR1cm4gb3B0cy5lcnJvciAmJiBvcHRzLmVycm9yKCk7XG4gICAgICAgIH0gZWxzZSBpZiAoeGhyLnJlYWR5U3RhdGUgPT0gNCkge1xuICAgICAgICAgIHZhciB0cmFuc2xhdGlvbiA9IHRoaXMuc3VjY2Vzc0hhbmRsZXIoZS50YXJnZXQucmVzcG9uc2UpO1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwic3VjY2VzcyB0dXJraXNoIHRyYW5zbGF0ZVwiLCB0cmFuc2xhdGlvbik7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJjYWxsXCIsIG9wdHMuc3VjY2Vzcyk7XG4gICAgICAgICAgcmV0dXJuIG9wdHMuc3VjY2VzcyAmJiBvcHRzLnN1Y2Nlc3ModHJhbnNsYXRpb24pO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBzdWNjZXNzSGFuZGxlcjoge1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHN1Y2Nlc3NIYW5kbGVyKHJlc3BvbnNlKSB7XG4gICAgICAgIHZhciBkYXRhID0gdGhpcy5wYXJzZShyZXNwb25zZSk7XG4gICAgICAgIGlmICh0aGlzLm5lZWRfcHVibGlzaCkge1xuICAgICAgICAgIGNocm9tZS50YWJzLmdldFNlbGVjdGVkKG51bGwsIHRoaXMucHVibGlzaFRyYW5zbGF0aW9uLmJpbmQodGhpcywgZGF0YSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcHVibGlzaFRyYW5zbGF0aW9uOiB7XG5cbiAgICAgIC8qIHB1Ymxpc2ggc3VjY2Vzc2Z1bHkgdHJhbnNsYXRlZCB0ZXh0IGFsbCBvdmVyIGV4dGVuc2lvbiAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHB1Ymxpc2hUcmFuc2xhdGlvbih0cmFuc2xhdGlvbiwgdGFiKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwicHVibGlzaCB0cmFuc2xhdGlvblwiKTtcbiAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgYWN0aW9uOiB0aGlzLnRvb2x0aXBBY3Rpb24odHJhbnNsYXRpb24pLFxuICAgICAgICAgIGRhdGE6IHRyYW5zbGF0aW9uLm91dGVySFRNTCxcbiAgICAgICAgICBzdWNjZXNzOiAhdHJhbnNsYXRpb24uY2xhc3NMaXN0LmNvbnRhaW5zKFwiZmFpbFRyYW5zbGF0ZVwiKVxuICAgICAgICB9KTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHRvb2x0aXBBY3Rpb246IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiB0b29sdGlwQWN0aW9uKHRyYW5zbGF0aW9uKSB7XG4gICAgICAgIGlmICh0cmFuc2xhdGlvbi50ZXh0Q29udGVudC50cmltKCkuaW5kZXhPZihcIndhcyBub3QgZm91bmQgaW4gb3VyIGRpY3Rpb25hcnlcIikgIT0gLTEpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhcInNpbWlsYXIgd29yZHNcIik7XG4gICAgICAgICAgcmV0dXJuIFwic2ltaWxhcl93b3Jkc1wiO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwib3BlbiB0b29sdGlwXCIpO1xuICAgICAgICAgIHJldHVybiBcIm9wZW5fdG9vbHRpcFwiO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBlcnJvckhhbmRsZXI6IHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBlcnJvckhhbmRsZXIocmVzcG9uc2UpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJlcnJvciBhamF4XCIsIHJlc3BvbnNlKTtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIHBhcnNlOiB7XG5cbiAgICAgIC8qIFBhcnNlIHJlc3BvbnNlIGZyb20gdHJhbnNsYXRpb24gZW5naW5lICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gcGFyc2UocmVzcG9uc2UsIHNpbGVudCwgdHJhbnNsYXRlKSB7XG4gICAgICAgIHZhciBkb2MgPSB0aGlzLnN0cmlwU2NyaXB0cyhyZXNwb25zZSksXG4gICAgICAgICAgICBmcmFnbWVudCA9IHRoaXMubWFrZUZyYWdtZW50KGRvYyk7XG4gICAgICAgIGlmIChmcmFnbWVudCkge1xuICAgICAgICAgIHRyYW5zbGF0ZSA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjbWVhbmluZ19kaXYgPiB0YWJsZVwiKTtcbiAgICAgICAgICBpZiAodHJhbnNsYXRlKSB7XG4gICAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gdGhpcy5UQUJMRV9DTEFTUztcbiAgICAgICAgICAgIHRyYW5zbGF0ZS5zZXRBdHRyaWJ1dGUoXCJjZWxscGFkZGluZ1wiLCBcIjVcIik7XG4gICAgICAgICAgICAvLyBAZml4SW1hZ2VzKHRyYW5zbGF0ZSlcbiAgICAgICAgICAgIC8vIEBmaXhMaW5rcyh0cmFuc2xhdGUpXG4gICAgICAgICAgfSBlbHNlIGlmICghc2lsZW50KSB7XG4gICAgICAgICAgICB0cmFuc2xhdGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICAgICAgdHJhbnNsYXRlLmNsYXNzTmFtZSA9IFwiZmFpbFRyYW5zbGF0ZVwiO1xuICAgICAgICAgICAgdHJhbnNsYXRlLmlubmVyVGV4dCA9IFwiVW5mb3J0dW5hdGVseSwgY291bGQgbm90IHRyYW5zbGF0ZVwiO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJhbnNsYXRlO1xuICAgICAgfSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0sXG4gICAgcGFyc2VUZXh0OiB7XG5cbiAgICAgIC8qKiBwYXJzaW5nIG9mIHRlcnJpYmxlIGh0bWwgbWFya3VwICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gcGFyc2VUZXh0KHJlc3BvbnNlLCBzaWxlbnQsIHRyYW5zbGF0ZSkge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICB2YXIgZG9jID0gdGhpcy5zdHJpcFNjcmlwdHMocmVzcG9uc2UpLFxuICAgICAgICAgICAgZnJhZ21lbnQgPSB0aGlzLm1ha2VGcmFnbWVudChkb2MpO1xuXG4gICAgICAgIGlmIChmcmFnbWVudCkge1xuICAgICAgICAgIHZhciBpO1xuICAgICAgICAgIHZhciBfcmV0ID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBzdG9wSW5kZXggPSBudWxsO1xuICAgICAgICAgICAgdmFyIHRyID0gZnJhZ21lbnQucXVlcnlTZWxlY3RvckFsbChcIiNtZWFuaW5nX2Rpdj50YWJsZT50Ym9keT50clwiKTtcbiAgICAgICAgICAgIHRyID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwodHIpO1xuXG4gICAgICAgICAgICB2YXIgdHJhbnMgPSB0ci5maWx0ZXIoZnVuY3Rpb24gKHRyLCBpbmRleCkge1xuICAgICAgICAgICAgICBpZiAoIWlzTmFOKHBhcnNlSW50KHN0b3BJbmRleCwgMTApKSAmJiBpbmRleCA+PSBzdG9wSW5kZXgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdHIgPSAkKHRyKTtcbiAgICAgICAgICAgICAgICAvLyB0YWtlIGV2ZXJ5IHJvdyBiZWZvcmUgbmV4dCBzZWN0aW9uICh3aGljaCBpcyBFbmdsaXNoLT5FbmdsaXNoKVxuICAgICAgICAgICAgICAgIGlmICh0ci5hdHRyKFwiYmdjb2xvclwiKSA9PSBcImUwZTZmZlwiKSB7XG4gICAgICAgICAgICAgICAgICBzdG9wSW5kZXggPSBpbmRleDtyZXR1cm47XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiAkLnRyaW0odHIuZmluZChcInRkXCIpLnRleHQoKSkubGVuZ3RoO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0cmFucyA9IHRyYW5zLnNsaWNlKDEsIHRyYW5zLmxlbmd0aCAtIDEpO1xuICAgICAgICAgICAgdHJhbnMgPSB0cmFucy5maWx0ZXIoZnVuY3Rpb24gKGVsLCBpbmR4KSB7XG4gICAgICAgICAgICAgIHJldHVybiBpbmR4ICUgMjtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdmFyIGZyYWcgPSBfdGhpcy5mcmFnbWVudEZyb21MaXN0KHRyYW5zKTtcbiAgICAgICAgICAgIHZhciBmb250cyA9IGZyYWcucXVlcnlTZWxlY3RvckFsbChcImZvbnRcIik7XG4gICAgICAgICAgICB2YXIgdGV4dCA9IFwiXCI7XG4gICAgICAgICAgICBmb3IgKGkgPSAwOyBpIDwgZm9udHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgdGV4dCArPSBcIiBcIiArIGZvbnRzW2ldLnRleHRDb250ZW50LnRyaW0oKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIHY6IHRleHRcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSkoKTtcblxuICAgICAgICAgIGlmICh0eXBlb2YgX3JldCA9PT0gXCJvYmplY3RcIikgcmV0dXJuIF9yZXQudjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyBcIkhUTUwgZnJhZ21lbnQgY291bGQgbm90IGJlIHBhcnNlZFwiO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBzdHJpcFNjcmlwdHM6IHtcblxuICAgICAgLy9UT0RPIGV4dHJhY3QgdG8gYmFzZSBlbmdpbmUgY2xhc3NcbiAgICAgIC8qIHJlbW92ZXMgPHNjcmlwdD4gdGFncyBmcm9tIGh0bWwgY29kZSAqL1xuICAgICAgdmFsdWU6IGZ1bmN0aW9uIHN0cmlwU2NyaXB0cyhodG1sKSB7XG4gICAgICAgIHZhciBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcbiAgICAgICAgdmFyIHNjcmlwdHMgPSBkaXYuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJzY3JpcHRcIik7XG4gICAgICAgIHZhciBpID0gc2NyaXB0cy5sZW5ndGg7XG4gICAgICAgIHdoaWxlIChpLS0pIHNjcmlwdHNbaV0ucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChzY3JpcHRzW2ldKTtcbiAgICAgICAgcmV0dXJuIGRpdi5pbm5lckhUTUw7XG4gICAgICB9LFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBtYWtlRnJhZ21lbnQ6IHtcblxuICAgICAgLy9UT0RPIGV4dHJhY3QgdG8gYmFzZSBlbmdpbmUgY2xhc3NcbiAgICAgIC8qIGNyZWF0ZXMgdGVtcCBvYmplY3QgdG8gcGFyc2UgdHJhbnNsYXRpb24gZnJvbSBwYWdlIFxuICAgICAgICAoc2luY2UgaXQncyBub3QgYSBmcmllbmRseSBhcGkpIFxuICAgICAgKi9cbiAgICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlRnJhZ21lbnQoaHRtbCkge1xuICAgICAgICB2YXIgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCksXG4gICAgICAgICAgICBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcbiAgICAgICAgd2hpbGUgKGRpdi5maXJzdENoaWxkKSB7XG4gICAgICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoZGl2LmZpcnN0Q2hpbGQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmcmFnbWVudDtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9LFxuICAgIGZyYWdtZW50RnJvbUxpc3Q6IHtcblxuICAgICAgLyoqIGNyZWF0ZSBmcmFnbWVudCBmcm9tIGxpc3Qgb2YgRE9NIGVsZW1lbnRzICovXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gZnJhZ21lbnRGcm9tTGlzdChsaXN0KSB7XG4gICAgICAgIHZhciBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKSxcbiAgICAgICAgICAgIGxlbiA9IGxpc3QubGVuZ3RoO1xuICAgICAgICB3aGlsZSAobGVuLS0pIHtcbiAgICAgICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZChsaXN0W2xlbl0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmcmFnbWVudDtcbiAgICAgIH0sXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9XG4gIH0pO1xuXG4gIHJldHVybiBUdXJraXNoRGljdGlvbmFyeTtcbn0pKCk7XG5cbi8vIFNpbmdsZXRvbmVcbm1vZHVsZS5leHBvcnRzID0gbmV3IFR1cmtpc2hEaWN0aW9uYXJ5KCk7Il19
