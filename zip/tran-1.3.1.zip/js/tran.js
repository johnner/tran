(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/
'use strict';

var CHAR_CODES = {
  //russian
  '%D1%8A': { val: '%FA', lang: 'ru' }, // ъ
  '%D0%AA': { val: '%DA', lang: 'ru' }, // Ъ

  '%C3%80': '&#192;', // À
  '%C3%81': '&#193;', // Á
  '%C3%82': '&#194;', // Â
  '%C3%83': '&#195;', // Ã
  '%C3%84': '&#196;', // Ä
  '%C3%85': '&#197;', // Å
  '%C3%86': '&#198;', // Æ

  '%C3%87': '&#199;', // Ç
  '%C3%88': '&#200;', // È
  '%C3%89': '&#201;', // É
  '%C3%8A': '&#202;', // Ê
  '%C3%8B': '&#203;', // Ë

  '%C3%8C': '&#204;', // Ì
  '%C3%8D': '&#205;', // Í
  '%C3%8E': '&#206;', // Î
  '%C3%8F': '&#207;', // Ï

  '%C3%91': '&#209;', // Ñ
  '%C3%92': '&#210;', // Ò
  '%C3%93': '&#211;', // Ó
  '%C3%94': '&#212;', // Ô
  '%C3%95': '&#213;', // Õ
  '%C3%96': '&#214;', // Ö

  '%C3%99': '&#217;', // Ù
  '%C3%9A': '&#218;', // Ú
  '%C3%9B': '&#219;', // Û
  '%C3%9C': '&#220;', // Ü

  '%C3%A0': '&#224;', // à
  '%C3%A1': '&#225;', // á
  '%C3%A2': '&#226;', // â
  '%C3%A3': '&#227;', // ã
  '%C3%A4': '&#228;', // ä
  '%C3%A5': '&#229;', // å
  '%C3%A6': '&#230;', // æ
  '%C3%A7': '&#231;', // ç

  '%C3%A8': '&#232;', // è
  '%C3%A9': '&#233;', // é
  '%C3%AA': '&#234;', // ê
  '%C3%AB': '&#235;', // ë

  '%C3%AC': '&#236;', // ì
  '%C3%AD': '&#237;', // í
  '%C3%AE': '&#238;', // î
  '%C3%AF': '&#239;', // ï

  '%C3%B0': '&#240;', // ð
  '%C3%B1': '&#241;', // ñ

  '%C3%B2': '&#242;', // ò
  '%C3%B3': '&#243;', // ó
  '%C3%B4': '&#244;', // ô
  '%C3%B5': '&#245;', // õ
  '%C3%B6': '&#246;', // ö

  '%C3%B9': '&#249;', // ù
  '%C3%BA': '&#250;', // ú
  '%C3%BB': '&#251;', // û
  '%C3%BC': '&#252;', // ü
  '%C3%BF': '&#255;', // ÿ
  '%C5%B8': '&#376;', // Ÿ

  '%C3%9F': '&#223;', // ß

  '%C2%BF': '&#191;', // ¿
  '%C2%A1': '&#161;' };

// ¡
module.exports = CHAR_CODES;
//# sourceMappingURL=char-codes.js.map

},{}],2:[function(require,module,exports){
/**
 Multitran translate engine
 Provides program interface for making translate queries to multitran and get clean response

 All engines must follow common interface and provide methods:
 - search (languange, successHandler)  clean translation must be passed into successHandler
 - click

 Translation-module that makes requests to language-engine,
 parses results and sends plugin-global message with translation data
 **/
// var iconv = require('iconv-lite');

'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var CHAR_CODES = require('./char-codes.js');

var Tran = (function () {
  function Tran() {
    _classCallCheck(this, Tran);

    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1'; // from russian to english by default
    this.xhr = {};
  }

  /**
   * Context menu click handler
   */

  _createClass(Tran, [{
    key: 'click',
    value: function click(data) {
      if (typeof data.silent === "undefined" || data.silent === null) {
        data.silent = true; // true by default
      }
      var selectionText = this.removeHyphenation(data.selectionText);
      this.search({
        value: selectionText,
        success: this.successtHandler.bind(this),
        silent: data.silent // if translation failed do not show dialog
      });
    }

    /**
     * Discard soft hyphen character (U+00AD, &shy;) from the input
     */
  }, {
    key: 'removeHyphenation',
    value: function removeHyphenation(text) {
      return text.replace(/\xad/g, '');
    }

    /**
     * Initiate translation search
     */
  }, {
    key: 'search',
    value: function search(params) {
      var _this = this;

      //value, callback, err
      chrome.storage.sync.get({ language: '1' }, function (items) {
        if (items.language === '') {
          items.language = '1';
        }
        _this.setLanguage(items.language);
        var url = _this.makeUrl(params.value);
        // decorate success to make preliminary parsing
        var origSuccess = params.success;
        params.success = function (response) {
          var translated = _this.parse(response, params.silent);
          origSuccess.call(_this, translated);
        };
        console.log('params.success=', params.success);
        _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      });
    }

    //Parse response from translation engine
  }, {
    key: 'parse',
    value: function parse(response, silent, translate) {
      translate = translate || null;
      var doc = this.stripScripts(response);
      var fragment = this.makeFragment(doc);
      if (fragment) {
        translate = fragment.querySelector('#translation ~ table');
        if (translate) {
          translate.className = this.TABLE_CLASS;
          translate.setAttribute("cellpadding", "5");
          this.fixImages(translate);
          this.fixLinks(translate);
        } else if (!silent) {
          translate = document.createElement('div');
          translate.className = 'failTranslate';
          translate.innerText = "Unfortunately, could not translate";
        }
      }
      return translate;
    }
  }, {
    key: 'setLanguage',
    value: function setLanguage(language) {
      this.currentLanguage = language;
      this.lang = '?l1=2&l2=' + language;
    }

    /**
     * Request translation and run callback function
     * passing translated result or error to callback
     * @param opts
     */
  }, {
    key: 'request',
    value: function request(opts) {
      var _this2 = this;

      var xhr = this.xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function (e) {
        xhr = _this2.xhr;
        if (xhr.readyState < 4) {
          return;
        } else if (xhr.status !== 200) {
          _this2.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error.call(_this2);
          }
          return;
        } else if (xhr.readyState == 4) {
          return opts.success(e.target.response);
        }
        return xhr;
      };
      xhr.overrideMimeType("text/html;charset=cp1251");
      xhr.open("GET", opts.url, true);

      xhr.send();
    }
  }, {
    key: 'makeUrl',
    value: function makeUrl(value) {
      return this.protocol + '://' + this.host + this.path + this.lang + this.query + this.getEncodedValue(value);
    }

    // Replace special language characters to html codes
  }, {
    key: 'getEncodedValue',
    value: function getEncodedValue(value) {
      //to find spec symbols we first encode them (raw search for that symbol doesn't work)
      var val = encodeURIComponent(value);
      var code = undefined,
          cc = undefined;
      for (var char in CHAR_CODES) {
        if (CHAR_CODES.hasOwnProperty(char)) {
          code = CHAR_CODES[char];
          if (typeof code === 'object') {
            // russian has special codes
            cc = code.val;
          } else {
            //for all langs except russian encode html-codes needed
            cc = encodeURIComponent(code);
          }
          val = val.replace(char, cc);
        }
      }
      return val;
    }
  }, {
    key: 'errorHandler',
    value: function errorHandler(xhr) {
      console.log('xhr error:', xhr);
    }

    //Receiving data from translation-engine and send ready message with data
  }, {
    key: 'successtHandler',
    value: function successtHandler(translated) {
      var _this3 = this;

      if (translated) {
        chrome.tabs.getSelected(null, function (tab) {
          chrome.tabs.sendMessage(tab.id, {
            action: _this3.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        });
      }
    }
  }, {
    key: 'messageType',
    value: function messageType(translated) {
      if (translated && translated.rows && translated.rows.length === 1) {
        return 'similar_words';
      } else {
        return 'open_tooltip';
      }
    }

    //  Strip script tags from response html
  }, {
    key: 'stripScripts',
    value: function stripScripts(res) {
      var div = document.createElement('div');
      div.innerHTML = res;
      var scripts = div.getElementsByTagName('script');
      var i = scripts.length;
      while (i--) {
        scripts[i].parentNode.removeChild(scripts[i]);
      }
      return div.innerHTML;
    }
  }, {
    key: 'makeFragment',
    value: function makeFragment(doc, fragment) {
      fragment = fragment || null;
      var div = document.createElement("div");
      div.innerHTML = doc;
      fragment = document.createDocumentFragment();
      while (div.firstChild) {
        fragment.appendChild(div.firstChild);
      }
      return fragment;
    }
  }, {
    key: 'fixImages',
    value: function fixImages(fragment) {
      fragment = fragment || null;
      this.fixUrl(fragment, 'img', 'src');
      return fragment;
    }
  }, {
    key: 'fixLinks',
    value: function fixLinks() {
      var fragment = arguments.length <= 0 || arguments[0] === undefined ? null : arguments[0];

      this.fixUrl(fragment, 'a', 'href');
      return fragment;
    }
  }, {
    key: 'fixUrl',
    value: function fixUrl(fragment, tag, attr) {
      if (fragment === undefined) fragment = null;

      var _this4 = this;

      var elements = {};
      if (fragment) {
        elements = fragment.querySelectorAll(tag);
      }
      var parser = document.createElement('a');
      elements.forEach(function (el) {
        parser.href = el[attr];
        parser.host = _this4.host;
        parser.protocol = _this4.protocol;
        // fix relative links
        if (tag == 'a') {
          el.classList.add('mtt_link');
          if (parser.pathname.indexOf('m.exe') !== -1) {
            parser.pathname = '/c' + parser.pathname;
            el.setAttribute('target', '_blank');
            el.setAttribute(attr, parser.href);
          }
        } else if (tag == 'img') {
          var url = _this4.getUrl(el.src);
          el.classList.add('mtt_img');
          el.src = _this4.protocol + '://' + _this4.host + '/' + url.pathname;
        }
      });
    }

    // todo: move to utils
  }, {
    key: 'getUrl',
    value: function getUrl(url) {
      var a = document.createElement('a');
      a.href = url;
      return a;
    }
  }]);

  return Tran;
})();

module.exports = new Tran();
//# sourceMappingURL=tran.js.map

},{"./char-codes.js":1}]},{},[2])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxkZXZcXHRyYW5cXG5vZGVfbW9kdWxlc1xcYnJvd3Nlci1wYWNrXFxfcHJlbHVkZS5qcyIsIkM6L2Rldi90cmFuL2pzL2VzNS9jaGFyLWNvZGVzLmpzIiwiQzovZGV2L3RyYW4vanMvZXM1L3RyYW4uanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2xGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKX12YXIgZj1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwoZi5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxmLGYuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiLypcciAgTXVsdGl0cmFuIGRlcGVuZHMgb24gaHRtbC1lc2NhcGluZyAobm90IFVURi04KSBydWxlcyBmb3Igc3BlY2lhbCBzeW1ib2xzXHIgIMOgLCDDqCwgw6wsIMOyLCDDuSAtIMOALCDDiCwgw4wsIMOSLCDDmVxyICDDoSwgw6ksIMOtLCDDsywgw7osIMO9IC0gw4EsIMOJLCDDjSwgw5MsIMOaLCDDnVxyICDDoiwgw6osIMOuLCDDtCwgw7sgw4IsIMOKLCDDjiwgw5QsIMObXHIgIMOjLCDDsSwgw7Ugw4MsIMORLCDDlVxyICDDpCwgw6ssIMOvLCDDtiwgw7wsIMO/IMOELCDDiywgw48sIMOWLCDDnCxcciAgw6UsIMOFXHIgIMOmLCDDhlxyICDDpywgw4dcciAgw7AsIMOQXHIgIMO4LCDDmFxyICDCvyDCoSDDn1xyKi9cbid1c2Ugc3RyaWN0JztcblxudmFyIENIQVJfQ09ERVMgPSB7XG4gIC8vcnVzc2lhblxuICAnJUQxJThBJzogeyB2YWw6ICclRkEnLCBsYW5nOiAncnUnIH0sIC8vINGKXG4gICclRDAlQUEnOiB7IHZhbDogJyVEQScsIGxhbmc6ICdydScgfSwgLy8g0KpcblxuICAnJUMzJTgwJzogJyYjMTkyOycsIC8vIMOAXG4gICclQzMlODEnOiAnJiMxOTM7JywgLy8gw4FcbiAgJyVDMyU4Mic6ICcmIzE5NDsnLCAvLyDDglxuICAnJUMzJTgzJzogJyYjMTk1OycsIC8vIMODXG4gICclQzMlODQnOiAnJiMxOTY7JywgLy8gw4RcbiAgJyVDMyU4NSc6ICcmIzE5NzsnLCAvLyDDhVxuICAnJUMzJTg2JzogJyYjMTk4OycsIC8vIMOGXG5cbiAgJyVDMyU4Nyc6ICcmIzE5OTsnLCAvLyDDh1xuICAnJUMzJTg4JzogJyYjMjAwOycsIC8vIMOIXG4gICclQzMlODknOiAnJiMyMDE7JywgLy8gw4lcbiAgJyVDMyU4QSc6ICcmIzIwMjsnLCAvLyDDilxuICAnJUMzJThCJzogJyYjMjAzOycsIC8vIMOLXG5cbiAgJyVDMyU4Qyc6ICcmIzIwNDsnLCAvLyDDjFxuICAnJUMzJThEJzogJyYjMjA1OycsIC8vIMONXG4gICclQzMlOEUnOiAnJiMyMDY7JywgLy8gw45cbiAgJyVDMyU4Ric6ICcmIzIwNzsnLCAvLyDDj1xuXG4gICclQzMlOTEnOiAnJiMyMDk7JywgLy8gw5FcbiAgJyVDMyU5Mic6ICcmIzIxMDsnLCAvLyDDklxuICAnJUMzJTkzJzogJyYjMjExOycsIC8vIMOTXG4gICclQzMlOTQnOiAnJiMyMTI7JywgLy8gw5RcbiAgJyVDMyU5NSc6ICcmIzIxMzsnLCAvLyDDlVxuICAnJUMzJTk2JzogJyYjMjE0OycsIC8vIMOWXG5cbiAgJyVDMyU5OSc6ICcmIzIxNzsnLCAvLyDDmVxuICAnJUMzJTlBJzogJyYjMjE4OycsIC8vIMOaXG4gICclQzMlOUInOiAnJiMyMTk7JywgLy8gw5tcbiAgJyVDMyU5Qyc6ICcmIzIyMDsnLCAvLyDDnFxuXG4gICclQzMlQTAnOiAnJiMyMjQ7JywgLy8gw6BcbiAgJyVDMyVBMSc6ICcmIzIyNTsnLCAvLyDDoVxuICAnJUMzJUEyJzogJyYjMjI2OycsIC8vIMOiXG4gICclQzMlQTMnOiAnJiMyMjc7JywgLy8gw6NcbiAgJyVDMyVBNCc6ICcmIzIyODsnLCAvLyDDpFxuICAnJUMzJUE1JzogJyYjMjI5OycsIC8vIMOlXG4gICclQzMlQTYnOiAnJiMyMzA7JywgLy8gw6ZcbiAgJyVDMyVBNyc6ICcmIzIzMTsnLCAvLyDDp1xuXG4gICclQzMlQTgnOiAnJiMyMzI7JywgLy8gw6hcbiAgJyVDMyVBOSc6ICcmIzIzMzsnLCAvLyDDqVxuICAnJUMzJUFBJzogJyYjMjM0OycsIC8vIMOqXG4gICclQzMlQUInOiAnJiMyMzU7JywgLy8gw6tcblxuICAnJUMzJUFDJzogJyYjMjM2OycsIC8vIMOsXG4gICclQzMlQUQnOiAnJiMyMzc7JywgLy8gw61cbiAgJyVDMyVBRSc6ICcmIzIzODsnLCAvLyDDrlxuICAnJUMzJUFGJzogJyYjMjM5OycsIC8vIMOvXG5cbiAgJyVDMyVCMCc6ICcmIzI0MDsnLCAvLyDDsFxuICAnJUMzJUIxJzogJyYjMjQxOycsIC8vIMOxXG5cbiAgJyVDMyVCMic6ICcmIzI0MjsnLCAvLyDDslxuICAnJUMzJUIzJzogJyYjMjQzOycsIC8vIMOzXG4gICclQzMlQjQnOiAnJiMyNDQ7JywgLy8gw7RcbiAgJyVDMyVCNSc6ICcmIzI0NTsnLCAvLyDDtVxuICAnJUMzJUI2JzogJyYjMjQ2OycsIC8vIMO2XG5cbiAgJyVDMyVCOSc6ICcmIzI0OTsnLCAvLyDDuVxuICAnJUMzJUJBJzogJyYjMjUwOycsIC8vIMO6XG4gICclQzMlQkInOiAnJiMyNTE7JywgLy8gw7tcbiAgJyVDMyVCQyc6ICcmIzI1MjsnLCAvLyDDvFxuICAnJUMzJUJGJzogJyYjMjU1OycsIC8vIMO/XG4gICclQzUlQjgnOiAnJiMzNzY7JywgLy8gxbhcblxuICAnJUMzJTlGJzogJyYjMjIzOycsIC8vIMOfXG5cbiAgJyVDMiVCRic6ICcmIzE5MTsnLCAvLyDCv1xuICAnJUMyJUExJzogJyYjMTYxOycgfTtcblxuLy8gwqFcbm1vZHVsZS5leHBvcnRzID0gQ0hBUl9DT0RFUztcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNoYXItY29kZXMuanMubWFwXG4iLCIvKipcbiBNdWx0aXRyYW4gdHJhbnNsYXRlIGVuZ2luZVxuIFByb3ZpZGVzIHByb2dyYW0gaW50ZXJmYWNlIGZvciBtYWtpbmcgdHJhbnNsYXRlIHF1ZXJpZXMgdG8gbXVsdGl0cmFuIGFuZCBnZXQgY2xlYW4gcmVzcG9uc2VcblxuIEFsbCBlbmdpbmVzIG11c3QgZm9sbG93IGNvbW1vbiBpbnRlcmZhY2UgYW5kIHByb3ZpZGUgbWV0aG9kczpcbiAtIHNlYXJjaCAobGFuZ3VhbmdlLCBzdWNjZXNzSGFuZGxlcikgIGNsZWFuIHRyYW5zbGF0aW9uIG11c3QgYmUgcGFzc2VkIGludG8gc3VjY2Vzc0hhbmRsZXJcbiAtIGNsaWNrXG5cbiBUcmFuc2xhdGlvbi1tb2R1bGUgdGhhdCBtYWtlcyByZXF1ZXN0cyB0byBsYW5ndWFnZS1lbmdpbmUsXG4gcGFyc2VzIHJlc3VsdHMgYW5kIHNlbmRzIHBsdWdpbi1nbG9iYWwgbWVzc2FnZSB3aXRoIHRyYW5zbGF0aW9uIGRhdGFcbiAqKi9cbi8vIHZhciBpY29udiA9IHJlcXVpcmUoJ2ljb252LWxpdGUnKTtcblxuJ3VzZSBzdHJpY3QnO1xuXG52YXIgX2NyZWF0ZUNsYXNzID0gKGZ1bmN0aW9uICgpIHsgZnVuY3Rpb24gZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIHByb3BzKSB7IGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpKyspIHsgdmFyIGRlc2NyaXB0b3IgPSBwcm9wc1tpXTsgZGVzY3JpcHRvci5lbnVtZXJhYmxlID0gZGVzY3JpcHRvci5lbnVtZXJhYmxlIHx8IGZhbHNlOyBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSA9IHRydWU7IGlmICgndmFsdWUnIGluIGRlc2NyaXB0b3IpIGRlc2NyaXB0b3Iud3JpdGFibGUgPSB0cnVlOyBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBkZXNjcmlwdG9yLmtleSwgZGVzY3JpcHRvcik7IH0gfSByZXR1cm4gZnVuY3Rpb24gKENvbnN0cnVjdG9yLCBwcm90b1Byb3BzLCBzdGF0aWNQcm9wcykgeyBpZiAocHJvdG9Qcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvci5wcm90b3R5cGUsIHByb3RvUHJvcHMpOyBpZiAoc3RhdGljUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IsIHN0YXRpY1Byb3BzKTsgcmV0dXJuIENvbnN0cnVjdG9yOyB9OyB9KSgpO1xuXG5mdW5jdGlvbiBfY2xhc3NDYWxsQ2hlY2soaW5zdGFuY2UsIENvbnN0cnVjdG9yKSB7IGlmICghKGluc3RhbmNlIGluc3RhbmNlb2YgQ29uc3RydWN0b3IpKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoJ0Nhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvbicpOyB9IH1cblxudmFyIENIQVJfQ09ERVMgPSByZXF1aXJlKCcuL2NoYXItY29kZXMuanMnKTtcblxudmFyIFRyYW4gPSAoZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBUcmFuKCkge1xuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBUcmFuKTtcblxuICAgIHRoaXMuVEFCTEVfQ0xBU1MgPSBcIl9fX210dF90cmFuc2xhdGVfdGFibGVcIjtcbiAgICB0aGlzLnByb3RvY29sID0gJ2h0dHAnO1xuICAgIHRoaXMuaG9zdCA9ICd3d3cubXVsdGl0cmFuLnJ1JztcbiAgICB0aGlzLnBhdGggPSAnL2MvbS5leGUnO1xuICAgIHRoaXMucXVlcnkgPSAnJnM9JztcbiAgICB0aGlzLmxhbmcgPSAnP2wxPTImbDI9MSc7IC8vIGZyb20gcnVzc2lhbiB0byBlbmdsaXNoIGJ5IGRlZmF1bHRcbiAgICB0aGlzLnhociA9IHt9O1xuICB9XG5cbiAgLyoqXG4gICAqIENvbnRleHQgbWVudSBjbGljayBoYW5kbGVyXG4gICAqL1xuXG4gIF9jcmVhdGVDbGFzcyhUcmFuLCBbe1xuICAgIGtleTogJ2NsaWNrJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gY2xpY2soZGF0YSkge1xuICAgICAgaWYgKHR5cGVvZiBkYXRhLnNpbGVudCA9PT0gXCJ1bmRlZmluZWRcIiB8fCBkYXRhLnNpbGVudCA9PT0gbnVsbCkge1xuICAgICAgICBkYXRhLnNpbGVudCA9IHRydWU7IC8vIHRydWUgYnkgZGVmYXVsdFxuICAgICAgfVxuICAgICAgdmFyIHNlbGVjdGlvblRleHQgPSB0aGlzLnJlbW92ZUh5cGhlbmF0aW9uKGRhdGEuc2VsZWN0aW9uVGV4dCk7XG4gICAgICB0aGlzLnNlYXJjaCh7XG4gICAgICAgIHZhbHVlOiBzZWxlY3Rpb25UZXh0LFxuICAgICAgICBzdWNjZXNzOiB0aGlzLnN1Y2Nlc3N0SGFuZGxlci5iaW5kKHRoaXMpLFxuICAgICAgICBzaWxlbnQ6IGRhdGEuc2lsZW50IC8vIGlmIHRyYW5zbGF0aW9uIGZhaWxlZCBkbyBub3Qgc2hvdyBkaWFsb2dcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIERpc2NhcmQgc29mdCBoeXBoZW4gY2hhcmFjdGVyIChVKzAwQUQsICZzaHk7KSBmcm9tIHRoZSBpbnB1dFxuICAgICAqL1xuICB9LCB7XG4gICAga2V5OiAncmVtb3ZlSHlwaGVuYXRpb24nLFxuICAgIHZhbHVlOiBmdW5jdGlvbiByZW1vdmVIeXBoZW5hdGlvbih0ZXh0KSB7XG4gICAgICByZXR1cm4gdGV4dC5yZXBsYWNlKC9cXHhhZC9nLCAnJyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSW5pdGlhdGUgdHJhbnNsYXRpb24gc2VhcmNoXG4gICAgICovXG4gIH0sIHtcbiAgICBrZXk6ICdzZWFyY2gnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzZWFyY2gocGFyYW1zKSB7XG4gICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgICAvL3ZhbHVlLCBjYWxsYmFjaywgZXJyXG4gICAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7IGxhbmd1YWdlOiAnMScgfSwgZnVuY3Rpb24gKGl0ZW1zKSB7XG4gICAgICAgIGlmIChpdGVtcy5sYW5ndWFnZSA9PT0gJycpIHtcbiAgICAgICAgICBpdGVtcy5sYW5ndWFnZSA9ICcxJztcbiAgICAgICAgfVxuICAgICAgICBfdGhpcy5zZXRMYW5ndWFnZShpdGVtcy5sYW5ndWFnZSk7XG4gICAgICAgIHZhciB1cmwgPSBfdGhpcy5tYWtlVXJsKHBhcmFtcy52YWx1ZSk7XG4gICAgICAgIC8vIGRlY29yYXRlIHN1Y2Nlc3MgdG8gbWFrZSBwcmVsaW1pbmFyeSBwYXJzaW5nXG4gICAgICAgIHZhciBvcmlnU3VjY2VzcyA9IHBhcmFtcy5zdWNjZXNzO1xuICAgICAgICBwYXJhbXMuc3VjY2VzcyA9IGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgICAgIHZhciB0cmFuc2xhdGVkID0gX3RoaXMucGFyc2UocmVzcG9uc2UsIHBhcmFtcy5zaWxlbnQpO1xuICAgICAgICAgIG9yaWdTdWNjZXNzLmNhbGwoX3RoaXMsIHRyYW5zbGF0ZWQpO1xuICAgICAgICB9O1xuICAgICAgICBjb25zb2xlLmxvZygncGFyYW1zLnN1Y2Nlc3M9JywgcGFyYW1zLnN1Y2Nlc3MpO1xuICAgICAgICBfdGhpcy5yZXF1ZXN0KHtcbiAgICAgICAgICB1cmw6IHVybCxcbiAgICAgICAgICBzdWNjZXNzOiBwYXJhbXMuc3VjY2VzcyxcbiAgICAgICAgICBlcnJvcjogcGFyYW1zLmVycm9yXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy9QYXJzZSByZXNwb25zZSBmcm9tIHRyYW5zbGF0aW9uIGVuZ2luZVxuICB9LCB7XG4gICAga2V5OiAncGFyc2UnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBwYXJzZShyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUpIHtcbiAgICAgIHRyYW5zbGF0ZSA9IHRyYW5zbGF0ZSB8fCBudWxsO1xuICAgICAgdmFyIGRvYyA9IHRoaXMuc3RyaXBTY3JpcHRzKHJlc3BvbnNlKTtcbiAgICAgIHZhciBmcmFnbWVudCA9IHRoaXMubWFrZUZyYWdtZW50KGRvYyk7XG4gICAgICBpZiAoZnJhZ21lbnQpIHtcbiAgICAgICAgdHJhbnNsYXRlID0gZnJhZ21lbnQucXVlcnlTZWxlY3RvcignI3RyYW5zbGF0aW9uIH4gdGFibGUnKTtcbiAgICAgICAgaWYgKHRyYW5zbGF0ZSkge1xuICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSB0aGlzLlRBQkxFX0NMQVNTO1xuICAgICAgICAgIHRyYW5zbGF0ZS5zZXRBdHRyaWJ1dGUoXCJjZWxscGFkZGluZ1wiLCBcIjVcIik7XG4gICAgICAgICAgdGhpcy5maXhJbWFnZXModHJhbnNsYXRlKTtcbiAgICAgICAgICB0aGlzLmZpeExpbmtzKHRyYW5zbGF0ZSk7XG4gICAgICAgIH0gZWxzZSBpZiAoIXNpbGVudCkge1xuICAgICAgICAgIHRyYW5zbGF0ZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSAnZmFpbFRyYW5zbGF0ZSc7XG4gICAgICAgICAgdHJhbnNsYXRlLmlubmVyVGV4dCA9IFwiVW5mb3J0dW5hdGVseSwgY291bGQgbm90IHRyYW5zbGF0ZVwiO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJhbnNsYXRlO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3NldExhbmd1YWdlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc2V0TGFuZ3VhZ2UobGFuZ3VhZ2UpIHtcbiAgICAgIHRoaXMuY3VycmVudExhbmd1YWdlID0gbGFuZ3VhZ2U7XG4gICAgICB0aGlzLmxhbmcgPSAnP2wxPTImbDI9JyArIGxhbmd1YWdlO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJlcXVlc3QgdHJhbnNsYXRpb24gYW5kIHJ1biBjYWxsYmFjayBmdW5jdGlvblxuICAgICAqIHBhc3NpbmcgdHJhbnNsYXRlZCByZXN1bHQgb3IgZXJyb3IgdG8gY2FsbGJhY2tcbiAgICAgKiBAcGFyYW0gb3B0c1xuICAgICAqL1xuICB9LCB7XG4gICAga2V5OiAncmVxdWVzdCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJlcXVlc3Qob3B0cykge1xuICAgICAgdmFyIF90aGlzMiA9IHRoaXM7XG5cbiAgICAgIHZhciB4aHIgPSB0aGlzLnhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgeGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHhociA9IF90aGlzMi54aHI7XG4gICAgICAgIGlmICh4aHIucmVhZHlTdGF0ZSA8IDQpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH0gZWxzZSBpZiAoeGhyLnN0YXR1cyAhPT0gMjAwKSB7XG4gICAgICAgICAgX3RoaXMyLmVycm9ySGFuZGxlcih4aHIpO1xuICAgICAgICAgIGlmICh0eXBlb2Ygb3B0cy5lcnJvciA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgb3B0cy5lcnJvci5jYWxsKF90aGlzMik7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSBlbHNlIGlmICh4aHIucmVhZHlTdGF0ZSA9PSA0KSB7XG4gICAgICAgICAgcmV0dXJuIG9wdHMuc3VjY2VzcyhlLnRhcmdldC5yZXNwb25zZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHhocjtcbiAgICAgIH07XG4gICAgICB4aHIub3ZlcnJpZGVNaW1lVHlwZShcInRleHQvaHRtbDtjaGFyc2V0PWNwMTI1MVwiKTtcbiAgICAgIHhoci5vcGVuKFwiR0VUXCIsIG9wdHMudXJsLCB0cnVlKTtcblxuICAgICAgeGhyLnNlbmQoKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdtYWtlVXJsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZVVybCh2YWx1ZSkge1xuICAgICAgcmV0dXJuIHRoaXMucHJvdG9jb2wgKyAnOi8vJyArIHRoaXMuaG9zdCArIHRoaXMucGF0aCArIHRoaXMubGFuZyArIHRoaXMucXVlcnkgKyB0aGlzLmdldEVuY29kZWRWYWx1ZSh2YWx1ZSk7XG4gICAgfVxuXG4gICAgLy8gUmVwbGFjZSBzcGVjaWFsIGxhbmd1YWdlIGNoYXJhY3RlcnMgdG8gaHRtbCBjb2Rlc1xuICB9LCB7XG4gICAga2V5OiAnZ2V0RW5jb2RlZFZhbHVlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZ2V0RW5jb2RlZFZhbHVlKHZhbHVlKSB7XG4gICAgICAvL3RvIGZpbmQgc3BlYyBzeW1ib2xzIHdlIGZpcnN0IGVuY29kZSB0aGVtIChyYXcgc2VhcmNoIGZvciB0aGF0IHN5bWJvbCBkb2Vzbid0IHdvcmspXG4gICAgICB2YXIgdmFsID0gZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcbiAgICAgIHZhciBjb2RlID0gdW5kZWZpbmVkLFxuICAgICAgICAgIGNjID0gdW5kZWZpbmVkO1xuICAgICAgZm9yICh2YXIgY2hhciBpbiBDSEFSX0NPREVTKSB7XG4gICAgICAgIGlmIChDSEFSX0NPREVTLmhhc093blByb3BlcnR5KGNoYXIpKSB7XG4gICAgICAgICAgY29kZSA9IENIQVJfQ09ERVNbY2hhcl07XG4gICAgICAgICAgaWYgKHR5cGVvZiBjb2RlID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgLy8gcnVzc2lhbiBoYXMgc3BlY2lhbCBjb2Rlc1xuICAgICAgICAgICAgY2MgPSBjb2RlLnZhbDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy9mb3IgYWxsIGxhbmdzIGV4Y2VwdCBydXNzaWFuIGVuY29kZSBodG1sLWNvZGVzIG5lZWRlZFxuICAgICAgICAgICAgY2MgPSBlbmNvZGVVUklDb21wb25lbnQoY29kZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHZhbCA9IHZhbC5yZXBsYWNlKGNoYXIsIGNjKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHZhbDtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdlcnJvckhhbmRsZXInLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBlcnJvckhhbmRsZXIoeGhyKSB7XG4gICAgICBjb25zb2xlLmxvZygneGhyIGVycm9yOicsIHhocik7XG4gICAgfVxuXG4gICAgLy9SZWNlaXZpbmcgZGF0YSBmcm9tIHRyYW5zbGF0aW9uLWVuZ2luZSBhbmQgc2VuZCByZWFkeSBtZXNzYWdlIHdpdGggZGF0YVxuICB9LCB7XG4gICAga2V5OiAnc3VjY2Vzc3RIYW5kbGVyJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc3VjY2Vzc3RIYW5kbGVyKHRyYW5zbGF0ZWQpIHtcbiAgICAgIHZhciBfdGhpczMgPSB0aGlzO1xuXG4gICAgICBpZiAodHJhbnNsYXRlZCkge1xuICAgICAgICBjaHJvbWUudGFicy5nZXRTZWxlY3RlZChudWxsLCBmdW5jdGlvbiAodGFiKSB7XG4gICAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgICBhY3Rpb246IF90aGlzMy5tZXNzYWdlVHlwZSh0cmFuc2xhdGVkKSxcbiAgICAgICAgICAgIGRhdGE6IHRyYW5zbGF0ZWQub3V0ZXJIVE1MLFxuICAgICAgICAgICAgc3VjY2VzczogIXRyYW5zbGF0ZWQuY2xhc3NMaXN0LmNvbnRhaW5zKCdmYWlsVHJhbnNsYXRlJylcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnbWVzc2FnZVR5cGUnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtZXNzYWdlVHlwZSh0cmFuc2xhdGVkKSB7XG4gICAgICBpZiAodHJhbnNsYXRlZCAmJiB0cmFuc2xhdGVkLnJvd3MgJiYgdHJhbnNsYXRlZC5yb3dzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICByZXR1cm4gJ3NpbWlsYXJfd29yZHMnO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuICdvcGVuX3Rvb2x0aXAnO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vICBTdHJpcCBzY3JpcHQgdGFncyBmcm9tIHJlc3BvbnNlIGh0bWxcbiAgfSwge1xuICAgIGtleTogJ3N0cmlwU2NyaXB0cycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHN0cmlwU2NyaXB0cyhyZXMpIHtcbiAgICAgIHZhciBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGRpdi5pbm5lckhUTUwgPSByZXM7XG4gICAgICB2YXIgc2NyaXB0cyA9IGRpdi5nZXRFbGVtZW50c0J5VGFnTmFtZSgnc2NyaXB0Jyk7XG4gICAgICB2YXIgaSA9IHNjcmlwdHMubGVuZ3RoO1xuICAgICAgd2hpbGUgKGktLSkge1xuICAgICAgICBzY3JpcHRzW2ldLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc2NyaXB0c1tpXSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZGl2LmlubmVySFRNTDtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdtYWtlRnJhZ21lbnQnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlRnJhZ21lbnQoZG9jLCBmcmFnbWVudCkge1xuICAgICAgZnJhZ21lbnQgPSBmcmFnbWVudCB8fCBudWxsO1xuICAgICAgdmFyIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICBkaXYuaW5uZXJIVE1MID0gZG9jO1xuICAgICAgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG4gICAgICB3aGlsZSAoZGl2LmZpcnN0Q2hpbGQpIHtcbiAgICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoZGl2LmZpcnN0Q2hpbGQpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZyYWdtZW50O1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2ZpeEltYWdlcycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGZpeEltYWdlcyhmcmFnbWVudCkge1xuICAgICAgZnJhZ21lbnQgPSBmcmFnbWVudCB8fCBudWxsO1xuICAgICAgdGhpcy5maXhVcmwoZnJhZ21lbnQsICdpbWcnLCAnc3JjJyk7XG4gICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnZml4TGlua3MnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBmaXhMaW5rcygpIHtcbiAgICAgIHZhciBmcmFnbWVudCA9IGFyZ3VtZW50cy5sZW5ndGggPD0gMCB8fCBhcmd1bWVudHNbMF0gPT09IHVuZGVmaW5lZCA/IG51bGwgOiBhcmd1bWVudHNbMF07XG5cbiAgICAgIHRoaXMuZml4VXJsKGZyYWdtZW50LCAnYScsICdocmVmJyk7XG4gICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnZml4VXJsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZml4VXJsKGZyYWdtZW50LCB0YWcsIGF0dHIpIHtcbiAgICAgIGlmIChmcmFnbWVudCA9PT0gdW5kZWZpbmVkKSBmcmFnbWVudCA9IG51bGw7XG5cbiAgICAgIHZhciBfdGhpczQgPSB0aGlzO1xuXG4gICAgICB2YXIgZWxlbWVudHMgPSB7fTtcbiAgICAgIGlmIChmcmFnbWVudCkge1xuICAgICAgICBlbGVtZW50cyA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3JBbGwodGFnKTtcbiAgICAgIH1cbiAgICAgIHZhciBwYXJzZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICBlbGVtZW50cy5mb3JFYWNoKGZ1bmN0aW9uIChlbCkge1xuICAgICAgICBwYXJzZXIuaHJlZiA9IGVsW2F0dHJdO1xuICAgICAgICBwYXJzZXIuaG9zdCA9IF90aGlzNC5ob3N0O1xuICAgICAgICBwYXJzZXIucHJvdG9jb2wgPSBfdGhpczQucHJvdG9jb2w7XG4gICAgICAgIC8vIGZpeCByZWxhdGl2ZSBsaW5rc1xuICAgICAgICBpZiAodGFnID09ICdhJykge1xuICAgICAgICAgIGVsLmNsYXNzTGlzdC5hZGQoJ210dF9saW5rJyk7XG4gICAgICAgICAgaWYgKHBhcnNlci5wYXRobmFtZS5pbmRleE9mKCdtLmV4ZScpICE9PSAtMSkge1xuICAgICAgICAgICAgcGFyc2VyLnBhdGhuYW1lID0gJy9jJyArIHBhcnNlci5wYXRobmFtZTtcbiAgICAgICAgICAgIGVsLnNldEF0dHJpYnV0ZSgndGFyZ2V0JywgJ19ibGFuaycpO1xuICAgICAgICAgICAgZWwuc2V0QXR0cmlidXRlKGF0dHIsIHBhcnNlci5ocmVmKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAodGFnID09ICdpbWcnKSB7XG4gICAgICAgICAgdmFyIHVybCA9IF90aGlzNC5nZXRVcmwoZWwuc3JjKTtcbiAgICAgICAgICBlbC5jbGFzc0xpc3QuYWRkKCdtdHRfaW1nJyk7XG4gICAgICAgICAgZWwuc3JjID0gX3RoaXM0LnByb3RvY29sICsgJzovLycgKyBfdGhpczQuaG9zdCArICcvJyArIHVybC5wYXRobmFtZTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gdG9kbzogbW92ZSB0byB1dGlsc1xuICB9LCB7XG4gICAga2V5OiAnZ2V0VXJsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZ2V0VXJsKHVybCkge1xuICAgICAgdmFyIGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICBhLmhyZWYgPSB1cmw7XG4gICAgICByZXR1cm4gYTtcbiAgICB9XG4gIH1dKTtcblxuICByZXR1cm4gVHJhbjtcbn0pKCk7XG5cbm1vZHVsZS5leHBvcnRzID0gbmV3IFRyYW4oKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXRyYW4uanMubWFwXG4iXX0=
