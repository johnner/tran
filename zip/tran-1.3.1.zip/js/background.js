(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){

/*global tran, chrome */
var CHAR_CODES, tran, turkishDictionary;

CHAR_CODES = require('./char-codes.js');

tran = require('./tran.js');

turkishDictionary = require('./turkishdictionary.js');

chrome.contextMenus.create({
  title: 'Multitran: "%s"',
  contexts: ["editable", "selection"],
  onclick: function(data) {
    data.silent = false;
    return tran.click(data);
  }
});


/*
 Can't get chrome.storage directly from content_script
 so content_script sends request message and then background script
 responds with storage value
 */

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.method === "get_fast_option") {
    chrome.storage.sync.get({
      fast: true
    }, function(items) {
      return sendResponse({
        fast: items.fast
      });
    });
  } else if (request.method === 'request_search') {
    chrome.storage.sync.get({
      language: '1',
      fast: true
    }, function(items) {
      request.data.silent = true;
      if (parseInt(items.language, 10) === 1000) {
        turkishDictionary.translate(request.data);
      } else {
        tran.click(request.data);
      }
      return true;
    });
  }
  return true;
});


},{"./char-codes.js":3,"./tran.js":4,"./turkishdictionary.js":5}],2:[function(require,module,exports){
// turkishdictionary codings
'use strict';

var DICT = {
    350: '%DE', //Ş
    286: '%D0', //Ğ
    287: '%F0', //ğ
    351: '%FE', //ş
    305: '%FD', //ı
    304: '%DD', //İ
    252: '%FC', //ü
    220: '%DC', //Ü
    231: '%E7', //ç
    199: '%C7', //Ç
    246: '%F6', //ö
    244: '%F4', //ô
    214: '%D6', //Ö
    212: '%D4', //Ô
    251: '%FB', //û
    219: '%DB', //Û
    194: '%C2', //Â
    226: '%E2', //â
    39: '' };

//'
module.exports = DICT;
//# sourceMappingURL=char-codes-turk.js.map

},{}],3:[function(require,module,exports){
/*  Multitran depends on html-escaping (not UTF-8) rules for special symbols  à, è, ì, ò, ù - À, È, Ì, Ò, Ù  á, é, í, ó, ú, ý - Á, É, Í, Ó, Ú, Ý  â, ê, î, ô, û Â, Ê, Î, Ô, Û  ã, ñ, õ Ã, Ñ, Õ  ä, ë, ï, ö, ü, ÿ Ä, Ë, Ï, Ö, Ü,  å, Å  æ, Æ  ç, Ç  ð, Ð  ø, Ø  ¿ ¡ ß*/
'use strict';

var CHAR_CODES = {
  //russian
  '%D1%8A': { val: '%FA', lang: 'ru' }, // ъ
  '%D0%AA': { val: '%DA', lang: 'ru' }, // Ъ

  '%C3%80': '&#192;', // À
  '%C3%81': '&#193;', // Á
  '%C3%82': '&#194;', // Â
  '%C3%83': '&#195;', // Ã
  '%C3%84': '&#196;', // Ä
  '%C3%85': '&#197;', // Å
  '%C3%86': '&#198;', // Æ

  '%C3%87': '&#199;', // Ç
  '%C3%88': '&#200;', // È
  '%C3%89': '&#201;', // É
  '%C3%8A': '&#202;', // Ê
  '%C3%8B': '&#203;', // Ë

  '%C3%8C': '&#204;', // Ì
  '%C3%8D': '&#205;', // Í
  '%C3%8E': '&#206;', // Î
  '%C3%8F': '&#207;', // Ï

  '%C3%91': '&#209;', // Ñ
  '%C3%92': '&#210;', // Ò
  '%C3%93': '&#211;', // Ó
  '%C3%94': '&#212;', // Ô
  '%C3%95': '&#213;', // Õ
  '%C3%96': '&#214;', // Ö

  '%C3%99': '&#217;', // Ù
  '%C3%9A': '&#218;', // Ú
  '%C3%9B': '&#219;', // Û
  '%C3%9C': '&#220;', // Ü

  '%C3%A0': '&#224;', // à
  '%C3%A1': '&#225;', // á
  '%C3%A2': '&#226;', // â
  '%C3%A3': '&#227;', // ã
  '%C3%A4': '&#228;', // ä
  '%C3%A5': '&#229;', // å
  '%C3%A6': '&#230;', // æ
  '%C3%A7': '&#231;', // ç

  '%C3%A8': '&#232;', // è
  '%C3%A9': '&#233;', // é
  '%C3%AA': '&#234;', // ê
  '%C3%AB': '&#235;', // ë

  '%C3%AC': '&#236;', // ì
  '%C3%AD': '&#237;', // í
  '%C3%AE': '&#238;', // î
  '%C3%AF': '&#239;', // ï

  '%C3%B0': '&#240;', // ð
  '%C3%B1': '&#241;', // ñ

  '%C3%B2': '&#242;', // ò
  '%C3%B3': '&#243;', // ó
  '%C3%B4': '&#244;', // ô
  '%C3%B5': '&#245;', // õ
  '%C3%B6': '&#246;', // ö

  '%C3%B9': '&#249;', // ù
  '%C3%BA': '&#250;', // ú
  '%C3%BB': '&#251;', // û
  '%C3%BC': '&#252;', // ü
  '%C3%BF': '&#255;', // ÿ
  '%C5%B8': '&#376;', // Ÿ

  '%C3%9F': '&#223;', // ß

  '%C2%BF': '&#191;', // ¿
  '%C2%A1': '&#161;' };

// ¡
module.exports = CHAR_CODES;
//# sourceMappingURL=char-codes.js.map

},{}],4:[function(require,module,exports){
/**
 Multitran translate engine
 Provides program interface for making translate queries to multitran and get clean response

 All engines must follow common interface and provide methods:
 - search (languange, successHandler)  clean translation must be passed into successHandler
 - click

 Translation-module that makes requests to language-engine,
 parses results and sends plugin-global message with translation data
 **/
// var iconv = require('iconv-lite');

'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var CHAR_CODES = require('./char-codes.js');

var Tran = (function () {
  function Tran() {
    _classCallCheck(this, Tran);

    this.TABLE_CLASS = "___mtt_translate_table";
    this.protocol = 'http';
    this.host = 'www.multitran.ru';
    this.path = '/c/m.exe';
    this.query = '&s=';
    this.lang = '?l1=2&l2=1'; // from russian to english by default
    this.xhr = {};
  }

  /**
   * Context menu click handler
   */

  _createClass(Tran, [{
    key: 'click',
    value: function click(data) {
      if (typeof data.silent === "undefined" || data.silent === null) {
        data.silent = true; // true by default
      }
      var selectionText = this.removeHyphenation(data.selectionText);
      this.search({
        value: selectionText,
        success: this.successtHandler.bind(this),
        silent: data.silent // if translation failed do not show dialog
      });
    }

    /**
     * Discard soft hyphen character (U+00AD, &shy;) from the input
     */
  }, {
    key: 'removeHyphenation',
    value: function removeHyphenation(text) {
      return text.replace(/\xad/g, '');
    }

    /**
     * Initiate translation search
     */
  }, {
    key: 'search',
    value: function search(params) {
      var _this = this;

      //value, callback, err
      chrome.storage.sync.get({ language: '1' }, function (items) {
        if (items.language === '') {
          items.language = '1';
        }
        _this.setLanguage(items.language);
        var url = _this.makeUrl(params.value);
        // decorate success to make preliminary parsing
        var origSuccess = params.success;
        params.success = function (response) {
          var translated = _this.parse(response, params.silent);
          origSuccess.call(_this, translated);
        };
        console.log('params.success=', params.success);
        _this.request({
          url: url,
          success: params.success,
          error: params.error
        });
      });
    }

    //Parse response from translation engine
  }, {
    key: 'parse',
    value: function parse(response, silent, translate) {
      translate = translate || null;
      var doc = this.stripScripts(response);
      var fragment = this.makeFragment(doc);
      if (fragment) {
        translate = fragment.querySelector('#translation ~ table');
        if (translate) {
          translate.className = this.TABLE_CLASS;
          translate.setAttribute("cellpadding", "5");
          this.fixImages(translate);
          this.fixLinks(translate);
        } else if (!silent) {
          translate = document.createElement('div');
          translate.className = 'failTranslate';
          translate.innerText = "Unfortunately, could not translate";
        }
      }
      return translate;
    }
  }, {
    key: 'setLanguage',
    value: function setLanguage(language) {
      this.currentLanguage = language;
      this.lang = '?l1=2&l2=' + language;
    }

    /**
     * Request translation and run callback function
     * passing translated result or error to callback
     * @param opts
     */
  }, {
    key: 'request',
    value: function request(opts) {
      var _this2 = this;

      var xhr = this.xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function (e) {
        xhr = _this2.xhr;
        if (xhr.readyState < 4) {
          return;
        } else if (xhr.status !== 200) {
          _this2.errorHandler(xhr);
          if (typeof opts.error === 'function') {
            opts.error.call(_this2);
          }
          return;
        } else if (xhr.readyState == 4) {
          return opts.success(e.target.response);
        }
        return xhr;
      };
      xhr.overrideMimeType("text/html;charset=cp1251");
      xhr.open("GET", opts.url, true);

      xhr.send();
    }
  }, {
    key: 'makeUrl',
    value: function makeUrl(value) {
      return this.protocol + '://' + this.host + this.path + this.lang + this.query + this.getEncodedValue(value);
    }

    // Replace special language characters to html codes
  }, {
    key: 'getEncodedValue',
    value: function getEncodedValue(value) {
      //to find spec symbols we first encode them (raw search for that symbol doesn't work)
      var val = encodeURIComponent(value);
      var code = undefined,
          cc = undefined;
      for (var char in CHAR_CODES) {
        if (CHAR_CODES.hasOwnProperty(char)) {
          code = CHAR_CODES[char];
          if (typeof code === 'object') {
            // russian has special codes
            cc = code.val;
          } else {
            //for all langs except russian encode html-codes needed
            cc = encodeURIComponent(code);
          }
          val = val.replace(char, cc);
        }
      }
      return val;
    }
  }, {
    key: 'errorHandler',
    value: function errorHandler(xhr) {
      console.log('xhr error:', xhr);
    }

    //Receiving data from translation-engine and send ready message with data
  }, {
    key: 'successtHandler',
    value: function successtHandler(translated) {
      var _this3 = this;

      if (translated) {
        chrome.tabs.getSelected(null, function (tab) {
          chrome.tabs.sendMessage(tab.id, {
            action: _this3.messageType(translated),
            data: translated.outerHTML,
            success: !translated.classList.contains('failTranslate')
          });
        });
      }
    }
  }, {
    key: 'messageType',
    value: function messageType(translated) {
      if (translated && translated.rows && translated.rows.length === 1) {
        return 'similar_words';
      } else {
        return 'open_tooltip';
      }
    }

    //  Strip script tags from response html
  }, {
    key: 'stripScripts',
    value: function stripScripts(res) {
      var div = document.createElement('div');
      div.innerHTML = res;
      var scripts = div.getElementsByTagName('script');
      var i = scripts.length;
      while (i--) {
        scripts[i].parentNode.removeChild(scripts[i]);
      }
      return div.innerHTML;
    }
  }, {
    key: 'makeFragment',
    value: function makeFragment(doc, fragment) {
      fragment = fragment || null;
      var div = document.createElement("div");
      div.innerHTML = doc;
      fragment = document.createDocumentFragment();
      while (div.firstChild) {
        fragment.appendChild(div.firstChild);
      }
      return fragment;
    }
  }, {
    key: 'fixImages',
    value: function fixImages(fragment) {
      fragment = fragment || null;
      this.fixUrl(fragment, 'img', 'src');
      return fragment;
    }
  }, {
    key: 'fixLinks',
    value: function fixLinks() {
      var fragment = arguments.length <= 0 || arguments[0] === undefined ? null : arguments[0];

      this.fixUrl(fragment, 'a', 'href');
      return fragment;
    }
  }, {
    key: 'fixUrl',
    value: function fixUrl(fragment, tag, attr) {
      if (fragment === undefined) fragment = null;

      var _this4 = this;

      var elements = {};
      if (fragment) {
        elements = fragment.querySelectorAll(tag);
      }
      var parser = document.createElement('a');
      elements.forEach(function (el) {
        parser.href = el[attr];
        parser.host = _this4.host;
        parser.protocol = _this4.protocol;
        // fix relative links
        if (tag == 'a') {
          el.classList.add('mtt_link');
          if (parser.pathname.indexOf('m.exe') !== -1) {
            parser.pathname = '/c' + parser.pathname;
            el.setAttribute('target', '_blank');
            el.setAttribute(attr, parser.href);
          }
        } else if (tag == 'img') {
          var url = _this4.getUrl(el.src);
          el.classList.add('mtt_img');
          el.src = _this4.protocol + '://' + _this4.host + '/' + url.pathname;
        }
      });
    }

    // todo: move to utils
  }, {
    key: 'getUrl',
    value: function getUrl(url) {
      var a = document.createElement('a');
      a.href = url;
      return a;
    }
  }]);

  return Tran;
})();

module.exports = new Tran();
//# sourceMappingURL=tran.js.map

},{"./char-codes.js":3}],5:[function(require,module,exports){
/*
  Translation engine: http://www.turkishdictionary.net
  For translating turkish-russian and vice versa
*/
'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var CHAR_CODES = require('./char-codes-turk.js');

var TurkishDictionary = (function () {
  function TurkishDictionary() {
    _classCallCheck(this, TurkishDictionary);

    this.host = 'http://www.turkishdictionary.net/?word=%FC';
    this.path = '';
    this.protocol = 'http';
    this.query = '&s=';
    this.TABLE_CLASS = '___mtt_translate_table';
    // this flag indicates that if translation was successful then publish it all over extension
    this.need_publish = true;
  }

  // Singletone

  _createClass(TurkishDictionary, [{
    key: 'search',
    value: function search(data) {
      data.url = this.makeUrl(data.value);
      this.need_publish = false;
      return this.request(data);
    }
  }, {
    key: 'translate',
    value: function translate(data) {
      data.url = this.makeUrl(data.selectionText);
      this.need_publish = true;
      this.request(data);
    }
  }, {
    key: 'makeUrl',
    value: function makeUrl(text) {
      var text = this.getEncodedValue(text);
      return ['http://www.turkishdictionary.net/?word=', text].join('');
    }

    // Replace special language characters to html codes
  }, {
    key: 'getEncodedValue',
    value: function getEncodedValue(value) {
      // to find spec symbols we first encode them (raw search for that symbol doesn't wor)
      return encodeURIComponent(value);
      //return this.makeStringTransferable(value);
    }

    /** converting script from the turkishdict */
  }, {
    key: 'makeStringTransferable',
    value: function makeStringTransferable(inputText) {
      var text = "";
      if (inputText.length > 0) {
        text = inputText;
        for (var i = 0; i < text.length; i++) {
          if (CHAR_CODES[text.charCodeAt(i)]) {
            text = text.substring(0, i) + CHAR_CODES[text.charCodeAt(i)] + text.substring(i + 1, text.length);
          } else if (text.charAt(i) == ' ') {
            // replace spaces
            text = text.substring(0, i) + '___' + text.substring(i + 1, text.length);
          }
        }
      }
      return text;
    }

    /*
      Request translation and run callback function
      passing translated result or error to callback
    */
  }, {
    key: 'request',
    value: function request(opts) {
      console.log('start request');
      this.xhr = new XMLHttpRequest();
      this.xhr.onreadystatechange = this.onReadyStateChange.bind(this, opts);
      this.xhr.open("GET", opts.url, true);
      this.xhr.send();
    }
  }, {
    key: 'onReadyStateChange',
    value: function onReadyStateChange(opts, e) {
      var xhr = this.xhr;
      if (xhr.readyState < 4) {
        return;
      } else if (xhr.status != 200) {
        this.errorHandler(xhr);
        return opts.error && opts.error();
      } else if (xhr.readyState == 4) {
        var translation = this.successHandler(e.target.response);
        console.log('success turkish translate', translation);
        console.log('call', opts.success);
        return opts.success && opts.success(translation);
      }
    }
  }, {
    key: 'successHandler',
    value: function successHandler(response) {
      var data = this.parse(response);
      if (this.need_publish) {
        chrome.tabs.getSelected(null, this.publishTranslation.bind(this, data));
      }
      return data;
    }

    /* publish successfuly translated text all over extension */
  }, {
    key: 'publishTranslation',
    value: function publishTranslation(translation, tab) {
      console.log('publish translation');
      chrome.tabs.sendMessage(tab.id, {
        action: this.tooltipAction(translation),
        data: translation.outerHTML,
        success: !translation.classList.contains('failTranslate')
      });
    }
  }, {
    key: 'tooltipAction',
    value: function tooltipAction(translation) {
      if (translation.textContent.trim().indexOf('was not found in our dictionary') != -1) {
        console.log('similar words');
        return 'similar_words';
      } else {
        console.log('open tooltip');
        return 'open_tooltip';
      }
    }
  }, {
    key: 'errorHandler',
    value: function errorHandler(response) {
      console.log('error ajax', response);
    }

    /* Parse response from translation engine */
  }, {
    key: 'parse',
    value: function parse(response, silent, translate) {
      var doc = this.stripScripts(response),
          fragment = this.makeFragment(doc);
      if (fragment) {
        translate = fragment.querySelector('#meaning_div > table');
        if (translate) {
          translate.className = this.TABLE_CLASS;
          translate.setAttribute("cellpadding", "5");
          // @fixImages(translate)
          // @fixLinks(translate)
        } else if (!silent) {
            translate = document.createElement('div');
            translate.className = 'failTranslate';
            translate.innerText = "Unfortunately, could not translate";
          }
      }
      return translate;
    }

    /** parsing of terrible html markup */
  }, {
    key: 'parseText',
    value: function parseText(response, silent, translate) {
      var _this = this;

      var doc = this.stripScripts(response),
          fragment = this.makeFragment(doc);

      if (fragment) {
        var i;

        var _ret = (function () {
          var stopIndex = null;
          var tr = fragment.querySelectorAll('#meaning_div>table>tbody>tr');
          tr = Array.prototype.slice.call(tr);

          var trans = tr.filter(function (tr, index) {
            if (!isNaN(parseInt(stopIndex, 10)) && index >= stopIndex) {
              return;
            } else {
              tr = $(tr);
              // take every row before next section (which is English->English)
              if (tr.attr('bgcolor') == "e0e6ff") {
                stopIndex = index;return;
              } else {
                return $.trim(tr.find('td').text()).length;
              }
            }
          });
          trans = trans.slice(1, trans.length - 1);
          trans = trans.filter(function (el, indx) {
            return indx % 2;
          });
          var frag = _this.fragmentFromList(trans);
          var fonts = frag.querySelectorAll('font');
          var text = '';
          for (i = 0; i < fonts.length; i++) {
            text += ' ' + fonts[i].textContent.trim();
          }
          return {
            v: text
          };
        })();

        if (typeof _ret === 'object') return _ret.v;
      } else {
        throw "HTML fragment could not be parsed";
      }
    }

    //TODO extract to base engine class
    /* removes <script> tags from html code */
  }, {
    key: 'stripScripts',
    value: function stripScripts(html) {
      var div = document.createElement('div');
      div.innerHTML = html;
      var scripts = div.getElementsByTagName('script');
      var i = scripts.length;
      while (i--) scripts[i].parentNode.removeChild(scripts[i]);
      return div.innerHTML;
    }

    //TODO extract to base engine class
    /* creates temp object to parse translation from page 
      (since it's not a friendly api) 
    */
  }, {
    key: 'makeFragment',
    value: function makeFragment(html) {
      var fragment = document.createDocumentFragment(),
          div = document.createElement("div");
      div.innerHTML = html;
      while (div.firstChild) {
        fragment.appendChild(div.firstChild);
      }
      return fragment;
    }

    /** create fragment from list of DOM elements */
  }, {
    key: 'fragmentFromList',
    value: function fragmentFromList(list) {
      var fragment = document.createDocumentFragment(),
          len = list.length;
      while (len--) {
        fragment.appendChild(list[len]);
      }
      return fragment;
    }
  }]);

  return TurkishDictionary;
})();

module.exports = new TurkishDictionary();
//# sourceMappingURL=turkishdictionary.js.map

},{"./char-codes-turk.js":2}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxkZXZcXHRyYW5cXG5vZGVfbW9kdWxlc1xcYnJvd3Nlci1wYWNrXFxfcHJlbHVkZS5qcyIsIkM6XFxkZXZcXHRyYW5cXGpzXFxlczVcXGJhY2tncm91bmQuY29mZmVlIiwiQzovZGV2L3RyYW4vanMvZXM1L2NoYXItY29kZXMtdHVyay5qcyIsIkM6L2Rldi90cmFuL2pzL2VzNS9jaGFyLWNvZGVzLmpzIiwiQzovZGV2L3RyYW4vanMvZXM1L3RyYW4uanMiLCJDOi9kZXYvdHJhbi9qcy9lczUvdHVya2lzaGRpY3Rpb25hcnkuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUFBLHdCQUFBO0FBQUEsSUFBQSxtQ0FBQTs7QUFBQSxVQUdBLEdBQWEsT0FBQSxDQUFRLGlCQUFSLENBSGIsQ0FBQTs7QUFBQSxJQUtBLEdBQU8sT0FBQSxDQUFRLFdBQVIsQ0FMUCxDQUFBOztBQUFBLGlCQU1BLEdBQW9CLE9BQUEsQ0FBUSx3QkFBUixDQU5wQixDQUFBOztBQUFBLE1BU00sQ0FBQyxZQUFZLENBQUMsTUFBcEIsQ0FDRTtBQUFBLEVBQUEsS0FBQSxFQUFRLGlCQUFSO0FBQUEsRUFDQSxRQUFBLEVBQVUsQ0FBQyxVQUFELEVBQWEsV0FBYixDQURWO0FBQUEsRUFFQSxPQUFBLEVBQVUsU0FBQyxJQUFELEdBQUE7QUFDUixJQUFBLElBQUksQ0FBQyxNQUFMLEdBQWMsS0FBZCxDQUFBO1dBQ0EsSUFBSSxDQUFDLEtBQUwsQ0FBVyxJQUFYLEVBRlE7RUFBQSxDQUZWO0NBREYsQ0FUQSxDQUFBOztBQWlCQTtBQUFBOzs7O0dBakJBOztBQUFBLE1Bc0JNLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxXQUF6QixDQUFxQyxTQUFDLE9BQUQsRUFBVSxNQUFWLEVBQWtCLFlBQWxCLEdBQUE7QUFDbkMsRUFBQSxJQUFHLE9BQU8sQ0FBQyxNQUFSLEtBQWtCLGlCQUFyQjtBQUNFLElBQUEsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBcEIsQ0FBd0I7QUFBQSxNQUFBLElBQUEsRUFBTSxJQUFOO0tBQXhCLEVBQW9DLFNBQUMsS0FBRCxHQUFBO2FBQ2hDLFlBQUEsQ0FBYTtBQUFBLFFBQUEsSUFBQSxFQUFNLEtBQUssQ0FBQyxJQUFaO09BQWIsRUFEZ0M7SUFBQSxDQUFwQyxDQUFBLENBREY7R0FBQSxNQU9LLElBQUcsT0FBTyxDQUFDLE1BQVIsS0FBa0IsZ0JBQXJCO0FBQ0gsSUFBQSxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFwQixDQUF3QjtBQUFBLE1BQUUsUUFBQSxFQUFVLEdBQVo7QUFBQSxNQUFpQixJQUFBLEVBQU0sSUFBdkI7S0FBeEIsRUFBc0QsU0FBQyxLQUFELEdBQUE7QUFDcEQsTUFBQSxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQWIsR0FBc0IsSUFBdEIsQ0FBQTtBQUNBLE1BQUEsSUFBRyxRQUFBLENBQVMsS0FBSyxDQUFDLFFBQWYsRUFBd0IsRUFBeEIsQ0FBQSxLQUErQixJQUFsQztBQUNFLFFBQUEsaUJBQWlCLENBQUMsU0FBbEIsQ0FBNEIsT0FBTyxDQUFDLElBQXBDLENBQUEsQ0FERjtPQUFBLE1BQUE7QUFHRSxRQUFBLElBQUksQ0FBQyxLQUFMLENBQVcsT0FBTyxDQUFDLElBQW5CLENBQUEsQ0FIRjtPQURBO0FBS0EsYUFBTyxJQUFQLENBTm9EO0lBQUEsQ0FBdEQsQ0FBQSxDQURHO0dBUEw7U0FnQkEsS0FqQm1DO0FBQUEsQ0FBckMsQ0F0QkEsQ0FBQTs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzNCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2xGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDM1NBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpfXZhciBmPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChmLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGYsZi5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCIjIyNnbG9iYWwgdHJhbiwgY2hyb21lIyMjXG5cbiNsb2FkIGVuZ2luZXNcbkNIQVJfQ09ERVMgPSByZXF1aXJlKCcuL2NoYXItY29kZXMuanMnKTtcblxudHJhbiA9IHJlcXVpcmUoJy4vdHJhbi5qcycpICAgICAgICAgICAgICAgICAgICAgICAgICAgICAjIG11bHRpdHJhbi5ydVxudHVya2lzaERpY3Rpb25hcnkgPSByZXF1aXJlKCcuL3R1cmtpc2hkaWN0aW9uYXJ5LmpzJykgICAjIHR1cmtpc2hkaWN0aW9uYXJ5Lm5ldFxuXG4jZ2VuZXJhdGVzIGEgY29udGV4dCBtZW51XG5jaHJvbWUuY29udGV4dE1lbnVzLmNyZWF0ZShcbiAgdGl0bGU6ICAnTXVsdGl0cmFuOiBcIiVzXCInXG4gIGNvbnRleHRzOiBbXCJlZGl0YWJsZVwiLCBcInNlbGVjdGlvblwiXVxuICBvbmNsaWNrOiAgKGRhdGEpIC0+XG4gICAgZGF0YS5zaWxlbnQgPSBmYWxzZVxuICAgIHRyYW4uY2xpY2soZGF0YSlcbilcblxuIyMjXG4gQ2FuJ3QgZ2V0IGNocm9tZS5zdG9yYWdlIGRpcmVjdGx5IGZyb20gY29udGVudF9zY3JpcHRcbiBzbyBjb250ZW50X3NjcmlwdCBzZW5kcyByZXF1ZXN0IG1lc3NhZ2UgYW5kIHRoZW4gYmFja2dyb3VuZCBzY3JpcHRcbiByZXNwb25kcyB3aXRoIHN0b3JhZ2UgdmFsdWVcbiMjI1xuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyIChyZXF1ZXN0LCBzZW5kZXIsIHNlbmRSZXNwb25zZSkgLT5cbiAgaWYgcmVxdWVzdC5tZXRob2QgPT0gXCJnZXRfZmFzdF9vcHRpb25cIlxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KGZhc3Q6IHRydWUsIChpdGVtcykgLT5cbiAgICAgICAgc2VuZFJlc3BvbnNlKGZhc3Q6IGl0ZW1zLmZhc3QpXG4gICAgICAgICNyZXR1cm4gdHJ1ZVxuICAgIClcbiAgI0Zhc3QgdHJhbnNsYXRpb24gaW5pdGlhdGUgc2VhcmNoIHdpdGggJ3JlcXVlc3Rfc2VhcmNoJyBtZXNzYWdlIGZyb21cbiAgI2NvbnRlbnRfc2NyaXB0XG4gIGVsc2UgaWYgcmVxdWVzdC5tZXRob2QgPT0gJ3JlcXVlc3Rfc2VhcmNoJ1xuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHsgbGFuZ3VhZ2U6ICcxJywgZmFzdDogdHJ1ZX0sIChpdGVtcykgLT5cbiAgICAgIHJlcXVlc3QuZGF0YS5zaWxlbnQgPSB0cnVlXG4gICAgICBpZiBwYXJzZUludChpdGVtcy5sYW5ndWFnZSwxMCkgPT0gMTAwMFxuICAgICAgICB0dXJraXNoRGljdGlvbmFyeS50cmFuc2xhdGUocmVxdWVzdC5kYXRhKVxuICAgICAgZWxzZVxuICAgICAgICB0cmFuLmNsaWNrKHJlcXVlc3QuZGF0YSlcbiAgICAgIHJldHVybiB0cnVlXG4gICAgKVxuICB0cnVlXG5cbiIsIi8vIHR1cmtpc2hkaWN0aW9uYXJ5IGNvZGluZ3Ncbid1c2Ugc3RyaWN0JztcblxudmFyIERJQ1QgPSB7XG4gICAgMzUwOiAnJURFJywgLy/FnlxuICAgIDI4NjogJyVEMCcsIC8vxJ5cbiAgICAyODc6ICclRjAnLCAvL8SfXG4gICAgMzUxOiAnJUZFJywgLy/Fn1xuICAgIDMwNTogJyVGRCcsIC8vxLFcbiAgICAzMDQ6ICclREQnLCAvL8SwXG4gICAgMjUyOiAnJUZDJywgLy/DvFxuICAgIDIyMDogJyVEQycsIC8vw5xcbiAgICAyMzE6ICclRTcnLCAvL8OnXG4gICAgMTk5OiAnJUM3JywgLy/Dh1xuICAgIDI0NjogJyVGNicsIC8vw7ZcbiAgICAyNDQ6ICclRjQnLCAvL8O0XG4gICAgMjE0OiAnJUQ2JywgLy/DllxuICAgIDIxMjogJyVENCcsIC8vw5RcbiAgICAyNTE6ICclRkInLCAvL8O7XG4gICAgMjE5OiAnJURCJywgLy/Dm1xuICAgIDE5NDogJyVDMicsIC8vw4JcbiAgICAyMjY6ICclRTInLCAvL8OiXG4gICAgMzk6ICcnIH07XG5cbi8vJ1xubW9kdWxlLmV4cG9ydHMgPSBESUNUO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y2hhci1jb2Rlcy10dXJrLmpzLm1hcFxuIiwiLypcciAgTXVsdGl0cmFuIGRlcGVuZHMgb24gaHRtbC1lc2NhcGluZyAobm90IFVURi04KSBydWxlcyBmb3Igc3BlY2lhbCBzeW1ib2xzXHIgIMOgLCDDqCwgw6wsIMOyLCDDuSAtIMOALCDDiCwgw4wsIMOSLCDDmVxyICDDoSwgw6ksIMOtLCDDsywgw7osIMO9IC0gw4EsIMOJLCDDjSwgw5MsIMOaLCDDnVxyICDDoiwgw6osIMOuLCDDtCwgw7sgw4IsIMOKLCDDjiwgw5QsIMObXHIgIMOjLCDDsSwgw7Ugw4MsIMORLCDDlVxyICDDpCwgw6ssIMOvLCDDtiwgw7wsIMO/IMOELCDDiywgw48sIMOWLCDDnCxcciAgw6UsIMOFXHIgIMOmLCDDhlxyICDDpywgw4dcciAgw7AsIMOQXHIgIMO4LCDDmFxyICDCvyDCoSDDn1xyKi9cbid1c2Ugc3RyaWN0JztcblxudmFyIENIQVJfQ09ERVMgPSB7XG4gIC8vcnVzc2lhblxuICAnJUQxJThBJzogeyB2YWw6ICclRkEnLCBsYW5nOiAncnUnIH0sIC8vINGKXG4gICclRDAlQUEnOiB7IHZhbDogJyVEQScsIGxhbmc6ICdydScgfSwgLy8g0KpcblxuICAnJUMzJTgwJzogJyYjMTkyOycsIC8vIMOAXG4gICclQzMlODEnOiAnJiMxOTM7JywgLy8gw4FcbiAgJyVDMyU4Mic6ICcmIzE5NDsnLCAvLyDDglxuICAnJUMzJTgzJzogJyYjMTk1OycsIC8vIMODXG4gICclQzMlODQnOiAnJiMxOTY7JywgLy8gw4RcbiAgJyVDMyU4NSc6ICcmIzE5NzsnLCAvLyDDhVxuICAnJUMzJTg2JzogJyYjMTk4OycsIC8vIMOGXG5cbiAgJyVDMyU4Nyc6ICcmIzE5OTsnLCAvLyDDh1xuICAnJUMzJTg4JzogJyYjMjAwOycsIC8vIMOIXG4gICclQzMlODknOiAnJiMyMDE7JywgLy8gw4lcbiAgJyVDMyU4QSc6ICcmIzIwMjsnLCAvLyDDilxuICAnJUMzJThCJzogJyYjMjAzOycsIC8vIMOLXG5cbiAgJyVDMyU4Qyc6ICcmIzIwNDsnLCAvLyDDjFxuICAnJUMzJThEJzogJyYjMjA1OycsIC8vIMONXG4gICclQzMlOEUnOiAnJiMyMDY7JywgLy8gw45cbiAgJyVDMyU4Ric6ICcmIzIwNzsnLCAvLyDDj1xuXG4gICclQzMlOTEnOiAnJiMyMDk7JywgLy8gw5FcbiAgJyVDMyU5Mic6ICcmIzIxMDsnLCAvLyDDklxuICAnJUMzJTkzJzogJyYjMjExOycsIC8vIMOTXG4gICclQzMlOTQnOiAnJiMyMTI7JywgLy8gw5RcbiAgJyVDMyU5NSc6ICcmIzIxMzsnLCAvLyDDlVxuICAnJUMzJTk2JzogJyYjMjE0OycsIC8vIMOWXG5cbiAgJyVDMyU5OSc6ICcmIzIxNzsnLCAvLyDDmVxuICAnJUMzJTlBJzogJyYjMjE4OycsIC8vIMOaXG4gICclQzMlOUInOiAnJiMyMTk7JywgLy8gw5tcbiAgJyVDMyU5Qyc6ICcmIzIyMDsnLCAvLyDDnFxuXG4gICclQzMlQTAnOiAnJiMyMjQ7JywgLy8gw6BcbiAgJyVDMyVBMSc6ICcmIzIyNTsnLCAvLyDDoVxuICAnJUMzJUEyJzogJyYjMjI2OycsIC8vIMOiXG4gICclQzMlQTMnOiAnJiMyMjc7JywgLy8gw6NcbiAgJyVDMyVBNCc6ICcmIzIyODsnLCAvLyDDpFxuICAnJUMzJUE1JzogJyYjMjI5OycsIC8vIMOlXG4gICclQzMlQTYnOiAnJiMyMzA7JywgLy8gw6ZcbiAgJyVDMyVBNyc6ICcmIzIzMTsnLCAvLyDDp1xuXG4gICclQzMlQTgnOiAnJiMyMzI7JywgLy8gw6hcbiAgJyVDMyVBOSc6ICcmIzIzMzsnLCAvLyDDqVxuICAnJUMzJUFBJzogJyYjMjM0OycsIC8vIMOqXG4gICclQzMlQUInOiAnJiMyMzU7JywgLy8gw6tcblxuICAnJUMzJUFDJzogJyYjMjM2OycsIC8vIMOsXG4gICclQzMlQUQnOiAnJiMyMzc7JywgLy8gw61cbiAgJyVDMyVBRSc6ICcmIzIzODsnLCAvLyDDrlxuICAnJUMzJUFGJzogJyYjMjM5OycsIC8vIMOvXG5cbiAgJyVDMyVCMCc6ICcmIzI0MDsnLCAvLyDDsFxuICAnJUMzJUIxJzogJyYjMjQxOycsIC8vIMOxXG5cbiAgJyVDMyVCMic6ICcmIzI0MjsnLCAvLyDDslxuICAnJUMzJUIzJzogJyYjMjQzOycsIC8vIMOzXG4gICclQzMlQjQnOiAnJiMyNDQ7JywgLy8gw7RcbiAgJyVDMyVCNSc6ICcmIzI0NTsnLCAvLyDDtVxuICAnJUMzJUI2JzogJyYjMjQ2OycsIC8vIMO2XG5cbiAgJyVDMyVCOSc6ICcmIzI0OTsnLCAvLyDDuVxuICAnJUMzJUJBJzogJyYjMjUwOycsIC8vIMO6XG4gICclQzMlQkInOiAnJiMyNTE7JywgLy8gw7tcbiAgJyVDMyVCQyc6ICcmIzI1MjsnLCAvLyDDvFxuICAnJUMzJUJGJzogJyYjMjU1OycsIC8vIMO/XG4gICclQzUlQjgnOiAnJiMzNzY7JywgLy8gxbhcblxuICAnJUMzJTlGJzogJyYjMjIzOycsIC8vIMOfXG5cbiAgJyVDMiVCRic6ICcmIzE5MTsnLCAvLyDCv1xuICAnJUMyJUExJzogJyYjMTYxOycgfTtcblxuLy8gwqFcbm1vZHVsZS5leHBvcnRzID0gQ0hBUl9DT0RFUztcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNoYXItY29kZXMuanMubWFwXG4iLCIvKipcbiBNdWx0aXRyYW4gdHJhbnNsYXRlIGVuZ2luZVxuIFByb3ZpZGVzIHByb2dyYW0gaW50ZXJmYWNlIGZvciBtYWtpbmcgdHJhbnNsYXRlIHF1ZXJpZXMgdG8gbXVsdGl0cmFuIGFuZCBnZXQgY2xlYW4gcmVzcG9uc2VcblxuIEFsbCBlbmdpbmVzIG11c3QgZm9sbG93IGNvbW1vbiBpbnRlcmZhY2UgYW5kIHByb3ZpZGUgbWV0aG9kczpcbiAtIHNlYXJjaCAobGFuZ3VhbmdlLCBzdWNjZXNzSGFuZGxlcikgIGNsZWFuIHRyYW5zbGF0aW9uIG11c3QgYmUgcGFzc2VkIGludG8gc3VjY2Vzc0hhbmRsZXJcbiAtIGNsaWNrXG5cbiBUcmFuc2xhdGlvbi1tb2R1bGUgdGhhdCBtYWtlcyByZXF1ZXN0cyB0byBsYW5ndWFnZS1lbmdpbmUsXG4gcGFyc2VzIHJlc3VsdHMgYW5kIHNlbmRzIHBsdWdpbi1nbG9iYWwgbWVzc2FnZSB3aXRoIHRyYW5zbGF0aW9uIGRhdGFcbiAqKi9cbi8vIHZhciBpY29udiA9IHJlcXVpcmUoJ2ljb252LWxpdGUnKTtcblxuJ3VzZSBzdHJpY3QnO1xuXG52YXIgX2NyZWF0ZUNsYXNzID0gKGZ1bmN0aW9uICgpIHsgZnVuY3Rpb24gZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIHByb3BzKSB7IGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpKyspIHsgdmFyIGRlc2NyaXB0b3IgPSBwcm9wc1tpXTsgZGVzY3JpcHRvci5lbnVtZXJhYmxlID0gZGVzY3JpcHRvci5lbnVtZXJhYmxlIHx8IGZhbHNlOyBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSA9IHRydWU7IGlmICgndmFsdWUnIGluIGRlc2NyaXB0b3IpIGRlc2NyaXB0b3Iud3JpdGFibGUgPSB0cnVlOyBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBkZXNjcmlwdG9yLmtleSwgZGVzY3JpcHRvcik7IH0gfSByZXR1cm4gZnVuY3Rpb24gKENvbnN0cnVjdG9yLCBwcm90b1Byb3BzLCBzdGF0aWNQcm9wcykgeyBpZiAocHJvdG9Qcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvci5wcm90b3R5cGUsIHByb3RvUHJvcHMpOyBpZiAoc3RhdGljUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IsIHN0YXRpY1Byb3BzKTsgcmV0dXJuIENvbnN0cnVjdG9yOyB9OyB9KSgpO1xuXG5mdW5jdGlvbiBfY2xhc3NDYWxsQ2hlY2soaW5zdGFuY2UsIENvbnN0cnVjdG9yKSB7IGlmICghKGluc3RhbmNlIGluc3RhbmNlb2YgQ29uc3RydWN0b3IpKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoJ0Nhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvbicpOyB9IH1cblxudmFyIENIQVJfQ09ERVMgPSByZXF1aXJlKCcuL2NoYXItY29kZXMuanMnKTtcblxudmFyIFRyYW4gPSAoZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBUcmFuKCkge1xuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBUcmFuKTtcblxuICAgIHRoaXMuVEFCTEVfQ0xBU1MgPSBcIl9fX210dF90cmFuc2xhdGVfdGFibGVcIjtcbiAgICB0aGlzLnByb3RvY29sID0gJ2h0dHAnO1xuICAgIHRoaXMuaG9zdCA9ICd3d3cubXVsdGl0cmFuLnJ1JztcbiAgICB0aGlzLnBhdGggPSAnL2MvbS5leGUnO1xuICAgIHRoaXMucXVlcnkgPSAnJnM9JztcbiAgICB0aGlzLmxhbmcgPSAnP2wxPTImbDI9MSc7IC8vIGZyb20gcnVzc2lhbiB0byBlbmdsaXNoIGJ5IGRlZmF1bHRcbiAgICB0aGlzLnhociA9IHt9O1xuICB9XG5cbiAgLyoqXG4gICAqIENvbnRleHQgbWVudSBjbGljayBoYW5kbGVyXG4gICAqL1xuXG4gIF9jcmVhdGVDbGFzcyhUcmFuLCBbe1xuICAgIGtleTogJ2NsaWNrJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gY2xpY2soZGF0YSkge1xuICAgICAgaWYgKHR5cGVvZiBkYXRhLnNpbGVudCA9PT0gXCJ1bmRlZmluZWRcIiB8fCBkYXRhLnNpbGVudCA9PT0gbnVsbCkge1xuICAgICAgICBkYXRhLnNpbGVudCA9IHRydWU7IC8vIHRydWUgYnkgZGVmYXVsdFxuICAgICAgfVxuICAgICAgdmFyIHNlbGVjdGlvblRleHQgPSB0aGlzLnJlbW92ZUh5cGhlbmF0aW9uKGRhdGEuc2VsZWN0aW9uVGV4dCk7XG4gICAgICB0aGlzLnNlYXJjaCh7XG4gICAgICAgIHZhbHVlOiBzZWxlY3Rpb25UZXh0LFxuICAgICAgICBzdWNjZXNzOiB0aGlzLnN1Y2Nlc3N0SGFuZGxlci5iaW5kKHRoaXMpLFxuICAgICAgICBzaWxlbnQ6IGRhdGEuc2lsZW50IC8vIGlmIHRyYW5zbGF0aW9uIGZhaWxlZCBkbyBub3Qgc2hvdyBkaWFsb2dcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIERpc2NhcmQgc29mdCBoeXBoZW4gY2hhcmFjdGVyIChVKzAwQUQsICZzaHk7KSBmcm9tIHRoZSBpbnB1dFxuICAgICAqL1xuICB9LCB7XG4gICAga2V5OiAncmVtb3ZlSHlwaGVuYXRpb24nLFxuICAgIHZhbHVlOiBmdW5jdGlvbiByZW1vdmVIeXBoZW5hdGlvbih0ZXh0KSB7XG4gICAgICByZXR1cm4gdGV4dC5yZXBsYWNlKC9cXHhhZC9nLCAnJyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSW5pdGlhdGUgdHJhbnNsYXRpb24gc2VhcmNoXG4gICAgICovXG4gIH0sIHtcbiAgICBrZXk6ICdzZWFyY2gnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzZWFyY2gocGFyYW1zKSB7XG4gICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgICAvL3ZhbHVlLCBjYWxsYmFjaywgZXJyXG4gICAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldCh7IGxhbmd1YWdlOiAnMScgfSwgZnVuY3Rpb24gKGl0ZW1zKSB7XG4gICAgICAgIGlmIChpdGVtcy5sYW5ndWFnZSA9PT0gJycpIHtcbiAgICAgICAgICBpdGVtcy5sYW5ndWFnZSA9ICcxJztcbiAgICAgICAgfVxuICAgICAgICBfdGhpcy5zZXRMYW5ndWFnZShpdGVtcy5sYW5ndWFnZSk7XG4gICAgICAgIHZhciB1cmwgPSBfdGhpcy5tYWtlVXJsKHBhcmFtcy52YWx1ZSk7XG4gICAgICAgIC8vIGRlY29yYXRlIHN1Y2Nlc3MgdG8gbWFrZSBwcmVsaW1pbmFyeSBwYXJzaW5nXG4gICAgICAgIHZhciBvcmlnU3VjY2VzcyA9IHBhcmFtcy5zdWNjZXNzO1xuICAgICAgICBwYXJhbXMuc3VjY2VzcyA9IGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgICAgIHZhciB0cmFuc2xhdGVkID0gX3RoaXMucGFyc2UocmVzcG9uc2UsIHBhcmFtcy5zaWxlbnQpO1xuICAgICAgICAgIG9yaWdTdWNjZXNzLmNhbGwoX3RoaXMsIHRyYW5zbGF0ZWQpO1xuICAgICAgICB9O1xuICAgICAgICBjb25zb2xlLmxvZygncGFyYW1zLnN1Y2Nlc3M9JywgcGFyYW1zLnN1Y2Nlc3MpO1xuICAgICAgICBfdGhpcy5yZXF1ZXN0KHtcbiAgICAgICAgICB1cmw6IHVybCxcbiAgICAgICAgICBzdWNjZXNzOiBwYXJhbXMuc3VjY2VzcyxcbiAgICAgICAgICBlcnJvcjogcGFyYW1zLmVycm9yXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy9QYXJzZSByZXNwb25zZSBmcm9tIHRyYW5zbGF0aW9uIGVuZ2luZVxuICB9LCB7XG4gICAga2V5OiAncGFyc2UnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBwYXJzZShyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUpIHtcbiAgICAgIHRyYW5zbGF0ZSA9IHRyYW5zbGF0ZSB8fCBudWxsO1xuICAgICAgdmFyIGRvYyA9IHRoaXMuc3RyaXBTY3JpcHRzKHJlc3BvbnNlKTtcbiAgICAgIHZhciBmcmFnbWVudCA9IHRoaXMubWFrZUZyYWdtZW50KGRvYyk7XG4gICAgICBpZiAoZnJhZ21lbnQpIHtcbiAgICAgICAgdHJhbnNsYXRlID0gZnJhZ21lbnQucXVlcnlTZWxlY3RvcignI3RyYW5zbGF0aW9uIH4gdGFibGUnKTtcbiAgICAgICAgaWYgKHRyYW5zbGF0ZSkge1xuICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSB0aGlzLlRBQkxFX0NMQVNTO1xuICAgICAgICAgIHRyYW5zbGF0ZS5zZXRBdHRyaWJ1dGUoXCJjZWxscGFkZGluZ1wiLCBcIjVcIik7XG4gICAgICAgICAgdGhpcy5maXhJbWFnZXModHJhbnNsYXRlKTtcbiAgICAgICAgICB0aGlzLmZpeExpbmtzKHRyYW5zbGF0ZSk7XG4gICAgICAgIH0gZWxzZSBpZiAoIXNpbGVudCkge1xuICAgICAgICAgIHRyYW5zbGF0ZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgICAgIHRyYW5zbGF0ZS5jbGFzc05hbWUgPSAnZmFpbFRyYW5zbGF0ZSc7XG4gICAgICAgICAgdHJhbnNsYXRlLmlubmVyVGV4dCA9IFwiVW5mb3J0dW5hdGVseSwgY291bGQgbm90IHRyYW5zbGF0ZVwiO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJhbnNsYXRlO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3NldExhbmd1YWdlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc2V0TGFuZ3VhZ2UobGFuZ3VhZ2UpIHtcbiAgICAgIHRoaXMuY3VycmVudExhbmd1YWdlID0gbGFuZ3VhZ2U7XG4gICAgICB0aGlzLmxhbmcgPSAnP2wxPTImbDI9JyArIGxhbmd1YWdlO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJlcXVlc3QgdHJhbnNsYXRpb24gYW5kIHJ1biBjYWxsYmFjayBmdW5jdGlvblxuICAgICAqIHBhc3NpbmcgdHJhbnNsYXRlZCByZXN1bHQgb3IgZXJyb3IgdG8gY2FsbGJhY2tcbiAgICAgKiBAcGFyYW0gb3B0c1xuICAgICAqL1xuICB9LCB7XG4gICAga2V5OiAncmVxdWVzdCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJlcXVlc3Qob3B0cykge1xuICAgICAgdmFyIF90aGlzMiA9IHRoaXM7XG5cbiAgICAgIHZhciB4aHIgPSB0aGlzLnhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgeGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHhociA9IF90aGlzMi54aHI7XG4gICAgICAgIGlmICh4aHIucmVhZHlTdGF0ZSA8IDQpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH0gZWxzZSBpZiAoeGhyLnN0YXR1cyAhPT0gMjAwKSB7XG4gICAgICAgICAgX3RoaXMyLmVycm9ySGFuZGxlcih4aHIpO1xuICAgICAgICAgIGlmICh0eXBlb2Ygb3B0cy5lcnJvciA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgb3B0cy5lcnJvci5jYWxsKF90aGlzMik7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSBlbHNlIGlmICh4aHIucmVhZHlTdGF0ZSA9PSA0KSB7XG4gICAgICAgICAgcmV0dXJuIG9wdHMuc3VjY2VzcyhlLnRhcmdldC5yZXNwb25zZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHhocjtcbiAgICAgIH07XG4gICAgICB4aHIub3ZlcnJpZGVNaW1lVHlwZShcInRleHQvaHRtbDtjaGFyc2V0PWNwMTI1MVwiKTtcbiAgICAgIHhoci5vcGVuKFwiR0VUXCIsIG9wdHMudXJsLCB0cnVlKTtcblxuICAgICAgeGhyLnNlbmQoKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdtYWtlVXJsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZVVybCh2YWx1ZSkge1xuICAgICAgcmV0dXJuIHRoaXMucHJvdG9jb2wgKyAnOi8vJyArIHRoaXMuaG9zdCArIHRoaXMucGF0aCArIHRoaXMubGFuZyArIHRoaXMucXVlcnkgKyB0aGlzLmdldEVuY29kZWRWYWx1ZSh2YWx1ZSk7XG4gICAgfVxuXG4gICAgLy8gUmVwbGFjZSBzcGVjaWFsIGxhbmd1YWdlIGNoYXJhY3RlcnMgdG8gaHRtbCBjb2Rlc1xuICB9LCB7XG4gICAga2V5OiAnZ2V0RW5jb2RlZFZhbHVlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZ2V0RW5jb2RlZFZhbHVlKHZhbHVlKSB7XG4gICAgICAvL3RvIGZpbmQgc3BlYyBzeW1ib2xzIHdlIGZpcnN0IGVuY29kZSB0aGVtIChyYXcgc2VhcmNoIGZvciB0aGF0IHN5bWJvbCBkb2Vzbid0IHdvcmspXG4gICAgICB2YXIgdmFsID0gZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcbiAgICAgIHZhciBjb2RlID0gdW5kZWZpbmVkLFxuICAgICAgICAgIGNjID0gdW5kZWZpbmVkO1xuICAgICAgZm9yICh2YXIgY2hhciBpbiBDSEFSX0NPREVTKSB7XG4gICAgICAgIGlmIChDSEFSX0NPREVTLmhhc093blByb3BlcnR5KGNoYXIpKSB7XG4gICAgICAgICAgY29kZSA9IENIQVJfQ09ERVNbY2hhcl07XG4gICAgICAgICAgaWYgKHR5cGVvZiBjb2RlID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgLy8gcnVzc2lhbiBoYXMgc3BlY2lhbCBjb2Rlc1xuICAgICAgICAgICAgY2MgPSBjb2RlLnZhbDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy9mb3IgYWxsIGxhbmdzIGV4Y2VwdCBydXNzaWFuIGVuY29kZSBodG1sLWNvZGVzIG5lZWRlZFxuICAgICAgICAgICAgY2MgPSBlbmNvZGVVUklDb21wb25lbnQoY29kZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHZhbCA9IHZhbC5yZXBsYWNlKGNoYXIsIGNjKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHZhbDtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdlcnJvckhhbmRsZXInLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBlcnJvckhhbmRsZXIoeGhyKSB7XG4gICAgICBjb25zb2xlLmxvZygneGhyIGVycm9yOicsIHhocik7XG4gICAgfVxuXG4gICAgLy9SZWNlaXZpbmcgZGF0YSBmcm9tIHRyYW5zbGF0aW9uLWVuZ2luZSBhbmQgc2VuZCByZWFkeSBtZXNzYWdlIHdpdGggZGF0YVxuICB9LCB7XG4gICAga2V5OiAnc3VjY2Vzc3RIYW5kbGVyJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc3VjY2Vzc3RIYW5kbGVyKHRyYW5zbGF0ZWQpIHtcbiAgICAgIHZhciBfdGhpczMgPSB0aGlzO1xuXG4gICAgICBpZiAodHJhbnNsYXRlZCkge1xuICAgICAgICBjaHJvbWUudGFicy5nZXRTZWxlY3RlZChudWxsLCBmdW5jdGlvbiAodGFiKSB7XG4gICAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgICBhY3Rpb246IF90aGlzMy5tZXNzYWdlVHlwZSh0cmFuc2xhdGVkKSxcbiAgICAgICAgICAgIGRhdGE6IHRyYW5zbGF0ZWQub3V0ZXJIVE1MLFxuICAgICAgICAgICAgc3VjY2VzczogIXRyYW5zbGF0ZWQuY2xhc3NMaXN0LmNvbnRhaW5zKCdmYWlsVHJhbnNsYXRlJylcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnbWVzc2FnZVR5cGUnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtZXNzYWdlVHlwZSh0cmFuc2xhdGVkKSB7XG4gICAgICBpZiAodHJhbnNsYXRlZCAmJiB0cmFuc2xhdGVkLnJvd3MgJiYgdHJhbnNsYXRlZC5yb3dzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICByZXR1cm4gJ3NpbWlsYXJfd29yZHMnO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuICdvcGVuX3Rvb2x0aXAnO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vICBTdHJpcCBzY3JpcHQgdGFncyBmcm9tIHJlc3BvbnNlIGh0bWxcbiAgfSwge1xuICAgIGtleTogJ3N0cmlwU2NyaXB0cycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHN0cmlwU2NyaXB0cyhyZXMpIHtcbiAgICAgIHZhciBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGRpdi5pbm5lckhUTUwgPSByZXM7XG4gICAgICB2YXIgc2NyaXB0cyA9IGRpdi5nZXRFbGVtZW50c0J5VGFnTmFtZSgnc2NyaXB0Jyk7XG4gICAgICB2YXIgaSA9IHNjcmlwdHMubGVuZ3RoO1xuICAgICAgd2hpbGUgKGktLSkge1xuICAgICAgICBzY3JpcHRzW2ldLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc2NyaXB0c1tpXSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZGl2LmlubmVySFRNTDtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdtYWtlRnJhZ21lbnQnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlRnJhZ21lbnQoZG9jLCBmcmFnbWVudCkge1xuICAgICAgZnJhZ21lbnQgPSBmcmFnbWVudCB8fCBudWxsO1xuICAgICAgdmFyIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICBkaXYuaW5uZXJIVE1MID0gZG9jO1xuICAgICAgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG4gICAgICB3aGlsZSAoZGl2LmZpcnN0Q2hpbGQpIHtcbiAgICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoZGl2LmZpcnN0Q2hpbGQpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZyYWdtZW50O1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2ZpeEltYWdlcycsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGZpeEltYWdlcyhmcmFnbWVudCkge1xuICAgICAgZnJhZ21lbnQgPSBmcmFnbWVudCB8fCBudWxsO1xuICAgICAgdGhpcy5maXhVcmwoZnJhZ21lbnQsICdpbWcnLCAnc3JjJyk7XG4gICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnZml4TGlua3MnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBmaXhMaW5rcygpIHtcbiAgICAgIHZhciBmcmFnbWVudCA9IGFyZ3VtZW50cy5sZW5ndGggPD0gMCB8fCBhcmd1bWVudHNbMF0gPT09IHVuZGVmaW5lZCA/IG51bGwgOiBhcmd1bWVudHNbMF07XG5cbiAgICAgIHRoaXMuZml4VXJsKGZyYWdtZW50LCAnYScsICdocmVmJyk7XG4gICAgICByZXR1cm4gZnJhZ21lbnQ7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnZml4VXJsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZml4VXJsKGZyYWdtZW50LCB0YWcsIGF0dHIpIHtcbiAgICAgIGlmIChmcmFnbWVudCA9PT0gdW5kZWZpbmVkKSBmcmFnbWVudCA9IG51bGw7XG5cbiAgICAgIHZhciBfdGhpczQgPSB0aGlzO1xuXG4gICAgICB2YXIgZWxlbWVudHMgPSB7fTtcbiAgICAgIGlmIChmcmFnbWVudCkge1xuICAgICAgICBlbGVtZW50cyA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3JBbGwodGFnKTtcbiAgICAgIH1cbiAgICAgIHZhciBwYXJzZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICBlbGVtZW50cy5mb3JFYWNoKGZ1bmN0aW9uIChlbCkge1xuICAgICAgICBwYXJzZXIuaHJlZiA9IGVsW2F0dHJdO1xuICAgICAgICBwYXJzZXIuaG9zdCA9IF90aGlzNC5ob3N0O1xuICAgICAgICBwYXJzZXIucHJvdG9jb2wgPSBfdGhpczQucHJvdG9jb2w7XG4gICAgICAgIC8vIGZpeCByZWxhdGl2ZSBsaW5rc1xuICAgICAgICBpZiAodGFnID09ICdhJykge1xuICAgICAgICAgIGVsLmNsYXNzTGlzdC5hZGQoJ210dF9saW5rJyk7XG4gICAgICAgICAgaWYgKHBhcnNlci5wYXRobmFtZS5pbmRleE9mKCdtLmV4ZScpICE9PSAtMSkge1xuICAgICAgICAgICAgcGFyc2VyLnBhdGhuYW1lID0gJy9jJyArIHBhcnNlci5wYXRobmFtZTtcbiAgICAgICAgICAgIGVsLnNldEF0dHJpYnV0ZSgndGFyZ2V0JywgJ19ibGFuaycpO1xuICAgICAgICAgICAgZWwuc2V0QXR0cmlidXRlKGF0dHIsIHBhcnNlci5ocmVmKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAodGFnID09ICdpbWcnKSB7XG4gICAgICAgICAgdmFyIHVybCA9IF90aGlzNC5nZXRVcmwoZWwuc3JjKTtcbiAgICAgICAgICBlbC5jbGFzc0xpc3QuYWRkKCdtdHRfaW1nJyk7XG4gICAgICAgICAgZWwuc3JjID0gX3RoaXM0LnByb3RvY29sICsgJzovLycgKyBfdGhpczQuaG9zdCArICcvJyArIHVybC5wYXRobmFtZTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gdG9kbzogbW92ZSB0byB1dGlsc1xuICB9LCB7XG4gICAga2V5OiAnZ2V0VXJsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZ2V0VXJsKHVybCkge1xuICAgICAgdmFyIGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICBhLmhyZWYgPSB1cmw7XG4gICAgICByZXR1cm4gYTtcbiAgICB9XG4gIH1dKTtcblxuICByZXR1cm4gVHJhbjtcbn0pKCk7XG5cbm1vZHVsZS5leHBvcnRzID0gbmV3IFRyYW4oKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXRyYW4uanMubWFwXG4iLCIvKlxuICBUcmFuc2xhdGlvbiBlbmdpbmU6IGh0dHA6Ly93d3cudHVya2lzaGRpY3Rpb25hcnkubmV0XG4gIEZvciB0cmFuc2xhdGluZyB0dXJraXNoLXJ1c3NpYW4gYW5kIHZpY2UgdmVyc2FcbiovXG4ndXNlIHN0cmljdCc7XG5cbnZhciBfY3JlYXRlQ2xhc3MgPSAoZnVuY3Rpb24gKCkgeyBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0aWVzKHRhcmdldCwgcHJvcHMpIHsgZm9yICh2YXIgaSA9IDA7IGkgPCBwcm9wcy5sZW5ndGg7IGkrKykgeyB2YXIgZGVzY3JpcHRvciA9IHByb3BzW2ldOyBkZXNjcmlwdG9yLmVudW1lcmFibGUgPSBkZXNjcmlwdG9yLmVudW1lcmFibGUgfHwgZmFsc2U7IGRlc2NyaXB0b3IuY29uZmlndXJhYmxlID0gdHJ1ZTsgaWYgKCd2YWx1ZScgaW4gZGVzY3JpcHRvcikgZGVzY3JpcHRvci53cml0YWJsZSA9IHRydWU7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGRlc2NyaXB0b3Iua2V5LCBkZXNjcmlwdG9yKTsgfSB9IHJldHVybiBmdW5jdGlvbiAoQ29uc3RydWN0b3IsIHByb3RvUHJvcHMsIHN0YXRpY1Byb3BzKSB7IGlmIChwcm90b1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLnByb3RvdHlwZSwgcHJvdG9Qcm9wcyk7IGlmIChzdGF0aWNQcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvciwgc3RhdGljUHJvcHMpOyByZXR1cm4gQ29uc3RydWN0b3I7IH07IH0pKCk7XG5cbmZ1bmN0aW9uIF9jbGFzc0NhbGxDaGVjayhpbnN0YW5jZSwgQ29uc3RydWN0b3IpIHsgaWYgKCEoaW5zdGFuY2UgaW5zdGFuY2VvZiBDb25zdHJ1Y3RvcikpIHsgdGhyb3cgbmV3IFR5cGVFcnJvcignQ2Fubm90IGNhbGwgYSBjbGFzcyBhcyBhIGZ1bmN0aW9uJyk7IH0gfVxuXG52YXIgQ0hBUl9DT0RFUyA9IHJlcXVpcmUoJy4vY2hhci1jb2Rlcy10dXJrLmpzJyk7XG5cbnZhciBUdXJraXNoRGljdGlvbmFyeSA9IChmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIFR1cmtpc2hEaWN0aW9uYXJ5KCkge1xuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBUdXJraXNoRGljdGlvbmFyeSk7XG5cbiAgICB0aGlzLmhvc3QgPSAnaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXQvP3dvcmQ9JUZDJztcbiAgICB0aGlzLnBhdGggPSAnJztcbiAgICB0aGlzLnByb3RvY29sID0gJ2h0dHAnO1xuICAgIHRoaXMucXVlcnkgPSAnJnM9JztcbiAgICB0aGlzLlRBQkxFX0NMQVNTID0gJ19fX210dF90cmFuc2xhdGVfdGFibGUnO1xuICAgIC8vIHRoaXMgZmxhZyBpbmRpY2F0ZXMgdGhhdCBpZiB0cmFuc2xhdGlvbiB3YXMgc3VjY2Vzc2Z1bCB0aGVuIHB1Ymxpc2ggaXQgYWxsIG92ZXIgZXh0ZW5zaW9uXG4gICAgdGhpcy5uZWVkX3B1Ymxpc2ggPSB0cnVlO1xuICB9XG5cbiAgLy8gU2luZ2xldG9uZVxuXG4gIF9jcmVhdGVDbGFzcyhUdXJraXNoRGljdGlvbmFyeSwgW3tcbiAgICBrZXk6ICdzZWFyY2gnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzZWFyY2goZGF0YSkge1xuICAgICAgZGF0YS51cmwgPSB0aGlzLm1ha2VVcmwoZGF0YS52YWx1ZSk7XG4gICAgICB0aGlzLm5lZWRfcHVibGlzaCA9IGZhbHNlO1xuICAgICAgcmV0dXJuIHRoaXMucmVxdWVzdChkYXRhKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICd0cmFuc2xhdGUnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiB0cmFuc2xhdGUoZGF0YSkge1xuICAgICAgZGF0YS51cmwgPSB0aGlzLm1ha2VVcmwoZGF0YS5zZWxlY3Rpb25UZXh0KTtcbiAgICAgIHRoaXMubmVlZF9wdWJsaXNoID0gdHJ1ZTtcbiAgICAgIHRoaXMucmVxdWVzdChkYXRhKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdtYWtlVXJsJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZVVybCh0ZXh0KSB7XG4gICAgICB2YXIgdGV4dCA9IHRoaXMuZ2V0RW5jb2RlZFZhbHVlKHRleHQpO1xuICAgICAgcmV0dXJuIFsnaHR0cDovL3d3dy50dXJraXNoZGljdGlvbmFyeS5uZXQvP3dvcmQ9JywgdGV4dF0uam9pbignJyk7XG4gICAgfVxuXG4gICAgLy8gUmVwbGFjZSBzcGVjaWFsIGxhbmd1YWdlIGNoYXJhY3RlcnMgdG8gaHRtbCBjb2Rlc1xuICB9LCB7XG4gICAga2V5OiAnZ2V0RW5jb2RlZFZhbHVlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZ2V0RW5jb2RlZFZhbHVlKHZhbHVlKSB7XG4gICAgICAvLyB0byBmaW5kIHNwZWMgc3ltYm9scyB3ZSBmaXJzdCBlbmNvZGUgdGhlbSAocmF3IHNlYXJjaCBmb3IgdGhhdCBzeW1ib2wgZG9lc24ndCB3b3IpXG4gICAgICByZXR1cm4gZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcbiAgICAgIC8vcmV0dXJuIHRoaXMubWFrZVN0cmluZ1RyYW5zZmVyYWJsZSh2YWx1ZSk7XG4gICAgfVxuXG4gICAgLyoqIGNvbnZlcnRpbmcgc2NyaXB0IGZyb20gdGhlIHR1cmtpc2hkaWN0ICovXG4gIH0sIHtcbiAgICBrZXk6ICdtYWtlU3RyaW5nVHJhbnNmZXJhYmxlJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gbWFrZVN0cmluZ1RyYW5zZmVyYWJsZShpbnB1dFRleHQpIHtcbiAgICAgIHZhciB0ZXh0ID0gXCJcIjtcbiAgICAgIGlmIChpbnB1dFRleHQubGVuZ3RoID4gMCkge1xuICAgICAgICB0ZXh0ID0gaW5wdXRUZXh0O1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRleHQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBpZiAoQ0hBUl9DT0RFU1t0ZXh0LmNoYXJDb2RlQXQoaSldKSB7XG4gICAgICAgICAgICB0ZXh0ID0gdGV4dC5zdWJzdHJpbmcoMCwgaSkgKyBDSEFSX0NPREVTW3RleHQuY2hhckNvZGVBdChpKV0gKyB0ZXh0LnN1YnN0cmluZyhpICsgMSwgdGV4dC5sZW5ndGgpO1xuICAgICAgICAgIH0gZWxzZSBpZiAodGV4dC5jaGFyQXQoaSkgPT0gJyAnKSB7XG4gICAgICAgICAgICAvLyByZXBsYWNlIHNwYWNlc1xuICAgICAgICAgICAgdGV4dCA9IHRleHQuc3Vic3RyaW5nKDAsIGkpICsgJ19fXycgKyB0ZXh0LnN1YnN0cmluZyhpICsgMSwgdGV4dC5sZW5ndGgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRleHQ7XG4gICAgfVxuXG4gICAgLypcbiAgICAgIFJlcXVlc3QgdHJhbnNsYXRpb24gYW5kIHJ1biBjYWxsYmFjayBmdW5jdGlvblxuICAgICAgcGFzc2luZyB0cmFuc2xhdGVkIHJlc3VsdCBvciBlcnJvciB0byBjYWxsYmFja1xuICAgICovXG4gIH0sIHtcbiAgICBrZXk6ICdyZXF1ZXN0JyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gcmVxdWVzdChvcHRzKSB7XG4gICAgICBjb25zb2xlLmxvZygnc3RhcnQgcmVxdWVzdCcpO1xuICAgICAgdGhpcy54aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgIHRoaXMueGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IHRoaXMub25SZWFkeVN0YXRlQ2hhbmdlLmJpbmQodGhpcywgb3B0cyk7XG4gICAgICB0aGlzLnhoci5vcGVuKFwiR0VUXCIsIG9wdHMudXJsLCB0cnVlKTtcbiAgICAgIHRoaXMueGhyLnNlbmQoKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdvblJlYWR5U3RhdGVDaGFuZ2UnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBvblJlYWR5U3RhdGVDaGFuZ2Uob3B0cywgZSkge1xuICAgICAgdmFyIHhociA9IHRoaXMueGhyO1xuICAgICAgaWYgKHhoci5yZWFkeVN0YXRlIDwgNCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9IGVsc2UgaWYgKHhoci5zdGF0dXMgIT0gMjAwKSB7XG4gICAgICAgIHRoaXMuZXJyb3JIYW5kbGVyKHhocik7XG4gICAgICAgIHJldHVybiBvcHRzLmVycm9yICYmIG9wdHMuZXJyb3IoKTtcbiAgICAgIH0gZWxzZSBpZiAoeGhyLnJlYWR5U3RhdGUgPT0gNCkge1xuICAgICAgICB2YXIgdHJhbnNsYXRpb24gPSB0aGlzLnN1Y2Nlc3NIYW5kbGVyKGUudGFyZ2V0LnJlc3BvbnNlKTtcbiAgICAgICAgY29uc29sZS5sb2coJ3N1Y2Nlc3MgdHVya2lzaCB0cmFuc2xhdGUnLCB0cmFuc2xhdGlvbik7XG4gICAgICAgIGNvbnNvbGUubG9nKCdjYWxsJywgb3B0cy5zdWNjZXNzKTtcbiAgICAgICAgcmV0dXJuIG9wdHMuc3VjY2VzcyAmJiBvcHRzLnN1Y2Nlc3ModHJhbnNsYXRpb24pO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3N1Y2Nlc3NIYW5kbGVyJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gc3VjY2Vzc0hhbmRsZXIocmVzcG9uc2UpIHtcbiAgICAgIHZhciBkYXRhID0gdGhpcy5wYXJzZShyZXNwb25zZSk7XG4gICAgICBpZiAodGhpcy5uZWVkX3B1Ymxpc2gpIHtcbiAgICAgICAgY2hyb21lLnRhYnMuZ2V0U2VsZWN0ZWQobnVsbCwgdGhpcy5wdWJsaXNoVHJhbnNsYXRpb24uYmluZCh0aGlzLCBkYXRhKSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZGF0YTtcbiAgICB9XG5cbiAgICAvKiBwdWJsaXNoIHN1Y2Nlc3NmdWx5IHRyYW5zbGF0ZWQgdGV4dCBhbGwgb3ZlciBleHRlbnNpb24gKi9cbiAgfSwge1xuICAgIGtleTogJ3B1Ymxpc2hUcmFuc2xhdGlvbicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHB1Ymxpc2hUcmFuc2xhdGlvbih0cmFuc2xhdGlvbiwgdGFiKSB7XG4gICAgICBjb25zb2xlLmxvZygncHVibGlzaCB0cmFuc2xhdGlvbicpO1xuICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgIGFjdGlvbjogdGhpcy50b29sdGlwQWN0aW9uKHRyYW5zbGF0aW9uKSxcbiAgICAgICAgZGF0YTogdHJhbnNsYXRpb24ub3V0ZXJIVE1MLFxuICAgICAgICBzdWNjZXNzOiAhdHJhbnNsYXRpb24uY2xhc3NMaXN0LmNvbnRhaW5zKCdmYWlsVHJhbnNsYXRlJylcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3Rvb2x0aXBBY3Rpb24nLFxuICAgIHZhbHVlOiBmdW5jdGlvbiB0b29sdGlwQWN0aW9uKHRyYW5zbGF0aW9uKSB7XG4gICAgICBpZiAodHJhbnNsYXRpb24udGV4dENvbnRlbnQudHJpbSgpLmluZGV4T2YoJ3dhcyBub3QgZm91bmQgaW4gb3VyIGRpY3Rpb25hcnknKSAhPSAtMSkge1xuICAgICAgICBjb25zb2xlLmxvZygnc2ltaWxhciB3b3JkcycpO1xuICAgICAgICByZXR1cm4gJ3NpbWlsYXJfd29yZHMnO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coJ29wZW4gdG9vbHRpcCcpO1xuICAgICAgICByZXR1cm4gJ29wZW5fdG9vbHRpcCc7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnZXJyb3JIYW5kbGVyJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gZXJyb3JIYW5kbGVyKHJlc3BvbnNlKSB7XG4gICAgICBjb25zb2xlLmxvZygnZXJyb3IgYWpheCcsIHJlc3BvbnNlKTtcbiAgICB9XG5cbiAgICAvKiBQYXJzZSByZXNwb25zZSBmcm9tIHRyYW5zbGF0aW9uIGVuZ2luZSAqL1xuICB9LCB7XG4gICAga2V5OiAncGFyc2UnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBwYXJzZShyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUpIHtcbiAgICAgIHZhciBkb2MgPSB0aGlzLnN0cmlwU2NyaXB0cyhyZXNwb25zZSksXG4gICAgICAgICAgZnJhZ21lbnQgPSB0aGlzLm1ha2VGcmFnbWVudChkb2MpO1xuICAgICAgaWYgKGZyYWdtZW50KSB7XG4gICAgICAgIHRyYW5zbGF0ZSA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3IoJyNtZWFuaW5nX2RpdiA+IHRhYmxlJyk7XG4gICAgICAgIGlmICh0cmFuc2xhdGUpIHtcbiAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gdGhpcy5UQUJMRV9DTEFTUztcbiAgICAgICAgICB0cmFuc2xhdGUuc2V0QXR0cmlidXRlKFwiY2VsbHBhZGRpbmdcIiwgXCI1XCIpO1xuICAgICAgICAgIC8vIEBmaXhJbWFnZXModHJhbnNsYXRlKVxuICAgICAgICAgIC8vIEBmaXhMaW5rcyh0cmFuc2xhdGUpXG4gICAgICAgIH0gZWxzZSBpZiAoIXNpbGVudCkge1xuICAgICAgICAgICAgdHJhbnNsYXRlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICAgICAgICB0cmFuc2xhdGUuY2xhc3NOYW1lID0gJ2ZhaWxUcmFuc2xhdGUnO1xuICAgICAgICAgICAgdHJhbnNsYXRlLmlubmVyVGV4dCA9IFwiVW5mb3J0dW5hdGVseSwgY291bGQgbm90IHRyYW5zbGF0ZVwiO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiB0cmFuc2xhdGU7XG4gICAgfVxuXG4gICAgLyoqIHBhcnNpbmcgb2YgdGVycmlibGUgaHRtbCBtYXJrdXAgKi9cbiAgfSwge1xuICAgIGtleTogJ3BhcnNlVGV4dCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHBhcnNlVGV4dChyZXNwb25zZSwgc2lsZW50LCB0cmFuc2xhdGUpIHtcbiAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAgIHZhciBkb2MgPSB0aGlzLnN0cmlwU2NyaXB0cyhyZXNwb25zZSksXG4gICAgICAgICAgZnJhZ21lbnQgPSB0aGlzLm1ha2VGcmFnbWVudChkb2MpO1xuXG4gICAgICBpZiAoZnJhZ21lbnQpIHtcbiAgICAgICAgdmFyIGk7XG5cbiAgICAgICAgdmFyIF9yZXQgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHZhciBzdG9wSW5kZXggPSBudWxsO1xuICAgICAgICAgIHZhciB0ciA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJyNtZWFuaW5nX2Rpdj50YWJsZT50Ym9keT50cicpO1xuICAgICAgICAgIHRyID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwodHIpO1xuXG4gICAgICAgICAgdmFyIHRyYW5zID0gdHIuZmlsdGVyKGZ1bmN0aW9uICh0ciwgaW5kZXgpIHtcbiAgICAgICAgICAgIGlmICghaXNOYU4ocGFyc2VJbnQoc3RvcEluZGV4LCAxMCkpICYmIGluZGV4ID49IHN0b3BJbmRleCkge1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB0ciA9ICQodHIpO1xuICAgICAgICAgICAgICAvLyB0YWtlIGV2ZXJ5IHJvdyBiZWZvcmUgbmV4dCBzZWN0aW9uICh3aGljaCBpcyBFbmdsaXNoLT5FbmdsaXNoKVxuICAgICAgICAgICAgICBpZiAodHIuYXR0cignYmdjb2xvcicpID09IFwiZTBlNmZmXCIpIHtcbiAgICAgICAgICAgICAgICBzdG9wSW5kZXggPSBpbmRleDtyZXR1cm47XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuICQudHJpbSh0ci5maW5kKCd0ZCcpLnRleHQoKSkubGVuZ3RoO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgdHJhbnMgPSB0cmFucy5zbGljZSgxLCB0cmFucy5sZW5ndGggLSAxKTtcbiAgICAgICAgICB0cmFucyA9IHRyYW5zLmZpbHRlcihmdW5jdGlvbiAoZWwsIGluZHgpIHtcbiAgICAgICAgICAgIHJldHVybiBpbmR4ICUgMjtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICB2YXIgZnJhZyA9IF90aGlzLmZyYWdtZW50RnJvbUxpc3QodHJhbnMpO1xuICAgICAgICAgIHZhciBmb250cyA9IGZyYWcucXVlcnlTZWxlY3RvckFsbCgnZm9udCcpO1xuICAgICAgICAgIHZhciB0ZXh0ID0gJyc7XG4gICAgICAgICAgZm9yIChpID0gMDsgaSA8IGZvbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICB0ZXh0ICs9ICcgJyArIGZvbnRzW2ldLnRleHRDb250ZW50LnRyaW0oKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHY6IHRleHRcbiAgICAgICAgICB9O1xuICAgICAgICB9KSgpO1xuXG4gICAgICAgIGlmICh0eXBlb2YgX3JldCA9PT0gJ29iamVjdCcpIHJldHVybiBfcmV0LnY7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBcIkhUTUwgZnJhZ21lbnQgY291bGQgbm90IGJlIHBhcnNlZFwiO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vVE9ETyBleHRyYWN0IHRvIGJhc2UgZW5naW5lIGNsYXNzXG4gICAgLyogcmVtb3ZlcyA8c2NyaXB0PiB0YWdzIGZyb20gaHRtbCBjb2RlICovXG4gIH0sIHtcbiAgICBrZXk6ICdzdHJpcFNjcmlwdHMnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzdHJpcFNjcmlwdHMoaHRtbCkge1xuICAgICAgdmFyIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgZGl2LmlubmVySFRNTCA9IGh0bWw7XG4gICAgICB2YXIgc2NyaXB0cyA9IGRpdi5nZXRFbGVtZW50c0J5VGFnTmFtZSgnc2NyaXB0Jyk7XG4gICAgICB2YXIgaSA9IHNjcmlwdHMubGVuZ3RoO1xuICAgICAgd2hpbGUgKGktLSkgc2NyaXB0c1tpXS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHNjcmlwdHNbaV0pO1xuICAgICAgcmV0dXJuIGRpdi5pbm5lckhUTUw7XG4gICAgfVxuXG4gICAgLy9UT0RPIGV4dHJhY3QgdG8gYmFzZSBlbmdpbmUgY2xhc3NcbiAgICAvKiBjcmVhdGVzIHRlbXAgb2JqZWN0IHRvIHBhcnNlIHRyYW5zbGF0aW9uIGZyb20gcGFnZSBcbiAgICAgIChzaW5jZSBpdCdzIG5vdCBhIGZyaWVuZGx5IGFwaSkgXG4gICAgKi9cbiAgfSwge1xuICAgIGtleTogJ21ha2VGcmFnbWVudCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG1ha2VGcmFnbWVudChodG1sKSB7XG4gICAgICB2YXIgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCksXG4gICAgICAgICAgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgIGRpdi5pbm5lckhUTUwgPSBodG1sO1xuICAgICAgd2hpbGUgKGRpdi5maXJzdENoaWxkKSB7XG4gICAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKGRpdi5maXJzdENoaWxkKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmcmFnbWVudDtcbiAgICB9XG5cbiAgICAvKiogY3JlYXRlIGZyYWdtZW50IGZyb20gbGlzdCBvZiBET00gZWxlbWVudHMgKi9cbiAgfSwge1xuICAgIGtleTogJ2ZyYWdtZW50RnJvbUxpc3QnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBmcmFnbWVudEZyb21MaXN0KGxpc3QpIHtcbiAgICAgIHZhciBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKSxcbiAgICAgICAgICBsZW4gPSBsaXN0Lmxlbmd0aDtcbiAgICAgIHdoaWxlIChsZW4tLSkge1xuICAgICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZChsaXN0W2xlbl0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZyYWdtZW50O1xuICAgIH1cbiAgfV0pO1xuXG4gIHJldHVybiBUdXJraXNoRGljdGlvbmFyeTtcbn0pKCk7XG5cbm1vZHVsZS5leHBvcnRzID0gbmV3IFR1cmtpc2hEaWN0aW9uYXJ5KCk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD10dXJraXNoZGljdGlvbmFyeS5qcy5tYXBcbiJdfQ==
